"""Emit C's v3 verdicts after whole-source and all-focus reinspection.

Only current neutral inventories and this auditor's own v2 derivations are used.
No old verdict is used as mathematical evidence; current classifications were
determined after rereading all 951 lines and all 861 child focuses.
"""
from pathlib import Path
from collections import Counter
import hashlib
import json
import re

ROOT = Path('/workspace/scratch/de6aed6f6a22')
OUT = ROOT / 'audit_v3'
source = (OUT / 'proof.tex').read_bytes()
ib = (OUT / 'audit_inventory.json').read_bytes()
inv = json.loads(ib)
oldinv = json.loads((ROOT / 'audit_v2/audit_inventory.json').read_bytes())
ownold = json.loads((ROOT / 'audit_v2/pass_c.json').read_bytes())
oldrecords = {r['id']: r for r in ownold['records']}
oldparents = {s['id']: s for s in oldinv['containers']}
sha = hashlib.sha256(source).hexdigest()
isha = hashlib.sha256(ib).hexdigest()
assert sha == '8743ce99900bfb3df37bb4ccdae9aa9269cff12fc0a6abff7e4989a4eb426230'
assert isha == '312e27c6941704d244f102a3907c290d82db5d41e68208e88b592b68d32adce7'

reasons = {s: r['rationale'] for s, r in oldrecords.items()}
reasons.update({
    'S0054': 'The published primary article, exact numbering, Theorem 2.2, Assumptions 2.1/3.1, Definition 3.2, Theorem 3.3 and the relevant existence-proof steps were freshly inspected. The current citation identifies the required finite-p bounded-vorticity input; no unavailable source remains.',
    'S0055': 'Fresh primary-source matching gives the signed L1 intersect Linfty data class, global Lagrangian solution, a.e.-time canonical velocity, L1 nonincrease, horizon Linfty bounds and log-Lipschitz modulus. The full Assumption 3.1 domain is verified at p=3 using Theorem 2.2 with q=1; the bounded densities in the existence proof belong to it. No compact support, positive sign or finite energy is required.',
    'S0058': 'Direct norm calculation gives |K(z)|=(2pi|z|)^-1, and inversion in the plane gives the exact stated difference identity. Distributionally Div K=0, so Fubini against compact test gradients gives Div(K*omega)=0 for every omega in the entire L1 intersect L3_ul domain. The original Assumption 3.1 map was inspected, including its displayed formula: at p=3 its domain is L1 intersect L3_ul and its range C_b^(0,1/3). Theorem 2.2 supplies precisely that full-domain bounded map with q=1, p=3. The boundary condition is empty on R2. Theorem 3.3 uses this divergence hypothesis on bounded densities, all lying in that domain since ||omega||L3_ul<=pi^(1/3)||omega||infty. Its log-Lipschitz conclusion is provided separately by the bounded-vorticity estimate, not by asserting that a fixed 1/3-Holder modulus is Osgood.',
    'S0060': 'The current full-domain finite-p verification of E1 supplies its bounded-vorticity background without an endpoint Lipschitz assertion. The flow representative, near/far estimate, weak-L2 layer-cake bound and zero-order relative-velocity multiplier in the following proof establish the stated every-time horizon bounds and C_t L2 difference. All these downstream steps were reread and retain their hypotheses.',
    'S0062': 'nu0=a*mu is signed L1 intersect Linfty and therefore belongs to L1 intersect L3_ul. The whole-plane kernel satisfies Assumption 2.1 and, by Theorem 2.2 with q=1,p=3, the entire domain/range and zero-divergence requirements of Assumption 3.1. Theorem 3.3 yields exactly the canonical a.e.-time bounded-vorticity Lagrangian background used here.',
    'S0229': 'For |x|>1 the function y -> G(x-y) is harmonic on the entire closed disk containing the support of U1. Its average on each centered circle of radius rho<1 is G(x). Integrating those averages against the radial probability density proves G*U1=G exactly, with no additive constant. U1(x)=0 there, so Z1,xi=-D^2G(x)xi, whose explicit Hessian is O(|x|^-2). A hole in an annular bump would invalidate equality merely outside the support, but is excluded by the current explicit |x|>1 condition.',
    'S0230': 'The already checked core bound applies on the entire unit disk, including possible holes in a radial bump; S0229 gives the tail only for |x|>1, which is all that is needed. The integral of r^(1-2p) at infinity converges exactly for p>1, while the bounded core has finite measure. Thus every asserted Lp norm is finite without an equality inside a support hole.',
    'S0237': 'Minkowski over an interval of length at most tau bounds both the source primitive and the primitive of its whole-cycle average. The now-verified unit-disk core/exterior argument and fixed-profile dilation give ||Z_H||2=C/H and ||Z_H||3/2=C H^-2/3. Curl removes the gradient and ||grad U_H||1=C/H. Multiplication by the coefficient bound B gives all three displayed estimates, with no row-count factor.',
    'S0306': 'With tau=H_k^6, the current fixed-profile Q estimates yield H_k^(6-1)=H_k^5 in L2 and curl L1 and H_k^(6-2/3)=H_k^(16/3) in L3/2. The coefficient bound is independent of sufficiently large N_k at fixed coarse data. The revised exterior condition still supplies all unit-profile norms needed here.',
    'S0362': 'A nonnegative smooth compact cutoff in (1/2,2) can be chosen identically one on the closed interval [3/4,3/2]. For every t>0, let j=floor(log2(4t/3)); then t/2^j lies in [3/4,3/2), so eta(t/2^j)=1 and the denominator is at least one. Only finitely many dyadic terms are nonzero near each positive t, because eta is supported in a compact subinterval of (1/2,2). Thus the displayed quotients are well-defined smooth functions with the stated interval indexing, including plateau endpoints.',
    'S0363': 'The explicit plateau from S0362 gives a strictly positive denominator, at least one, at every positive time. Local finiteness permits summing the smooth nonnegative quotients to exactly one. Each numerator has support 2^j supp eta compactly contained in I_j, and division by the positive denominator does not enlarge it. This verifies the partition and support properties needed by every subsequent patch operation.',
    'S0380': 'At a fixed positive time only finitely many patch corrections/errors are present. Successively applying the prescribed-piece identity gives u^(q+1)=u^(q)+sum_j w_qj and R^(q+1)=R^(q)-sum_j chi_j R^(q)+sum_j E_qj. The current verified positive dyadic partition sums to one, so the original stress cancels exactly, including separately assigned boundary values. This proves both displayed stage identities.',
    'S0415': 'The current global iteration uses the positively defined partition and unchanged local repair estimates with the now-explicit full-domain background input. Geometric L2/curl summability, anchor traces and the initial cutoff argument prove the claimed global velocity, exact initial formulation and every-time finite-measure curl with horizon variation bound. No changed hypothesis invalidates the proposition invoked here.',
})

new_child_reasons = {
    'S0058.C01': 'The Euclidean norm of (-z2,z1) is |z|, so the displayed kernel norm is exactly (2pi|z|)^-1 for z nonzero.',
    'S0058.C02': 'Squaring |z/|z|^2-w/|w|^2| gives |z-w|^2/(|z|^2|w|^2). Rotation preserves norm; division by 2pi gives the stated identity for nonzero z,w, and hence the kernel difference hypothesis.',
    'S0058.C03': 'The explicit kernel is divergence-free off zero and tangent to each circle, so its distributional divergence is also zero. For every omega in L1 intersect L3_ul, the uniform translated-ball integrability bound permits Fubini against compact test gradients and proves Div(K*omega)=0 on the entire required domain.',
    'S0058.C04': 'The original Assumption 3.1 permits a fixed p in (2,infinity]; p=3 lies in that range. Its displayed map is then K:L1 intersect L3_ul -> C_b^(0,1/3). The bounded-vorticity existence proof invokes the divergence/no-boundary hypothesis only on densities belonging to this domain, so it does not require the invalid Lipschitz endpoint.',
    'S0058.C05': 'Theorem 2.2 is stated for q in [1,2), p in (2,infinity), and omega in Lq intersect Lp_ul, with bounded velocity and Holder exponent 1-2/p. Setting q=1 and p=3 gives the exact full domain L1 intersect L3_ul and range C_b^(0,1/3) appearing in Assumption 3.1. The near kernel L3/2 norm and the intermediate difference-kernel norm scale d^(1/3), while the far contribution is bounded by the L1 norm, independently confirming that mapping.',
    'S0058.C06': 'For every unit ball B1(x), ||omega||L3(B1(x)) <= |B1|^(1/3)||omega||infty = pi^(1/3)||omega||infty. Taking the supremum over centers gives the uniform-local norm bound. The theorem supplies the finite-horizon Linfty bound on the time-stepped and limiting vorticities, so the same implication is uniform in the relevant times and approximants.',
    'S0229.C01': reasons['S0229'],
    'S0229.C02': 'Radiality permits disintegration into centered circle averages. The probability normalization makes the weighted average of their common harmonic mean G(x) equal to G(x), with no extra constant.',
    'S0229.C03': 'On |x|>1 the bump itself is zero and G*U1=G holds on an open region, so differentiating twice gives D^2G*U1=D^2G there. Substitution into the definition of Z yields precisely -D^2G xi.',
    'S0229.C04': 'D^2G(x)=(2pi)^-1(I/|x|^2-2 x tensor x/|x|^4), whose norm is bounded by C|x|^-2. The unit direction xi introduces no additional scale.',
    'S0229.C05': 'The stipulated |x|>1 lies outside the entire support disk, so y -> G(x-y) is harmonic for every |y|<1. This excludes the annular-bump central-hole counterexample, where being outside the support alone would not ensure the asserted potential equality.',
    'S0362.C01': reasons['S0362'],
    'S0362.C02': 'A standard smooth cutoff equal to one on [3/4,3/2] and zero near both endpoints of (1/2,2) can be chosen between zero and one. Nonnegativity makes the normalized partition nonnegative.',
    'S0362.C03': 'I_j is the dilation 2^j(1/2,2)=(2^(j-1),2^(j+1)), precisely the open interval enclosing the numerator support.',
    'S0362.C04': 'For every t>0 the denominator is a finite local sum and at least one term equals one. Thus division is valid; smoothness and nonnegativity are preserved, and summing the displayed quotients gives one.',
    'S0362.C05': 'The compact interval [3/4,3/2] lies strictly inside (1/2,2), so such a smooth unit plateau exists. The endpoints are included; adjacent plateau dilates meet, ensuring no uncovered boundary ratio.',
    'S0362.C06': 'For t>0, take j=floor(log2(4t/3)). Then 2^j <= 4t/3 < 2^(j+1), hence 3/4 <= t/2^j < 3/2. This is a positivity interval with eta=1, so every positive t is covered and the denominator is uniformly at least one.',
}

def dependency_review(sid):
    n=int(sid[1:])
    if 54<=n<=114:
        return 'Current external input and its full-domain p=3 verification rechecked; background representative, relative L2, pressure and seed consequences retain their hypotheses.'
    if 229<=n<=349:
        return 'Current exterior-disk estimate and core bound rechecked; fixed-profile norms, Q estimates and every LER parameter/pasting dependency retain their hypotheses.'
    if 362<=n<=418:
        return 'Current positive dyadic partition rechecked; finite overlap, stress telescoping, anchors, uniform series and every-time target closure retain their hypotheses.'
    return 'Current full source and exact focus reread; definitions, hypotheses and unchanged upstream derivations rechecked in the current argument.'

records=[]; children_count=0; identical=0; next_byte=0
scaffolds=set(inv['scaffolding_only_child_ids'])
for s in inv['containers']:
    assert s['byte_start']==next_byte
    b=source[s['byte_start']:s['byte_end_exclusive']]
    assert b.decode()==s['text'] and hashlib.sha256(b).hexdigest()==s['sha256']
    next_byte=s['byte_end_exclusive']
    same=oldparents[s['id']]['sha256']==s['sha256']; identical+=same
    oldchild={c['id']:c for c in oldrecords[s['id']]['nested_checks']}
    changed_parent=s['id'] in {'S0058','S0229','S0362'}
    status='VERIFIED' if s['mathematical'] else 'NOT MATHEMATICAL'
    children=[]
    for c in s['nested_checks']:
        cb=source[c['byte_start']:c['byte_end_exclusive']]
        assert cb.decode()==c['text'] and hashlib.sha256(cb).hexdigest()==c['sha256']
        nm=c['id'] in scaffolds
        if c['id'] in new_child_reasons:
            why=new_child_reasons[c['id']]
        elif s['id'] in reasons and reasons[s['id']]!=oldrecords[s['id']]['rationale']:
            why='Current focus checked with all parent hypotheses. '+reasons[s['id']]
        else:
            assert c['id'] in oldchild and c['sha256']==oldchild[c['id']]['source_sha256']
            why=oldchild[c['id']]['rationale']
        children.append({'id':c['id'],'source_sha256':c['sha256'],
            'status':'NOT MATHEMATICAL' if nm else status,'rationale':why,
            'line_start':c['line_start'],'line_end':c['line_end'],
            'exact_source_anchor':c['text'],'scope':'Entire current v3 parent '+s['id'],
            'checked_in_revision':'v3','current_source_reinspection':True,
            'dependency_review':dependency_review(s['id'])})
        children_count+=1
    records.append({'id':s['id'],'source_sha256':s['sha256'],'status':status,
        'rationale':reasons[s['id']],'nested_checks':children,'supplemental_checks':[],
        'filename':s['filename'],'original_filename':s['original_filename'],
        'line_start':s['line_start'],'line_end':s['line_end'],
        'exact_source_anchor':s['text'],'container_mode':s['mode'],
        'mathematical':s['mathematical'],'checked_in_revision':'v3',
        'current_source_reinspection':True,'identical_parent_bytes_to_v2':same,
        'dependency_review':dependency_review(s['id'])})
assert next_byte==len(source) and len(records)==419 and children_count==861 and identical==416

meta=dict(ownold['metadata'])
meta.update({'revision':'v3','source_sha256':sha,'inventory_sha256':isha,
    'source_lines_checked':[1,951],'source_bytes_checked':45329,'nested_checks':861,
    'formula_occurrences_checked':584,'inline_formula_occurrences_checked':525,
    'external_theorem_containers_checked':23,
    'mode':'independent adversarial and edge-case audit renewed over the entire frozen v3 source',
    'independence':'Read current source, all current parent/child focuses, target and neutral inventory/formula/notation files; inspected original primary theorem including Assumption 3.1 mapping image. No other auditor output, verdict communication, reconciliation, route conclusion or source-change manifest was inspected. An agent assigned solely within C independently checked the same primary-source map and current background claims.',
    'derivation_provenance':'Reread all 951 current source lines and 861 current child focuses. All 419 parents underwent source identity and dependency review. Exactly 416 parent byte strings match v2, three differ; three old child focus spans differ and six are new. Current verdicts were assigned after this review. Prior own derivations were reused only after rechecking current definitions, hypotheses and dependencies; changed and affected rationales were renewed explicitly.',
    'current_source_attestations':{'parents':419,'children':861},
    'identical_parent_bytes_to_v2':416,'changed_parent_ids':['S0058','S0229','S0362'],
    'overall_mathematical_verdict':'PASS',
    'status_counts':dict(Counter(r['status'] for r in records)),
    'nested_status_counts':dict(Counter(c['status'] for r in records for c in r['nested_checks']))})
(OUT/'pass_c.json').write_text(json.dumps({'metadata':meta,'records':records},ensure_ascii=False,indent=2)+'\n')

prior_report=(ROOT/'audit_v2/pass_c_report.md').read_text()
head=prior_report.split('## C. Source-ordered permanent-container C ledger',1)[0]
head=head.replace('frozen revision v2','frozen revision v3').replace('audit_v2/','audit_v3/')
head=head.replace('1–949','1–951').replace('45,127','45,329').replace('| 949 | 949 |','| 951 | 951 |')
head=head.replace(ownold['metadata']['source_sha256'],sha).replace(ownold['metadata']['inventory_sha256'],isha)
head=head.replace('855','861').replace('| 520 | 520 |','| 525 | 525 |').replace('| 579 | 579 |','| 584 | 584 |')
head=head.replace('| 22 | 22 |','| 23 | 23 |').replace('852 VERIFIED','858 VERIFIED')
head=head.replace('current external-theorem/background and translated packet material',
    'current full-domain external-theorem/background, radial-potential and dyadic-partition material')
head=head.replace('Some unchanged derivations below preserve wording from my own earlier notes, after checking it against the current full source. No prior verdict was accepted as evidence by itself. In particular, the two missing hypotheses found in my own supplemental v1 audit were tested against the actual new text and their downstream estimates were rederived. Earlier v1 outputs remain unchanged.',
'''All 416 unchanged parent byte strings were identity-checked, reread and reviewed for changed dependencies. Three current parents differ (S0058, S0229, S0362); their three changed old child spans and six added focuses were rederived explicitly. No prior verdict was accepted as evidence by itself. All v2 outputs remain unchanged. The full-domain finite-p theorem map was inspected directly in the published formula image, and the theorem's actual use of that assumption was checked in its proof.''')

table='''## C. Source-ordered permanent-container C ledger

The companion `pass_c.json` contains all exact anchors and full SHA-256 hashes, each current child focus and rationale, and explicit current-source/dependency attestations for 419 parents and 861 children. The table includes every permanent container in source order. A/B/D receipt and reconciliation remain coordinator responsibilities.

| ID | File:lines | SHA-256 prefix | Exact opening | Mode | Math | Child IDs | A | B | C | D | Reconciled | Affirmative C reason |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
'''
def cell(x): return str(x).replace('|','\\|').replace('\n',' ')
for r in records:
    opening=r['exact_source_anchor'].lstrip().split('\n',1)[0][:100]
    table+='| '+' | '.join([r['id'],f"proof.tex:{r['line_start']}–{r['line_end']}",
        '`'+r['source_sha256'][:16]+'`','`'+cell(opening)+'`',r['container_mode'],
        'yes' if r['mathematical'] else 'no',', '.join(c['id'] for c in r['nested_checks']) or 'none',
        'pending','pending',r['status'],'pending','coordinator',cell(r['rationale'])])+' |\n'

body=prior_report.split('## D. Adversarial and current-revision tests',1)[1]
body='## D. Adversarial and current-revision tests'+body
body=body.replace('### Current hypotheses and calculations tested afresh','### Additional unchanged hypotheses and calculations rechecked in v3')
body=body.replace('The following are C\'s own local tests, not a change manifest or another pass\'s conclusions. The latest source was read directly before each determination.',
    'These own C tests were reapplied to the current source. They are not conclusions imported from another pass. The renewed v3-specific checks appear first below.')
v3tests=r'''

### V3-specific falsification tests and affected dependencies

**S0058: full theorem domain, not only bounded data.** The primary displayed Assumption 3.1 map was read directly. Theorem 2.2, with q=1 and p=3, supplies \(K:L^1\cap L^3_{\rm ul}\to C_b^{0,1/3}\). The kernel bounds and distributional divergence identity apply to every member of that entire domain. Bounded vorticity then supplies the subclass used in Theorem 3.3 because \(\sup_x\|\omega\|_{L^3(B_1(x))}\le\pi^{1/3}\|\omega\|_\infty\). Its proof applies the divergence assumption on these bounded densities; log-Lipschitz control is a separate bounded-vorticity conclusion. No p=infinity Lipschitz map is presumed. genui{"citation":{"refs":["turn141view1","turn143view0"]}}

An independent kernel derivation also checks the map. For d=|x−y|<1, split the difference integral into balls of radius 3d, an intermediate annulus and a region separated by order one from x,y. On the near balls, Holder with exponents 3 and 3/2 gives a bound proportional to
\[
\left(\int_0^{3d}r^{-3/2}r\,dr\right)^{2/3}\|\omega\|_{L^3_{\rm ul}}=C d^{1/3}\|\omega\|_{L^3_{\rm ul}},
\]
using a fixed finite cover if the chosen ball radius exceeds one. On the intermediate annulus, the difference kernel is bounded by C d/r^2, and
\[
\left(\int_{2d}^{3}(d/r^2)^{3/2}r\,dr\right)^{2/3}\le C d^{1/3}.
\]
The far integral is at most C d||omega||1. The near/far split at unit radius bounds the velocity itself, and d>=1 is covered by twice that bound. These estimates establish the bounded C^(1/3) map on the full domain without a global L3 or energy hypothesis. Fubini against compact test gradients extends Div K=0 to every such convolution. A merely local L3 bound with no uniformity in the center would not justify this map; the actual domain and bounded-data implication give exactly that uniformity.

Downstream E1, the every-time representative, relative-L2 velocity, pressure and initial seed were rechecked in S0054–S0114. The fixed Holder exponent is used for theorem hypothesis matching, while the flow argument uses the actual log-Lipschitz modulus. No Osgood conclusion is incorrectly inferred from the 1/3-Holder estimate.

**S0229: annular bumps and the exact far-field domain.** Let U1 be radial and supported in an annulus strictly inside B1. Inside its central hole, G*U1 is a finite constant, whereas G(x) varies and is singular at zero. Thus “outside the support” alone would not prove the potential identity. The current hypothesis is |x|>1: then y→G(x−y) is harmonic on the whole support disk, so its centered circular means all equal G(x). Integrating against the radial probability gives exactly G*U1=G, including the additive constant. Differentiation gives the Hessian formula and O(|x|^-2) tail only where needed. The bounded core estimate applies on the entire unit disk, so all Lp profile norms, their dilation laws, Q estimates and LER bounds in S0230–S0349 survive even for an annular U1.

**S0362: positivity rather than mere support coverage.** Smooth nonnegative functions may vanish at points of their support. A cover by supports alone therefore does not justify dividing by their sum. The current plateau directly excludes this: for t>0 set
\[
j=\lfloor\log_2(4t/3)\rfloor.
\]
Then \(3/4\le t/2^j<3/2\), so one summand equals one. Adjacent plateau endpoints are included, and the denominator is everywhere at least one. Compact support in (1/2,2) gives local finiteness and support compactly inside I_j. This supplies smooth nonnegative chi_j summing exactly to one. The stress cancellation, partial-color estimate, finite overlap, anchor gaps and exact-trace/TV/canonical closure were rechecked in S0363–S0418 with this actual partition.

'''
body=body.replace('## D. Adversarial and current-revision tests\n','## D. Adversarial and current-revision tests\n'+v3tests,1)
ext_start=body.index('Primary source: [Crippa–Stefani')
ext_end=body.index('\n\nThe remaining invocations',ext_start)
body=body[:ext_start]+'''Primary source: [Crippa–Stefani, published article](https://link.springer.com/article/10.1007/s00526-024-02750-4). The current verification above covers Theorem 2.2 and the full Assumption 3.1 map. Definition 3.2 supplies canonical velocity and the initial weak/Lagrangian formulation; Theorem 3.3 supplies the signed bounded-vorticity existence and stated horizon estimates. The manuscript derives its stronger every-time and pressure properties separately. genui{"citation":{"ref":"turn143view0"}}'''+body[ext_end:]
body=body.replace('22 flagged parent records','23 flagged parent records')
body=body.replace('All 579 formula byte spans','All 584 formula byte spans')
body=body.replace('949/949','951/951').replace('45,127/45,127','45,329/45,329')
body=body.replace('855','861').replace('520 inline plus 59 displays, total 579/579','525 inline plus 59 displays, total 584/584')
body=body.replace('22/22','23/23')
body=body.replace('None identified by this independent pass. There is no current earliest erroneous container or current error-propagation chain to report. In particular, the two prior supplemental C counterexamples for missing temporal regularity and an unfixed bump family fail the explicit current hypotheses; this was confirmed by the direct derivations above, not by accepting that a revision had been labeled a repair.',
'''None identified by this independent pass. There is no current earliest erroneous container or current error-propagation chain. The current source excludes the annular-hole potential and zero-denominator partition tests, and the external theorem is matched on its full p=3 domain. Prior temporal-regularity and fixed-bump scaling hypotheses were also reread and retested rather than presumed to remain sufficient.''')
body=body.replace('the primary external theorem and hypotheses were inspected directly','the primary external theorem, full-domain map and hypotheses were inspected directly')
body=body.replace('both earlier supplemental C counterexamples were retested against explicit current hypotheses and their affected identities rederived','all current targeted counterexamples were tested against explicit current hypotheses and their affected dependencies rederived')
body=body.replace('No dependency above is accepted only conditionally on a current unproved claim in C\'s ledger.',
'''Current source identity and dependency attestations are explicit for all 419 parents and 861 children. The three changes propagate through the background/seed, projected-bump/LER and dyadic-iteration/closure chains as detailed above; each chain was rechecked. No dependency above is accepted only conditionally on a current unproved claim in C's ledger.''')
(OUT/'pass_c_report.md').write_text(head+table+'\n'+body)
print(json.dumps({'parents':len(records),'children':children_count,'identical_parents_to_v2':identical,
    'statuses':meta['status_counts'],'child_statuses':meta['nested_status_counts']},indent=2))
