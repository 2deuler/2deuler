# Final hostile whole-proof check of frozen v3

## Source-bound conclusion and scope

**PASS within this additional whole-proof audit's documented scope.** I found no fatal construction obstruction, hidden fine-scale loss in the leading curl estimate, invalid weak trace, or failed implication to the exact target. This conclusion was reached by reading the current source and rechecking its formulas and interfaces; it is not inherited from the earlier version's outcome.

Examined: all lines 1–951 of audit_v3/proof.tex and the entire audit_v3/target_problem.txt. The source SHA256 was verified as

**8743ce99900bfb3df37bb4ccdae9aa9269cff12fc0a6abff7e4989a4eb426230**.

The source was not edited. No other pass verdict, reconciliation, source-change manifest, or other auditor's report was inspected. The supplied forensic-audit standards had previously been read; this report is an additional hostile check, not a replacement for the four permanent-container passes. It introduces no new container inventory or competing procedural-completeness denominator.

The target requires weak local $L^2$ continuity at zero, the velocity weak formulation, canonical Biot–Savart normalization, and an every-time locally uniform measure bound. It does not require an energy inequality, strong initial velocity continuity, a renormalized vorticity equation, preservation of the Jordan components, or a uniform $L^p$ vorticity bound for $p>1$. Proposed contradictions requiring one of these additional conclusions do not falsify the actual target.

## 1. The external input, including the precise $p=3$ issue

**Source anchors:** lines 106–121 and 123–190; particularly

> “take $p=3$ in Assumption~3.1”

at line 118.

I independently reopened the [primary publisher article](https://link.springer.com/article/10.1007/s00526-024-02750-4) and its [PDF](https://link.springer.com/content/pdf/10.1007/s00526-024-02750-4.pdf). I inspected Theorem 2.2, Assumption 3.1, Definition 3.2, and Theorem 3.3, including its proof. Assumption 3.1 has a fixed exponent and the mapping $L^1\cap L^p_{\rm ul}\to C_b^{0,1-2/p}$; Theorem 2.2 supplies this for finite $p>2$. Theorem 3.3 supplies the bounded-vorticity Lagrangian evolution. Its proof applies the divergence condition to bounded-vorticity time-stepping states and uses the separate kernel-based log-Lipschitz estimate. Definition 3.2 supplies the initial-value transport equation and canonical velocity. No compact-support or global-energy condition occurs in this application.

Here is the actual hypothesis match, independently of a formal substitution $p=\infty$.

For every $f\in L^1\cap L^3_{\rm ul}$, the near part of $K*f$ is bounded by Hölder with exponents $3$ and $3/2$, and the far part by $\|f\|_1$. For a displacement $d<1$, split the difference integral at radii comparable to $d$ and $1$. The near singular integral is $O(d^{1/3}\|f\|_{L^3_{\rm ul}})$. On the intermediate annulus, the kernel difference is $O(d/r^2)$, whose $L^{3/2}$ norm is $O(d^{1/3})$; the far term is $O(d\|f\|_1)$. Thus the finite-exponent mapping needed at $p=3$ is valid. Distributionally $\operatorname{div}K*f=0$, and the plane has no boundary.

Every bounded function obeys

$$
\|f\|_{L^3_{\rm ul}}\leq |B_1|^{1/3}\|f\|_\infty.
$$

Thus all bounded-vorticity states to which the external construction applies its divergence hypothesis belong to this fixed domain. The log-Lipschitz modulus needed for uniqueness and stability of the flow comes separately from bounded vorticity and the kernel estimates: integrating $d/r^2$ against a bounded density over the annulus $d<r<1$ gives $O(d|\log d|)$, with $O(d)$ near and far terms. No $C^{0,1}$ estimate for $K:L^1\cap L^\infty\to C^{0,1}$ is required. Such an endpoint Lipschitz assertion would generally be false; v3 does not make it.

The bounded-vorticity theorem's hypotheses need not be strengthened to an Assumption 3.1 mapping at $p=\infty$: its fixed finite-exponent divergence and boundary hypotheses cover every bounded-vorticity state involved, and the additional modulus is obtained from Assumption 2.1. Therefore taking $p=3$ does not silently replace Theorem 3.3 by the weaker $L^3$ existence theorem.

The every-time upgrade is internal to the manuscript. Space-mollified velocities converge uniformly under the common Osgood modulus. Their divergence-free flows preserve volume. Osgood stability gives convergence of flows and inverse flows; bounded displacement confines transported compact tests to a common bounded set. Passing the volume-preservation identity and approximating $\nu_0$ by compact smooth functions gives

$$
\nu(t)=\nu_0\circ X_t^{-1}\in C_tL^1\cap C_tL^2.
$$

The near/far estimate at line 156 then gives continuity of $V=K*\nu$ in $L^\infty$. Since

$$
\nu(t)-\nu(s)=-\operatorname{div}\int_s^tV\nu,
\qquad V\nu\in L^\infty_t(L^1\cap L^2),
$$

and the multiplier of $-K*\operatorname{div}$ has operator norm at most one,

$$
\|V(t)-V(s)\|_2\leq \int_s^t\|V\nu\|_2\,d\tau.
$$

This is a difference estimate; it does not assume $V\in L^2$. The weak-$L^2$ kernel bound and boundedness give $V\in L^3$, and the displayed interpolation estimate gives $C_tL^3$. Also $\nabla V,\partial_tV\in L^\infty_tL^2$. The residual $\partial_tV+(V\cdot\nabla)V$ has zero curl by transport and belongs to $L^2$, so the pressure-gradient conclusion is legitimate.

**Outcome:** PASS. The specific $p=3$ application survives primary-source scrutiny and direct hypothesis checking.

## 2. Arbitrary signed, noncompact, inhomogeneous $H^{-1}$ data

**Source anchors:** lines 59–104 and 204–247.

The radial cancellation is essential. With $a$ radial and of mass one,

$$
(K*a)(x)=K(x)\int_{|y|<|x|}a(y)\,dy.
$$

Therefore $L_a=K-K*a$ is supported in $B_A$ and has only an integrable $1/|x|$ singularity. This yields $v_0=L_a*\mu_0\in L^1$. The multiplier estimate is

$$
|(1-\widehat a)m|=O(|\xi|)\quad(\xi\to0),\qquad
|(1-\widehat a)m|=O(|\xi|^{-1})\quad(|\xi|\to\infty).
$$

Consequently its squared magnitude is bounded by $C(1+|\xi|^2)^{-1}$, which proves $v_0\in L^2$ under the stated inhomogeneous hypothesis. No zero-circulation assumption or separate $H^{-1}$ bounds for the Jordan components have entered. The locally integrable multiplier at zero and rapid decay of $\widehat a$ give $V_0\in C_0\cap C^\infty$ and the asserted derivative bounds. Truncation of finite measures in total variation passes both the physical local convolution and its Fourier distribution identity.

For the seed, direct differentiation gives

$$
\partial_tW=-4t^3\Delta^2W,\qquad
\operatorname{div}\bigl[\nabla\Delta W+(\nabla\Delta W)^T\bigr]=\Delta^2W.
$$

Hence the negative sign of the derivative stress in line 211 is correct. Further,

$$
\nabla\Delta W=\nabla\nabla^\perp b_t*\sigma_0,\qquad
\|\nabla\Delta W\|_1\leq Ct^{-2}\|\sigma_0\|_{\mathcal M}.
$$

Multiplication by $t^3$ makes its stress cost $O(t)$, not a near-zero blowup. The remaining stress terms use $W\in L^1\cap L^2$ and bounded $V$. This supplies a finite near-zero majorant and bounded local energies. Fourier approximate-identity convergence gives the strong seed trace. Positive-time continuity of the stress uses the actual $L^3$-$L^{3/2}$ products, not a global-energy assumption on $V$.

The tail example in lines 255–258 checks correctly: the swirl $e_\theta/(r\log r)$ has finite energy and integrable curl but fails $L^{3/2}$; its product with a circulation field has divergent absolute integral. Thus the manuscript identifies and addresses a real whole-plane obstruction rather than implicitly treating all finite-energy increments as acceptable.

**Outcome:** PASS. The initial normalization genuinely covers signed noncompact data with nonzero circulation.

## 3. Dipole, translation, pressure, and moments

**Source anchors:** lines 264–391.

Writing the core stream function as $f(\rho)\sin\theta$, with

$$
f(\rho)=-\rho+\frac{2J_1(\beta\rho)}{\beta J_0(\beta)},
$$

the Bessel equation and recurrence give

$$
f(1)=-1,\qquad f'(1)=1,\qquad f''(1)=-2.
$$

These are the values for the exterior $f(\rho)=-1/\rho$. Angular differentiation of the matched traces gives the mixed and tangential second derivatives. The power series gives smoothness at the origin. Thus $D$ is $C^1$ across the interface, and its curl has no interface measure. The alternating-series signs at $3$ and $4$ and nonvanishing of $J_0(\beta)$ also check directly.

For $w=D-e_1=\nabla^\perp q$, one has $w^\perp=-\nabla q$ and $\operatorname{curl}w=-\beta^2q$ in the disk, so

$$
(w\cdot\nabla)w
=\nabla\left(\frac{|w|^2}{2}+\frac{\beta^2q^2}{2}\right).
$$

This fixes the pressure sign in line 299. The trace $q=0$ removes the boundary contribution from $q^2\mathbf1_{B_1}$. The stated rotation and pressure scaling at line 306 multiply each spatial term by $r^{-3}$, proving the speed $r^{-1}$.

An independent stress-moment calculation is a useful falsification test. Angular integration yields

$$
\int_0^{2\pi}(D_1^2-D_2^2)\,d\theta
=\frac{\pi}{2}(f'+f/\rho)^2,\qquad
\int_0^{2\pi}D_1D_2\,d\theta=0.
$$

The exterior difference is zero. In the core,

$$
f'+f/\rho=-2+2J_0(\beta\rho)/J_0(\beta).
$$

The identities

$$
\int_0^1\rho J_0(\beta\rho)\,d\rho=0,\qquad
\int_0^1\rho J_0(\beta\rho)^2\,d\rho=\tfrac12J_0(\beta)^2
$$

give anisotropy $2\pi$. The stream-function Dirichlet energy is $3\pi$ in the core and $\pi$ outside. Therefore, after rotation,

$$
\int_{\mathbb R^2}D_\xi\otimes D_\xi
=\pi I+2\pi\xi\otimes\xi.
$$

This independently confirms the source coefficient and its sign.

The anti-divergence formula has divergence $f$ by cancellation of the two gradient-divergence terms. Its locally integrable degree-$-1$ kernel gives an $O(R)$ near-field bound. Vanishing zeroth and all first moments leave a far-field Taylor remainder $O(R^2|x|^{-3})$, integrable in two dimensions. Both moments are needed.

Differentiation of $D_r$ gives exactly

$$
\partial_rD_r=r^{-1}D_r-\operatorname{div}(D_r\otimes x/r).
$$

The latter divergence is supported in $B_r$ by degree-$-2$ exterior homogeneity, has uniformly bounded $L^1$ norm by scaling, is even, and has zero mean by its exterior-circle flux. Thus its first moments vanish and $\|F_r\|_1\leq Cr$ follows.

The explicit translations in lines 355–360 and 388 are consistent. With $T_Xf=f(\cdot-X)$,

$$
\partial_t(\eta T_XD_r)
=\eta'T_XD_r+\eta r'T_X\partial_rD_r-\eta X'\cdot T_X\nabla D_r.
$$

Taking $X'=\eta\xi/r$ cancels the translating nonlinear term and leaves

$$
\frac{(\eta r)'}rT_XD_r+\operatorname{div}(\eta r'T_XF_r).
$$

One can make the packet-source pressure completely explicit:

$$
p_v=\eta^2T_XP_r-\frac{(\eta r)'}rT_X\Pi_r.
$$

Indeed $D_r=Z_r+\nabla\Pi_r$, and moving the resulting gradient from the right side to the left requires this negative sign. No time derivative of $\Pi_r$ occurs: the velocity is the full $D_r$, not $Z_r$.

The compact even $Z_r$ has mass $2\pi r\xi$. This is computed on a disk containing its support: the integrals of $D_r$ and $\nabla\Pi_r$ over that disk are respectively $\pi r\xi$ and $-\pi r\xi$. Neither individual field is falsely being treated as globally $L^1$. The compact difference has norm $O(r(1+|\log r|))$ by annular integration. Its first moments vanish by evenness. Subtracting $2\pi U_H\xi$ therefore gives exactly the two moment cancellations used by $\mathcal A$.

Translations preserve those cancellations because the mean is zero. This proves the intrinsic stress bound in line 389, with the translated tensors and correct signs.

**Outcome:** PASS. Direct source, pressure, tensor-moment, and interface calculations agree.

## 4. Strongest parameter attack: tiny floors, huge derivatives, short patches

**Source anchors:** lines 396–506 and 605–746.

The directional decomposition can be verified entry by entry:

$$
\sum_i a_i\xi_i\otimes\xi_i
=\begin{pmatrix}A+B-S_{11}&-S_{12}\\-S_{12}&A+B-S_{22}\end{pmatrix}
=-S+qI.
$$

Its coefficients are nonnegative and smooth, with total mass at most $C\|S\|_1+C\gamma\|h\|_1$. The coefficient $C$ here depends only on the fixed finite directions and tensor norm. Support size enters the regularization mass, which can be made arbitrarily small; it does not multiply the leading $\|S\|_1$ contribution.

On a row, $r=r_0c$ and $ds/dt=\eta/r$, so

$$
dt=(r_0/\eta)c\,ds.
$$

On a buffer with amplitude $\eta_i\zeta(t/T)$ and radius $r_0e$, its displacement is $\eta_iTI_\zeta/(r_0e)$. Thus the specified duration traverses exactly $L$. The complete direction scan lasts $(r_0/\eta_i)B_i$, while its normalized interior coefficient is $2\pi\eta_i r_0/\tau$. The two choices in lines 456–457 solve these two normalization conditions simultaneously:

$$
(r_0/\eta_i)B_i=\tau/4,\qquad
2\pi\eta_i r_0/\tau=d.
$$

The number of rows is $O(d^{-1})$, but it does not multiply the instantaneous velocity or vorticity norm: there is one principal packet, visited sequentially. The row count is already charged in $B_i$ and the scan duration.

For fixed positive floors, $dB_i$ has a positive finite limit, so peak amplitudes are uniformly bounded above and below for sufficiently fine scales. They are not literally independent of the cycle count; line 699 correctly needs only their uniform upper bound. Their leading upper estimate is $C\sqrt{\delta}$ plus controllable mass and approximation slack.

The fine-scale dependence of the potentially dangerous derivatives is explicit:

$$
\eta r'=\eta_i^2\partial_\xi\log c
\quad\hbox{on an interior row},
$$

whereas on a ramp

$$
(\eta r)'=
\frac{\eta_i(r_0e)}{T}\zeta'
=\frac{\eta_i^2I_\zeta}{L}\zeta',
\qquad \eta r'=0.
$$

The enormous derivative of the short temporal ramp is exactly canceled by its small radius. A tiny floor may make $\|\partial_\xi\log c\|_\infty$ enormous, but the floor is fixed before the cycle count grows. The resulting constant $B$ is finite and independent of that later count.

At fixed coarse data, taking $\tau=H^6$, $d=H^2$ gives $r\asymp H^8$. The entire relevant error list is:

| Quantity | Bound at fixed coarse data |
|---|---|
| Compact-source stress | $O(BH|\log H|)$ |
| Radius-variation stress | $O(BH^8)$ |
| Corrector $L^2$ and curl $L^1$ | $O(BH^5)$ |
| Corrector $L^{3/2}$ | $O(BH^{16/3})$ |
| Principal $L^{3/2}$ | $O(H^{8/3})$ |
| Raster discrepancy | $O(H^2\|\partial_\perp a\|_1+H\|a\|_1+H\|\nabla a\|_1)$ |
| Source-support compatibility | $r^{1/5}/H=O(H^{3/5})$ |

Each term tends to zero. No requirement here imposes a competing lower bound on $H$. Old $L^3$ norms, support sizes, floor derivatives, or small patch lengths merely determine how large a finite cycle count must be.

The endpoint is decisive:

$$
\|\operatorname{curl}(\eta D_r)\|_p
=|\eta|r^{2/p-2}\|\operatorname{curl}D\|_p.
$$

At $p=1$ there is no radius loss. Thus reducing $H$ to pay for an arbitrarily large old $L^3$ norm does not enlarge the leading curl cost. At $p>1$ the same argument would require additional quantitative balancing; v3 makes no such conclusion.

The order of quantifiers is valid: approximate the piecewise-continuous prescribed tensor on finitely many coarse cells; choose regularization and floor masses to fit both the stress and amplitude slack; then choose the fine cycle counts; finally choose a fixed spatial smoothing scale on each of the finitely many cycles. At the smoothing step the previous choices are fixed, so all compact-image approximation claims are uniform on the cycle. Small $\delta$, tiny floors, and very short patches do not reverse this order.

The Banach-valued row rule uses the original smooth compact coefficient. Its derivative bound is

$$
\int\|F'(y)\|_1\,dy
\leq\|\partial_\perp a\|_1+CH^{-1}\|a\|_1.
$$

The piecewise rectangular floor is never differentiated in this estimate; its contribution and the ramp contributions are separately bounded by their total mass.

**Outcome:** PASS. The universal leading $C\sqrt\delta$ estimate is not hiding a fine-scale or support-dependent coefficient.

## 5. Fixed bump, full-cycle correction, smoothing, and the stress sign

**Source anchors:** lines 375, 477–603, and 713–783.

The specified bump family $U_H=H^{-2}U(\cdot/H)$ makes every scaling constant independent of $H$. Because the radial mass-one bump is supported in $B_1$, for $|x|>1$ its logarithmic potential is $G(x)$ by angular averaging. The projected profile therefore has an $O(|x|^{-2})$ exterior. It belongs to every $L^p$, $p>1$, and scales as $H^{2/p-2}$. Smoothness of its core follows by writing its Hessian potential as $\partial_iG*\partial_jU$.

The identity

$$
\frac d{dt}(\eta rU_H(\cdot-X))
=(\eta r)'U_H-\eta^2\xi\cdot\nabla U_H
$$

has the correct sign. The visit endpoints have $\eta=0$, so integration gives

$$
\overline{\mathcal U}=\operatorname{div}A_{\rm av}.
$$

Taking the average across all four direction slots is essential. The source does so. The time primitive is small by its duration, rather than by a nonexistent spatial cancellation estimate at each time.

With $\mathcal U-\mathbb P\mathcal U=\nabla\pi_{\mathcal U}$,

$$
\partial_tQ+\mathcal U
=\overline{\mathcal U}
+\nabla(\pi_{\mathcal U}-\overline{\pi_{\mathcal U}}).
$$

This verifies the pressure $p_Q=-\pi_{\mathcal U}+\overline{\pi_{\mathcal U}}$ in line 540. The curl estimate uses

$$
\operatorname{curl}\mathbb P(U_H\xi)=\operatorname{curl}(U_H\xi),
$$

and hence directly $\|\nabla U_H\|_1=O(H^{-1})$. It never asks for $\mathbb P:L^1\to L^1$. The $L^2$ and $L^{3/2}$ estimates use the proved fixed-profile bounds.

Adding the seed, packet, and corrector equations, expanding $(u+v+Q)^{\otimes2}$, and subtracting $q$ from the combined pressure yields precisely the tensor in lines 565–567. All mixed products appear with their transposes. The error $S+A_{\rm av}-qI$ has the correct sign because the coefficient decomposition is $-S+qI$.

For the old–new terms, $L^3\times L^{3/2}\to L^1$ is a global Hölder bound. For $v,Q$ products, $L^2\times L^2\to L^1$ suffices. The old field's derivative never appears. There is no assertion of a uniform old $L^3$ bound through the infinite iteration.

Convolving the packet equation gives the correction

$$
\operatorname{div}\bigl[v_\ell\otimes v_\ell-(v\otimes v)_\ell\bigr]
$$

on the right-hand side. This verifies the sign in line 593. The continuous $L^2$ image on a fixed cycle is compact, so the commutator is uniformly small in $L^1$. Fixed $\ell$ avoids a time-kernel derivative; convolution contracts all required velocity and curl norms. Convolving the averaged tensor adds a separate small $L^1$ averaging error. The old seed is not mollified.

The completed-cycle correction has zero $L^2$ traces. At row resets only the principal center is changed, with the principal amplitude and its ramp derivatives zero; $Q$ stays a continuous primitive. Thus no temporal atom is introduced. Piecewise stress jumps are legitimate under spatial divergence. Actual stress values assigned at isolated boundaries change neither the equation nor one-sided continuity, while preserving the required pointwise bounds.

**Outcome:** PASS. No source, translation, pressure, projection, quadratic term, commutator, or reset term is missing from the tested identities.

## 6. Exact initial trace and every-time closure

**Source anchors:** lines 789–947.

The anchor lemma's mechanism is stronger than merely finding zero times. For compact smooth solenoidal $\psi$,

$$
\left|\frac d{dt}\int W\cdot\psi\right|
\leq \|\nabla\psi\|_\infty
\left(\|\widetilde U\|_{L^2(\operatorname{supp}\psi)}^2
+\|U\|_{L^2(\operatorname{supp}\psi)}^2
+\|\widetilde R\|_1+\|R\|_1\right).
$$

The uniform hypotheses give a common Lipschitz constant. Sending earlier zero anchors to zero shows that the pairing tends to zero. This by itself treats only solenoidal tests, but the global $L^2$ hypothesis supplies the rest: any weak cluster point has zero divergence and, by testing with $\nabla^\perp\phi$, zero curl. An $L^2$ harmonic vector field on the plane vanishes by its Fourier transform. Thus the correction is weakly zero in global $L^2$, and therefore on every bounded subdomain.

The plateau in line 823 gives a positive dyadic denominator: the intervals $[3\cdot2^{j-2},3\cdot2^{j-1}]$ cover positive times and correspond to the plateau of the $j$-th dilate. The supports are compactly contained in $I_j$. Same-color intervals are disjoint with the gap point $3\cdot2^j$. Hence a total same-color correction has genuine zero anchors tending to zero.

The trace lemma's uniform hypotheses actually hold. The seed has bounded local energies near zero. The patch increment estimate provides a uniformly bounded global $L^2$ correction near zero. The partially completed-stage stress has the exact algebraic form

$$
\left(1-\sum_{j\ {\rm processed}}\chi_j\right)R^{(q)}
+\sum_{j\ {\rm processed}}E_{qj}.
$$

Its first coefficient lies in $[0,1]$, and the error terms have bounded overlap. This bounds both old and new stresses near zero. Thus the argument is not substituting local positive-time boundedness for a uniform estimate at zero.

The partition's originally frozen pieces still cancel after later colors are processed, because LER allows $S$ independent of the current stress. At most three patches are active at any time. On an active patch, $m_j\leq\Theta(t)$; if $t\leq T$, that patch lies in $(0,4T)$, giving $M_j\leq\Theta(4T)$. These observations prove both contraction and the exact stage bound in lines 872–874.

Since $\sqrt{\delta_q}=4^{-q}$, the correction series converges uniformly in global $L^2$ on $(0,T]$, and its curl series converges uniformly and absolutely in $L^1$. The latter statement implies an $L^1$ curl at every fixed positive time, not merely an almost-everywhere representative. The distributional curl of the velocity limit equals that sum by local $L^2$ convergence. At zero the prescribed measure has its original finite norm.

Positive-time local strong continuity follows by uniform convergence of the finite stages. At zero, split the series into finitely many weakly zero corrections and a uniformly small global $L^2$ tail. This proves the requested weak local $L^2$ continuity with all bounded-domain $L^2$ tests, not only solenoidal tests.

The nonlinear limit is justified by strong local $L^2$ convergence, while stress tends to zero. For a temporal cutoff rising on $(\varepsilon,2\varepsilon)$, the omitted convection term is $O(\varepsilon)$ by local energy, and its derivative term converges to $+\int u_0\cdot\varphi(0)$. Replacing $\varphi(t)$ by $\varphi(0)$ costs $O(\varepsilon)$ because the cutoff derivative has bounded total mass. This gives precisely the target's initial-value identity.

Finally, the canonical normalization lemma does not assume the unknown $K*\mu$ is already locally $L^2$. It is locally $L^1$ for a finite measure, so $h=u-K*\mu$ is a harmonic distribution and hence a smooth harmonic field. Its mean-value bound is

$$
|h(x)|\leq \fint_{B_R(x)}|V_0|
+C\|u-V_0\|_2/R+C\|\mu\|_{\mathcal M}/R.
$$

All three terms vanish as $R\to\infty$. Here $u-V_0=(V(t)-V_0)+W+\sum_qw_q$ belongs to global $L^2$ at each time. This excludes a constant or other harmonic parasitic velocity and gives the required Biot–Savart identity at every time.

**Outcome:** PASS. The weak trace, pointwise-time vorticity, full initial-value formulation, and canonical velocity all survive the limiting process.

## 7. Attempts to turn the construction into a contradiction

**Arbitrary isotropic stress and compact-time creation.** Starting from zero velocity with $R=-h(t)f(x)I$ and pressure $p=-h(t)f(x)$ is a legitimate Euler–Reynolds seed. The local repair would indeed permit a nontrivial compact-time weak Euler flow with uniformly $L^1$ vorticity after a suitable summable iteration. The packet amplitude gives a positive first-step $L^2$ lower bound; choosing the first residual and subsequent tail small preserves nontriviality. This consequence does not contradict any required energy inequality or renormalization property, because neither is assumed. Mere $C_tL^2$ continuity is not sufficient to test the equation against the velocity at this regularity.

**Circulation.** Each principal packet has zero integral of curl, by its exterior gradient field. Each corrector has curl equal to a time integral of derivatives of compact bumps, also of zero integral. The seed has the original circulation, and absolute $L^1$ convergence preserves it. No circulation is being manufactured.

**Far-field impulse.** The principal exterior has leading coefficient $-2\pi\eta rD^2G\,\xi$. The leading term of the projected source primitive is $+2\pi\eta rD^2G\,\xi$. Their cancellation provides an additional check on the compact-source normalization. The full-cycle averaged source has zero spatial mean because it is a divergence.

**Instantaneously $L^1$ vorticity with singular initial measure.** A uniform total-variation bound does not imply uniform integrability near zero. Approximate identities already demonstrate that smooth positive-time densities can approach a singular measure with such a bound. The proof claims no strong $L^1$ initial vorticity trace. Thus this observation supplies no functional-analytic contradiction.

**Tail and time regularity.** The proof's fields may have enormous finite derivatives and enormous finite $L^3$ norms at individual stages. Those quantities are not claimed to be uniformly controlled in the limit. The target requires neither them nor a pressure with a uniform global integral. Every place where the construction needs a finite-stage bound has its fine parameters chosen afterward.

None of these attacks exposed an additional hypothesis required by the target or a mathematical inconsistency in the displayed construction.

## 8. Dependency status and remaining limitations

| Interface examined | v3 lines | Result |
|---|---:|---|
| Initial finite-measure/inhomogeneous normalization | 59–104 | PASS |
| Exact primary $p=3$ background interface and every-time background | 106–190 | PASS |
| Bounded initial Euler–Reynolds stress and trace | 204–247 | PASS |
| Exact translating dipole and pressure | 264–318 | PASS |
| Two-moment whole-plane anti-divergence and translated source | 320–391 | PASS |
| Universal leading amplitude and compatible parameter order | 396–506, 605–746 | PASS |
| Fixed bump, time primitive, stress sign, and smoothing | 375, 508–603, 713–783 | PASS |
| Anchor lemma and dyadic patch iteration | 789–895 | PASS |
| Every-time curl, weak formulation, canonical velocity | 896–947 | PASS |

The dependency chain is initial normalization plus bounded background → bounded-stress seed; dipole plus two-moment anti-divergence → compact source; source plus raster plus whole-cycle primitive → local repair; local repair plus dyadic coloring plus anchors → convergent global iteration; iteration plus harmonic normalization → the exact target.

No definite E1–E10 mathematical defect or material failed obligation was found in this additional examination. The source-bound theorem therefore survives the specific strongest counterattacks documented here. This is an audit conclusion about the given proof, not an appeal to plausibility or the status of the general problem.

Remaining limits of this report:

- It does not certify the separate permanent-container inventory, all nested checks, four independent verdicts, or reconciliation counts.
- It is not a formal proof-assistant verification.
- Primary-source reliance is limited to the explicitly identified bounded-vorticity theorem; this report checks its applicability, not every theorem in its reference list.
- It establishes no energy inequality, uniqueness, renormalization, strong initial trace, or $p>1$ vorticity bound for the constructed solution.
- No conclusion is asserted for an altered source digest.

## Final scope certificate

- **PASS:** The 951-line frozen source and exact target were read, and the specified source digest was matched.
- **PASS:** The source remained immutable during this check.
- **PASS:** The dependency-critical algebra, parameter choices, global estimates, temporal pasting, weak trace, and every-time closure were re-derived as documented.
- **PASS:** The finite-exponent external application was checked against the primary article and PDF, including the relevant proof.
- **PASS:** No other pass verdict or reconciliation was used.
- **INCONCLUSIVE / outside scope:** The separate four-pass permanent-container completeness certificate is not issued by this report.
- **PASS within this documented whole-proof scope:** No material counterexample, fatal construction obstruction, or failed implication to the exact target was found.
