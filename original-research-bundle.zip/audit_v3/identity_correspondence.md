# V3 neutral identity and source correspondence

All 419 permanent parents survive with their identifiers and source order unchanged. Three exact reviewed replacements reconstruct the complete revised source. No parent was split, merged, inserted, or deleted.

V3 source SHA-256: `8743ce99900bfb3df37bb4ccdae9aa9269cff12fc0a6abff7e4989a4eb426230`.
V2 source SHA-256: `1ffbeee20c4208e954396b55c3f4bc5289e478d76555579b09d5e7fbfae975bd`.
V2 consolidated ledger SHA-256: `6f43080009e044109938412d2f40e6ba7374ec8777e8be2962c7c1489ea8e0eb`.
V3 ledger SHA-256: `312e27c6941704d244f102a3907c290d82db5d41e68208e88b592b68d32adce7`.

All 855 allocated child identities are retained; 6 new children are appended, giving 861 in 253 compound parents. The three scaffolding-only S0130 spans remain allocated. Exact old/new anchor hashes and byte positions for every parent and child appear in identity_correspondence_manifest.json.

| Changed parent | Identity/scope correspondence |
|---|---|
| S0058 | The three existing kernel-identity roles persist in the extended single sentence; new local-parameter, external-mapping, and local-norm clauses receive appended checks. Assumption 3.1 and Theorem 2.2 are prose references anchored to external E1 in S0053-S0054. |
| S0229 | The potential-identity role persists with the explicitly stated exterior-disk condition |x|>1 replacing the prior support-complement phrase. |
| S0362 | The original cutoff-type and dyadic-coverage role persists; the explicit unit plateau and positive-dilate coverage receive appended focuses. |

## Appended child identities

- S0058.C04
- S0058.C05
- S0058.C06
- S0229.C05
- S0362.C05
- S0362.C06

All current source bytes, line positions, parent/child/formula digests, formula-parent containment, and one-layer child depth were validated. The exact target_problem.txt bytes were copied from v2. Original v2 artifacts were checked again and remain unchanged.

Every v3 pass must use the v3 source and frozen v3 inventory hashes. No mathematical verdict from v2 was read or copied. This is a source-identity certificate only.
