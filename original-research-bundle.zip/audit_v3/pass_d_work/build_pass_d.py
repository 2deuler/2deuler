"""Assemble PASS D after the full independent current-v3 source/child reread.

Own v2 derivations are retained only after identity and dependency review.
The frozen source, neutral inventories, and prior outputs are never modified.
"""
import collections, copy, datetime, hashlib, json, re
from fractions import Fraction
from math import factorial
from pathlib import Path
ROOT=Path('/workspace/scratch/de6aed6f6a22')
P=ROOT/'audit_v3'
inv=json.loads((P/'audit_inventory.json').read_text())
forms=json.loads((P/'audit_formulas.json').read_text())
previous=json.loads((ROOT/'audit_v2/pass_d.json').read_text())
old={r['id']:r for r in previous['records']}
src=(P/'proof.tex').read_bytes()
sha=hashlib.sha256(src).hexdigest()
ihash=hashlib.sha256((P/'audit_inventory.json').read_bytes()).hexdigest()
assert sha=='8743ce99900bfb3df37bb4ccdae9aa9269cff12fc0a6abff7e4989a4eb426230'
assert ihash=='312e27c6941704d244f102a3907c290d82db5d41e68208e88b592b68d32adce7'

reasons={
 'S0054':'The primary publisher article was retrieved directly for v3. The bibliographic data, Theorem 3.3, Assumptions 2.1 and 3.1 and Definition 3.2 match the citation. Theorem 2.2 was additionally inspected, including its image-only range and Holder estimate, to verify the now explicit finite-p interface in S0058.',
 'S0055':'Primary Theorem 3.3 supplies a global signed L1/Linfinity Lagrangian solution, canonical bounded velocity, finite-horizon vorticity bounds, log-Lipschitz modulus and the stated L1 upper bound. Current S0058 verifies its assumptions using p=3, whose domain contains every bounded-vorticity approximant in the theorem proof. Every-time representatives and incompressible norm preservation are subsequently derived locally.',
 'S0058':'Direct inversion-vector algebra gives both kernel identities and distributional div K=0. I visually inspected the primary Assumption 3.1 map L1 intersect L_ul^p -> C_b^(0,1-2/p), and Theorem 2.2 with q=1,p=3 gives its bounded 1/3-Holder specialization under the checked kernel assumptions. The domain is the full L1 intersect L_ul^3 class, not only globally bounded inputs; its divergence is zero for every member and the plane boundary condition is empty. For bounded omega, sup_z||omega||_(L3(B1(z)))<=pi^(1/3)||omega||infinity. Theorem 3.3 applies its divergence bound to bounded-vorticity approximants, all in this domain; its log-Lipschitz conclusion comes from its bounded-vorticity estimate, not a false p=infinity Lipschitz endpoint.',
 'S0060':'The datum properties S0039 and the fully matched finite-p external interface S0054-S0058 provide a global bounded-vorticity evolution. S0065-S0076 select every-time representatives, S0079-S0088 establish global L3 and relative-L2 continuity, and S0089 supplies the velocity pressure. The finite p=3 operator-domain check adds no restriction to nu0 or to the exact original datum.',
 'S0062':'nu0=a*mu is signed L1/Linfinity by S0039 and therefore belongs to L1 intersect L_ul^3. The primary existence theorem allows signed noncompact data; the full p=3 mapping, divergence and vacuous whole-plane boundary hypotheses were checked at current S0058. Its bounded-vorticity conclusion supplies exactly the source solution used here.',
 'S0229':'For |x|>1, the function y -> G(x-y) is harmonic on a neighborhood of the closed unit disk containing supp U1. Its average on each centered circle is G(x); integrating these circle averages against the radial unit-mass U1 gives G*U1=G. Also U1(x)=0 there, hence Z_(1,xi)=-D2G(x)xi. The explicit Hessian of (2pi)^-1 log|x| is O(|x|^-2). No assertion about an interior hole of the bump support is needed.',
 'S0230':'S0228 gives a smooth bounded profile on the compact unit disk, and the current S0229 gives |Z|<=C|x|^-2 for every |x|>1. Polar integration of r^(1-2p) converges exactly for p>1, proving the stated global Lp claim without requiring the exterior formula at interior points outside the bump support.',
 'S0362':'A nonnegative smooth cutoff compactly supported in (1/2,2) and identically one on the closed interval [3/4,3/2] exists because that interval lies strictly inside the open one. The dyadic plateau intervals [3*2^j/4,3*2^j/2] cover every positive number, meeting at endpoints. Thus for every t>0 some numerator equals one and the denominator is at least one. Only locally finitely many terms are nonzero, so the displayed normalized functions are smooth and well defined.',
 'S0363':'The explicit plateau in current S0362 makes the denominator positive at every time, including exact dyadic plateau endpoints. Compact positive-time intervals meet finitely many rescaled supports; normalization gives sum_j chi_j=1, and compact support of eta inside (1/2,2) gives supp chi_j compactly contained in I_j.',
 'S0366':'For each of the three fixed residue classes, the gap times 3*2^j tend to zero as j tends to minus infinity through that class. The revised positive partition denominator changes neither I_j nor these gaps, so they remain exact anchors for the later total correction of that color.',
 'S0371':'The current smooth nonnegative partition is globally defined by its explicit plateau. Multiplying the original R^(q) by each chi_j before any color repair gives symmetric S_qj with compact temporal support in I_j and inherited one-sided L1 continuity; its size is at most delta_q M_j. No positivity gap or undefined normalization occurs.',
}

new_child_reasons={
 'S0058.C04':'The original Assumption 3.1 allows any fixed p in (2,infinity]; p=3 lies in that range and also in the finite range of Theorem 2.2. With q=1, its entire domain L1 intersect L_ul^3 maps to bounded C^(0,1/3) vector fields. This choice avoids making an endpoint Lipschitz assertion.',
 'S0058.C05':'Theorem 2.2 assumes the two kernel bounds, q in [1,2) and finite p>2. Here q=1,p=3, and the exact Biot-Savart kernel identities verify the assumptions. The primary equation images explicitly give the range C_b^(0,1-2/p) and a difference estimate with exponent 1-2/p. Substitution gives 1/3 and a bounded linear map in the sum norm ||omega||1+||omega||_(L_ul^3).',
 'S0058.C06':'For every unit ball B1(z), ||omega||_(L3(B1(z)))<=|B1|^(1/3)||omega||infinity=pi^(1/3)||omega||infinity, uniformly in z. A finite-horizon Linfinity vorticity bound therefore gives a uniform L_ul^3 bound at every approximation stage where it is used in Theorem 3.3.',
 'S0229.C05':'The explicit |x|>1 condition lies outside the entire disk containing supp U1, even if the radial bump has interior holes. Therefore y -> G(x-y) is harmonic on all averaging circles, and U1(x)=0; both parts of the ensuing identity follow.',
 'S0362.C05':'The plateau [3/4,3/2] is a closed compact subinterval of (1/2,2), so a nonnegative compact smooth cutoff can equal one on it, including both endpoints.',
 'S0362.C06':'The positive plateau dilates are [3*2^j/4,3*2^j/2]. Their right endpoint equals the next interval\'s left endpoint, their lower endpoints tend to zero and upper endpoints to infinity. They cover (0,infinity), proving positivity of the partition denominator for every t>0.'
}

records=[]; changed=[]; unchanged_children=0; end=0
md_rows={line.strip('| ').split(' | ')[0]:line for line in (P/'audit_inventory.md').read_text().splitlines() if line.startswith('| S')}
for c in inv['containers']:
 assert c['byte_start']==end;end=c['byte_end_exclusive']
 assert src[c['byte_start']:end].decode()==c['text']
 assert hashlib.sha256(c['text'].encode()).hexdigest()==c['sha256']
 assert c['sha256'][:16] in md_rows[c['id']]
 assert int(md_rows[c['id']].strip('| ').split(' | ')[4])==len(c['nested_checks'])
 prior=old[c['id']]
 same=c['sha256']==prior['source_sha256']
 if not same:changed.append(c['id'])
 # Current verdict was decided from current source; this copies only an own
 # unchanged derivation after the full reread and dependency review.
 reason=reasons.get(c['id'],prior['rationale'])
 status='VERIFIED' if c['mathematical'] else 'NOT MATHEMATICAL'
 nc=[]; oldch={n['id']:n for n in prior['nested_checks']}
 for n in c['nested_checks']:
  assert src[n['byte_start']:n['byte_end_exclusive']].decode()==n['text']
  assert hashlib.sha256(n['text'].encode()).hexdigest()==n['sha256']
  if n['id'] in oldch and n['sha256']==oldch[n['id']]['focus_sha256']:unchanged_children+=1
  if n['id'] in ('S0130.C05','S0130.C10','S0130.C11'):
   st='NOT MATHEMATICAL';why='The exact current focus is empty, whitespace or the cases delimiter; the complete two-branch formula and its domains were affirmatively checked in the parent scope.'
  else:
   st='VERIFIED'
   why=new_child_reasons.get(n['id'],reason if c['id'] in reasons else oldch[n['id']]['rationale'])
  nc.append({'id':n['id'],'status':st,'rationale':why,'focus_sha256':n['sha256'],'source_text':n['text']})
 records.append({'id':c['id'],'source_sha256':c['sha256'],'status':status,'rationale':reason,'nested_checks':nc,'supplemental_checks':[],'source_file':'proof.tex','original_source_file':'candidate_proof.tex','line_start':c['line_start'],'line_end':c['line_end'],'source_text':c['text'],'mode':c['mode'],'mathematical':c['mathematical'],'review_basis':'Entire current-v3 parent and every current child reread; every mathematical item affirmatively reconsidered and its dependencies checked against v3. Own earlier calculations retained only after source identity and dependency review.','text_identical_to_own_v2_review':same})
assert changed==['S0058','S0229','S0362']
assert end==len(src)==45329
for f in forms['formulas']:
 assert src[f['byte_start']:f['byte_end_exclusive']].decode()==f['text']
 assert hashlib.sha256(f['text'].encode()).hexdigest()==f['sha256']
assert len(records)==419 and sum(len(r['nested_checks']) for r in records)==861
counts=collections.Counter(r['status'] for r in records)
childcounts=collections.Counter(n['status'] for r in records for n in r['nested_checks'])
assert counts=={'VERIFIED':388,'NOT MATHEMATICAL':31} and childcounts=={'VERIFIED':858,'NOT MATHEMATICAL':3}

maps=copy.deepcopy(previous['dependency_maps'])
maps[1]['prerequisites'][1]['role']='Primary Theorems 2.2 and 3.3, p=3 operator domain/range, kernel/divergence and plane hypotheses'
maps[1]['explanation']='The full L1 intersect L_ul^3 to bounded 1/3-Holder mapping is matched directly to the primary source. Bounded-vorticity data and all source approximants lie in that domain. Every-time representatives precede all relative-L2 and L3 continuity arguments; the velocity pressure is derived locally.'
maps[3]['explanation']+=' The projected profile uses the radial-potential identity only on |x|>1; a bounded compact core and that exterior tail give all required Lp norms.'
maps[5]['explanation']+=' The explicit unit plateau ensures the partition denominator is positive for every time, and its dyadic intervals retain the same support, overlap and gap anchors.'
for m in maps:m['current_source_sha256']=sha;m['current_dependency_review']='All listed statement, proof and prerequisite IDs checked against the frozen v3 source; no error dependency or circularity found.'

theorems=copy.deepcopy(previous['theorem_hypothesis_checks'])
for t in theorems:
 if t['container_id']=='S0054':t['hypotheses_checked']='Current primary Theorem 3.3, Assumptions 2.1/3.1, Definition 3.2 and the finite-p Theorem 2.2 mapping were retrieved, including equation images and the relevant proof uses.'
 if t['container_id']=='S0062':t['hypotheses_checked']='nu0 is signed L1/Linfinity and hence L1 intersect L_ul^3. Current S0058 checks the full p=3 domain/range, the divergence bound for all that domain, and the empty plane boundary condition. Theorem 3.3 uses these on bounded-vorticity approximants, and independently gives the required log-Lipschitz conclusion.'
theorems.append({'container_id':'S0058','principle':'Crippa-Stefani Theorem 2.2 and Assumption 3.1, with inspection of their use in Theorem 3.3','hypotheses_checked':'Assumption 2.1 kernel bounds hold exactly; select q=1,p=3. The full domain is L1 intersect L_ul^3 and the range is C_b^(0,1/3). Distributional divergence is zero for every domain member. The plane has no boundary. Bounded vorticities have uniform unit-ball L3 norms and therefore every bounded approximation used by Theorem 3.3 belongs to the domain.','conclusion_used':'A bounded 1/3-Holder velocity mapping validates Assumption 3.1 with finite p. Theorem 3.3 then supplies the bounded-vorticity existence interface; its stronger log-Lipschitz modulus is obtained there without an endpoint C^(0,1) mapping claim.','status':'VERIFIED'})
theorems.sort(key=lambda t:t['container_id'])
assert {t['container_id'] for t in theorems}=={c['id'] for c in inv['containers'] if c['external_theorem_invocation']}
assert len(theorems)==23

labels=re.findall(r'\\label\{([^}]+)\}',src.decode());refs=re.findall(r'\\(?:eqref|ref)\{([^}]+)\}',src.decode())
assert len(labels)==len(set(labels))==25 and len(refs)==27 and not set(refs)-set(labels)
def trunc(z,n):return Fraction(z,2)*sum((-Fraction(z*z,4))**k/Fraction(factorial(k)*factorial(k+1)) for k in range(n+1))
assert trunc(3,3)==Fraction(669,2048) and trunc(4,4)==-Fraction(2,45)

meta=copy.deepcopy(previous['metadata'])
meta.update({'revision_id':'v3','source_sha256':sha,'inventory_sha256':ihash,'source_lines_examined':[1,951],'source_bytes':len(src),'shared_nested_checks_examined':861,'formula_occurrences_examined':584,'inline_formula_occurrences_examined':525,'external_theorem_containers_matched':23,'status_counts':dict(counts),'shared_child_status_counts':dict(childcounts),'current_source_attestations':419,'current_child_attestations':861,'text_identical_parent_derivations_rechecked':416,'text_changed_parent_derivations_rechecked':3,'new_v3_child_derivations':6,'independence':'Only frozen v3 source/neutral inventories/notation/target, audit instructions, own v2 calculations and independently retrieved primary material were used. No other pass output, source-change/reconciliation manifest, route packet, dependency-provenance file, list_agents or other-auditor communication was read or used.','revision_review':'All 419 current parents and 861 children were reread in source order, including all six new children. Own unchanged derivations were reused only after exact identity and current dependency review; three changed parents and all affected theorem/global interfaces were derived against v3.','verdict_scope':'Independent frozen-v3 pass D; cross-pass comparison and combined certification remain the coordinator\'s responsibility.','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()})

obj={'metadata':meta,'records':records,'dependency_maps':maps,'theorem_hypothesis_checks':theorems,'critical_errors':[],'unjustified_or_ambiguous_items':[],'earliest_affected_containers':[],'propagated_error_descendants':[],'new_supplemental_checks':[],
 'revision_dependency_checks':[
  {'parent_id':'S0058','status':'VERIFIED','direct_dependents':['S0054','S0055','S0056','S0060','S0062'],'downstream_major_results':['Bounded background','Initial seed','LER applied to current background','Global iteration','Exact-target global theorem'],'rationale':'The finite-p source interface holds on its full domain and supports every later background norm and equation; no dropped hypothesis or circular use is introduced.'},
  {'parent_id':'S0229','status':'VERIFIED','direct_dependents':['S0230','S0231','S0232','S0237','S0238','S0239'],'downstream_major_results':['Prescribed-piece LER','Global iteration','Exact-target global theorem'],'rationale':'The explicit exterior disk is enough for every tail estimate; smooth bounded core plus r^-2 tail yields all projected-profile norms, with the previously fixed scaling family.'},
  {'parent_id':'S0362','status':'VERIFIED','direct_dependents':['S0363','S0364','S0365','S0366','S0367','S0371','S0375','S0378','S0380','S0383','S0388'],'downstream_major_results':['Global iteration','Initial trace preservation','Exact-target global theorem'],'rationale':'The plateau ensures every-time positive normalization. The same interval geometry gives local finiteness, exact frozen-piece cancellation, bounded overlap and color gap anchors.'}
 ],
 'primary_sources':[{'title':'Crippa-Stefani, An elementary proof of existence and uniqueness for the Euler flow in localized Yudovich spaces','url':'https://link.springer.com/article/10.1007/s00526-024-02750-4','current_retrieval_refs':['turn137view0','turn137view1','turn137view2','turn139view0','turn139view1','turn139view2','turn139view3'],'interfaces_inspected':['Assumption 2.1','Theorem 2.2 including image-only codomain and equation (2.5)','Assumption 3.1 including image-only full domain/range','Definition 3.2','Theorem 3.3 and its divergence-bound uses in construction Steps 1-3'],'local_primary_snapshot':'pass_d_work/primary_article.html','local_equation_images':['pass_d_work/primary_assumption31.png','pass_d_work/primary_theorem22_range.gif','pass_d_work/primary_theorem22_holder.png'],'status':'VERIFIED','matching_summary':'q=1,p=3 matches the full L1 intersect L_ul^3 to bounded 1/3-Holder map; divergence vanishes and the plane boundary condition is empty. The existence proof uses it on bounded-vorticity approximants.'}],
 'computational_checks':[
  {'method':'Exact SHA256 and byte-span/Markdown-row comparison','claim':'Current source anchoring','result':'419 parents, 861 children, 584 formulas and 419 Markdown rows match the full 45329-byte frozen source. Exactly three parent digests differ from this auditor\'s v2 source anchors.','scope':'Procedural integrity; not a proof of mathematics.'},
  {'method':'fractions.Fraction rerun','claim':'S0124 exact Bessel truncations','inputs':'J1(3), k=0..3; J1(4), k=0..4','result':'669/2048 and -2/45 exactly','scope':'Finite arithmetic corroboration; alternating remainders and root/ODE conclusions were checked analytically.'},
  {'method':'Source reference extraction and semantic dependency review','claim':'Reference integrity','result':'25 unique labels, 27 references and zero undefined references.','scope':'The automated syntax check supplements source-context verification.'},
  {'method':'Visual inspection of primary-source equation images plus direct integral re-derivation','claim':'Full p=3 operator mapping','result':'Primary domain/range is L1 intersect L_ul^p -> C_b^(0,1-2/p). At q=1,p=3, near/middle/far kernel integration yields the bounded 1/3-Holder estimate on the full domain.','scope':'Primary interface matching and analytic verification; no endpoint-Lipschitz assumption.'}
 ],'notation_clarifications_not_findings':[],'cross_pass_reconciliation':{'performed_by_this_independent_pass':False,'reason':'Other independent passes and coordinator conclusions were not inspected.'}}
(P/'pass_d.json').write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n')
(P/'pass_d_work/notes.tsv').write_text('\n'.join(r['id']+'\t'+r['status']+'\t'+r['rationale'] for r in records if r['mathematical'])+'\n')
print(json.dumps({'source_sha256':sha,'inventory_sha256':ihash,'parents':len(records),'children':861,'parent_statuses':dict(counts),'child_statuses':dict(childcounts),'theorem_checks':len(theorems),'dependency_maps':len(maps),'changed_parent_ids':changed}))
