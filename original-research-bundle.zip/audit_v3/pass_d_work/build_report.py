from pathlib import Path
import re
ROOT=Path('/workspace/scratch/de6aed6f6a22')
P=ROOT/'audit_v3'
r=(ROOT/'audit_v2/pass_d_report.md').read_text()
r=r.replace('frozen revision v2','frozen revision v3')
r=r.replace('entire `proof.tex`, lines 1–949','entire `proof.tex`, lines 1–951')
for old_count,new_count in [('855','861'),('579','584'),('520','525'),('852','858'),('949','951')]:
 r=re.sub(r'\b'+old_count+r'\b',new_count,r)
r=r.replace('45,127','45,329')
r=r.replace('1ffbeee20c4208e954396b55c3f4bc5289e478d76555579b09d5e7fbfae975bd','8743ce99900bfb3df37bb4ccdae9aa9269cff12fc0a6abff7e4989a4eb426230')
r=r.replace('6f43080009e044109938412d2f40e6ba7374ec8777e8be2962c7c1489ea8e0eb','312e27c6941704d244f102a3907c290d82db5d41e68208e88b592b68d32adce7')
r=r.replace('the v1 outputs remain untouched','the v1 and v2 outputs remain untouched')
r=r.replace('received v2 TeX','received v3 TeX')
r=r.replace('| External-theorem flagged containers | 22 | 22 |','| External-theorem flagged containers | 23 | 23 |')
r=r.replace('22 theorem-hypothesis records','23 theorem-hypothesis records')
r=r.replace('All 22 inventory-flagged containers','All 23 inventory-flagged containers')
r=r.replace('All 22 theorem-application containers','All 23 theorem-application containers')
r=r.replace('All six previously appended neutral focus obligations and all fifteen newly appended v2 children are included in the 861 and were directly checked.','All six consolidated neutral focus obligations, the fifteen children added in v2, and all six children newly added in v3 are included in the 861 and were directly checked. Direct comparison of current source anchors with this auditor\'s own v2 anchors found exactly three changed parents: S0058, S0229 and S0362. The other 416 parent texts were identical; all their current children and dependencies were nevertheless reread and affirmatively checked before retaining own earlier calculations.')
r=r.replace('Own earlier calculation notes were used as calculation references only after comparison with the current source; no earlier verdict was adopted without a current check.','Own earlier calculation notes were used only after exact identity and dependency review against the current source; every current container and child received a fresh current-version attestation. No earlier verdict was adopted without that check.')

extra='''### Three changed current parents and their propagated interfaces

| Parent and new children | Current direct check | Dependencies rechecked |
|---|---|---|
| S0058; C04–C06 | The primary domain is `L1 ∩ L_ul^p` and the displayed range is `C_b^(0,1−2/p)`. Taking `q=1,p=3` in Theorem 2.2 gives the stated bounded 1/3-Hölder map. Divergence vanishes for every member of that full domain; the plane boundary condition is empty. | S0054–S0059 and S0060–S0090; then the seed, every subsequent current-background LER use, the global iteration, and the final theorem. |
| S0229; C05 | For `|x|>1`, the entire unit disk containing the bump is a harmonicity region for `y ↦ G(x−y)`. Radial unit-mass averaging gives `G*U1=G`, and `U1(x)=0` there; differentiating gives the stated Hessian tail. | S0230–S0239, all Q bounds, old/new stress integrability, LER smallness and continuity, then global convergence. |
| S0362; C05–C06 | A nonnegative smooth cutoff can equal one on the closed plateau `[3/4,3/2]`. Its dyadic plateau intervals cover all positive times, including their shared endpoints, so the normalization denominator is at least one. | S0363–S0367, frozen pieces, exact cancellation, overlap bounds, color anchors and every-time trace closure through S0418. |

All three current parent conclusions and their affected dependencies are VERIFIED. No unchanged dependency was treated as valid merely because its exact bytes were unchanged. The ledger contains explicit parent-level revision dependency records; no error propagates from these checks.

### Full primary-source mapping check

The publisher renders three decisive formulas as images, not searchable mathematical text. I downloaded and visually inspected those exact primary images: Assumption 3.1's domain/range, Theorem 2.2's codomain, and its difference estimate (2.5). Their images and the retrieved article HTML are retained in `pass_d_work`; the ledger records retrieval references. In particular, the checked interface is a bounded map from the **full** `L1 ∩ L_ul^3` class to bounded 1/3-Hölder vector fields. It is not just an estimate for the particular smoothed datum.

Here is an independent derivation for that full domain. Write `M3=sup_z ||omega||_(L3(B1(z)))`. The radius-one near field is bounded by Hölder with exponents 3 and 3/2 because `|x|^-1` belongs to L3/2 of a disk; the far field is bounded by `C||omega||1`. For a displacement `h=|x−y|<1`, split the velocity difference into a disk of radius proportional to h, an intermediate annulus, and the far field. The near contribution is `C M3 h^(1/3)`. On the annulus the kernel difference is bounded by `C h/|x−z|²`; its L3/2 norm is `C h^(1/3)`, giving the same bound. The fixed far region contributes `C h||omega||1`, which is at most `C h^(1/3)||omega||1`. A fixed-radius enlargement changes the uniformly local norm by only a finite covering factor. For h at least one, twice the velocity sup norm gives the global Hölder estimate. Thus the domain/range assertion holds directly under exactly the displayed kernel hypotheses.

Distributional divergence is zero for every such omega, since omega is globally L1 and the translated-ball kernel bound permits distributional convolution and testing. A strictly positive divergence-bound constant allowed by the article may be chosen arbitrarily because the actual divergence is zero. Bounded vorticity satisfies `M3 <= pi^(1/3)||omega||infinity`, uniformly over all unit-ball centers and, on a bounded-vorticity finite horizon, uniformly in time.

I inspected the actual proof of Theorem 3.3, not just its heading: its construction applies the divergence bound (3.1) to bounded-vorticity frozen-time data and obtains bounds (3.11)–(3.12); the p=3 domain contains all of them. Its spatial modulus is obtained from the bounded-vorticity logarithmic estimate, and its canonical velocity is identified in the passage to the limit. This use requires no assertion that the p=infinity endpoint of the displayed Hölder map is Lipschitz. The manuscript's separate flow-representative, relative-L2, velocity-equation and initial-trace arguments remain necessary and were checked in S0065–S0090.

'''
needle='No container requires escalation on this independent pass\'s evidence. The following current formulations received explicit fresh checks together with their downstream dependencies:\n'
assert needle in r
r=r.replace(needle,'No container requires escalation on this independent pass\'s evidence.\n\n'+extra+'### Other current formulations and interfaces rechecked\n\nThe following source formulations were also checked with their downstream dependencies:\n')

r=r.replace('| External bounded-vorticity existence interface | S0054–S0059, S0062 | One global canonical Lagrangian source solution |','| External bounded-vorticity existence interface | S0054–S0059, S0062 | Full finite-p mapping domain/range, kernel and divergence hypotheses, then one global canonical Lagrangian source solution |')
r=r.replace('| Projected full-cycle primitive | S0221–S0242 | Small Q, zero endpoint trace, correct averaged tensor and pressure sign |','| Projected full-cycle primitive | S0221–S0242 | Exterior identity on the explicit disk complement, global profile norms, small Q, zero endpoint trace and pressure sign |')
r=r.replace('| Three-color dyadic geometry | S0362–S0367 | Local finiteness, bounded overlap and exact gap anchors |','| Three-color dyadic geometry | S0362–S0367 | Explicit unit plateau and positive denominator, local finiteness, bounded overlap and exact gap anchors |')
r=r.replace('The datum nu0 satisfies its signed L1∩Linfinity condition; the plane has no boundary condition; the displayed kernel identities verify its size/difference assumptions, and divergence is zero.','The datum nu0 satisfies its signed L1∩Linfinity condition. With `q=1,p=3`, Theorem 2.2 supplies the full operator domain/range in Assumption 3.1; divergence is zero on that entire domain and the plane has no boundary condition. The primary image formulas and actual proof uses were inspected as detailed above.')
table_line='| S0054, S0062 | The named primary theorem and its exact datum, domain, kernel, divergence and canonical-solution interfaces |'
assert table_line in r
r=r.replace(table_line,table_line+'\n| S0058 | Primary Theorem 2.2: q=1, p=3, full `L1 ∩ L_ul^3` domain, bounded 1/3-Hölder codomain, both kernel hypotheses; Assumption 3.1: divergence bound on that full domain and empty whole-plane boundary condition; bounded approximants in Theorem 3.3 lie in it |')
r=r.replace('All eight major conclusions','All eight major conclusions')
assert r.rstrip().endswith('not asserted here.')
(P/'pass_d_report.md').write_text(r)
print('Wrote',P/'pass_d_report.md')
