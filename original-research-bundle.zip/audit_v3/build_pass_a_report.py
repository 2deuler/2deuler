from pathlib import Path
import json

root=Path(__file__).resolve().parent
old=(root.parent/'audit_v2/pass_a_report.md').read_text()
j=json.loads((root/'pass_a.json').read_text())

# Reaffirmed reconstruction prose from this auditor's own v2 report; current
# source and dependencies were reread before reuse. Changed claims are replaced.
calculations=old[old.index('1. **Initial normalization'):old.index('### Theorem-hypothesis matching')]
calculations=calculations.replace(
 'The cited existence input applies to signed `ν0=a*μ0∈L1∩L∞`.',
 'The cited existence input applies to signed `ν0=a*μ0∈L1∩L∞`; the explicit p=3 domain/range match and its use in the original construction are checked below.')
calculations=calculations.replace(
 'The one overbroad support-complement statement is the error below; its false part is not needed for the norms.',
 'The current source explicitly states this identity only for `|x|>1`; shell averaging proves it on exactly that region, including when the bump has annular support.')
calculations=calculations.replace(
 'Three dyadic colors have gaps at `3·2^j`, and at most N=3 patches overlap.',
 'The explicit plateau `[3/4,3/2]` makes the partition denominator at least one: take `j=floor(log2(4t/3))` for each t>0. Three dyadic colors have gaps at `3·2^j`, and at most N=3 patches overlap.')
table=old[old.index('| Invocation container(s)'):old.index('### Endpoint and adversarial checks')]
table=table.replace(
 '| S0054, S0062 | The primary-source invocation and its actual application match the hypotheses summarized above. |',
 '| S0054, S0062 | The primary-source invocation and actual application match the finite-exponent hypothesis check below; only bounded L1 vorticities are used by its time-stepping construction. |\n| S0058 | Theorem 2.2 uses q=1 and p=3 in its strict finite-p range. Assumption 3.1 then has domain L1∩L3_ul and range bounded C^(1/3); bounded vorticities have uniform local L3 norms. The distributional divergence is zero and the plane has no boundary. |')

report='''# Independent PASS A — frozen revision v3

**Mathematical verdict for this independent pass: PASS.** All 388 mathematical parent containers and all 858 mathematical child checks are affirmatively verified against the frozen v3 source. The remaining 31 parents and three children contain only non-mathematical material. No further definite error, unjustified claim, material ambiguity, unavailable source or supplemental mathematical check was found. This report does not certify other passes or their reconciliation.

## A. Audit scope

The examined source is `audit_v3/proof.tex`, the frozen revision of `candidate_proof.tex`, lines 1–951, all 45,329 bytes. Its SHA-256 is `8743ce99900bfb3df37bb4ccdae9aa9269cff12fc0a6abff7e4989a4eb426230`. The neutral inventory SHA-256 is `312e27c6941704d244f102a3907c290d82db5d41e68208e88b592b68d32adce7`.

The entire current source was reread in source order through all 419 full parent texts, with every one of the 861 current children read in its full parent context. The exact target, neutral notation, inventory and all 584 formula occurrences were inspected. Exact byte checks establish that the permanent parents form a disjoint contiguous partition of the whole source; all parent, child and formula text hashes match their current spans. The Markdown index lists the same 419 IDs in order. All figures in the manuscript are formulas; no TeX include or bibliography dependency is missing, and no mathematical macro remains unresolved.

The source segmentation was unchanged: 380 sentence containers, 37 structural containers and two retained boundary groups. Whole aligned displays stay attached to their sentence and use a single nested layer. Direct identity comparison against this auditor's own v2 anchors found 416 unchanged parent byte sequences and three changed sequences, S0058, S0229 and S0362. All six new children were checked. Every current claim and the affected background, profile, partition and global dependencies were rechecked before assigning current verdicts; unchanged prior derivations were reused only as explanatory text after that review. Old verdict labels were not used to assign v3 statuses. Every output parent and child carries the full current manuscript hash and its current focus hash. V2 artifacts were preserved.

No other pass output, reconciliation or change manifest, route, checkpoint or dependency-provenance file was read. No agent-status listing or contact with other auditors occurred. Findings were communicated only to the coordinator. The substantive external input was independently reopened at its original primary URL, including the original image containing Assumption 3.1's domain and range. The actual uses of that assumption in the proof of Theorem 3.3 were inspected. The source image is retained as `pass_a_assumption31.png`.

Technical limits: this is a mathematical audit, not a machine formalization. Exact rational arithmetic was rerun for the two displayed Bessel partial sums. No numerical agreement is used as universal proof and no unavailable symbolic package is claimed. The final cross-pass checklist below distinguishes this pass's verified coverage from orchestration facts it has not inspected.

## B. Coverage summary

| Item | Examined by Pass A |
|---|---:|
| Source files | 1 / 1 |
| Source lines | 951 / 951 |
| Source bytes | 45,329 / 45,329 |
| Permanent containers | 419 / 419 |
| Sentence / structural / boundary-group containers | 380 / 37 / 2 |
| Compound containers | 253 / 253 |
| Mathematical / non-mathematical parents | 388 / 31 |
| Shared children | 861 / 861 |
| Mathematical / layout-only children | 858 / 3 |
| Inline / display formula occurrences | 525 / 59 |
| Total formulas | 584 / 584 |
| Algebra-bearing containers | 106 / 106 |
| Standard/external theorem-invocation containers | 23 / 23 |
| Proof environments / major-result maps | 8 / 8 |
| Proposed supplemental children | 0 |
| Uncovered lines / bytes / containers | 0 / 0 / 0 |
| Missing Pass A parent / child verdicts | 0 / 0 |

Parent status counts: 388 VERIFIED and 31 NOT MATHEMATICAL; zero ERROR, UNJUSTIFIED, AMBIGUOUS, DEPENDS ON EARLIER ERROR or NOT VERIFIABLE FROM PROVIDED MATERIAL. Child counts: 858 VERIFIED and three NOT MATHEMATICAL, namely the frozen empty/alignment/case-closing focuses S0130.C05, S0130.C10 and S0130.C11. The full mathematical cases remain verified in their parent and mathematical siblings.

This pass proposes zero v3 escalations and zero supplemental claims. No coordinator-owned local dispute identifiers were allocated here, and zero cross-pass reconciliation items are claimed as resolved by this independent pass. Other passes' coverage and reconciliation are deliberately uninspected.

## C. Permanent-container and nested-check ledger

`pass_a.json` contains one source-ordered record for every S0001–S0419, all 861 children, current container/focus hashes, the full current manuscript hash, current-version attestations and affirmative rationales. `pass_a_notes.tsv` is the current parent-rationale index. The unchanged `audit_inventory.json` supplies exact full TeX anchors, original filename, line/byte spans, modes and child scopes; joining by permanent ID and digest produces the exact anchored ledger without altering or normalizing source text. No verified or non-mathematical parent is omitted.

### Direct checks of the three revised assertions

**S0058: finite-exponent external mapping.** The primary Assumption 3.1 image states

\[
K:L^1(\Omega)\cap L^p_{ul}(\Omega)\longrightarrow
C_b^{0,1-2/p}(\Omega;\mathbb R^2).
\]

Its p=3 instance has exponent 1/3. Theorem 2.2 applies with q=1 and p=3; both are inside its stated ranges. The manuscript's exact kernel size/difference identities match Assumption 2.1, distributional divergence is zero, and the plane has no boundary condition. The proof of Theorem 3.3 uses Assumption 3.1's divergence bound on bounded integrable time-step vorticities; those lie in L1∩L3_ul. Its log-Lipschitz estimates arise separately from Corollary 2.4. Thus this application does not require a Lipschitz endpoint map. The theorem still supplies global Lagrangian transport and the initial-value equation. genui{"citation":{"refs":["turn128view0","turn131view0"]}}

The finite-exponent mapping was also checked directly. If `A=sup_x||ω||L3(B1(x))`, then the near part of K has finite L3/2 norm and the far part is bounded against `||ω||1`; hence `||K*ω||∞≤C(A+||ω||1)`. For displacement h<1, the near ball has contribution `C A h^(1/3)`. On the intermediate annulus the kernel-difference bound and Hölder give

\[
C A h\left(\int_h^1 r^{-3}r\,dr\\right)^{2/3}
\le C A h^{1/3}.
\]

The far contribution is at most `C h||ω||1`, and boundedness handles h≥1. Fixed-radius enlargements are covered by finitely many unit balls. This proves the entire stated bounded Hölder map, not only membership for the particular initial datum. Moreover `||ω||L3(B1(x))≤π^(1/3)||ω||∞`, uniformly in the center, so every bounded-vorticity input in the cited construction is in this domain. S0058.C04–C06, all preceding kernel children, and the affected background and seed conclusions are VERIFIED.

**S0229: exterior radial identity.** Its current text says exactly: “For `$|x|>1$`, radial averaging gives `$G*U_1=G$`, so `$Z_{1,\\xi}=-D^2G\\xi=O(|x|^{-2})$`.” Every shell of the radial probability U has radius s<1. Its angular mean obeys `mean log|x-s e^(iθ)|=log|x|` for |x|>1. Integrating the unit mass gives equality with G and no additive constant. Since U vanishes on that open exterior, taking two derivatives yields Z=-D²G ξ. The explicit Hessian is `(2π|x|²)^(-1)(I-2e_r⊗e_r)`, proving the tail. Annular support causes no exception in this domain; its holes lie in the separately bounded core S0228. The current equality, the new domain child S0229.C05, all profile norms and their later uses are VERIFIED.

**S0362: positivity of the dyadic partition.** A compact smooth cutoff on (1/2,2) equal to one on [3/4,3/2] exists because the closed plateau is strictly inside the open interval. For every t>0 set `j=floor(log2(4t/3))`. Then `3/4≤t/2^j<3/2`, so one denominator summand is exactly one. Both plateau endpoints are included, and no dyadic endpoint gap remains. Only finitely many summands occur near each positive t, making the denominator smooth and ≥1. Each χ_j is nonnegative, compactly supported inside I_j, and their sum is one. The new children S0362.C05–C06 and the whole partition/telescoping/anchor chain are VERIFIED.

### Reconstruction across the current manuscript

'''+calculations+'''
### All theorem-invocation containers

The following table accounts for all 23 frozen invocation containers. Every hypothesis match was checked against the current source; standard analytical tools are also reconstructed in the per-container ledger.

'''+table+'''
### Edge cases and adversarial checks

The current checks include the zero measure and zero stress, nonzero total circulation, arbitrary signed noncompact data, lack of a first moment and lack of global kinetic energy, the Bessel origin and circle interface, positivity of all divisions and square-root branches, vanishing coefficient directions, arbitrarily small positive floors, annular probability bumps, p=3 versus the excluded Lipschitz endpoint inference, each dyadic plateau endpoint, row and cycle endpoints, center resets, unequal one-sided stress traces, independently assigned actual boundary values, small-scale order of choices, every finite horizon including zero, absolute curl convergence at every positive time, and possible harmonic velocity additions. No verified judgment rests only on the absence of a quick counterexample.

## D. Escalated-container and dispute report

This pass finds no v3 parent requiring escalation on its own mathematical verdict. The three revised parents and all their children are VERIFIED for the direct reasons above. No local `R` identifiers or cross-pass reconciliation conclusions are invented here. The coordinator must still compare all independent outputs and perform any escalation their combined evidence requires.

## E. Definite mathematical errors

None established in the frozen v3 source by Pass A. There is no proposed source edit from this pass.

## F. Unjustified, ambiguous and source-dependent items

None remains in this pass's current judgments. The primary theorem's actual domain/range and finite-p applicability were inspected, the exterior potential identity is asserted on a proved domain, and the dyadic cutoff is positive where the denominator needs it. All earlier explicit definitions and parameter choices were reread and checked in their present context. No external source essential to a current assertion is unavailable.

## G. Dependency and error-propagation report

| Major result | Current permanent dependencies | Judgment |
|---|---|---|
| Canonical decomposition, S0034–S0039 | S0026–S0033 conventions; S0040–S0052 local kernel integrability, truncation, radial cancellation and inhomogeneous Fourier estimate. | All VERIFIED; no sign/support/circulation strengthening. |
| Bounded background, S0060–S0061 | Decomposition; S0054–S0058 primary theorem match with finite p=3; S0062–S0090 all-time flow representative, norm bounds, relative L2 continuity and pressure. | All VERIFIED; no global background L2 assumption. |
| Initial seed, S0096–S0100 | Decomposition/background; S0092–S0095 conventions/kernel; S0101–S0114 exact equation, curl/stress estimates, trace and continuity. | All VERIFIED; supplies the stated repair class. |
| LER, S0261–S0275 | S0122–S0168 dipole, anti-divergence and translated source; S0171–S0219 coefficient/raster normalization and quadrature; S0221–S0260 corrector, exterior profile bound, stress identity and smoothing; S0276–S0349 parameter order and pasting. | All VERIFIED, including current S0229 and arbitrary allowed radial U. |
| Anchor lemma, S0351–S0353 | S0354–S0360 bounded distributional pairing derivative, exact anchor values, weak compactness and zero harmonic L2 cluster point. | All VERIFIED. |
| Global iteration, S0361 | Seed, LER and anchors; S0362–S0392 positive partition, three colors, frozen-piece subtraction, summable increments and exact initial traces; S0393–S0406 convergence, curl and target weak formulation. | All VERIFIED on one global time axis. |
| Canonical normalization, S0407–S0408 | S0040–S0043 arbitrary-finite-measure kernel identities; S0409–S0413 harmonicity and expanding-ball mean-value bounds. | All VERIFIED; removes harmonic additions with fixed C0 background and L2 perturbation. |
| Global existence, S0414 | All seven preceding results; S0415–S0418 match every exact target conclusion and apply canonical normalization at every time with U=V0. | VERIFIED for the stated arbitrary signed finite inhomogeneous-H^-1 data. |

All dependencies in these eight maps have current affirmative records. There is no earlier-error propagation in v3 and no circular dependency was found. Forward lemma statements are supported by the following proofs rather than assumed in them. Fine parameters may depend on coarse geometry, finite old L3 norms and derivative constants, while the leading increment coefficient remains universal as stated. The global limit uses a single sequence whose bounds hold on every finite horizon; it does not glue independent finite-horizon solutions. No energy inequality or uniqueness statement is claimed.

## H. Final completeness certificate

- [PASS] Every TeX file was inventoried — 1/1 current source; no missing include.
- [PASS] Every source line belongs to at least one permanent container — 951/951 lines and 45,329/45,329 bytes; zero uncovered.
- [PASS] Permanent container identifiers remained unchanged after the inventory was frozen — all 419 retained, with exact current hashes validated.
- [PASS] Every compound mathematical container received exactly one non-recursive layer of nested checks — 253 compound containers and 861 allocated current children.
- [FAIL] Every permanent container received a verdict from every required pass — Pass A has 419/419; other required passes are deliberately uninspected by this independent report.
- [FAIL] Every final nested check and every remaining simple mathematical container was affirmatively checked by every pass — Pass A checked 861/861 children and all 388 mathematical parents; cross-pass coverage awaits the coordinator.
- [PASS] Every inventoried inline and display formula occurrence was checked — Pass A, 525 inline plus 59 display, 584/584 total.
- [PASS] Every algebra-bearing container was independently re-derived — Pass A, 106/106 current containers.
- [PASS] Every theorem-application container received complete hypothesis matching — Pass A, 23/23, including the original Assumption 3.1 domain/range and the finite-p use in Theorem 3.3.
- [PASS] Every proof was checked locally and globally — Pass A, 8/8 proofs and 8/8 major-result maps.
- [PASS] Edge cases and attempted counterexamples were investigated — zero, sign, origin, support-hole, finite-exponent, dyadic-endpoint, tail, reset, time-boundary and infinite-iteration cases recorded.
- [PASS] Definitions and notation were checked across the manuscript — all current declarations, formulas and cross-references inspected.
- [PASS] Dependencies and error propagation were traced — all eight result chains reviewed; no current error dependency found.
- [FAIL] Every required escalation was reconciled through local dispute items — this pass proposes zero v3 escalations; whether the combined passes require others is reserved to the coordinator and not certified here.
- [PASS] Every definite error was independently confirmed where feasible — no current definite error established; the prior annular-support test was reapplied on the newly stated domain and does not contradict it.
- [FAIL] No source container, pass verdict, or dispute item remains unchecked — no missing Pass A parent, child or formula check; other-pass verdicts and any resulting reconciliation remain outside this independent report.
'''
assert 'the error below' not in report
assert 'overbroad support' not in report
assert report.rstrip().splitlines()[-1].startswith('- [FAIL] No source container')
(root/'pass_a_report.md').write_text(report)
print('Wrote report',len(report.encode()),'bytes')
