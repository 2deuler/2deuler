import json
from pathlib import Path
b=Path('audit_v3'); o=json.loads((b/'pass_b.json').read_text())
s=Path('audit_v2/pass_b_report.md').read_text().split('## Full source-ordered PASS B container ledger')[0]
s=s.replace('# PASS B — fresh independent re-derivation','# PASS B — complete current-revision recheck (v3)')
s=s.replace('This pass found no substantive mathematical error or missing deduction in the current manuscript. It independently re-derived the construction, including the proposed general signed-measure existence conclusion, rather than taking that conclusion or the local repair lemma as an assumption. This is one audit pass; it is not a claim that the required four-pass reconciliation has been completed.', 'This pass identified no substantive mathematical error, invalid deduction or missing hypothesis in the current v3 manuscript. It re-read the complete current construction and re-derived the changed claims, validating identity and dependencies before reusing its own independent v2 calculations. The proposed general signed-measure existence conclusion and local repair lemma were audited as conclusions requiring proof. This is one revision-bound PASS B; it does not certify completion of four-pass reconciliation.')
for a,c in [('audit_v2/proof.tex','audit_v3/proof.tex'),('949','951'),('45,127','45,329'),('1ffbeee20c4208e954396b55c3f4bc5289e478d76555579b09d5e7fbfae975bd','8743ce99900bfb3df37bb4ccdae9aa9269cff12fc0a6abff7e4989a4eb426230'),('6f43080009e044109938412d2f40e6ba7374ec8777e8be2962c7c1489ea8e0eb','312e27c6941704d244f102a3907c290d82db5d41e68208e88b592b68d32adce7'),('855','861'),('852 / 3','858 / 3'),('579','584'),('520 / 59','525 / 59'),('22 / 22','23 / 23'),('All 22 inventoried','All 23 inventoried')]:s=s.replace(a,c)
s=s.replace('- No earlier revision, other pass verdict, prior worker output, change/reconciliation manifest, checkpoint, provenance or route was read. No agent-list call was made and no other auditor was contacted. Messages to the coordinator contained this pass\'s progress only. No substantive auditing was delegated.', '- The same independent PASS B worker rechecked v3. Only its own immutable v2 source/inventory and PASS B derivations were reused, after exact current-parent identity and dependency review. No other pass, reconciliation, source-change manifest, other worker output or verdict communication was inspected. No agent-list call was made and no other auditor was contacted. Messages to the coordinator contained this pass\'s progress only. This is an independent pass relative to the other auditors, not a claim of a newly isolated v3 context. No substantive auditing was delegated.')
s=s.replace('The full source was read in consecutive order. Shared child focuses were then inspected in consecutive groups against their complete parents.', 'All 951 current source lines were read in consecutive order. The entire neutral inventory and formula inventory were parsed and their exact spans checked; the source-ordered parent/child identity listing was reviewed against the complete current parents and their dependencies.')
old='**Primary-source match.** I inspected the [Crippa–Stefani publisher article](https://link.springer.com/article/10.1007/s00526-024-02750-4), specifically Assumptions 2.1 and 3.1, Definition 3.2 and Theorem 3.3. The datum \\(a*\\mu\\) is in \\(L^1\\cap L^\\infty\\). The exact kernel distance identity gives both size hypotheses; divergence is zero and the plane has no boundary. The result supplies the claimed global Lagrangian solution, canonical velocity a.e. in time, vorticity/velocity bounds and log-Lipschitz modulus. The weak initial equation and a.e.-time pushforward are in its definition. No sign, support or energy hypothesis is imported. Every-time representatives, norm preservation and additional regularity are proved in the manuscript, not attributed to a stronger external theorem.'
new=r'''**Primary-source match, checked on the current finite-p statement.** I inspected the [Crippa–Stefani publisher article](https://link.springer.com/article/10.1007/s00526-024-02750-4) and its [original publisher PDF](https://link.springer.com/content/pdf/10.1007/s00526-024-02750-4.pdf): Assumption 2.1, Theorem 2.2 (printed page 10), Corollary 2.4, Assumption 3.1 and Definition 3.2 (printed pages 14–15), and Theorem 3.3 with its proof (printed pages 15–19).

Assumption 3.1 allows a fixed \(p\in(2,\infty]\) and requires the full mapping
\[
K:L^1(\Omega)\cap L^p_{\mathrm{ul}}(\Omega)
\longrightarrow C_b^{0,1-2/p}(\Omega;\mathbb R^2),
\]
a distributional divergence bound \(\|\operatorname{div}K\omega\|_\infty\le C_3\|\omega\|_1\), and the applicable boundary condition. Choosing **p=3** is legitimate. Theorem 2.2 assumes the kernel bounds of Assumption 2.1, \(q\in[1,2)\) and finite \(p>2\); at \(q=1,p=3\), its estimates (2.4)–(2.5) supply boundedness and exponent \(1-2/3=1/3\) on exactly this entire domain. The manuscript's kernel size and exact difference identity verify Assumption 2.1. Distributional \(\operatorname{div}K=0\) verifies the divergence inequality for any positive \(C_3\); the plane has no boundary.

The original proof of Theorem 3.3 was also checked, rather than stopping at its statement. Its time-stepped vorticities are bounded and integrable. For any bounded vorticity,
\[
\sup_x\|\omega\|_{L^3(B_1(x))}\le \pi^{1/3}\|\omega\|_\infty,
\]
so each actual use of Assumption 3.1's divergence inequality lies in the p=3 domain. The source obtains the needed log-Lipschitz estimates separately from Corollary 2.4, not from the weaker Hölder exponent. Subsequent time-stepping compactness and flow convergence use these same bounds. The current manuscript does not require an endpoint p=infinity Lipschitz mapping.

The datum \(a*\mu\) is in \(L^1\cap L^\infty\), so Theorem 3.3 supplies its global Lagrangian solution, canonical velocity a.e. in time, vorticity/velocity bounds and log-Lipschitz modulus. The weak initial equation and a.e.-time pushforward occur in Definition 3.2. No sign, support or energy restriction is introduced. The manuscript itself proves every-time representatives, exact norm preservation and additional regularity; those stronger statements were checked below rather than silently attributed to the external result.'''
assert old in s;s=s.replace(old,new)
s=s.replace('Radial averaging gives \\(G*U_1=G\\) outside the bump, so the projected tail is', 'For the explicitly stated region \\(|x|>1\\), every support circle of the radial probability bump has radius less than \\(|x|\\). Its angular logarithmic mean gives \\(G*U_1=G\\), so the projected tail is')
s=s.replace('For the global stage, same-color intervals are disjoint:', r'''For the global stage the revised cutoff equals one on \([3/4,3/2]\) and is compactly supported in \((1/2,2)\). Its dyadically scaled closed plateaux are
\[
[3\cdot2^{j-2},3\cdot2^{j-1}],\qquad j\in\mathbb Z.
\]
The right endpoint of one is the left endpoint of the next, and their endpoint limits are zero and infinity. Thus they cover every positive time, including all shared endpoints. The locally finite denominator in the partition is at least one. Normalization, smoothness, compact patch support and exact sum one follow. Same-color intervals are disjoint:''')
s=s.replace('SymPy import was attempted in the shell Python and the primary-runtime Python; it was unavailable in both. No successful symbolic-software computation, numerical experiment, proof-assistant verification, or unperformed external check is claimed. The tensor, normalization, pressure and exponent calculations above were performed algebraically by hand.', 'The exact Fraction calculations were re-run for this revision, returning the same values shown above. No symbolic-software computation or proof-assistant verification is claimed. The tensor, normalization, pressure and exponent calculations were checked algebraically. The primary-source PDF text was inspected; screenshot calls returned only image placeholders, so visual PDF inspection is not claimed.')
insert='''## Current-revision identity and dependency checks

All 419 current parent texts and all 861 current shared child focuses were checked against the frozen source. Of the 419 parents, 416 have exactly the same bytes as the worker's own v2 inputs; their earlier calculations were reused only after reading their current context and reviewing their dependencies. Three parents were re-derived as changed claims. Of the children, 852 retain exactly the prior focus bytes, while three existing focuses changed and six new focuses were added. The JSON records a current-source attestation for every parent and child, plus every one of the 584 current formulas.

| Changed parent | Current derivation and downstream review |
|---|---|
| S0058, including C04–C06 | Verified p=3 against the full domain/range in original Assumption 3.1 and the original proof of Theorem 3.3. Rechecked the background, Osgood-flow, seed, iteration and final-existence dependencies. The 1/3-Hölder mapping is not used as an Osgood modulus. |
| S0229, including C05 | Verified the radial-potential identity only on the stated exterior region \\(|x|>1\\). This condition covers the tail required for every p>1 integrability and scaling estimate; core smoothness is supplied independently by S0228, including for annular bumps with holes. Rechecked projection, corrector and repair estimates. |
| S0362, including C05–C06 | Verified that the closed unit plateaux tile positive time after dyadic scaling, including shared endpoints, so the normalization denominator is at least one. Rechecked compact supports, the three color gaps, frozen stress cancellation, anchor times and the exact initial trace. |

No mathematical error was identified in these current claims or their affected dependencies. These current-source findings do not claim that an earlier wording had the same explicit hypotheses.

'''
s=s.replace('## Independent derivations in source order',insert+'## Independent derivations in source order')
s+='''## Full source-ordered PASS B container ledger

Each row's exact source anchor and digest occur in the frozen `audit_inventory.json`; `pass_b.json` repeats the parent digest under `source_sha256`, every current child focus, formula mapping and verdict. Every parent and child also contains an explicit current-source attestation. The following table contains all 419 parent rationales.

| ID | Current source lines | PASS B | Affirmative rationale |
|---|---|---|---|
'''
for c in o['containers']:
 ra=c['rationale'].replace('|','\\|').replace('\n',' ')
 s+=f"| {c['id']} | {c['line_start']}–{c['line_end']} | {c['status']} | {ra} |\n"
s+='''
## Final completeness certificate

- PASS — Every TeX file in this pass was inventoried: one root, no missing include dependency.
- PASS — Every source line belongs to a permanent container: 951/951; all 45,329 source bytes exactly partitioned.
- PASS — Permanent identifiers remained unchanged: 419/419 current parent digests matched.
- PASS — Every compound mathematical container has one nonrecursive shared layer: 253 containers, 861 allocated current children.
- FAIL — Every permanent container received a verdict from every required pass: this report certifies only current PASS B, 419/419; other passes were intentionally not inspected.
- FAIL — Every final child and simple mathematical container was affirmatively checked by every pass: current PASS B checked 861/861 shared children and all 388 mathematical parents; cross-pass completion is outside this report.
- PASS — Every current inventoried formula was checked by PASS B: 584/584, comprising 525 inline and 59 display occurrences.
- PASS — Every algebra-bearing container was re-derived or identity- and dependency-validated against this worker's own derivation: 106/106.
- PASS — Every inventoried theorem application received hypothesis matching in current PASS B: 23/23, including the original finite-p domain/range and its actual use in the specialized existence theorem.
- PASS — Every proof was checked locally and globally in current PASS B: 8/8, with eight current major-result dependency maps.
- PASS — Edge cases and attempted failure modes were investigated as described above.
- PASS — Definitions, macros, formula conventions and cross-references were checked across all 951 current source lines.
- PASS — Current dependencies were traced; no earlier mathematical error was identified to propagate in this pass.
- FAIL — Every required escalation was reconciled through local dispute items: independent PASS B does not perform or claim four-pass reconciliation.
- PASS — Definite errors were independently confirmed where feasible: no definite error was identified, so the confirmation set is empty.
- FAIL — No source container, pass verdict or dispute item remains unchecked: PASS B has zero uncovered current source containers and zero missing own verdicts, but makes no claim about uninspected other passes or coordinator disputes.

This certificate is revision-bound to source SHA-256 `8743ce99900bfb3df37bb4ccdae9aa9269cff12fc0a6abff7e4989a4eb426230` and inventory SHA-256 `312e27c6941704d244f102a3907c290d82db5d41e68208e88b592b68d32adce7`.
'''
(b/'pass_b_report.md').write_text(s)
print('Wrote report',len(s.encode()),'bytes')
