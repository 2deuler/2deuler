# Independent pass D — frozen revision v3

## A. Audit scope

**Independent mathematical verdict: PASS.** This verdict is bound to the current source identified below. It does not certify another pass or the coordinator's cross-pass reconciliation.

I reread the entire `proof.tex`, lines 1–951, in source order, every one of its 419 permanent containers, all 861 current shared children, all 584 formula occurrences, the neutral Markdown and JSON inventories, the notation ledger, the exact `target_problem.txt`, and the entire audit instructions. All mathematical content was reconsidered against this version, including unchanged steps, changed hypotheses, affected downstream uses, and the final target. Own earlier calculation notes were used only after exact identity and dependency review against the current source; every current container and child received a fresh current-version attestation. No earlier verdict was adopted without that check.

The frozen source SHA-256 is `8743ce99900bfb3df37bb4ccdae9aa9269cff12fc0a6abff7e4989a4eb426230`. The frozen inventory SHA-256 is `312e27c6941704d244f102a3907c290d82db5d41e68208e88b592b68d32adce7`. The snapshot filename is `proof.tex`; the neutral inventory records its original filename as `candidate_proof.tex`. Exact complete source anchors, current inclusive line spans, parent digests, modes, mathematical classifications, and child focus digests are included in the JSON ledger.

No other auditor's output, change/reconciliation manifest, route packet, or dependency-provenance file was opened. I did not call `list_agents` or communicate with other auditors. No mathematical work was delegated for this revision. No source or neutral inventory was edited, and the v1 and v2 outputs remain untouched.

There are no missing `input`, `include`, bibliography, or macro dependencies. All seven meaning-bearing macros were inspected. All 25 labels are unique and all 27 references have defined, semantically correct destinations. The inventory is an exact disjoint contiguous partition of all 45,329 source bytes. The permanent modes remain 380 SENTENCE, 37 STRUCTURAL, and two BOUNDARY-GROUP containers. S0176 and S0221 retain their frozen boundary-group identity; their complete formulas and grammatical scopes are mathematically determinate.

The named primary paper was independently retrieved and its exact interface checked. No external theorem needed by this pass remains unavailable. Standard analytic principles were matched to concrete hypotheses and, where helpful, reduced to explicit integrals, multiplier estimates, or difference bounds. Exact arithmetic and source-integrity computations are corroboration and are distinguished from mathematical proof.

## B. Coverage summary

| Item | Checked by current pass D | Frozen total |
|---|---:|---:|
| Source lines | 951 | 951 |
| Permanent containers | 419 | 419 |
| Mathematical containers | 388 | 388 |
| Nonmathematical containers | 31 | 31 |
| Compound containers | 253 | 253 |
| Shared children | 861 | 861 |
| Inline formula occurrences | 525 | 525 |
| Display formula occurrences | 59 | 59 |
| Algebra-bearing containers | 106 | 106 |
| External-theorem flagged containers | 23 | 23 |
| Proof environments | 8 | 8 |
| Major-result dependency maps | 8 | 8 |
| Uncovered source lines/containers | 0 | 0 |
| Unchecked mathematical containers/children | 0 | 0 |
| Missing pass-D verdicts | 0 | 0 |

The current parent outcomes are **388 VERIFIED** and **31 NOT MATHEMATICAL**; every other allowed status has count zero. Child outcomes are **858 VERIFIED** and **3 NOT MATHEMATICAL**. The three mechanical focus spans are S0130.C05 (empty), S0130.C10 (whitespace), and S0130.C11 (the cases delimiter); the full mathematical two-branch definition was checked in its complete parent scope.

All six consolidated neutral focus obligations, the fifteen children added in v2, and all six children newly added in v3 are included in the 861 and were directly checked. Direct comparison of current source anchors with this auditor's own v2 anchors found exactly three changed parents: S0058, S0229 and S0362. The other 416 parent texts were identical; all their current children and dependencies were nevertheless reread and affirmatively checked before retaining own earlier calculations. No additional omitted mathematical item requiring a new supplemental child was found. This pass created no local dispute items and has no unresolved mathematical concern; cross-pass escalation and dispute counts are reserved to the coordinator rather than inferred from unavailable other-pass outputs.

## C. Permanent-container ledger

The machine-readable companion `pass_d.json` contains one source-ordered record for every permanent container and one nested record for every current child. Each parent supplies the current exact source text, source file and line span, current SHA-256, mode, mathematical classification, aggregate status, and affirmative rationale. Each child supplies its current exact focus, digest, status, and rationale read with the entire parent. Where several focused fragments belong to one calculation, the complete affirmative parent calculation is repeated so no fragment is judged outside its hypotheses.

The ledger also contains eight explicit permanent-ID dependency maps, 23 theorem-hypothesis records, primary-source retrieval metadata, computation inputs/results, and empty issue/error-propagation lists. The report below explains the same dependency decisions in prose. It does not replace the exhaustive ledger with a selection of representative claims.

## D. Escalations and current-version sensitive checks

No container requires escalation on this independent pass's evidence.

### Three changed current parents and their propagated interfaces

| Parent and new children | Current direct check | Dependencies rechecked |
|---|---|---|
| S0058; C04–C06 | The primary domain is `L1 ∩ L_ul^p` and the displayed range is `C_b^(0,1−2/p)`. Taking `q=1,p=3` in Theorem 2.2 gives the stated bounded 1/3-Hölder map. Divergence vanishes for every member of that full domain; the plane boundary condition is empty. | S0054–S0059 and S0060–S0090; then the seed, every subsequent current-background LER use, the global iteration, and the final theorem. |
| S0229; C05 | For `|x|>1`, the entire unit disk containing the bump is a harmonicity region for `y ↦ G(x−y)`. Radial unit-mass averaging gives `G*U1=G`, and `U1(x)=0` there; differentiating gives the stated Hessian tail. | S0230–S0239, all Q bounds, old/new stress integrability, LER smallness and continuity, then global convergence. |
| S0362; C05–C06 | A nonnegative smooth cutoff can equal one on the closed plateau `[3/4,3/2]`. Its dyadic plateau intervals cover all positive times, including their shared endpoints, so the normalization denominator is at least one. | S0363–S0367, frozen pieces, exact cancellation, overlap bounds, color anchors and every-time trace closure through S0418. |

All three current parent conclusions and their affected dependencies are VERIFIED. No unchanged dependency was treated as valid merely because its exact bytes were unchanged. The ledger contains explicit parent-level revision dependency records; no error propagates from these checks.

### Full primary-source mapping check

The publisher renders three decisive formulas as images, not searchable mathematical text. I downloaded and visually inspected those exact primary images: Assumption 3.1's domain/range, Theorem 2.2's codomain, and its difference estimate (2.5). Their images and the retrieved article HTML are retained in `pass_d_work`; the ledger records retrieval references. In particular, the checked interface is a bounded map from the **full** `L1 ∩ L_ul^3` class to bounded 1/3-Hölder vector fields. It is not just an estimate for the particular smoothed datum.

Here is an independent derivation for that full domain. Write `M3=sup_z ||omega||_(L3(B1(z)))`. The radius-one near field is bounded by Hölder with exponents 3 and 3/2 because `|x|^-1` belongs to L3/2 of a disk; the far field is bounded by `C||omega||1`. For a displacement `h=|x−y|<1`, split the velocity difference into a disk of radius proportional to h, an intermediate annulus, and the far field. The near contribution is `C M3 h^(1/3)`. On the annulus the kernel difference is bounded by `C h/|x−z|²`; its L3/2 norm is `C h^(1/3)`, giving the same bound. The fixed far region contributes `C h||omega||1`, which is at most `C h^(1/3)||omega||1`. A fixed-radius enlargement changes the uniformly local norm by only a finite covering factor. For h at least one, twice the velocity sup norm gives the global Hölder estimate. Thus the domain/range assertion holds directly under exactly the displayed kernel hypotheses.

Distributional divergence is zero for every such omega, since omega is globally L1 and the translated-ball kernel bound permits distributional convolution and testing. A strictly positive divergence-bound constant allowed by the article may be chosen arbitrarily because the actual divergence is zero. Bounded vorticity satisfies `M3 <= pi^(1/3)||omega||infinity`, uniformly over all unit-ball centers and, on a bounded-vorticity finite horizon, uniformly in time.

I inspected the actual proof of Theorem 3.3, not just its heading: its construction applies the divergence bound (3.1) to bounded-vorticity frozen-time data and obtains bounds (3.11)–(3.12); the p=3 domain contains all of them. Its spatial modulus is obtained from the bounded-vorticity logarithmic estimate, and its canonical velocity is identified in the passage to the limit. This use requires no assertion that the p=infinity endpoint of the displayed Hölder map is Lipschitz. The manuscript's separate flow-representative, relative-L2, velocity-equation and initial-trace arguments remain necessary and were checked in S0065–S0090.

### Other current formulations and interfaces rechecked

The following source formulations were also checked with their downstream dependencies:

| Containers | Current statement checked | Direct verification and downstream use |
|---|---|---|
| S0049 | Only the differentiated low-frequency multipliers are also L2 | Near zero their order is `|xi|^(|alpha|-1)` for positive alpha; the undifferentiated `1/|xi|` multiplier is claimed only L1. This preserves nonzero-circulation data. |
| S0139, S0141 | Unit directions, simultaneous velocity/pressure rotation, `P_r=r^-2 P(x/r)` | Orthogonal rotation preserves the equation; all three scaled equation terms acquire `r^-3`. Norms have exactly the displayed powers. |
| S0158–S0159 | C1 visit parameters and an explicit translation operator | The time chain rule is justified by the stated hypotheses. Its translation term cancels dipole motion, and both remaining right-hand profiles carry the same translation. |
| S0164, S0214–S0217, S0225–S0239 | One fixed smooth radial probability bump and its explicit dilation | Change of variables yields the uniform gradient and projected-profile scaling. The quadrature and corrector estimates now follow from the actual defined family. |
| S0167 | Both intrinsic stress terms explicitly translated | Spatial divergence commutes with translation, and L1 norm is translation invariant. No derivative of the stress in time is taken. |
| S0242, S0252–S0260, S0337–S0344 | Piecewise time smoothness is asserted for the new correction after fixed spatial mollification | Actual scan parameters are smooth on visits; convolution gives the needed spatial derivatives. Zero traces preserve continuity at resets, and old-background smoothness is not used. |
| S0247 | Symmetry of the assembled stress from transpose pairs | Every mixed dyad occurs with its transpose; all other displayed stress terms are symmetric. The individual Holder bounds remain valid for the unpaired dyads. |
| S0268, S0278 | J is an open interval | A compact temporal support has a containing `[a,b]` compactly inside J. Every global dyadic patch meets this interface. |
| S0304 | Peak amplitudes are uniformly bounded in the cycle count | `eta_i^2=(2/pi)dB_i` may vary but stays bounded at fixed coarse data and floors. Interior and ramp derivative formulas use only this bound and fixed logarithmic derivatives. |
| S0357–S0360 | Weak subsequences explicitly use `t_n` decreasing to zero | The uniform global L2 bound gives a subsequence, and the established zero-time pairings identify its divergence-free/curl-free limit as zero. |
| S0373, S0384–S0386 | Exact positive `kappa_qj=2^-q/N` and `r_*=1` | These meet every LER budget. An upper increment bound still permits choosing a smaller increment for cross-stress tolerance; no later common radius schedule is needed. |

The other consolidated focuses were also independently checked: S0084.C03 follows from a Lipschitz L2 Bochner integral and the norm-one multiplier; S0130.C13 follows from the Cartesian Bessel power series at the origin; S0162.C03 follows from the negative gradient boundary flux. Their explicit focused rationales appear in the ledger.

## E. Definite mathematical errors

None was found in the current frozen source by this pass. There is no earliest erroneous current container and no propagated-error descendant list. This conclusion follows from affirmative local and global checks, rather than absence of a quickly found counterexample.

## F. Unjustified, ambiguous, or source-dependent items

None remains on this pass. No missing regularity, profile choice, normalization, source theorem, or time-representative assumption is silently inserted into the current proof. The target does not require an energy inequality, uniqueness, transported or renormalized limiting vorticity, or a uniform-in-stage global L3 bound; those stronger properties are neither used nor certified.

## G. Dependency and global consistency report

Every range below denotes the specified permanent IDs inclusively; all listed dependencies have pass-D status VERIFIED. The JSON supplies each range as an explicit ID array.

### 1. Canonical decomposition: S0034–S0039, proof S0040–S0052

| Dependency | IDs | Function in the argument |
|---|---|---|
| Exact datum/kernel conventions | S0026–S0033 | Finite signed measure, inhomogeneous H^-1, Fourier and curl orientation |
| Local convolution and distribution identities | S0040–S0043 | Define K*mu without spatial moments or compact support |
| Radial cancellation and L1 kernel | S0044–S0046 | `L_a=K-K*a` is compactly supported and integrable |
| High-frequency multiplier estimate | S0047–S0048 | v0 is global L2 under exactly inhomogeneous H^-1 |
| Low-frequency multiplier and finite-measure convolution | S0049–S0052 | V0 is bounded smooth C0; all claimed derivative and variation bounds |

The decomposition preserves nonzero total circulation in V0. It does not replace inhomogeneous H^-1 by homogeneous H^-1. Its L1 component is essential to the bounded initial stress, and its C0 component is used again in the final normalization.

### 2. Bounded background: S0060–S0061, proof S0062–S0090

| Dependency | IDs | Function |
|---|---|---|
| Smoothed datum properties | S0034–S0052 | nu0 is signed L1∩Linfinity, with finite L2 norm |
| External bounded-vorticity existence interface | S0054–S0059, S0062 | Full finite-p mapping domain/range, kernel and divergence hypotheses, then one global canonical Lagrangian source solution |
| Osgood flow and volume preservation | S0065–S0072 | Every-time representatives and L1/L2 norm preservation |
| Near–far velocity bound and weak-L2 distribution function | S0073–S0082 | Uniform bounded velocity and global L3 |
| Integrated transport and order-zero Fourier multiplier | S0083–S0088 | Every-time relative L2 Lipschitz continuity and C_tL3 |
| Curl-free acceleration | S0089–S0090 | Distributional velocity Euler equation and pressure |

No smoothness theorem for the rough global background is invoked. The time representative is fixed before it is used in every-time estimates. The pressure is obtained from a globally L2 curl-free acceleration; global L2 of V itself is unnecessary.

### 3. Initial Euler–Reynolds seed: S0096–S0100, proof S0101–S0114

| Dependency | IDs | Function |
|---|---|---|
| v0 in L1∩L2, sigma0 finite | S0034–S0052 | Convolution and integrable cross stresses |
| Global background and initial trace | S0060–S0090 | Exact old Euler equation, bounded V, C_tL3, relative L2 |
| ER sign and quartic kernel | S0092–S0095 | Stress sign and `partial_t W=-4t^3 Delta^2 W` |
| Divergence identity and kernel derivative scaling | S0101–S0108 | Symmetric derivative stress has L1 cost C t||sigma0|| |
| Trace and positive-time product continuity | S0109–S0114 | All inputs needed for LER and the iteration majorant |

The stress remains bounded as t approaches zero, even when initial vorticity is singular. The factors C_b are retained because the quartic kernel need not be positive.

### 4. Prescribed-piece LER: S0261–S0275, proof S0276–S0349

| Dependency | IDs | Function |
|---|---|---|
| Explicit translating dipole | S0122–S0142 | Unit directions, simultaneous rotation, explicit pressure scaling, core matching and critical L2/curl norms |
| Symmetric anti-divergence | S0144–S0156 | Zero mean and all first moments give globally integrable stresses |
| Compact packet source | S0158–S0168 | C1 visit hypotheses, explicit translations, fixed bump dilation, exact source and small intrinsic error |
| Directional stress coefficients | S0171–S0178 | Nonnegative decomposition of `-S+qI` with universal mass bound |
| Positive-floor raster, ramps, exact normalization | S0181–S0209 | Single active packet; exact cycle duration and row weight |
| Two-scale rectangle rule | S0210–S0219 | d=H² samples a bump of width H with vanishing L1 error |
| Projected full-cycle primitive | S0221–S0242 | Exterior identity on the explicit disk complement, global profile norms, small Q, zero endpoint trace and pressure sign |
| Nonlinear stress identity | S0243–S0250 | All old/new and new/new terms with integrable global bounds |
| Constant-cycle spatial smoothing | S0252–S0260 | Spatial smoothness without remollifying old fields or adding time-kernel errors |
| Coarse L1 approximation and parameter order | S0276–S0328 | Independent stress, amplitude, L3/2 and radius budgets |
| Boundary choices and continuity | S0329–S0349 | Exact every-time algebra, distributional pasting and preservation of the class |

The universal leading bound follows from `eta_i²=(2/pi)d B_i` and the coefficient L1 bound. Derivative norms, rectangle size, positive-floor reciprocals and the current old-field L3 norm only determine how small H must be. The number of coarse cells does not multiply the instantaneous amplitude, because their time interiors are disjoint. Within a cycle only one principal packet is active.

The source reduction's factor 2pi was checked independently by the two boundary fluxes: the integral of D_r over a large disk is pi r xi, while the integral of grad Pi_r is -pi r xi. Their compact difference has mean 2pi r xi. The zero first moments then permit the stated integrable anti-divergence. The complete-cycle integration by parts has positive sign: `(eta r U_H(x-X))'=(eta r)'U_H-eta² xi·grad U_H`. This produces the required averaged rank-one tensor.

The projected-bump pressure was also checked directly. From `Q'=-P(U-Ubar)`, one gets `Q'+U=Ubar+grad(pi_U-average pi_U)`; the chosen `p_Q=-pi_U+average pi_U` cancels it. Subtracting `qI` from the final stress requires subtracting q from the intermediate pressure, as S0318 states. The spatial commutator has positive right-hand-side sign `v_ell⊗v_ell-(v⊗v)_ell`.

### 5. Anchor-time trace lemma: S0351–S0353, proof S0354–S0360

The only earlier dependency is the ER convention S0092. The lemma explicitly assumes uniform local kinetic energy, global L1 stress, positive-time continuous local L2 velocities, a globally bounded L2 difference, and actual zero difference at times descending to zero.

Testing the difference against compact solenoidal fields gives a uniform Lipschitz bound on the pairing. Its zero anchors force zero limiting pairings. For each expressly stipulated sequence of times decreasing to zero, boundedness in the Hilbert space L2 supplies subsequential weak compactness. A cluster point is both divergence free and curl free, and its Fourier transform vanishes off frequency zero; an L2 transform cannot be supported at that single point. Thus the entire difference has weakly zero initial trace. No global velocity energy or pressure estimate is assumed.

### 6. Global iteration: S0361, proof S0362–S0406

| Dependency | IDs | Function |
|---|---|---|
| Admissible seed and bounded initial stress | S0096–S0114 | Base stage, exact trace and finite majorant Theta |
| LER, including independent prescribed piece | S0261–S0349 | Remove each original chi_j R^(q) using the current repaired pair |
| Three-color dyadic geometry | S0362–S0367 | Explicit unit plateau and positive denominator, local finiteness, bounded overlap and exact gap anchors |
| Stress budget and stage estimates | S0368–S0387 | Pointwise stress decay and summable L2/curl increments |
| Anchor lemma and partial-color bounds | S0351–S0360, S0388–S0392 | Every finite stage retains the exact weak initial trace |
| Uniform correction convergence | S0393–S0400 | Positive-time strong continuity and every-time finite curl variation |
| Quadratic limit and initial temporal cutoff | S0401–S0406 | Exact target weak equation including t=0 |

The exact choices `kappa_qj=2^-q/N` and `r_*=1` are positive and satisfy LER; the upper L3/2 budget does not prevent making an increment still smaller to meet the stress tolerance. The frozen pieces sum to the original stage stress even after earlier colors change the background. This avoids a circular cancellation assumption. Within a color, temporal supports are disjoint, so cross terms between its separate patch increments vanish. Different colors are processed sequentially with all actual current-field cross terms charged in LER.

At every active time, `m_j<=Theta(t)`, yielding the pointwise next-stage stress bound. If a patch meets `(0,T]`, its whole interval lies in `(0,4T)`, yielding the stage increment constant involving only `Theta(4T)`. The square-root geometric sequence is `4^-q`, whose sum is finite. Partial colors satisfy the same bounds, which is essential before applying the trace lemma.

The infinite union of all stage boundaries need not be locally finite; the proof never uses that stronger statement. Local finiteness is required at each finite stage only. The limiting equation follows from uniform L2 convergence and vanishing stress, and the limiting every-time curl follows from an absolutely convergent L1 series at each fixed time. No weak compactness argument is substituted for this strong quadratic passage.

### 7. Fixed-background normalization: S0407–S0408, proof S0409–S0413

Dependencies are the finite-measure convolution bound and distributional kernel identities S0040–S0043. They do not require later-time H^-1. For `u=U+v`, with U in C0 and v in global L2, the residual `h=u-K*mu` is locally integrable and distributionally harmonic. Weyl's lemma is applicable componentwise.

The average estimate separates the three terms exactly. The U average tends to zero by C0 decay; the v average is at most C||v||2/R; and the Biot–Savart average is at most C||mu||/R. Letting R grow forces h to vanish. This excludes constant and other harmonic velocity additions without imposing zero circulation.

### 8. Exact-target global theorem: S0414, proof S0415–S0418

Dependencies are S0361–S0406 for the global velocity and weak initial formulation; S0407–S0413 for canonical normalization; S0038/S0050 for V0 in C0; S0060/S0084/S0086 for every-time `V(t)-V0` in L2; S0098/S0104 for W(t) in L2; and S0384/S0393 for the L2 correction series.

At each positive time the same fixed C0 background V0 is used. Its perturbation is `(V(t)-V0)+W(t)+sum_q w_q(t)`, a globally L2 vector field. The final curl is a finite measure at that exact time, so the canonical lemma applies time by time. At zero the input identity `u0=K*mu0` is already prescribed. The construction is global from the outset; no independently chosen finite-horizon solutions must be glued.

## Exact-target and admissibility table

| Target/interface requirement | Established in | Check |
|---|---|---|
| All finite signed measure∩inhomogeneous H^-1 data | S0027, S0034–S0052 | No Jordan-part energy, compact support, moment, sign, or zero-mass condition added |
| Canonical initial velocity in local L2 | S0035–S0052 | Finite-measure convolution plus bounded/L2 decomposition |
| Positive-time finite-stage C_t local L2 and global L3 | S0100–S0114, S0337–S0348, S0379 | Exactly the class used in LER; no uniform stage L3 conclusion used |
| Symmetric integrable stresses | S0096–S0108, S0244–S0247, S0317–S0348 | Every cross dyad is paired; tails retain global L1 integrability |
| One-sided time-partition traces and actual boundary values | S0263–S0265, S0281–S0282, S0333–S0335 | Actual values are independent of traces and do not alter the distributional equation |
| Every finite-stage exact initial trace | S0388–S0392 | All anchor lemma hypotheses checked for each of three colors |
| C_w([0,infinity);L2_loc), u(0)=u0 | S0393–S0396 | Strong positive-time limit; finite-head/small-tail weak trace at zero |
| Every-time measure curl and finite-horizon variation | S0397–S0399 | Positive-time L1 curl series plus the initial finite measure |
| Divergence zero | S0400 | Distributional passage from every finite stage |
| Quadratic Euler term and initial weak formulation | S0401–S0406 | Strong local L2 convergence, vanishing stress, bounded-energy cutoff |
| Canonical velocity at every time | S0407–S0417 | Fixed C0 background normalization, applied separately at each positive time |

The basic fields are strongly measurable in their claimed Banach spaces. Background time continuity precedes its Bochner integrals. New increments are continuous in the required Lp spaces. The stress pieces have continuous one-sided L1 extensions with only locally finite exceptional times at each finite stage; thus their integrals and weak equations are defined. Countable patch sums are locally finite at positive time. Uniform correction bounds ensure all compact-cylinder linear and quadratic integrals converge. At zero the local energy bound controls omitted integrals, while weak local continuity identifies the initial term.

## Constants and parameter order

The compatible order for each LER application is:

1. Fix a compact time interval and a finite inherited one-sided partition.
2. Choose the coarse approximation tolerance satisfying both the stress and amplitude slack requirements; choose the finitely many smooth compact tensors.
3. Fix their rectangles and ramps, then choose positive regularization and floor masses small enough for both averaging and amplitude budgets.
4. Increase each integer cycle count. Set `tau=cell length/N`, `H=tau^(1/6)`, `d=H²`; use the exact amplitude/radius normalization.
5. After the cycle counts are finite and fixed, choose the constant-in-cycle spatial mollification scales small enough for the remaining commutator and averaging errors.

The peaks depend on the integer cycle counts but are uniformly bounded; all derivative estimates use this uniform bound. The single fixed bump U in S0164 gives `||grad U_H||1=H^-1||grad U||1` and the exact projected-profile dilation. At fixed coarse data, the principal radii are comparable to H⁸, the compact-source radius is O(H^(8/5))=o(H), the intrinsic stress is O(H|log H|)+O(H⁸), the corrector's L2 and curl-L1 norms are O(H⁵), its L3/2 norm is O(H^(16/3)), and the principal L3/2 norm is O(H^(8/3)). Each needed error therefore vanishes. Positive floors are fixed before these limits, so their potentially large logarithmic derivative constants are harmless. No parameter must be simultaneously fixed and sent to zero in an incompatible order.

## External theorem and standard analytic interface checks

The primary [Crippa–Stefani article](https://link.springer.com/article/10.1007/s00526-024-02750-4) was independently retrieved again for this revision and inspected at Assumptions 2.1 and 3.1, Definition 3.2, and Theorem 3.3. The current retrieval references are recorded in `pass_d.json`. It supplies the bounded-vorticity Lagrangian interface claimed in the manuscript. The datum nu0 satisfies its signed L1∩Linfinity condition. With `q=1,p=3`, Theorem 2.2 supplies the full operator domain/range in Assumption 3.1; divergence is zero on that entire domain and the plane has no boundary condition. The primary image formulas and actual proof uses were inspected as detailed above. The manuscript separately proves every-time representatives, norm preservation, relative L2 continuity, L3 continuity, and the velocity formulation. It does not attribute those extra steps to an unavailable smoothness result.

All 23 inventory-flagged containers received the following matching:

| Container(s) | Principle and hypotheses actually checked |
|---|---|
| S0040 | Tonelli for the nonnegative absolute kernel integral; finite translated-ball bound times finite measure mass |
| S0046 | L1 Young/measure convolution; integrable compact kernel and finite total variation, proved directly by Tonelli |
| S0048 | Plancherel with the explicit bounded multiplier weighted by `(1+|xi|²)^-1`; exactly inhomogeneous H^-1 |
| S0050 | Fourier inversion and Riemann–Lebesgue for bounded mu-hat times the checked L1 multipliers, including every differentiated one |
| S0054, S0062 | The named primary theorem and its exact datum, domain, kernel, divergence and canonical-solution interfaces |
| S0058 | Primary Theorem 2.2: q=1, p=3, full `L1 ∩ L_ul^3` domain, bounded 1/3-Hölder codomain, both kernel hypotheses; Assumption 3.1: divergence bound on that full domain and empty whole-plane boundary condition; bounded approximants in Theorem 3.3 lie in it |
| S0065 | Osgood reciprocal-modulus divergence; bounded time-measurable velocity gives global finite-horizon trajectories, uniqueness and backward flow |
| S0067 | Spatially smooth mollified velocity, bounded derivatives at fixed scale, divergence zero; the Jacobian ODE preserves volume |
| S0069 | Dominated convergence on a common bounded transported-support set, supplied by the displacement bound |
| S0081 | Chebyshev applied to the L1 near convolution at threshold lambda/2; zero-measure case is trivial |
| S0082 | Nonnegative layer cake, with weak-L2 distribution bound and bounded-velocity upper cutoff |
| S0104 | Plancherel contraction and dominated convergence against `|v0-hat|²` |
| S0110 | Absolute Fubini against compact tests using the translated-ball kernel bound and finite convolution masses |
| S0126 | Intermediate value theorem for the continuous Bessel power series and exact opposite endpoint signs |
| S0128 | Uniqueness for the regular linear Bessel ODE at positive beta, with zero value and derivative |
| S0214 | Fundamental theorem for a C1 map into L1; integrated triangle inequality over each finite row interval |
| S0232 | Minkowski/Bochner integration for finite-time translates of an explicitly bounded Lp profile, p>1 |
| S0256 | Approximate identities are uniformly convergent on compact L2 and L1 sets; continuity of squaring connects them |
| S0309 | Hölder pairs (3,3/2) and (2,2), with finite old global L3 norm on a compact interval |
| S0338 | Young exponents 2 and 6/5 to 3; `||rho_ell||_(6/5)=C ell^(-1/3)` |
| S0357 | The current statement explicitly takes every sequence `t_n` decreasing to zero; the uniform global L2 bound gives a Hilbert weak subsequence, in the regime needed for the next zero-pairing argument |
| S0409 | Weyl for a locally integrable distribution with Delta h=0; the div/curl identity establishes this hypothesis componentwise |

## Edge cases and independent corroboration

- **Zero datum/zero prescribed stress:** the datum decomposition is zero when mu=0; LER explicitly uses the zero correction when delta=0. No zero amplitude is divided by in an active scan.
- **Zero directional coefficient:** an idle quarter-cycle is allowed; otherwise a fixed positive floor supplies positive B_i and positive radius. Vanishing original coefficients on individual coarse cells do not obstruct adding arbitrarily small floors.
- **Nonzero circulation/noncompact data:** the bounded C0 background absorbs the 1/|x| far field; no global L2 velocity or finite first moment is used. The canonical lemma uses only finite measure mass.
- **Signed cancellations:** all kernel and stress estimates use total variation or absolute norms. No positivity of the original vorticity or its Jordan components is assumed.
- **Spatial infinity:** the anti-divergence retains all first-moment cancellations, eliminating the nonintegrable generic 1/|x|² stress tail. The projected velocity has a 1/|x|² tail in every Lp, p>1, and old/new products use L3–L3/2, not an unjustified L2–L2 estimate for the background.
- **Circle/core interfaces:** exact Bessel identities match the streamfunction through two spatial derivatives; q=0 at the circle removes boundary vorticity/pressure terms. The polar origin is removable by the power series.
- **Temporal resets:** flat amplitude endpoints make the packet vanish, the full-cycle primitive makes Q vanish, and stress jumps are allowed because only spatial divergence acts on them. A change of smoothing scale occurs only at zero increment traces.
- **Approach to zero time:** stage energy need not approach the seed energy strongly. The anchor lemma supplies weak trace and the uniformly small L2 tail passes it to the limit. This is the exact continuity requested by the target.
- **Unbounded final stage derivatives/L3 norms:** fine profiles may have large derivatives and global L3 norms, but each finite stage satisfies LER and the convergence proof uses only the uniformly summable norms it actually establishes.

Exact rational arithmetic was rerun against the current formulas and confirmed the alternating-series truncations `J1(3)` through k=3 as `669/2048=(3/2)(223/1024)` and `J1(4)` through k=4 as `-2/45`. The alternating remainder signs were checked analytically from the term ratio. Exact rational matrix tests at a mixed-sign and a zero stress agreed with `-S+(A+B)I`; the universal tensor equality was separately proved by component expansion, so the finite tests are corroboration only.

## H. Pass-D completeness certificate

- PASS — The entire received v3 TeX source was inventoried and examined: one file, 951 lines, no missing include or mathematical source dependency.
- PASS — Every source byte and line belongs to the frozen 419-container partition; all 45,329 bytes, parent hashes, child spans and formula spans were validated.
- PASS — All permanent parent and child identifiers and frozen source bytes remained unchanged during this pass.
- PASS — All 253 compound containers were inspected with the single shared non-recursive layer; all 861 children were checked in their current parent scope.
- PASS — Every permanent container has a current pass-D verdict: 388 VERIFIED and 31 NOT MATHEMATICAL; zero missing D verdicts.
- PASS — All 388 mathematical parents, all 858 mathematical child focuses, and all remaining simple or parent-scope mathematical content received affirmative checks; three mechanical child spans were explicitly inventoried as nonmathematical.
- PASS — All 584 formula occurrences were checked: 525 inline and 59 display occurrences; their exact spans and digests match the current source.
- PASS — All 106 algebra-bearing containers were independently re-derived, including signs, powers, constants, pressure conventions, translations and moment cancellations.
- PASS — All 23 theorem-application containers have explicit hypothesis matching; the named primary theorem was retrieved independently for this revision.
- PASS — All eight proof environments were checked locally and globally, and all eight major results have current permanent-ID dependency maps.
- PASS — Degenerate, signed, noncompact, spatial-infinity, interface, temporal-reset, zero-time and every-time cases were investigated.
- PASS — Definitions, parameter scopes, all seven meaning-bearing macros, 25 labels and 27 references were checked throughout the source.
- PASS — Assumption preservation, constants, limiting order, admissible classes, dependencies, exact target matching and potential error propagation were checked; no current error chain was found.
- PASS — This independent pass has no unresolved mathematical finding, omitted shared check or required local dispute; zero new supplemental checks were needed.
- PASS — Computation inputs and exact results are recorded separately from analytic proof; no unavailable source or unperformed method is claimed as evidence.
- PASS — The certificate is strictly for independent current-version pass D. Other passes' coverage, cross-pass escalation/reconciliation and the combined final certificate remain the coordinator's responsibility and are not asserted here.
