# Independent PASS A — frozen revision v3

**Mathematical verdict for this independent pass: PASS.** All 388 mathematical parent containers and all 858 mathematical child checks are affirmatively verified against the frozen v3 source. The remaining 31 parents and three children contain only non-mathematical material. No further definite error, unjustified claim, material ambiguity, unavailable source or supplemental mathematical check was found. This report does not certify other passes or their reconciliation.

## A. Audit scope

The examined source is `audit_v3/proof.tex`, the frozen revision of `candidate_proof.tex`, lines 1–951, all 45,329 bytes. Its SHA-256 is `8743ce99900bfb3df37bb4ccdae9aa9269cff12fc0a6abff7e4989a4eb426230`. The neutral inventory SHA-256 is `312e27c6941704d244f102a3907c290d82db5d41e68208e88b592b68d32adce7`.

The entire current source was reread in source order through all 419 full parent texts, with every one of the 861 current children read in its full parent context. The exact target, neutral notation, inventory and all 584 formula occurrences were inspected. Exact byte checks establish that the permanent parents form a disjoint contiguous partition of the whole source; all parent, child and formula text hashes match their current spans. The Markdown index lists the same 419 IDs in order. All figures in the manuscript are formulas; no TeX include or bibliography dependency is missing, and no mathematical macro remains unresolved.

The source segmentation was unchanged: 380 sentence containers, 37 structural containers and two retained boundary groups. Whole aligned displays stay attached to their sentence and use a single nested layer. Direct identity comparison against this auditor's own v2 anchors found 416 unchanged parent byte sequences and three changed sequences, S0058, S0229 and S0362. All six new children were checked. Every current claim and the affected background, profile, partition and global dependencies were rechecked before assigning current verdicts; unchanged prior derivations were reused only as explanatory text after that review. Old verdict labels were not used to assign v3 statuses. Every output parent and child carries the full current manuscript hash and its current focus hash. V2 artifacts were preserved.

No other pass output, reconciliation or change manifest, route, checkpoint or dependency-provenance file was read. No agent-status listing or contact with other auditors occurred. Findings were communicated only to the coordinator. The substantive external input was independently reopened at its original primary URL, including the original image containing Assumption 3.1's domain and range. The actual uses of that assumption in the proof of Theorem 3.3 were inspected. The source image is retained as `pass_a_assumption31.png`.

Technical limits: this is a mathematical audit, not a machine formalization. Exact rational arithmetic was rerun for the two displayed Bessel partial sums. No numerical agreement is used as universal proof and no unavailable symbolic package is claimed. The final cross-pass checklist below distinguishes this pass's verified coverage from orchestration facts it has not inspected.

## B. Coverage summary

| Item | Examined by Pass A |
|---|---:|
| Source files | 1 / 1 |
| Source lines | 951 / 951 |
| Source bytes | 45,329 / 45,329 |
| Permanent containers | 419 / 419 |
| Sentence / structural / boundary-group containers | 380 / 37 / 2 |
| Compound containers | 253 / 253 |
| Mathematical / non-mathematical parents | 388 / 31 |
| Shared children | 861 / 861 |
| Mathematical / layout-only children | 858 / 3 |
| Inline / display formula occurrences | 525 / 59 |
| Total formulas | 584 / 584 |
| Algebra-bearing containers | 106 / 106 |
| Standard/external theorem-invocation containers | 23 / 23 |
| Proof environments / major-result maps | 8 / 8 |
| Proposed supplemental children | 0 |
| Uncovered lines / bytes / containers | 0 / 0 / 0 |
| Missing Pass A parent / child verdicts | 0 / 0 |

Parent status counts: 388 VERIFIED and 31 NOT MATHEMATICAL; zero ERROR, UNJUSTIFIED, AMBIGUOUS, DEPENDS ON EARLIER ERROR or NOT VERIFIABLE FROM PROVIDED MATERIAL. Child counts: 858 VERIFIED and three NOT MATHEMATICAL, namely the frozen empty/alignment/case-closing focuses S0130.C05, S0130.C10 and S0130.C11. The full mathematical cases remain verified in their parent and mathematical siblings.

This pass proposes zero v3 escalations and zero supplemental claims. No coordinator-owned local dispute identifiers were allocated here, and zero cross-pass reconciliation items are claimed as resolved by this independent pass. Other passes' coverage and reconciliation are deliberately uninspected.

## C. Permanent-container and nested-check ledger

`pass_a.json` contains one source-ordered record for every S0001–S0419, all 861 children, current container/focus hashes, the full current manuscript hash, current-version attestations and affirmative rationales. `pass_a_notes.tsv` is the current parent-rationale index. The unchanged `audit_inventory.json` supplies exact full TeX anchors, original filename, line/byte spans, modes and child scopes; joining by permanent ID and digest produces the exact anchored ledger without altering or normalizing source text. No verified or non-mathematical parent is omitted.

### Direct checks of the three revised assertions

**S0058: finite-exponent external mapping.** The primary Assumption 3.1 image states

\[
K:L^1(\Omega)\cap L^p_{ul}(\Omega)\longrightarrow
C_b^{0,1-2/p}(\Omega;\mathbb R^2).
\]

Its p=3 instance has exponent 1/3. Theorem 2.2 applies with q=1 and p=3; both are inside its stated ranges. The manuscript's exact kernel size/difference identities match Assumption 2.1, distributional divergence is zero, and the plane has no boundary condition. The proof of Theorem 3.3 uses Assumption 3.1's divergence bound on bounded integrable time-step vorticities; those lie in L1∩L3_ul. Its log-Lipschitz estimates arise separately from Corollary 2.4. Thus this application does not require a Lipschitz endpoint map. The theorem still supplies global Lagrangian transport and the initial-value equation. genui{"citation":{"refs":["turn128view0","turn131view0"]}}

The finite-exponent mapping was also checked directly. If `A=sup_x||ω||L3(B1(x))`, then the near part of K has finite L3/2 norm and the far part is bounded against `||ω||1`; hence `||K*ω||∞≤C(A+||ω||1)`. For displacement h<1, the near ball has contribution `C A h^(1/3)`. On the intermediate annulus the kernel-difference bound and Hölder give

\[
C A h\left(\int_h^1 r^{-3}r\,dr\right)^{2/3}
\le C A h^{1/3}.
\]

The far contribution is at most `C h||ω||1`, and boundedness handles h≥1. Fixed-radius enlargements are covered by finitely many unit balls. This proves the entire stated bounded Hölder map, not only membership for the particular initial datum. Moreover `||ω||L3(B1(x))≤π^(1/3)||ω||∞`, uniformly in the center, so every bounded-vorticity input in the cited construction is in this domain. S0058.C04–C06, all preceding kernel children, and the affected background and seed conclusions are VERIFIED.

**S0229: exterior radial identity.** Its current text says exactly: “For `$|x|>1$`, radial averaging gives `$G*U_1=G$`, so `$Z_{1,\xi}=-D^2G\xi=O(|x|^{-2})$`.” Every shell of the radial probability U has radius s<1. Its angular mean obeys `mean log|x-s e^(iθ)|=log|x|` for |x|>1. Integrating the unit mass gives equality with G and no additive constant. Since U vanishes on that open exterior, taking two derivatives yields Z=-D²G ξ. The explicit Hessian is `(2π|x|²)^(-1)(I-2e_r⊗e_r)`, proving the tail. Annular support causes no exception in this domain; its holes lie in the separately bounded core S0228. The current equality, the new domain child S0229.C05, all profile norms and their later uses are VERIFIED.

**S0362: positivity of the dyadic partition.** A compact smooth cutoff on (1/2,2) equal to one on [3/4,3/2] exists because the closed plateau is strictly inside the open interval. For every t>0 set `j=floor(log2(4t/3))`. Then `3/4≤t/2^j<3/2`, so one denominator summand is exactly one. Both plateau endpoints are included, and no dyadic endpoint gap remains. Only finitely many summands occur near each positive t, making the denominator smooth and ≥1. Each χ_j is nonnegative, compactly supported inside I_j, and their sum is one. The new children S0362.C05–C06 and the whole partition/telescoping/anchor chain are VERIFIED.

### Reconstruction across the current manuscript

1. **Initial normalization, S0026–S0052.** With `G=(2π)^(-1)log|x|`, the convention `∇⊥=(-∂2,∂1)` gives `K=∇⊥G`, `curl K=δ0` and multiplier `-i ξ⊥/|ξ|²`. The local integral of `|K|` over any translated radius-R disk is at most `CR`; Tonelli and truncation in total variation justify arbitrary noncompact finite measures. Radial averaging gives `K*a=K` beyond the support disk, so `K-K*a` is compactly supported and L1. Evenness gives `|1-â|≤C min(|ξ|²,1)`, hence `(1+|ξ|²)|(1-â)m|²≤C`, exactly the inhomogeneous H^-1 to L2 estimate. At zero `mâ` is L1 but generally not L2; the revised sentence S0049 explicitly makes square integrability a claim about the positive-order differentiated multipliers. No zero circulation, first moment or global initial kinetic energy is used.

2. **Bounded background, S0054–S0090.** The cited existence input applies to signed `ν0=a*μ0∈L1∩L∞`; the explicit p=3 domain/range match and its use in the original construction are checked below. The manuscript then derives its own all-time representative. Spatially mollified divergence-free bounded velocities have Jacobian one; the common Osgood modulus yields convergence of flows and inverses, and bounded displacement gives a fixed support enlargement for passing volume preservation by dominated convergence. Pullback of ν0 preserves L1, L2 and L∞ norms, and approximation by compact smooth functions gives `ν∈C_t L1∩C_t L2`. The near/far bound gives `V∈C_t L∞`; weak L2 plus layer cake gives `||V||3³≤C||ν||1²||V||∞`. For `F_t=∫_0^t Vν`, the product is strongly continuous in L2. The multiplier of `-K div` is `-ξ⊥⊗ξ/|ξ|²`, of operator norm one, so `V(t)-V0` is a strong L2-continuous primitive and has the stated coefficient-one bound. The curl of the L2 acceleration vanishes by transport; its negative potential is pressure. This requires no global L2 norm of V itself.

3. **Seed and the mixed-stress endpoint, S0092–S0119.** The multiplier `exp(-t⁴|ξ|⁴)` gives `∂tW=-4t³Δ²W`; `div(∇ΔW+(∇ΔW)^T)=Δ²W` since `div W=0`. Thus the derivative stress has precisely the displayed negative sign and factor four. Two derivatives of `b_t` cost `t^-2` in L1, leaving `O(t)||σ0||M` after multiplication by `t³`. The curl estimate uses `||b||1`, not positivity of b. Products with the old background use exponents 3 and 3/2. The illustrative swirl has finite energy and curl variation but divergent L3/2 tail; its product with a `1/r` circulation background has integral comparable to `∫dr/(r log r)`, so that example and its stated limitation are correct.

4. **Dipole, S0122–S0142.** Exact Python `Fraction` summation was rerun: the J1(3) sum through m=3 is `669/2048=(3/2)(223/1024)>0`; the J1(4) sum through m=4 is `-2/45<0`. The ratio of successive magnitudes is `(z/2)²/((m+1)(m+2))`, strictly below one throughout the relevant tails, so the next-term signs justify both bound directions. The Bessel ODE at a common hypothetical zero of J1 and J0 would give zero value and derivative at a regular point, contradicting `J1(z)=z/2+O(z³)`. At the origin the interior ψ is a Cartesian power series times x2; no polar singularity remains. At radius one the radial values and first two derivatives match as `-1,1,-2`, making D C1. With `q=ψ+x2`, `D-e1=∇⊥q` and `curl D=-β²q`, direct component expansion gives the displayed pressure sign. S0139 explicitly provides unit directions and rotated, scaled pressure `P_r=r^-2P(x/r)`. Norm scaling gives L2 and curl L1 invariance and the L3/2 exponent 1/3.

5. **Anti-divergence and variable radius, S0144–S0168.** Componentwise differentiation of A cancels the two gradient-divergence terms and leaves f. Its degree-minus-one kernel has an `L1(B3R)` contribution at most `CR||f||1`. Canceling both zeroth and first moments leaves `CR²|x|^-3||f||1` outside B3R, whose radial integral is again `CR||f||1`. Only mean cancellation would leave a generally nonintegrable degree-minus-two term. The radius derivative satisfies `∂rD_r=D_r/r-div(D_r⊗x/r)`; exterior homogeneity makes that divergence compactly supported. Evenness cancels first moments and the exterior angular flux cancels its mean. The current C1 visit hypotheses justify all time chain rules, and both translated tensor terms are explicitly present. For the compact source, the two large-circle integrals are `πrξ` and `-πrξ`, so their difference is `2πrξ`. The fixed dilation `U_H=H^-2U(x/H)` now explicitly supplies all uniform bump constants.

6. **Raster and normalization, S0171–S0219.** Expanding the four rank-one directions gives diagonal `A+B-Sii` and off-diagonal `(a3-a4)/2=-S12`, hence `-S+qI` without a missing factor. Positive floors and nonzero ramp integral make every speed and normalization denominator legitimate. On a row `dt=(r0/η)c ds`; each ramp time is `r0 e L/(η Iζ)`. Substitution in the normalization gives exactly the allocated scan time `τi` and weight `2πη_i r0_i/τ=d`. Fixed positive floors make `dB_i` converge to a positive finite limit; η_i is uniformly bounded above and below, not independent of the cycle count. Thus `r≈H⁸`, `r^(1/5)=O(H^(8/5))=o(H)`. On rows `ηr'=(ηr)'=η_i²∂ξlog c`; on ramps the bound is `η_i² Iζ||ζ'||∞/L`. Integration by parts in time gives the positive averaged-divergence sign. The Banach-valued rectangle rule has error `d∫||F'||1`, with `∫||F'||1≤||∂⊥a||1+C H^-1||a||1`; convolution contributes `H||∇a||1`. Setting d=H² makes all terms vanish. Floor and ramp mass are estimated separately and are never differentiated as if they were a globally smooth coefficient.

7. **Temporal correction and stress, S0221–S0260.** `Q=-P∫(U-Ubar)` subtracts the average of the entire four-direction cycle. The projected bump has zero divergence and the same curl as `U_H ξ`. Its core is smooth and bounded by transferring one derivative to U. Its tail for `|x|>1` is the Hessian of G, giving every required Lp bound. The current source explicitly states this identity only for `|x|>1`; shell averaging proves it on exactly that region, including when the bump has annular support. Fixed dilation gives `||Z_H||p=H^(2/p-2)||Z_1||p`. The pressure `p_Q=-π_U+average π_U` yields exactly `∂tQ+U+∇p_Q=Ubar`. Corrector bounds are `τH^-1` in L2 and curl L1 and `τH^-2/3` in L3/2. Endpoint values vanish exactly. The revised time-smoothness sentence explicitly applies after spatial mollification. Expanding the full quadratic tensor gives both orders of all three mixed pairs and Q⊗Q; the revised symmetry assertion concerns that assembled tensor. Absorbing `-qI` into the stress requires subtracting q from pressure. The mollification commutator sign is `v_ell⊗v_ell-(v⊗v)_ell`; compactness of the cycle's continuous L2 image makes its L1 norm uniformly small. The old seed is untouched.

8. **LER parameter order and pasting, S0261–S0349.** J is explicitly an interval and S is compactly supported in time, so a single `[a,b]⊂⊂J` encloses its support. The case δ=0 is handled by zero correction. Finitely many inherited continuity pieces admit finite uniform coarse approximation, including their separate one-sided extensions; actual boundary values are not forced to equal conflicting traces. Choose coarse errors, regularization masses and floors first, then finite cycle counts, then fixed mollification scales. With `τ=H⁶`, the intrinsic stress is `O(H|log H|)+O(H⁸)`, Q costs `O(H⁵)` in L2/curl and `O(H^(16/3))` in L3/2, and the main packet costs `O(H^(8/3))` in L3/2. Actual old-new products tend to zero using the old finite C_t L3 norm; no old derivative is used. All conditions hold on tails of sufficiently large counts, so literal monotonicity of a Riemann sum is unnecessary. The ε half-budgets and ζ thirds are compatible. Zero velocity traces exclude temporal deltas; arbitrary bounded actual stress values at finitely many boundaries do not change its spatial-divergence distribution. Fixed convolution maps C_t L2 to C_t L3 with kernel norm `C ell^-1/3`, the correct Young exponent.

9. **Anchors and global closure, S0351–S0418.** Subtracting the two equations gives a positive quadratic-test term and negative stress-test term. Uniform local energy and global stress bounds make compact divergence-free pairings Lipschitz. The anchor values force their zero-time limits to vanish. The revised statement explicitly extracts a weak L2 subsequence from any `t_n↓0`; the cluster limit is both divergence- and curl-free, and its L2 Fourier transform cannot be supported only at zero. The explicit plateau `[3/4,3/2]` makes the partition denominator at least one: take `j=floor(log2(4t/3))` for each t>0. Three dyadic colors have gaps at `3·2^j`, and at most N=3 patches overlap. Frozen prescribed pieces telescope the old stress exactly; partial-color stresses are bounded by `(δq+δq+1)Θ`. The local parameters now explicitly include `κ=2^-q/N` and `r_*=1`. The increment estimate is `[NC sqrt(Θ(4T))+1]sqrt(δq)`, with `sqrt(δq)=4^-q` summable. No uniform L3 bound in q is used. The resulting L2 series is uniform on `(0,T]`; finite heads have weakly zero trace and uniformly small tails give the exact initial trace. Curl series converge absolutely in L1 at every positive time. Strong local L2 convergence passes the quadratic flux, while temporal cutoffs recover the plus initial term. Finally, `u=V0+v` with `V0∈C0`, `v∈L2` and finite measure curl has no harmonic remainder: its mean-value bound is a vanishing C0 average plus `C(||v||2+||μ||M)/R`. This yields the canonical velocity at every time, including the initial definition at zero.


### All theorem-invocation containers

The following table accounts for all 23 frozen invocation containers. Every hypothesis match was checked against the current source; standard analytical tools are also reconstructed in the per-container ledger.

| Invocation container(s) | Hypotheses matched and conclusion checked |
|---|---|
| S0040 | Tonelli: nonnegative absolute kernel, finite measure, uniform disk integral; gives local L1 and almost-everywhere finiteness. |
| S0046 | Measure Young inequality: L_a is L1 and μ finite; its proof is the nonnegative iterated integral. |
| S0048 | Plancherel: the weighted multiplier times the H^-1 transform is square integrable; gives global L2 of the residual only. |
| S0050 | Fourier inversion and Riemann–Lebesgue: every relevant multiplier times bounded μ-hat is L1; positive derivatives additionally L2. |
| S0054, S0062 | The primary-source invocation and actual application match the finite-exponent hypothesis check below; only bounded L1 vorticities are used by its time-stepping construction. |
| S0058 | Theorem 2.2 uses q=1 and p=3 in its strict finite-p range. Assumption 3.1 then has domain L1∩L3_ul and range bounded C^(1/3); bounded vorticities have uniform local L3 norms. The distributional divergence is zero and the plane has no boundary. |
| S0065 | Osgood comparison: bounded measurable-in-time field, uniform modulus r(1-log r), divergent reciprocal integral; forward and backward uniqueness and continuous dependence follow. |
| S0067 | Jacobian equation: spatially smooth mollified velocity, locally integrable Lipschitz bounds and zero divergence; Jacobian stays one. |
| S0069 | Dominated convergence: bounded compact test, common bounded support enlargement and convergent flows. |
| S0081 | Chebyshev: near convolution is L1 and far convolution is at most λ/2; λ>0, with M=0 handled separately. |
| S0082 | Layer cake: bounded V and its weak-L2 distribution bound; cancellation of λ² against λ^-2 makes the integral finite. |
| S0104 | Plancherel and dominated convergence: multipliers are at most one and tend pointwise to one against an L2 transform. |
| S0110 | Fubini on compact tests: the same uniform local kernel integral and integrable smoothing kernel dominate the absolute iterated integrals. |
| S0126 | Intermediate value theorem: continuous J1 with strictly opposite signs at 3 and 4. |
| S0128 | ODE uniqueness: continuous regular coefficients near the positive root and zero Cauchy data; continuation through the connected positive axis contradicts the series. |
| S0214 | Banach-valued fundamental theorem: F has an integrable L1-valued derivative; integration over each row interval gives the factor d. |
| S0232 | Minkowski: translated fixed profiles belong to each relevant Lp, with an integrable bounded time coefficient on a finite cycle. |
| S0256 | Approximation of the identity: uniformly bounded convolution operators and a compact continuous image in L2, plus its quadratic compact image in L1. |
| S0309 | Hölder: old u has finite supremum in L3 on the fixed compact interval; new v,Q tend to zero in L3/2. |
| S0338 | Young: `1+1/3=1/2+1/(6/5)` and the mollifier L6/5 norm scales as ell^-1/3. |
| S0357 | Weak sequential compactness: the bounded sequence of global L2 differences is in a reflexive Hilbert space. |
| S0409 | Weyl's lemma: the locally integrable difference has componentwise zero distributional Laplacian from zero divergence and curl. |


### Edge cases and adversarial checks

The current checks include the zero measure and zero stress, nonzero total circulation, arbitrary signed noncompact data, lack of a first moment and lack of global kinetic energy, the Bessel origin and circle interface, positivity of all divisions and square-root branches, vanishing coefficient directions, arbitrarily small positive floors, annular probability bumps, p=3 versus the excluded Lipschitz endpoint inference, each dyadic plateau endpoint, row and cycle endpoints, center resets, unequal one-sided stress traces, independently assigned actual boundary values, small-scale order of choices, every finite horizon including zero, absolute curl convergence at every positive time, and possible harmonic velocity additions. No verified judgment rests only on the absence of a quick counterexample.

## D. Escalated-container and dispute report

This pass finds no v3 parent requiring escalation on its own mathematical verdict. The three revised parents and all their children are VERIFIED for the direct reasons above. No local `R` identifiers or cross-pass reconciliation conclusions are invented here. The coordinator must still compare all independent outputs and perform any escalation their combined evidence requires.

## E. Definite mathematical errors

None established in the frozen v3 source by Pass A. There is no proposed source edit from this pass.

## F. Unjustified, ambiguous and source-dependent items

None remains in this pass's current judgments. The primary theorem's actual domain/range and finite-p applicability were inspected, the exterior potential identity is asserted on a proved domain, and the dyadic cutoff is positive where the denominator needs it. All earlier explicit definitions and parameter choices were reread and checked in their present context. No external source essential to a current assertion is unavailable.

## G. Dependency and error-propagation report

| Major result | Current permanent dependencies | Judgment |
|---|---|---|
| Canonical decomposition, S0034–S0039 | S0026–S0033 conventions; S0040–S0052 local kernel integrability, truncation, radial cancellation and inhomogeneous Fourier estimate. | All VERIFIED; no sign/support/circulation strengthening. |
| Bounded background, S0060–S0061 | Decomposition; S0054–S0058 primary theorem match with finite p=3; S0062–S0090 all-time flow representative, norm bounds, relative L2 continuity and pressure. | All VERIFIED; no global background L2 assumption. |
| Initial seed, S0096–S0100 | Decomposition/background; S0092–S0095 conventions/kernel; S0101–S0114 exact equation, curl/stress estimates, trace and continuity. | All VERIFIED; supplies the stated repair class. |
| LER, S0261–S0275 | S0122–S0168 dipole, anti-divergence and translated source; S0171–S0219 coefficient/raster normalization and quadrature; S0221–S0260 corrector, exterior profile bound, stress identity and smoothing; S0276–S0349 parameter order and pasting. | All VERIFIED, including current S0229 and arbitrary allowed radial U. |
| Anchor lemma, S0351–S0353 | S0354–S0360 bounded distributional pairing derivative, exact anchor values, weak compactness and zero harmonic L2 cluster point. | All VERIFIED. |
| Global iteration, S0361 | Seed, LER and anchors; S0362–S0392 positive partition, three colors, frozen-piece subtraction, summable increments and exact initial traces; S0393–S0406 convergence, curl and target weak formulation. | All VERIFIED on one global time axis. |
| Canonical normalization, S0407–S0408 | S0040–S0043 arbitrary-finite-measure kernel identities; S0409–S0413 harmonicity and expanding-ball mean-value bounds. | All VERIFIED; removes harmonic additions with fixed C0 background and L2 perturbation. |
| Global existence, S0414 | All seven preceding results; S0415–S0418 match every exact target conclusion and apply canonical normalization at every time with U=V0. | VERIFIED for the stated arbitrary signed finite inhomogeneous-H^-1 data. |

All dependencies in these eight maps have current affirmative records. There is no earlier-error propagation in v3 and no circular dependency was found. Forward lemma statements are supported by the following proofs rather than assumed in them. Fine parameters may depend on coarse geometry, finite old L3 norms and derivative constants, while the leading increment coefficient remains universal as stated. The global limit uses a single sequence whose bounds hold on every finite horizon; it does not glue independent finite-horizon solutions. No energy inequality or uniqueness statement is claimed.

## H. Final completeness certificate

- [PASS] Every TeX file was inventoried — 1/1 current source; no missing include.
- [PASS] Every source line belongs to at least one permanent container — 951/951 lines and 45,329/45,329 bytes; zero uncovered.
- [PASS] Permanent container identifiers remained unchanged after the inventory was frozen — all 419 retained, with exact current hashes validated.
- [PASS] Every compound mathematical container received exactly one non-recursive layer of nested checks — 253 compound containers and 861 allocated current children.
- [FAIL] Every permanent container received a verdict from every required pass — Pass A has 419/419; other required passes are deliberately uninspected by this independent report.
- [FAIL] Every final nested check and every remaining simple mathematical container was affirmatively checked by every pass — Pass A checked 861/861 children and all 388 mathematical parents; cross-pass coverage awaits the coordinator.
- [PASS] Every inventoried inline and display formula occurrence was checked — Pass A, 525 inline plus 59 display, 584/584 total.
- [PASS] Every algebra-bearing container was independently re-derived — Pass A, 106/106 current containers.
- [PASS] Every theorem-application container received complete hypothesis matching — Pass A, 23/23, including the original Assumption 3.1 domain/range and the finite-p use in Theorem 3.3.
- [PASS] Every proof was checked locally and globally — Pass A, 8/8 proofs and 8/8 major-result maps.
- [PASS] Edge cases and attempted counterexamples were investigated — zero, sign, origin, support-hole, finite-exponent, dyadic-endpoint, tail, reset, time-boundary and infinite-iteration cases recorded.
- [PASS] Definitions and notation were checked across the manuscript — all current declarations, formulas and cross-references inspected.
- [PASS] Dependencies and error propagation were traced — all eight result chains reviewed; no current error dependency found.
- [FAIL] Every required escalation was reconciled through local dispute items — this pass proposes zero v3 escalations; whether the combined passes require others is reserved to the coordinator and not certified here.
- [PASS] Every definite error was independently confirmed where feasible — no current definite error established; the prior annular-support test was reapplied on the newly stated domain and does not contradict it.
- [FAIL] No source container, pass verdict, or dispute item remains unchecked — no missing Pass A parent, child or formula check; other-pass verdicts and any resulting reconciliation remain outside this independent report.
