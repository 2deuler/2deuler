# Independent whole-proof counterattack

## Scope and result

**PASS within the hostile whole-proof scope described here.** I found no fatal construction obstruction, invalid quantifier interchange, conservation-law contradiction, or failure of the weak-trace/gluing argument. This means that the attempted counterattacks below failed for the stated, affirmative reasons. It is not a substitute for the separate permanent-container audit, and it is not a claim that a four-pass completeness certificate has been produced here.

I read all 948 lines of `proof.tex`, all 39 lines of `target_problem.txt`, and the supplied `mathematical_audit_prompt_v3 (1).md`. The source digest at the end of the examination was

```
b6741b471ba2f128b147f5a5c05fea0afe639c2c3a535b99a5afaf03ea6d4a43
```

The TeX source was not modified. There are no `\input` or `\include` dependencies in it. I did not read any other audit, route, checkpoint, inventory, or verdict file, and did not solicit another auditor's conclusions. This report deliberately uses exact source lines rather than introducing a competing permanent-container inventory.

The target is weak velocity Euler, with weak local $L^2$ continuity at zero, canonical Biot–Savart velocity, and a locally uniform finite total-variation bound. It does **not** require a renormalized vorticity equation, preservation of either Jordan component, an energy inequality, or strong initial $L^2$ continuity. These distinctions matter to the counterattacks below.

## 1. Initial normalization and the noncompact background

**Tested source:** lines 59–104, 106–189, 202–246, and 915–944.

### The inhomogeneous hypothesis really is sufficient

For radial $a$, the angular Biot–Savart calculation gives

\[
K*a(x)=K(x)\int_{|y|<|x|}a(y)\,dy.
\]

Consequently $L_a=K-K*a$ is supported in $B_A$, and its sole singularity is of order $|x|^{-1}$. Thus $L_a\in L^1$ and $\|L_a*\mu\|_1\leq\|L_a\|_1\|\mu\|_{\mathcal M}$. At small frequencies,

\[
|(1-\widehat a)m|=O(|\xi|),
\]

and at large frequencies it is $O(|\xi|^{-1})$. Hence

\[
\int |(1-\widehat a)m\widehat\mu|^2
\leq C_a\int (1+|\xi|^2)^{-1}|\widehat\mu|^2.
\]

This checks lines 94–98 without replacing the inhomogeneous assumption by homogeneous $H^{-1}$, without assuming zero circulation, and without requiring the Jordan parts separately to lie in $H^{-1}$.

The multipliers $m\widehat a$ and $\xi^\alpha m\widehat a$ have the asserted integrability: the possible origin singularity is $1/|\xi|$, which is integrable in two dimensions; with $|\alpha|\geq1$ the latter multiplier is also square-integrable. Multiplication by bounded $\widehat\mu$ therefore yields $V_0\in C_0\cap C^\infty$, with the stated derivative bounds. Truncation of a finite measure in total variation passes the Fourier identity because $m\phi\in L^1$ for Schwartz $\phi$. The physical convolution converges in $L^1_{\mathrm{loc}}$ by the uniform local integral bound on $K$. These give the same distribution.

### External input E1 was checked against the primary statement

I inspected the publisher's text of Crippa–Stefani, DOI [10.1007/s00526-024-02750-4](https://link.springer.com/article/10.1007/s00526-024-02750-4), specifically Assumptions 2.1 and 3.1, Definition 3.2, and Theorem 3.3. The theorem supplies the signed $L^1\cap L^\infty$ Lagrangian solution used here; the definition includes the weak initial-value equation and canonical velocity. Its kernel assumptions match the displayed bounds for $K$; divergence is zero and the plane has no boundary condition. There is no compact-support or global kinetic-energy hypothesis. The manuscript does not use the source as a smoothness theorem.

The every-time improvement in lines 136–157 is an additional argument, not an unjustified strengthening of the cited theorem: spatial mollification converges uniformly under the common log-Lipschitz modulus; the resulting volume-preserving flows and inverse flows converge on compact time-space sets by Osgood stability. Bounded displacement makes passage of volume preservation against compact tests legitimate. Approximation of $\nu_0$ by compact smooth functions then gives $C_tL^1\cap C_tL^2$ for the transported representative. The near/far estimate for $K*f$, together with the uniform $L^\infty$ bound on $f$, gives $C_tL^\infty$ for its velocity.

The identity

\[
\nu(t)-\nu(s)=-\operatorname{div}\int_s^tV\nu
\]

has a right-hand side whose primitive is in $L^1\cap L^2$. The multiplier of $-K*\operatorname{div}$ has norm at most one, so it yields the claimed global $L^2$ difference $V(t)-V(s)$ even though $V(t)$ itself need not be globally $L^2$. Since $V$ is bounded and $\nu\in L^2$, the velocity equation has an $L^2$ curl-free residual, hence a distributional pressure gradient. This checks the intended whole-plane background interface.

### The seed does not hide an initial-stress blowup

The multiplier $e^{-t^4|\xi|^4}$ gives $\partial_tW=-4t^3\Delta^2W$. With the declared matrix convention,

\[
\operatorname{div}\bigl(\nabla\Delta W+(\nabla\Delta W)^T\bigr)=\Delta^2W.
\]

Thus the sign in lines 208–209 is correct. Also

\[
\nabla\Delta W=\nabla\nabla^\perp b_t*\sigma_0,
\qquad \|\nabla\Delta W\|_1\leq Ct^{-2}\|\sigma_0\|_{\mathcal M},
\]

so its stress costs $Ct$, not a singular negative power of $t$. The other stress terms use $W\in L^1\cap L^2$ and bounded $V$. A majorant $\Theta$ finite at zero therefore exists. The seed is strongly continuous at zero in local $L^2$. Its positive-time $L^3$ and stress $L^1$ continuity follow from the explicitly provided global $L^3$-$L^{3/2}$ product bounds.

**Outcome:** PASS. The nonzero-circulation and noncompact-data cases are actually covered by this decomposition.

## 2. The exact dipole: signs, interface regularity, and a moment countercheck

**Tested source:** lines 262–316, especially

> “$P=-\tfrac12|D-e_1|^2-\tfrac{\beta^2}{2}q^2\mathbf1_{B_1}$” (lines 296–299)

and

> “$-r^{-1}\partial_\xi D_r+\operatorname{div}(D_r\otimes D_r)+\nabla P_r=0$” (lines 306–309).

Put $c=2/(\beta J_0(\beta))$ and $f(\rho)=-\rho+cJ_1(\beta\rho)$ in the core, so $\psi=f(\rho)\sin\theta$. The claimed alternating-series bounds are correct:

\[
1-\frac98+\frac{27}{64}-\frac{81}{1024}=\frac{223}{1024},
\]

and the corresponding fourth-degree truncation at $4$ is $-2/45$ after multiplication by $2$. The omitted tails have decreasing magnitudes. The nonvanishing of $J_0(\beta)$ follows from uniqueness of the regular ODE at the positive point $\beta$, as stated.

At the interface,

\[
f(1)=-1,\qquad f'(1)=1,\qquad f''(1)=-2,
\]

which agree with the exterior $f(\rho)=-1/\rho$. The angular derivatives also match; the core is smooth at the origin by the odd Bessel series. Thus $D$ is $C^1$, and there is no hidden vortex sheet on the matching circle.

Since $w=D-e_1=\nabla^\perp q$, $w^\perp=-\nabla q$, and $\operatorname{curl}w=-\beta^2q$ in the disk,

\[
(w\cdot\nabla)w
=\nabla\left(\frac{|w|^2}{2}+\frac{\beta^2q^2}{2}\right).
\]

The stated negative pressure is therefore correct. The term $q^2\mathbf1_{B_1}$ has zero value and zero first-order trace at the circle; it creates no boundary distribution. Rescaling multiplies all three terms in the steady translating equation by $r^{-3}$, which proves the exact speed $r^{-1}$.

### Independent energy-tensor check of the crucial $2\pi$

A potential fatal obstruction would be an incorrect sign or coefficient in the anisotropic stress produced by the moving dipole. It can be checked independently of the source construction. For $\psi=f(\rho)\sin\theta$, direct angular integration gives

\[
\int_0^{2\pi}(D_1^2-D_2^2)\,d\theta
=\frac\pi2\left(f'+\frac f\rho\right)^2,
\qquad \int_0^{2\pi}D_1D_2\,d\theta=0.
\]

The exterior contribution to the difference is zero. In the core,

\[
f'+f/\rho=-2+2J_0(\beta\rho)/J_0(\beta).
\]

Using

\[
\int_0^1\rho J_0(\beta\rho)\,d\rho=0,
\qquad
\int_0^1\rho J_0(\beta\rho)^2\,d\rho=\frac12J_0(\beta)^2,
\]

one obtains

\[
\int_{\mathbb R^2}(D_1^2-D_2^2)=2\pi.
\]

For completeness, integration of the Dirichlet energy of the stream function gives core energy $3\pi$ and exterior energy $\pi$. Thus

\[
\boxed{\int_{\mathbb R^2}D\otimes D=\pi I+2\pi e_1\otimes e_1.}
\]

This confirms the positive $2\pi$ directional stress independently of the packet-source calculation below. Numerical quadrature with SciPy's first positive $J_1$ zero, absolute and relative tolerance $10^{-12}$, gave $\beta=3.831705970207512$, diagonal entries $9.424777960769379$ and $3.141592653589793$, matching $3\pi,\pi$. The numerical calculation is only a check; the displayed identities give the proof.

The norm scalings follow directly from $D_r(x)=r^{-1}D(x/r)$: $L^2$ and curl $L^1$ are invariant, and $L^{3/2}$ is proportional to $r^{1/3}$. The exterior decay $D=O(|x|^{-2})$, $\nabla D=O(|x|^{-3})$ gives the required global integrability.

**Outcome:** PASS. Neither interface distributions nor an incorrect dipole stress sign defeats the construction.

## 3. Whole-plane anti-divergence and the compact source

**Tested source:** lines 318–389.

The divergence of the displayed symmetric tensor is exactly

\[
\partial_j(\mathcal Af)_{ij}
=\partial_i\Delta^{-1}\operatorname{div}f+f_i
-\partial_i\Delta^{-1}\operatorname{div}f=f_i.
\]

Its degree $-1$ kernel is locally integrable. On the far region, subtracting both the zeroth and first Taylor terms leaves a bound $CR^2|x|^{-3}\|f\|_1$. Its integral is $CR\|f\|_1$. Thus the $L^1$ estimate is genuinely a whole-plane estimate; it does not use a false $L^1$ Calderón–Zygmund bound.

Direct differentiation gives

\[
\partial_rD_r=-r^{-1}D_r-r^{-1}(x\cdot\nabla)D_r
=r^{-1}D_r-\operatorname{div}(D_r\otimes x/r).
\]

For $f_r=\operatorname{div}(D_r\otimes x/r)$, exterior homogeneity makes $f_r=0$ outside $B_r$, and scaling gives $\|f_r\|_1=O(1)$. It is even, so all first moments vanish. Its mean is the exterior-circle flux; the angular average of the exterior dipole is zero, so this flux is zero. Therefore $F_r=-\mathcal Af_r$ has $\|F_r\|_1\leq Cr$. No nonintegrable first-order far field has been omitted.

For the variable packet, the time derivative contributes

\[
\eta'D_r+\eta r'\partial_rD_r-\eta X'\cdot\nabla D_r.
\]

With $X'=\eta\xi/r$, its translation term cancels the nonlinear translation term. The remaining non-gradient terms are

\[
\frac{(\eta r)'}rD_r+\operatorname{div}(\eta r'F_r),
\]

as in line 358.

Now $D_r=r\nabla\Phi_\xi$ outside the core. Hence $Z_r=D_r-\nabla\Pi_r$ is compactly supported and even. Integrating over a circle outside its support gives

\[
\int D_r=\pi r\xi,
\qquad \int\nabla\Pi_r=-\pi r\xi,
\qquad \int Z_r=2\pi r\xi.
\]

These are integrals over the containing disk before subtraction; the individual fields are not being claimed to lie in $L^1$. Their compact difference does. On the annulus between radii $r$ and $r^{1/5}$, the magnitude $r/|x|^2$ integrates to $O(r|\log r|)$; the transition annulus costs $O(r)$. This proves the stated $L^1$ bound on $Z_r$.

Thus $S_r-2\pi U_H\xi$ has both moment cancellations, and the anti-divergence estimate with support radius $H$ gives

\[
\|E\|_1\leq C|\eta r'|r
+C|(\eta r)'|H(1+|\log r|).
\]

Translation of a zero-mean, zero-first-moment input preserves those cancellations. Gradients removed through $\Pi_r$ are pressure terms; no time derivative of $\Pi_r$ is introduced, because the velocity itself is not replaced by $Z_r$.

**Outcome:** PASS. The two moment conditions are sufficient and actually satisfied; the cutoff does not alter the velocity or create an unaccounted derivative.

## 4. Raster normalization and the potentially dangerous quantifiers

**Tested source:** lines 393–504 and 639–743.

The four coefficients satisfy, entry by entry,

\[
\sum_i a_i\xi_i\otimes\xi_i
=\begin{pmatrix}A+B-S_{11}&-S_{12}\\-S_{12}&A+B-S_{22}\end{pmatrix}
=-S+qI.
\]

The regularizing $\gamma h$ makes the square roots smooth wherever the entries of $S$ may be nonzero; near the zero set of $h$ the formulas reduce to $\gamma h$. Their total mass is bounded by a universal multiple of $|S|_1$, plus an arbitrarily small regularization mass. This is why the leading amplitude constant need not depend on a support diameter or a derivative norm.

On an interior row $r=r_0c(s,kd)$, $ds/dt=\eta/r$, so

\[
dt=\frac{r_0c}{\eta}\,ds,
\qquad \int\eta^2U_H(\cdot-X(t))\,dt
=\eta r_0\int cU_H(\cdot-s\xi-kd\xi^\perp)\,ds.
\]

For a ramp, its displacement is exactly $\eta_i T I_\zeta/(r_0e)$. Taking $T=r_0eL/(\eta_iI_\zeta)$ gives the desired buffer length. Therefore the definition of $B_i$ gives total duration $r_0B_i/\eta_i$, and the displayed choices yield simultaneously

\[
\frac{r_0B_i}{\eta_i}=\tau_i,
\qquad \frac{2\pi\eta_i r_0}{\tau}=d.
\]

The ramp's quadratic coefficient weight is bounded by a fixed ramp-dependent multiple of its floor mass; it does not produce a hidden order-one stress. Only one principal packet is present at any instant. A jump of its center between rows occurs with zero amplitude and flat ramp endpoints, so it does not create a velocity jump or a temporal delta.

At fixed rectangles, coefficients, positive floors, and ramps, $dB_i$ tends to a positive finite limit. Hence $\eta_i$ stays between positive constants independent of the subsequently increasing cycle count. With $\tau=H^6$ and $d=H^2$,

\[
r_0=\frac{H^8}{2\pi\eta_i},\qquad r\asymp H^8,
\qquad r^{1/5}=O(H^{8/5})=o(H).
\]

On an interior row, $\eta r'=\eta^2\partial_\xi\log c$; on a ramp, $(\eta r)'$ is bounded by a fixed multiple of $\eta_i^2$. These bounds may deteriorate when a floor becomes small, but the floor is fixed **before** $H\downarrow0$. No uniformity in the floor is used when sending $H$ to zero. The only uniform coefficient needed for the iteration is the leading $C\sqrt\delta$ amplitude bound, which follows from the coefficient mass estimate.

The order of choices in lines 733–743 is therefore legitimate: choose the coarse approximation and masses to fit the additive slack, then let cycle counts grow to overcome every finite coefficient, floor-derivative, old-velocity, and geometric constant. There are only finitely many coarse cells in a patch. Their constraints can all be met at once.

The Banach-valued rectangle rule is also sufficient: for

\[
F(y)=\int a(s,y)U_H(\cdot-s\xi-y\xi^\perp)\,ds,
\]

one has

\[
\int\|F'(y)\|_1dy\leq\|\partial_\perp a\|_1
+C H^{-1}\|a\|_1.
\]

Summing the fundamental-theorem estimate on intervals of length $d$, then using the convolution translation estimate, gives exactly line 485–487. Taking $d=H^2$ makes its right side tend to zero. The error is charged to the original smooth compact coefficient; floor and buffer contributions are separately bounded by their small mass, so no derivative of a discontinuous rectangular floor is required.

**Outcome:** PASS. I did not find a swapped quantifier in the floor/fine-scale choice, or a support-dependent leading increment constant.

## 5. Time average, projection, and the complete stress identity

**Tested source:** lines 475–601.

The identity

\[
\frac d{dt}\bigl(\eta rU_H(\cdot-X)\bigr)
=(\eta r)'U_H-\eta^2\xi\cdot\nabla U_H
\]

has the stated sign. Its endpoint term vanishes on each visit. Therefore the average source is the positive divergence of the average $2\pi\eta^2U_H\xi\otimes\xi$. Summing the four directions over the **whole cycle** produces the correct instantaneous tensor $A_{\rm av}$. Averaging only over the active slot would fail, but that is explicitly not the construction here.

The projected bump satisfies

\[
Z_{H,\xi}=\mathbb P(U_H\xi),\qquad
\operatorname{curl}Z_{H,\xi}=\operatorname{curl}(U_H\xi).
\]

Its exterior is $-D^2G\xi$, so $Z_{1,\xi}\in L^p$ for every $p>1$, and scaling gives $H^{2/p-2}$. The estimates for $Q$ therefore are

\[
\|Q\|_2\lesssim\tau H^{-1}B,
\quad\|Q\|_{3/2}\lesssim\tau H^{-2/3}B,
\quad\|\operatorname{curl}Q\|_1\lesssim\tau H^{-1}B.
\]

The same $B$ bounds the norm of the average by Minkowski. This does not assume $\mathbb P:L^1\to L^1$.

For the pressure, write $\mathcal U-\mathbb P\mathcal U=\nabla\pi_{\mathcal U}$. Then

\[
\partial_tQ+\mathcal U
=\overline{\mathcal U}+\nabla(\pi_{\mathcal U}-\overline{\pi_{\mathcal U}}),
\]

so $p_Q=-\pi_{\mathcal U}+\overline{\pi_{\mathcal U}}$ gives exactly line 540. Adding this equation to the packet and seed equations yields every term of lines 562–565. Replacing $A_{\rm av}$ by $A_{\rm av}-qI$ requires subtracting $q$ from the intermediate pressure, as done in line 723.

The cross estimates are dimensionally and integrably correct:

\[
u\in L^3,\quad v,Q\in L^{3/2},\quad v,Q\in L^2.
\]

At a fixed old seed, $\sup\|u\|_3<\infty$, while $\|v\|_{3/2}=O(H^{8/3})$, $\|Q\|_{3/2}=O(H^{16/3})$, and $\|Q\|_2=O(H^5)$. Thus all old–new and corrector quadratic stresses become arbitrarily small. No uniform-in-stage $L^3$ bound is needed or used.

Finally, spatial convolution of the packet equation introduces

\[
C_\ell=v_\ell\otimes v_\ell-(v\otimes v)_\ell
\]

with a **positive** divergence on the new right side. This is the displayed sign. On a fixed finite cycle the $L^2$ image of $v(t)$ is compact, so approximation of the identity is uniform on it. The commutator is uniformly small in $L^1$. Keeping $\ell$ constant on the cycle avoids a kernel time derivative. The old seed is not convolved. All endpoint values stay zero, and different scales on adjacent cycles therefore cause no velocity jump.

**Outcome:** PASS. The time primitive, projection sign, pressure sign, complete cross terms, and smoothing commutator have been independently reconstructed.

## 6. Gluing and actual stress values at boundaries

**Tested source:** lines 602–638 and 719–782.

The local lemma permits piecewise-continuous $L^1$ stresses with unrelated one-sided traces. It does not demand time continuity of the stress. On interiors of coarse cells,

\[
E_{\rm total}=S-S_k+E_k^{\rm loc}
\]

gives the exact equality $\widetilde R=R-S+E_{\rm total}$. At a finite set of boundary times, setting $E_{\rm total}=0$ and $\widetilde R=R-S$ changes no space-time distribution. This is legitimate because the equation contains spatial divergence of stress, not its time derivative.

This would be invalid if the velocity jumped. It does not: the principal packet and $Q$ vanish at every completed-cycle endpoint. At row resets the packet vanishes and $Q$ remains a continuous time primitive. The compactly supported patch correction extends continuously by zero. Distributional $\partial_tw$ therefore has no temporal atoms. A jump of $\partial_tw$ is harmless.

For positive-radius, finite-cycle constructions, the packet is continuous in $L^2\cap L^{3/2}$; fixed smoothing makes it continuous in $L^3$. The projected-bump primitive is continuous in all three spaces. The anti-divergence terms are $L^1$-continuous by the common-support moment estimate. Old–new products are $L^1$-continuous by the displayed $L^3$-$L^{3/2}$ inequality. This establishes exactly the admissible class required at the next finite stage.

**Outcome:** PASS. Boundary stress representative choices are not being used to conceal a velocity delta.

## 7. The anchor lemma and weak initial continuity

**Tested source:** lines 786–811 and 878–892.

For a compact smooth solenoidal $\psi$, subtraction of the two Euler–Reynolds equations gives

\[
\left|\frac d{dt}\int W\cdot\psi\right|
\leq\|\nabla\psi\|_\infty
\left(\|\widetilde U\|_{L^2(\operatorname{supp}\psi)}^2
+\|U\|_{L^2(\operatorname{supp}\psi)}^2
+\|\widetilde R\|_1+\|R\|_1\right).
\]

Thus the pairing is uniformly Lipschitz on $(0,T)$. Since it is zero along anchor times tending to zero, its limit is zero; indeed its absolute value at time $t$ is bounded by a constant times $t$, by sending an earlier anchor to zero.

Solenoidal tests alone do not automatically determine an arbitrary vector field, but the manuscript supplies the missing argument. Any global $L^2$ weak cluster point is divergence-free. Testing against $\nabla^\perp\phi$ also gives zero curl. Its Fourier transform is both parallel and perpendicular to $\xi$ for $\xi\ne0$, and an $L^2$ function cannot be supported only at frequency zero. Therefore the cluster point is zero. This proves weak global $L^2$ convergence of the correction, hence the required weak local trace.

The hypotheses are actually available for a whole color near zero. Same-color supports lie in disjoint dyadic patches, so the total correction is zero at the gap times $3\cdot2^j$. Its global $L^2$ norm is bounded by the patch estimate and the finite near-zero majorant. The seed has bounded local energy; adding a bounded global $L^2$ correction preserves this. The intermediate stress formula in lines 863–866 bounds both old and new stresses near zero. Thus the lemma is applied to fields satisfying its stated uniform hypotheses, not merely positive-time local bounds.

The series step is also valid: each finite correction has weak zero trace, and the remaining correction tail is uniformly small in global $L^2$ on $(0,T]$. Pairing the tail against any bounded-domain $L^2$ test makes it uniformly small, independently of $t\downarrow0$. This is the needed order of limits.

**Outcome:** PASS. The anchor mechanism gives exactly weak initial continuity. It does not prove, and the target does not demand, strong initial continuity of the final velocity.

## 8. Global iteration and the every-time conclusions

**Tested source:** lines 813–913 and 934–944.

Coloring by $j\bmod3$ makes $I_j$ and $I_{j+3}$ disjoint with a genuine gap. On any compact positive-time interval only finitely many patches occur. At each finite stage the union of old and newly introduced time boundaries is therefore locally finite.

The prescribed pieces are frozen as $S_{qj}=\chi_jR^{(q)}$. Later colors may use a changed seed because LER permits a prescribed $S$ independent of the current stress. Algebraically, after some colors the stress is

\[
\left(1-\sum_{j\text{ processed}}\chi_j\right)R^{(q)}
+\sum_{j\text{ processed}}E_{qj}.
\]

The coefficient of $R^{(q)}$ remains nonnegative. At the end, partition of unity cancels it exactly. At a time belonging to patch $j$, $m_j\leq\Theta(t)$; bounded overlap then gives the stated stress contraction. If $t\leq T$ and the patch is active, its upper endpoint is below $4T$, so $M_j\leq\Theta$4T$$. This establishes the displayed stage increment estimate without exchanging a patch supremum with an unrelated time supremum.

Since $\sqrt{\delta_q}=4^{-q}$, both the global $L^2$ increment series and curl $L^1$ series converge uniformly on $(0,T]$. At every fixed positive time the latter converges in the Banach space $L^1$, and its distributional curl identity follows by testing the local $L^2$ velocity limit. This is an every-time conclusion, not merely an almost-everywhere representative. Positive-time local strong $L^2$ continuity follows from uniform convergence of the continuous finite stages.

The quadratic term passes by strong local $L^2$ convergence, and stress tends to zero in $L^\infty_tL^1_x$ on compact positive-time intervals. To include zero, a cutoff rising on $(\varepsilon,2\varepsilon)$ produces the initial pairing with the correct positive sign. The omitted convection integral is $O(\varepsilon)$ by the uniform local energy bound; replacing $\varphi(t)$ by $\varphi(0)$ in the cutoff-derivative term also costs $O(\varepsilon)$. Weak local continuity identifies the remaining pairing.

For canonical normalization, $h=u-K*\mu$ is a locally integrable harmonic vector field. The mean-value estimate gives

\[
|h(x)|\leq\fint_{B_R(x)}|V_0|
+C\|u-V_0\|_2/R+C\|\mu\|_{\mathcal M}/R.
\]

All three terms tend to zero. The first uses $V_0\in C_0$, not a global $L^2$ assumption. At every positive time,

\[
u-V_0=(V(t)-V_0)+W(t)+\sum_qw_q(t)\in L^2,
\]

so the lemma applies at every time. At zero the initial decomposition already supplies the identity.

**Outcome:** PASS. The iteration does not lose a pointwise-in-time vorticity statement, a canonical velocity normalization, or the initial-value formulation.

## 9. Conservation-law attacks that do not work

1. **Energy:** The proof controls local energy and a global $L^2$ perturbation of a background; the target imposes no energy inequality. The final regularity does not itself supply the differentiability needed to test Euler with its own velocity. In particular, weak continuity at zero permits an energy jump there. The exact dipole energy-tensor computation above verifies the anisotropic stress rather than contradicting it.

2. **Circulation:** Each packet has zero total curl, since its exterior velocity is a gradient decaying like $|x|^{-2}$. Each projected-bump correction has curl equal to a derivative of a compact bump and hence zero integral. The seed has circulation $\int\nu_0+\int\sigma_0=\int\mu_0$. The absolutely convergent curl series preserves this identity. Thus total circulation creates no obstruction here.

3. **Impulse/far field:** A single packet carries a leading dipole far field. The projected time primitive cancels its leading coefficient: outside a large disk $D_r=-2\pi rD^2G\xi$, whereas the time primitive of $-\mathbb P\mathcal U$ has leading term $+2\pi\eta rD^2G\xi$. The average source has zero spatial mean because it is a divergence. This independently checks that the compact source is not silently inserting an uncompensated dipole tail.

4. **Immediate absolute continuity of vorticity:** Uniform total variation does not imply uniform integrability as $t\downarrow0$. Smooth approximate identities already give absolutely continuous positive-time vorticities converging to a singular finite measure with a uniform variation bound. Thus the claimed instantaneous $L^1$ vorticity is not functionally incompatible with the initial trace. A contradiction based on transport or preservation of Jordan components would need an additional renormalization theorem with its hypotheses verified; those hypotheses are not among the target's assumptions and are not supplied by the displayed bounds.

These are checks of particular proposed obstructions, not assertions of a general uniqueness or nonuniqueness theorem.

## 10. Findings and dependency status

No definite E1–E10 mathematical error was established by this independent counterattack. No material failed proof obligation was found at the following dependency-critical interfaces:

| Interface | Source lines | Status | Affirmative test |
|---|---:|---|---|
| Inhomogeneous initial normalization | 59–104 | PASS | Multiplier bound, compact radial difference kernel, distributional truncation |
| External bounded background and trace | 106–189 | PASS | Primary theorem hypothesis matching, volume-preserving flow upgrade, order-zero multiplier |
| Uniformly bounded initial stress | 202–246 | PASS | Direct differentiation and $D^2b_t$ scaling |
| Translating dipole | 262–316 | PASS | Bessel matching, pressure identity, independent energy tensor |
| Integrable anti-divergence and source | 318–389 | PASS | Two moments, Taylor remainder, boundary integral $2\pi r\xi$ |
| Raster and universal leading amplitude | 393–504, 639–743 | PASS | Exact visit times, coefficient mass, rectangle rule, explicit parameter order |
| Time corrector and stress identity | 506–601 | PASS | Projection and pressure signs, cross terms, convolution commutator |
| Local temporal gluing | 602–638, 719–782 | PASS | Zero velocity traces; stress jumps occur only under spatial divergence |
| Weak initial trace | 786–811, 878–892 | PASS | Uniform pairing Lipschitz bound, anchor times, global $L^2$ Hodge argument |
| Iteration and exact target closure | 813–944 | PASS | Frozen-piece algebra, bounded overlap, uniform series, cutoff and harmonic normalization |

The dependency chain tested is: initial decomposition and background → seed; dipole and two-moment anti-divergence → packet source; source, raster, and projected time primitive → LER; LER, coloring, and anchor lemma → global iteration; iteration and the fixed-background harmonic lemma → the target. None of these tested links failed.

## 11. Additional diagnostic: compact-time creation and moving-dipole comparison

This additional check was requested after the main report was drafted. It was performed directly from the source and the primary reference, without reading another audit.

### The diagnostic consequence is mathematically real

Take a fixed bounded time patch $J\Subset(0,\infty)$, a nonzero nonnegative compact smooth spatial function $f$, and a nonnegative $h\in C_c^\infty(J)$ with a positive plateau. Then

\[
u^{(0)}=0,\qquad R^{(0)}=-h(t)f(x)I,\qquad p^{(0)}=-h(t)f(x)
\]

is an Euler–Reynolds seed. Applying LER repeatedly in the **same fixed patch** with prescribed piece $S=R$ makes a summable sequence of global $L^2$ and curl $L^1$ corrections. Each finite correction vanishes outside $J$. Uniform $L^2$ convergence then gives a strongly $L^2$-continuous limit supported in the compact closure of $J$, with a uniform global $L^1$ bound on its vorticity. In fact the uniformly convergent $L^1$ curl series has $C_tL^1$ regularity in this special construction.

Nontriviality is not automatic from an upper increment estimate alone, but the explicit first repair supplies it. On a plateau of $h$, at least one coefficient has spatial integral bounded below by a positive multiple of $\int f$. Normalization gives a positive lower bound on the corresponding amplitude as the fine scale tends to zero. At an interior instant, the principal packet consequently has $L^2$ norm bounded below, while $Q$ and the smoothing difference can be made arbitrarily small. Choose the residual after that repair sufficiently small, and choose later stress budgets so the total remaining $L^2$ increment is less than half that lower bound. The resulting limit is nonzero. This uses the lemma's arbitrary error tolerance; it does not require the manuscript's particular fixed sequence $16^{-q}$.

This diagnostic does not contradict an asserted energy inequality: there is none. Strong $C_tL^2$ continuity itself is not an energy-conservation theorem at this vorticity regularity. Nor does the manuscript provide the product integrability or renormalization hypotheses that would force a zero initial vorticity to remain zero.

### Primary-source comparison

I inspected [Bruè–Colombo–Kumar, arXiv:2408.07934v1](https://arxiv.org/html/2408.07934v1), especially Theorem 1.3, §1.2, §4.1, §4.8, and Remark 4.1. Theorem 1.3 already provides nontrivial compact-time solutions on the torus with vorticity in some $L^p$, $p>1$. Their scheme uses a moving Lamb dipole, an enlarged auxiliary source, and a projected time primitive. Formula (4.77) uses the full-cycle average. Formula (4.3) mollifies the old seed; Remark 4.1 identifies the cycle-endpoint field with that mollification, explaining its endpoint discrepancy. These facts refute the proposed compact-time diagnostic as a general obstruction, but do not establish the present whole-plane or initial-trace claims.

### The endpoint radius loss is absent in the displayed norms

The scaling calculation that matters is independent of any literature statement:

\[
\|\operatorname{curl}(\eta D_r)\|_p
=|\eta|\,r^{2/p-2}\|\operatorname{curl}D\|_p.
\]

For $p>1$, shrinking $r$ worsens this norm; an iteration seeking a fixed $p>1$ bound must relate amplitude decay, radius decay, and derivatives of the coarse data quantitatively. At $p=1$, the radius exponent is exactly zero. Thus the present local lemma can fix arbitrarily bad but finite coarse constants and then shrink $H$, hence $r\asymp H^8$, as far as necessary without increasing its principal curl $L^1$ cost. That is the exact mathematical reason the coarse-data dependence in the clock is not a hidden loss at this endpoint.

For the enlarged bump, the needed corrector curl is especially simple:

\[
\operatorname{curl}Q
=-\int_{t_k}^t\bigl(\operatorname{curl}\mathcal U
-\overline{\operatorname{curl}\mathcal U}\bigr)\,ds,
\]

so its $L^1$ norm is $O(\tau BH^{-1})=O(BH^5)$. There is no $L^1$ norm of a general Leray projection here. The full-plane $L^2$ and $L^{3/2}$ projection estimates are separately proved for a fixed bump profile. The two distinct widths $d=H^2$ and $H$ are important: quadrature costs $d/H=H$, while the source primitive costs $\tau/H=H^5$. The radius/support compatibility is $r^{1/5}/H=O(H^{3/5})\to0$. All three requirements improve together.

### What actually has to be added on the plane and at zero

The extra whole-plane obligations are the zeroth- and first-moment cancellations needed for globally $L^1$ anti-divergence, the $L^{3/2}$ increment needed to pair with a non-$L^2$ background, and removal of a possible harmonic velocity component. They are handled respectively in lines 318–388, 248–257 and 570–578, and 915–944; the direct checks are in §§1, 3, 5, and 8 of this report.

For the initial condition, the distinction is exact and consequential. The manuscript never remollifies the old velocity. Each compact patch correction has zero endpoint values, and a color of patches accumulating at zero has a sequence of genuine zero anchors. The uniform stress and local energy bounds then convert those anchors into a weak zero trace, as proved in §7. This does not require the local $L^2$ correction amplitude to go to zero near zero. Such amplitude smallness would be needed to infer a strong initial trace directly; it is not claimed. The singular initial measure also need not be an $L^1$ function because no $C_tL^1$ vorticity trace at zero is claimed for the general-data construction.

**Additional diagnostic outcome: PASS within this scope.** I found no hidden radius, corrector, or clock loss defeating the endpoint $L^1$ estimates. The primary literature is consistent with the local flexibility mechanism. The independently checked whole-plane and weak-trace additions remain the decisive interfaces; they were not obtained by invoking the torus theorem.

## Scope certificate

- **PASS:** All 948 lines of the sole TeX source and the entire supplied target were read; the source was not edited.
- **PASS:** The whole-proof construction, quantifier, conservation, weak-trace, temporal-gluing, and every-time closure attacks documented above received affirmative mathematical checks.
- **PASS:** The stated external background invocation was matched against the primary theorem, assumptions, and definition.
- **PASS:** No other auditor's conclusions or local route papers were consulted.
- **INCONCLUSIVE / outside this report's scope:** This report does not certify the separate 419-container ledger, all nested checks in that ledger, four independent pass verdicts, or their dispute reconciliation. It introduces no competing completeness denominator.
- **PASS within documented scope:** No material obstruction or failed obligation was found. This scoped outcome should not be expanded into a claim that the separate forensic audit procedure has been completed.
