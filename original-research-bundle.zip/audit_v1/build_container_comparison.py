"""Post-audit v1 comparison support. This is not an independent audit pass."""
from pathlib import Path
import json, hashlib, collections, datetime

BASE=Path('/workspace/scratch/de6aed6f6a22/audit_v1')
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def read(name): return json.loads((BASE/name).read_text())

inventory=read('audit_inventory_supplemented.json')
assert sha(BASE/'audit_inventory_supplemented.json')=='6c93b60ef4b6b83665605caf389746d2009bb6f4e7520be9f01dfa67cd5082e2'
assert sha(BASE/'proof.tex')=='b6741b471ba2f128b147f5a5c05fea0afe639c2c3a535b99a5afaf03ea6d4a43'
source=(BASE/'proof.tex').read_bytes()
passes={p:read(f'pass_{p.lower()}.json') for p in 'ABCD'}
supplements={p:read(f'pass_{p.lower()}_supplement.json') for p in 'ABCD'}
original={p:{r['id']:r for r in passes[p]['records']} for p in 'ABCD'}
supp_by_parent={p:collections.defaultdict(list) for p in 'ABCD'}
for p in 'ABCD':
    assert len(original[p])==419
    for r in supplements[p]['records']: supp_by_parent[p][r['parent_id']].append(r)
    assert len(supplements[p]['records'])==6

qc={
 'S0139':'Coordinator quality control: determine the explicitly stated normalization of the direction xi, the rotation convention, and how it links to the scaled pressure in S0141.',
 'S0159':'Coordinator quality control: reconstruct the translated packet identity, including the evaluation point of every D_r/F_r profile, temporal regularity and pressure convention.',
 'S0167':'Coordinator quality control: reconstruct the compact moving-source equation with all translated stress profiles and the pressure-gradient term explicitly located.',
 'S0229':'Coordinator quality control: distinguish the whole complement of the radial bump support from the unbounded exterior of an enclosing disk; test the asserted logarithmic identity on a radial annular bump without assuming a positive core.',
 'S0357':'Coordinator quality control: distinguish weak subsequence extraction for arbitrary bounded-time sequences from the sequences tending to zero needed in the following limit argument.',
 'S0358':'Coordinator quality control: identify the time-sequence hypothesis under which a weak cluster point annihilates all compact solenoidal tests.',
 'S0373':'Coordinator quality control: examine whether LER requires a named positive radius cap at this application or whether its unused radius conclusion may be dropped logically.',
}

disputes={
 'S0049':[('Square-integrability scope','Determine whether “they” includes the undifferentiated multiplier m a-hat, or only the positive-order family xi^alpha m a-hat; separately test the low-frequency squared integral.')],
 'S0139':[('Unit direction and rotation','Determine whether xi is explicitly required to be a unit vector, and reconstruct how rotation and scaling define the direction-dependent profile without silently normalizing xi.')],
 'S0141':[('Scaled pressure definition','Check whether P_r is defined by the source, and reconstruct the scaling of its pressure gradient and the four norm identities; distinguish an implicit conventional definition from a stated one.')],
 'S0158':[('Temporal parameter hypotheses','Determine which temporal regularity follows from r>0, eta>=0 and X\'=eta xi/r, and which additional hypotheses are needed for the derivatives/products in S0159.')],
 'S0159':[('Chain rule under stated data','Reconstruct packet differentiation under exactly S0158 and determine whether derivative products and interface distributions are defined.'),('Translated profiles and pressure','Track the evaluation point x-X(t) of D_r, F_r and the pressure on the right-hand side; decide whether omitted translations are harmless notation or a literal identity gap.')],
 'S0164':[('Uniform bump family','Determine whether the source specifies a fixed dilation across H or only individual support/probability properties; rederive the uniform derivative/projected-profile norms and test permitted thinner families.')],
 'S0167':[('Translated compact-source identity','Reconstruct the pressure absorption and both stress terms with their spatial translations explicit, checking that the displayed U(x-X) and the suppressed stress arguments refer to the same center.')],
 'S0188':[('Meaning of bump width','Determine whether “width H” supplies a uniform dilation/profile condition or merely a support scale, and reconcile this with the supplemented S0164 finding.')],
 'S0210':[('Uniform raster quadrature','Reconstruct the Banach-valued quadrature bound, identify exactly where ||partial_perp U_H||_1 is replaced by C/H, and decide whether the printed family hypotheses provide that replacement.')],
 'S0213':[('Supplemental propagation scope','Determine whether this derivative estimate itself needs a fixed dilation, or instead remains valid with its explicit ||partial_perp U_H||_1 factor; reconcile the original VERIFIED reasons with the supplemental dependency annotation.')],
 'S0215':[('Rectangle-rule H power','Determine whether summing the rectangle-rule estimate justifies the H^{-1} term as printed before any fixed-profile family is supplied.')],
 'S0216':[('Support-only convolution estimate','Determine whether probability and support in B_H already suffice for this translation estimate, and whether the supplemented family gap actually propagates to this parent.')],
 'S0219':[('Quadrature convergence','Determine which exact H-uniform assumptions are necessary for d=H^2 to make the quadrature error vanish.')],
 'S0225':[('Fixed-profile proof scope','Determine whether the announced fixed-profile proof presupposes a cross-scale definition absent from S0164, and which part of its conclusion remains valid for an arbitrary individual bump.')],
 'S0229':[('Exterior support versus exterior disk','Test G*U_1=G at points in an inner hole of an annular radial probability bump, distinguish those points from the unbounded exterior, and determine the exact domain needed for the later tail estimate.')],
 'S0231':[('Projected-profile dilation','Reconstruct the claimed H^{2/p-2} norm bound from the family actually specified in the source; separate the fixed-dilation calculation from its availability as a source hypothesis.')],
 'S0237':[('Corrector scale bounds','Reconstruct the L2, L3/2 and curl-L1 corrector bounds and identify which uniform bump/profile assumptions each exponent uses.')],
 'S0239':[('Gradient bump norm','Determine whether ||grad U_H||_1=O(H^{-1}) follows from the printed declaration or requires a separate scale-family condition.')],
 'S0242':[('Referent and topology of temporal smoothness','Determine whether “resulting velocity” denotes Q, the raw packet/corrector, or the later spatially smoothed increment, and which temporal topology is asserted; check raw interface regularity if relevant.')],
 'S0247':[('Scope of symmetry adjective','Determine whether “all displayed tensors” refers only to grouped symmetric stresses or also to individual cross dyads; separately verify the norm estimates without changing the tensor grouping.')],
 'S0248':[('Cross-stress smallness dependency','Reconstruct each smallness estimate and determine whether the supplemented fixed-family gap leaves this assertion conditional.')],
 'S0249':[('Subcritical increment dependency','Reconstruct the principal and corrector L3/2 norms, distinguishing directly established scaling from the scale-family-dependent part.')],
 'S0268':[('Open patch interpretation','Determine whether the stated open patch J is required to be an interval and whether its support assumptions imply the single-interval construction used at S0278.')],
 'S0270':[('LER bounds under explicit family data','Determine whether the fully quantified local repair follows from the literal bump-family and temporal-parameter specifications; trace only genuine dependencies into its output bounds.'),('Patch generality of LER','Check the local lemma for a disconnected open patch and determine whether the proof as written covers its full stated support quantifier.')],
 'S0275':[('Pasting and patch scope','Determine whether every asserted output pastes in the admissible class under the patch/support generality actually stated, rather than only the interval construction used later.')],
 'S0278':[('Existence of one containing interval','Determine whether compact support in an arbitrary open J guarantees [a,b] compactly contained in J containing all support, and identify any implicit connectedness restriction.')],
 'S0304':[('Fixed versus uniformly bounded amplitudes','Determine whether “fixed amplitudes” means fixed within a chosen construction or independent of N_k, and rederive the derivative-product bound using exactly the established parameter dependence.')],
 'S0305':[('Intrinsic-stress propagation scope','Reconstruct the intrinsic O(H|log H|)+O(H^8) estimate and decide whether it depends only on bump support/mass or on the missing derivative/profile scaling; reconcile supplemental propagation scope.')],
 'S0306':[('Corrector exponent availability','Recompute 6-1 and 6-2/3 and determine whether the underlying projected-profile bounds are licensed by the literal family definition.')],
 'S0308':[('Quadrature convergence dependency','Determine whether the referenced quadrature estimate is available uniformly for the stated family, and therefore whether the error convergence is established.')],
 'S0309':[('Actual old-field cross terms','Reconstruct the actual-old-u Holder bounds and identify which vanishing increment norms are established without an added profile convention.')],
 'S0325':[('Amplitude budget closure','Determine whether the row-rule and corrector errors used for the remaining zeta budget are established under the printed family specification.')],
 'S0327':[('Simultaneous subcritical/radius constraints','Separate radius smallness, principal L3/2 smallness and corrector L3/2 smallness, and determine which of these are conditional on the supplemented family issue.')],
 'S0328':[('Compatible parameter choice','Reconstruct the order of coarse data, mass parameters, fine cycle counts and mollification choices; determine whether all claimed eventual thresholds follow from the stated hypotheses.')],
 'S0336':[('Compact temporal output support','Determine whether both outputs are supported in a compact subset of J under the full open-patch interpretation and the actual chosen containing interval.')],
 'S0348':[('Admissible-class closure dependency','Determine which exact local estimates and support properties establish the claimed admissible-class closure, and how the supplemented omissions affect the conclusion.')],
 'S0357':[('Subsequence time regime','Distinguish the true weak compactness statement for arbitrary time sequences from the t_n downarrow 0 restriction needed to use vanishing trace pairings in S0358.')],
 'S0358':[('Annihilation of the weak limit','Reconstruct why the extracted limit annihilates all compact solenoidal tests and determine whether the source has explicitly restricted the underlying times to tend to zero.')],
 'S0361':[('Iteration theorem dependency','Reconstruct whether the global iteration proposition is established from the local repair as literally written, separating the correctness of the iteration mechanism from unresolved local specifications.')],
 'S0373':[('Unused radius parameter','Determine whether a numerical or patchwise positive r_* must be named to apply LER, or whether existentially forgetting its unused radius output is sufficient without inserting a choice.'),('LER application dependency','Match the current seed, prescribed tensor and budgets to the literally established LER conclusion after accounting for the supplemented bump-family and temporal regularity findings.')],
 'S0379':[('Finite-stage admissibility','Determine whether each stage remains in the admissible class under the local lemma actually established, rather than under a repaired version.')],
 'S0384':[('Stage increment estimate dependency','Reconstruct the dyadic support containment and overlap estimate, then identify whether its required local bound has been established under the literal source choices.')],
 'S0396':[('Exact trace conclusion dependency','Reconstruct the seed-plus-correction weak continuity and initial-value conclusion, distinguishing the valid summable-series argument from existence of the required repaired stages.')],
 'S0397':[('Every-time curl-series conclusion','Reconstruct absolute L1 curl convergence at each fixed positive time and its identification with the velocity curl, including whether the increment bounds it invokes are established.')],
 'S0398':[('Uniform curl variation conclusion','Reconstruct the supremum and summation estimate and determine the dependency status of its local increment input.')],
 'S0401':[('Quadratic limit and stress removal','Check the strong-local-L2 product limit and vanishing stress estimate separately from the existence and bounds of the stage sequence; reconcile whether the whole sentence is conditional.')],
 'S0402':[('Positive-time Euler conclusion','Determine whether the positive-time Euler conclusion follows from the actually established finite-stage construction and convergence assertions.')],
 'S0406':[('Initial weak formulation conclusion','Reconstruct the temporal-cutoff passage and determine whether the exact target formulation is established or remains conditional on the local construction.')],
 'S0414':[('Main-theorem dependency closure','Check whether every target property follows from the literal established lemmas after the supplemental findings, without adopting a charitable missing construction choice or resolving by pass agreement.')],
 'S0415':[('Invocation of global iteration','Determine the precise proven content of the iteration proposition under the literal source conditions and whether every listed conclusion may be invoked unconditionally.')],
 'S0416':[('Every-time canonical hypothesis match','Reconstruct the fixed-background decomposition and its global-L2 perturbation at each time, distinguishing the normalization lemma from the conditional construction of its inputs.')],
 'S0417':[('Every-time canonical conclusion','Determine whether the every-time canonical identity is established for an actually constructed global field, or is a valid conditional consequence awaiting the local construction issue.')],
}

# This records differences in what the source is taken to state; it does not
# decide which interpretation or parent status is correct.
scope_differences={
 'S0049':'Pass B treats the square-integrability pronoun as unresolved; A/C/D restrict it to positive-order multipliers.',
 'S0141':'Pass B treats P_r as undefined; A/C/D provide the natural scaled pressure in their verification rationales.',
 'S0188':'Pass B withholds a fixed-profile interpretation of width H, while other original rationales use a prescribed scaled bump.',
 'S0242':'A/B distinguish raw velocity regularity and withhold the unqualified smoothness assertion; C/D verify a corrector or later mollified-field interpretation.',
 'S0247':'A/B treat the all-tensors adjective as ambiguous; C/D restrict symmetry to paired stress sums.',
 'S0268':'Pass B retains a disconnected-open-patch interpretation that other original verifications do not separately treat.',
 'S0278':'Pass B requires checking whether J is an interval; other original rationales use the existence of a containing interval.',
 'S0304':'A marks the word fixed as ambiguous; B/C/D explicitly use amplitudes varying with N_k but uniformly bounded.',
}

dependency_comments=collections.defaultdict(list)
for a in supplements['D'].get('propagation_analysis',[]):
    for parent in a.get('affected_claims',[]):
        dependency_comments[parent].append({'pass':'D','origin':'pass_d_supplement.json propagation_analysis','earliest_parent':a['earliest_parent'],'rationale':a['analysis'],'explicit_parent_status_update':False})

rows=[]
for s in inventory['containers']:
    sid=s['id']
    assert source[s['byte_start']:s['byte_end_exclusive']].decode()==s['text']
    assert hashlib.sha256(s['text'].encode()).hexdigest()==s['sha256']
    positions={}
    for p in 'ABCD':
        r=original[p][sid]
        assert r['source_sha256']==s['sha256'],(p,sid,'digest mismatch')
        status=r['status']
        supplement_records=supp_by_parent[p].get(sid,[])
        update_notes=[]
        for sr in supplement_records:
            assert sr.get('parent_source_sha256',sr.get('parent_sha256'))==s['sha256']
            frozen_child=next(c for c in s['nested_checks'] if c['id']==sr['child_id'])
            assert sr.get('child_source_sha256',sr.get('child_sha256'))==frozen_child['sha256'],(p,sr['child_id'],'child digest mismatch')
            status=sr.get('aggregate_parent_status_after_supplement',sr.get('updated_parent_status',status))
            update=sr.get('aggregate_parent_status_update')
            if update and 'supplemented_status' in update: status=update['supplemented_status']
            update_notes.append({'child_id':sr['child_id'],'status':sr['status'],'rationale':sr['rationale']})
        for update in supplements[p].get('aggregate_parent_updates',[]):
            if update['parent_id']==sid:
                status=update.get('supplemented_pass_d_status',update.get('updated_parent_status',status))
        child_map={c['id']:c for c in r['nested_checks']}
        for sr in supplement_records:
            child_map[sr['child_id']]={'id':sr['child_id'],'status':sr['status'],'rationale':sr['rationale']}
        assert set(child_map)=={c['id'] for c in s['nested_checks']},(p,sid,'final child coverage')
        rationale=r['rationale']
        if update_notes:
            rationale+='\n\nSupplemental focus records (applied without altering the original pass):\n'+'\n'.join(f"{x['child_id']} [{x['status']}]: {x['rationale']}" for x in update_notes)
        positions[p]={'original_status':r['status'],'aggregate_status':status,'original_rationale':r['rationale'],'rationale':rationale,'supplemental_focus_records':update_notes,'aggregate_changed_by_supplement':status!=r['status'],
                      'final_nested_checks':[child_map[c['id']] for c in s['nested_checks']]}
    values={v['aggregate_status'] for v in positions.values()}
    triggers=[]
    if len(values)>1: triggers.append({'kind':'DIFFERENT_AGGREGATE_STATUSES','detail':'The supplemented A/B/C/D parent aggregate statuses differ.'})
    if any(v not in {'VERIFIED','NOT MATHEMATICAL'} for v in values): triggers.append({'kind':'NONVERIFIED_AGGREGATE','detail':'At least one supplemented parent status is outside VERIFIED/NOT MATHEMATICAL.'})
    if sid in scope_differences: triggers.append({'kind':'MATERIAL_RATIONALE_SCOPE_DIFFERENCE','detail':scope_differences[sid]})
    if sid in qc: triggers.append({'kind':'COORDINATOR_QUALITY_CONTROL','detail':qc[sid]})
    if sid in dependency_comments: triggers.append({'kind':'SUPPLEMENTAL_DEPENDENCY_SCOPE','detail':'A supplemental propagation annotation identifies this claim for dependency review but does not explicitly replace its original aggregate status; its precise scope requires coordinator reconciliation.'})
    row={'id':sid,'filename':s['filename'],'source_lines':[s['line_start'],s['line_end']],'source_sha256':s['sha256'],'exact_source_anchor':s['text'],'mode':s['mode'],'mathematical':s['mathematical'],
         'final_nested_check_ids':[c['id'] for c in s['nested_checks']],'passes':positions,
         'distinct_aggregate_statuses':sorted(values),'escalated':bool(triggers),'escalation_triggers':triggers,'supplemental_dependency_comments':dependency_comments.get(sid,[]),
         'comparison_note':'Parent-level comparison only; child records are supporting coverage/evidence. No final mathematical judgment is assigned.',
         'proposed_dispute_ids':[]}
    rows.append(row)

register=[]
for row in rows:
    if not row['escalated']: continue
    assert row['id'] in disputes,('missing precise escalation focus',row['id'])
    items=[]
    for i,(title,assertion) in enumerate(disputes[row['id']],1):
        rid=f"{row['id']}.R{i:02d}"
        items.append({'id':rid,'title':title,'assertion_to_rederive':assertion,'source_anchor_parent':row['id'],'source_sha256':row['source_sha256'],
                      'original_pass_positions':{p:{'original_status':v['original_status'],'supplemented_aggregate_status':v['aggregate_status'],'original_rationale':v['original_rationale'],'supplemental_reasons':v['supplemental_focus_records']} for p,v in row['passes'].items()},
                      'state':'PROPOSED_FOR_COORDINATOR_RECONSTRUCTION','reconciliation_result':None,'resolution_rationale':None})
    row['proposed_dispute_ids']=[x['id'] for x in items]
    register.append({'parent_id':row['id'],'filename':row['filename'],'source_lines':row['source_lines'],'source_sha256':row['source_sha256'],'exact_source_anchor':row['exact_source_anchor'],
                     'triggers':row['escalation_triggers'],'supplemental_dependency_comments':row['supplemental_dependency_comments'],'dispute_items':items,'reconciled_parent_status':None})

assert len(rows)==419
assert sum(len(r['final_nested_check_ids']) for r in rows)==840
inputs=['proof.tex','audit_inventory.json','audit_inventory_supplemented.json']+[f'pass_{p.lower()}{s}.json' for p in 'ABCD' for s in ['', '_supplement']]
counts={p:dict(collections.Counter(r['passes'][p]['aggregate_status'] for r in rows)) for p in 'ABCD'}
out={'metadata':{'role':'POST-AUDIT COMPARISON SUPPORT — NOT AN INDEPENDENT PASS','authorization':'Coordinator authorized reading the completed original v1 A/B/C/D passes and six-check supplements after independent B had been finalized. This comparison is a separate role and does not revise independent B.',
                 'source_version':'v1 only','source_sha256':sha(BASE/'proof.tex'),'initial_inventory_sha256':sha(BASE/'audit_inventory.json'),'supplemented_inventory_sha256':sha(BASE/'audit_inventory_supplemented.json'),
                 'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'input_hashes':{name:sha(BASE/name) for name in inputs},'permanent_containers':419,'consolidated_shared_children':840,
                 'parent_first_matching_key':'Permanent source container id; never child count or child numbering.','source_mutations':False,'independent_pass_mutations':False,'v2_material_read':False,'v2_auditors_contacted':False,
                 'comparison_rules':['Escalate any parent aggregate disagreement.','Escalate any aggregate outside VERIFIED/NOT MATHEMATICAL.','Escalate identified material differences of rationale scope.','Escalate the seven requested coordinator quality-control parents.','Preserve supplemental propagation annotations without silently assigning new pass statuses; escalate their parent scope for reconstruction.'],
                 'status_counts_after_explicit_supplement_updates':counts,'explicit_changed_pass_parent_records':sum(v['aggregate_changed_by_supplement'] for r in rows for v in r['passes'].values()),'escalated_containers':len(register),'proposed_dispute_items':sum(len(x['dispute_items']) for x in register),'resolved_dispute_items':0,
                 'uncovered_containers':0,'missing_parent_pass_verdicts':0,'missing_final_child_pass_verdicts':0,'digest_mismatches':0,
                 'provenance_notice':'The immutable B metadata records an accidental prior exposure affecting the narrow external mapping-display independence check. That provenance is preserved; this deliberately non-independent support comparison creates no replacement pass and supplies no proof verdict.',
                 'reconciliation_policy':'No majority vote, no final proof verdict, no final container mathematical status. All local R identifiers are proposals for root reconstruction.'},
     'containers':rows,'escalation_register':register}
(BASE/'container_comparison.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')

def esc(value): return str(value).replace('&','&amp;').replace('|','&#124;').replace('\n','<br>')
md=['# Frozen v1 — post-audit container comparison support','',
    '**Role:** comparison support after the independent passes. This is not an independent audit, a reconciliation outcome, or a proof verdict. The completed A/B/C/D v1 records and six-check supplements were read only for this task. No v2 source or auditor was consulted.','',
    f"Source SHA-256: `{sha(BASE/'proof.tex')}`. Supplemented inventory SHA-256: `{sha(BASE/'audit_inventory_supplemented.json')}`.",'',
    f"Coverage: **419 parent containers × 4 pass verdicts**, **840 final shared children × 4 child verdicts**. There are **{len(register)} escalated parents** and **{sum(len(x['dispute_items']) for x in register)} proposed local dispute items**; all remain unresolved for coordinator reconstruction. No source, original pass, or supplement was changed.",'',
    'Only explicit supplement parent updates are applied to the A/B/C/D columns. Supplemental dependency comments remain annotations and trigger review; they are not silently converted into new pass verdicts. Compatible differences of derivation detail do not create child-level comparison keys.','',
    'The immutable B independence disclosure is preserved in the companion metadata; this separate comparison role is intentionally permitted to inspect all completed v1 passes.','',
    '## Supplemented parent status counts','',
    '| Pass | VERIFIED | UNJUSTIFIED | AMBIGUOUS | NOT MATHEMATICAL |','|---|---:|---:|---:|---:|']
for p in 'ABCD': md.append('| '+p+' | '+' | '.join(str(counts[p].get(k,0)) for k in ['VERIFIED','UNJUSTIFIED','AMBIGUOUS','NOT MATHEMATICAL'])+' |')
md+=['','## Parent-level comparison index','','Each row is keyed only by its permanent parent. Exact anchors, all four unabridged rationales, and final child IDs follow in the full ledger and JSON companion. No column here is a final mathematical verdict.','',
     '| Parent | Lines | Mode | Math? | A | B | C | D | Escalate | Proposed items |','|---|---|---|---|---|---|---|---|---|---|']
for r in rows:
    md.append('| '+' | '.join([r['id'],f"{r['source_lines'][0]}–{r['source_lines'][1]}",r['mode'],'yes' if r['mathematical'] else 'no']+[r['passes'][p]['aggregate_status'] for p in 'ABCD']+['yes' if r['escalated'] else 'no',', '.join(r['proposed_dispute_ids']) or '—'])+' |')
md+=['','## Neutral escalation register','','Every item below is proposed, not decided. The precise assertion is a reconstruction task. The original and supplemental pass reasons appear verbatim under the same parent in the full ledger and in each JSON dispute item.']
for r in register:
    md+=['',f"### {r['parent_id']}",'',*['- **'+t['kind']+':** '+t['detail'] for t in r['triggers']]]
    for d in r['dispute_items']:
        md+=['',f"**{d['id']} — {d['title']}**",'',d['assertion_to_rederive'],'','State: proposed for coordinator reconstruction. Resolution: unset.']
    if r['supplemental_dependency_comments']:
        md+=['','Supplemental dependency annotations (verbatim; no automatic verdict change):']
        for d in r['supplemental_dependency_comments']: md+=['',f"- {d['pass']} / {d['earliest_parent']}: {d['rationale']}"]
md+=['','## Full permanent-container ledger','','The exact source object in every code block is unchanged. Each A/B/C/D rationale is reproduced verbatim from its original record, followed by any supplement. Statuses shown are that pass\'s explicit supplemented aggregate, not a reconciled judgment.']
for r in rows:
    md+=['',f"### {r['id']}",'',f"`{r['filename']}`, lines {r['source_lines'][0]}–{r['source_lines'][1]}; mode `{r['mode']}`; mathematical content: {'yes' if r['mathematical'] else 'no'}.",'',f"SHA-256: `{r['source_sha256']}`.",'','```tex',r['exact_source_anchor'],'```','',
         'Final shared child IDs: '+(', '.join(r['final_nested_check_ids']) if r['final_nested_check_ids'] else 'none (simple or structural parent)')+'.','',
         'Escalation: '+(', '.join(r['proposed_dispute_ids']) if r['escalated'] else 'no trigger assigned in this comparison')+'.']
    for p,v in r['passes'].items():
        suffix=f" (originally {v['original_status']}; explicit supplement update)" if v['aggregate_changed_by_supplement'] else ''
        md+=['',f"**Pass {p}: {v['aggregate_status']}{suffix}**",'',v['rationale']]
md+=['','## Comparison-support validation','',
    '- 419/419 permanent parent identifiers and exact source digests match all four original passes.',
    '- 840/840 consolidated shared child identifiers have a verdict from all four passes after adding the six-check supplements.',
    '- Every differing or non-verified supplemented parent aggregate is escalated.',
    '- The seven coordinator quality-control parents are escalated, including S0229.',
    '- Supplemental propagation comments are preserved without invented pass updates.',
    '- Proposed local dispute IDs remain under their original permanent parents; no parent was split, merged or renumbered.',
    '- No dispute has been decided, no majority vote used, and no final proof verdict assigned.','']
(BASE/'container_comparison.md').write_text('\n'.join(md))
print(json.dumps({'counts':counts,'escalated':len(register),'proposed_items':sum(len(x['dispute_items']) for x in register),'escalated_ids':[x['parent_id'] for x in register]},indent=2))
