# Independent pass D: global consistency and dependency audit

**Verdict: PASS for this independent mathematical pass.** I found no definite mathematical error, unsupported theorem application, unresolved dependency gap, or circularity in the frozen candidate. This is one pass's conclusion, not the coordinator's four-pass reconciliation certificate. The complete source-ordered judgments and all shared-child judgments are in `pass_d.json`.

## Scope and independence

I examined `proof.tex`, lines 1–948, in source order and compared the claim with `target_problem.txt`. I used the frozen neutral `audit_inventory.json`, `audit_formulas.json`, and `audit_notation.md`, and read the entire forensic audit prompt. No earlier audit, route packet, checkpoint, dependency-provenance file, or another pass's output was opened. A directory listing exposed filenames but no earlier mathematical conclusions. An attempted delegation was refused by the agent-thread limit; no delegated mathematical work is claimed.

The exact source SHA-256 is `b6741b471ba2f128b147f5a5c05fea0afe639c2c3a535b99a5afaf03ea6d4a43`. The inventory SHA-256 is `efbd3fc4311f910b394581f46718f3b73a03f99a5891b38d2e7e2be24d7b9b71`. I checked every container's exact byte span and digest against that source, every shared child span, and every formula span and digest. Neither frozen file was edited.

There are no `input`, `include`, or external bibliography dependencies. All seven meaning-bearing macros were inspected. All 25 labels and 27 references resolve, with no duplicate label or undefined reference. The two frozen boundary groups remain unchanged: S0176 contains the unpunctuated coefficient definition followed by its tensor identity; S0221 contains the comma-terminated complete-cycle corrector definition. Their mathematical meanings are determinate in context.

The named external paper was retrieved directly from its primary publisher. Standard analytic principles were also matched to their precise hypotheses; where useful their particular applications were independently reduced to explicit integrals, multiplier bounds, or difference estimates. A failed attempt to import SymPy provided no mathematical evidence. Exact arithmetic checks subsequently used Python's `fractions.Fraction` and succeeded.

## Coverage

| Item | Inspected by pass D | Total |
|---|---:|---:|
| Source lines | 948 | 948 |
| Permanent containers | 419 | 419 |
| Mathematical containers | 388 | 388 |
| Nonmathematical containers | 31 | 31 |
| Compound containers | 252 | 252 |
| Shared nested checks | 834 | 834 |
| Inline formula occurrences | 512 | 512 |
| Display formula occurrences | 59 | 59 |
| Algebra-bearing containers independently re-derived | 106 | 106 |
| External-theorem flagged containers matched | 22 | 22 |
| Proof environments | 8 | 8 |
| Major-result dependency maps | 8 | 8 |
| Supplemental checks identified by pass D | 4 | 4 |
| Uncovered containers / missing D verdicts | 0 | 0 |

The permanent modes are 380 SENTENCE, 37 STRUCTURAL, and 2 BOUNDARY-GROUP. Container outcomes are **388 VERIFIED**, **31 NOT MATHEMATICAL**, and zero of every other permitted status. Shared-child outcomes are **831 VERIFIED** and **3 NOT MATHEMATICAL**: S0130.C05 is empty, S0130.C10 is whitespace, and S0130.C11 is the cases delimiter. The mathematical two-branch expression was checked in its entirety despite those mechanical focus spans.

Every parent rationale in the JSON records an affirmative derivation or exact interface check. Its nested records carry that derivation in the complete parent scope, including duplicate or partial focus spans in the shared inventory. Four supplemental checks are listed under their existing parents; the coordinator assigns their final child IDs. They concern S0084's relative-L2 continuity clause, the removable polar origin in S0130, the negative gradient flux in S0162, and the freely selectable positive radius budget in S0373. All four are VERIFIED.

## Findings and limitations

There is no numbered list of definite errors because none was found by this pass. There is no earliest erroneous container and consequently no error-propagation chain in this independent result. All eight major conclusions survive the dependency checks below. The manuscript is not merely conditionally reduced to an unquoted endpoint repair theorem: the endpoint repair is constructed in S0122–S0349 and was checked locally as well as at its interfaces.

The following points deserve explicit notation in a polished manuscript, but I do not classify them as mathematical failures:

- **S0141:** the naturally associated scaled pressure is `P_r(x)=r^-2 P(x/r)`, after the stated rotation. Substitution verifies the displayed equation; an arbitrary spatial constant is irrelevant.
- **S0164, S0225–S0231:** the freely chosen probability bumps are the fixed-profile family `U_H(x)=H^-2 U_1(x/H)`. The later fixed-profile scaling specifies the intended choice; no condition on prescribed data is added.
- **S0247:** symmetry refers to the stress tensors and paired cross dyads such as `u⊗v+v⊗u`; an isolated dyad generally is not symmetric. Every actual stress in the identity is symmetric.
- **S0278:** the written construction uses interval patches, exactly the `I_j` used globally. If “open patch” also allows a disconnected open subset of time, the compact support meets only finitely many relevant components, and the construction applies componentwise. This does not affect any application in the manuscript.
- **S0304:** the amplitudes depend on the chosen cycle count, but their upper bounds are uniform for large counts by S0298. The displayed derivative estimate uses those uniform bounds, not literal constancy across different constructions.

The target does not ask for energy admissibility, vorticity transport/renormalization, uniqueness, or a uniform-in-stage global L3 estimate. None of those stronger properties was used to justify the conclusion. No claim about them is part of this pass.

## Dependency maps

Every range below denotes the specified permanent IDs inclusively; all listed dependencies have pass-D status VERIFIED. The JSON supplies each range as an explicit ID array.

### 1. Canonical decomposition: S0034–S0039, proof S0040–S0052

| Dependency | IDs | Function in the argument |
|---|---|---|
| Exact datum/kernel conventions | S0026–S0033 | Finite signed measure, inhomogeneous H^-1, Fourier and curl orientation |
| Local convolution and distribution identities | S0040–S0043 | Define K*mu without spatial moments or compact support |
| Radial cancellation and L1 kernel | S0044–S0046 | `L_a=K-K*a` is compactly supported and integrable |
| High-frequency multiplier estimate | S0047–S0048 | v0 is global L2 under exactly inhomogeneous H^-1 |
| Low-frequency multiplier and finite-measure convolution | S0049–S0052 | V0 is bounded smooth C0; all claimed derivative and variation bounds |

The decomposition preserves nonzero total circulation in V0. It does not replace inhomogeneous H^-1 by homogeneous H^-1. Its L1 component is essential to the bounded initial stress, and its C0 component is used again in the final normalization.

### 2. Bounded background: S0060–S0061, proof S0062–S0090

| Dependency | IDs | Function |
|---|---|---|
| Smoothed datum properties | S0034–S0052 | nu0 is signed L1∩Linfinity, with finite L2 norm |
| External bounded-vorticity existence interface | S0054–S0059, S0062 | One global canonical Lagrangian source solution |
| Osgood flow and volume preservation | S0065–S0072 | Every-time representatives and L1/L2 norm preservation |
| Near–far velocity bound and weak-L2 distribution function | S0073–S0082 | Uniform bounded velocity and global L3 |
| Integrated transport and order-zero Fourier multiplier | S0083–S0088 | Every-time relative L2 Lipschitz continuity and C_tL3 |
| Curl-free acceleration | S0089–S0090 | Distributional velocity Euler equation and pressure |

No smoothness theorem for the rough global background is invoked. The time representative is fixed before it is used in every-time estimates. The pressure is obtained from a globally L2 curl-free acceleration; global L2 of V itself is unnecessary.

### 3. Initial Euler–Reynolds seed: S0096–S0100, proof S0101–S0114

| Dependency | IDs | Function |
|---|---|---|
| v0 in L1∩L2, sigma0 finite | S0034–S0052 | Convolution and integrable cross stresses |
| Global background and initial trace | S0060–S0090 | Exact old Euler equation, bounded V, C_tL3, relative L2 |
| ER sign and quartic kernel | S0092–S0095 | Stress sign and `partial_t W=-4t^3 Delta^2 W` |
| Divergence identity and kernel derivative scaling | S0101–S0108 | Symmetric derivative stress has L1 cost C t||sigma0|| |
| Trace and positive-time product continuity | S0109–S0114 | All inputs needed for LER and the iteration majorant |

The stress remains bounded as t approaches zero, even when initial vorticity is singular. The factors C_b are retained because the quartic kernel need not be positive.

### 4. Prescribed-piece LER: S0261–S0275, proof S0276–S0349

| Dependency | IDs | Function |
|---|---|---|
| Explicit translating dipole | S0122–S0142 | Correct speed, pressure, core matching and critical L2/curl norms |
| Symmetric anti-divergence | S0144–S0156 | Zero mean and all first moments give globally integrable stresses |
| Compact packet source | S0158–S0168 | Exact `2pi(eta r)' U_H xi` source and small intrinsic error |
| Directional stress coefficients | S0171–S0178 | Nonnegative decomposition of `-S+qI` with universal mass bound |
| Positive-floor raster, ramps, exact normalization | S0181–S0209 | Single active packet; exact cycle duration and row weight |
| Two-scale rectangle rule | S0210–S0219 | d=H² samples a bump of width H with vanishing L1 error |
| Projected full-cycle primitive | S0221–S0242 | Small Q, zero endpoint trace, correct averaged tensor and pressure sign |
| Nonlinear stress identity | S0243–S0250 | All old/new and new/new terms with integrable global bounds |
| Constant-cycle spatial smoothing | S0252–S0260 | Spatial smoothness without remollifying old fields or adding time-kernel errors |
| Coarse L1 approximation and parameter order | S0276–S0328 | Independent stress, amplitude, L3/2 and radius budgets |
| Boundary choices and continuity | S0329–S0349 | Exact every-time algebra, distributional pasting and preservation of the class |

The universal leading bound follows from `eta_i²=(2/pi)d B_i` and the coefficient L1 bound. Derivative norms, rectangle size, positive-floor reciprocals and the current old-field L3 norm only determine how small H must be. The number of coarse cells does not multiply the instantaneous amplitude, because their time interiors are disjoint. Within a cycle only one principal packet is active.

The source reduction's factor 2pi was checked independently by the two boundary fluxes: the integral of D_r over a large disk is pi r xi, while the integral of grad Pi_r is -pi r xi. Their compact difference has mean 2pi r xi. The zero first moments then permit the stated integrable anti-divergence. The complete-cycle integration by parts has positive sign: `(eta r U_H(x-X))'=(eta r)'U_H-eta² xi·grad U_H`. This produces the required averaged rank-one tensor.

The projected-bump pressure was also checked directly. From `Q'=-P(U-Ubar)`, one gets `Q'+U=Ubar+grad(pi_U-average pi_U)`; the chosen `p_Q=-pi_U+average pi_U` cancels it. Subtracting `qI` from the final stress requires subtracting q from the intermediate pressure, as S0318 states. The spatial commutator has positive right-hand-side sign `v_ell⊗v_ell-(v⊗v)_ell`.

### 5. Anchor-time trace lemma: S0351–S0353, proof S0354–S0360

The only earlier dependency is the ER convention S0092. The lemma explicitly assumes uniform local kinetic energy, global L1 stress, positive-time continuous local L2 velocities, a globally bounded L2 difference, and actual zero difference at times descending to zero.

Testing the difference against compact solenoidal fields gives a uniform Lipschitz bound on the pairing. Its zero anchors force zero limiting pairings. Boundedness in the Hilbert space L2 supplies subsequential weak compactness. A cluster point is both divergence free and curl free, and its Fourier transform vanishes off frequency zero; an L2 transform cannot be supported at that single point. Thus the entire difference has weakly zero initial trace. No global velocity energy or pressure estimate is assumed.

### 6. Global iteration: S0361, proof S0362–S0406

| Dependency | IDs | Function |
|---|---|---|
| Admissible seed and bounded initial stress | S0096–S0114 | Base stage, exact trace and finite majorant Theta |
| LER, including independent prescribed piece | S0261–S0349 | Remove each original chi_j R^(q) using the current repaired pair |
| Three-color dyadic geometry | S0362–S0367 | Local finiteness, bounded overlap and exact gap anchors |
| Stress budget and stage estimates | S0368–S0387 | Pointwise stress decay and summable L2/curl increments |
| Anchor lemma and partial-color bounds | S0351–S0360, S0388–S0392 | Every finite stage retains the exact weak initial trace |
| Uniform correction convergence | S0393–S0400 | Positive-time strong continuity and every-time finite curl variation |
| Quadratic limit and initial temporal cutoff | S0401–S0406 | Exact target weak equation including t=0 |

The frozen pieces sum to the original stage stress even after earlier colors change the background. This avoids a circular cancellation assumption. Within a color, temporal supports are disjoint, so cross terms between its separate patch increments vanish. Different colors are processed sequentially with all actual current-field cross terms charged in LER.

At every active time, `m_j<=Theta(t)`, yielding the pointwise next-stage stress bound. If a patch meets `(0,T]`, its whole interval lies in `(0,4T)`, yielding the stage increment constant involving only `Theta(4T)`. The square-root geometric sequence is `4^-q`, whose sum is finite. Partial colors satisfy the same bounds, which is essential before applying the trace lemma.

The infinite union of all stage boundaries need not be locally finite; the proof never uses that stronger statement. Local finiteness is required at each finite stage only. The limiting equation follows from uniform L2 convergence and vanishing stress, and the limiting every-time curl follows from an absolutely convergent L1 series at each fixed time. No weak compactness argument is substituted for this strong quadratic passage.

### 7. Fixed-background normalization: S0407–S0408, proof S0409–S0413

Dependencies are the finite-measure convolution bound and distributional kernel identities S0040–S0043. They do not require later-time H^-1. For `u=U+v`, with U in C0 and v in global L2, the residual `h=u-K*mu` is locally integrable and distributionally harmonic. Weyl's lemma is applicable componentwise.

The average estimate separates the three terms exactly. The U average tends to zero by C0 decay; the v average is at most C||v||2/R; and the Biot–Savart average is at most C||mu||/R. Letting R grow forces h to vanish. This excludes constant and other harmonic velocity additions without imposing zero circulation.

### 8. Exact-target global theorem: S0414, proof S0415–S0418

Dependencies are S0361–S0406 for the global velocity and weak initial formulation; S0407–S0413 for canonical normalization; S0038/S0050 for V0 in C0; S0060/S0084/S0086 for every-time `V(t)-V0` in L2; S0098/S0104 for W(t) in L2; and S0384/S0393 for the L2 correction series.

At each positive time the same fixed C0 background V0 is used. Its perturbation is `(V(t)-V0)+W(t)+sum_q w_q(t)`, a globally L2 vector field. The final curl is a finite measure at that exact time, so the canonical lemma applies time by time. At zero the input identity `u0=K*mu0` is already prescribed. The construction is global from the outset; no independently chosen finite-horizon solutions must be glued.

## Exact-target and admissibility table

| Target/interface requirement | Established in | Check |
|---|---|---|
| All finite signed measure∩inhomogeneous H^-1 data | S0027, S0034–S0052 | No Jordan-part energy, compact support, moment, sign, or zero-mass condition added |
| Canonical initial velocity in local L2 | S0035–S0052 | Finite-measure convolution plus bounded/L2 decomposition |
| Positive-time finite-stage C_t local L2 and global L3 | S0100–S0114, S0337–S0348, S0379 | Exactly the class used in LER; no uniform stage L3 conclusion used |
| Symmetric integrable stresses | S0096–S0108, S0244–S0247, S0317–S0348 | Every cross dyad is paired; tails retain global L1 integrability |
| One-sided time-partition traces and actual boundary values | S0263–S0265, S0281–S0282, S0333–S0335 | Actual values are independent of traces and do not alter the distributional equation |
| Every finite-stage exact initial trace | S0388–S0392 | All anchor lemma hypotheses checked for each of three colors |
| C_w([0,infinity);L2_loc), u(0)=u0 | S0393–S0396 | Strong positive-time limit; finite-head/small-tail weak trace at zero |
| Every-time measure curl and finite-horizon variation | S0397–S0399 | Positive-time L1 curl series plus the initial finite measure |
| Divergence zero | S0400 | Distributional passage from every finite stage |
| Quadratic Euler term and initial weak formulation | S0401–S0406 | Strong local L2 convergence, vanishing stress, bounded-energy cutoff |
| Canonical velocity at every time | S0407–S0417 | Fixed C0 background normalization, applied separately at each positive time |

The basic fields are strongly measurable in their claimed Banach spaces. Background time continuity precedes its Bochner integrals. New increments are continuous in the required Lp spaces. The stress pieces have continuous one-sided L1 extensions with only locally finite exceptional times at each finite stage; thus their integrals and weak equations are defined. Countable patch sums are locally finite at positive time. Uniform correction bounds ensure all compact-cylinder linear and quadratic integrals converge. At zero the local energy bound controls omitted integrals, while weak local continuity identifies the initial term.

## Constants and parameter order

The compatible order for each LER application is:

1. Fix a compact time interval and a finite inherited one-sided partition.
2. Choose the coarse approximation tolerance satisfying both the stress and amplitude slack requirements; choose the finitely many smooth compact tensors.
3. Fix their rectangles and ramps, then choose positive regularization and floor masses small enough for both averaging and amplitude budgets.
4. Increase each integer cycle count. Set `tau=cell length/N`, `H=tau^(1/6)`, `d=H²`; use the exact amplitude/radius normalization.
5. After the cycle counts are finite and fixed, choose the constant-in-cycle spatial mollification scales small enough for the remaining commutator and averaging errors.

At fixed coarse data, the principal radii are comparable to H⁸, the compact-source radius is O(H^(8/5))=o(H), the intrinsic stress is O(H|log H|)+O(H⁸), the corrector's L2 and curl-L1 norms are O(H⁵), its L3/2 norm is O(H^(16/3)), and the principal L3/2 norm is O(H^(8/3)). Each needed error therefore vanishes. Positive floors are fixed before these limits, so their potentially large logarithmic derivative constants are harmless. No parameter must be simultaneously fixed and sent to zero in an incompatible order.

## External theorem and standard analytic interface checks

The primary [Crippa–Stefani article](https://link.springer.com/article/10.1007/s00526-024-02750-4) was inspected at Assumptions 2.1 and 3.1, Definition 3.2, and Theorem 3.3. It supplies the bounded-vorticity Lagrangian interface claimed in the manuscript. The datum nu0 satisfies its signed L1∩Linfinity condition; the plane has no boundary condition; the displayed kernel identities verify its size/difference assumptions, and divergence is zero. The manuscript separately proves every-time representatives, norm preservation, relative L2 continuity, L3 continuity, and the velocity formulation. It does not attribute those extra steps to an unavailable smoothness result.

All 22 inventory-flagged containers received the following matching:

| Container(s) | Principle and hypotheses actually checked |
|---|---|
| S0040 | Tonelli for the nonnegative absolute kernel integral; finite translated-ball bound times finite measure mass |
| S0046 | L1 Young/measure convolution; integrable compact kernel and finite total variation, proved directly by Tonelli |
| S0048 | Plancherel with the explicit bounded multiplier weighted by `(1+|xi|²)^-1`; exactly inhomogeneous H^-1 |
| S0050 | Fourier inversion and Riemann–Lebesgue for bounded mu-hat times the checked L1 multipliers, including every differentiated one |
| S0054, S0062 | The named primary theorem and its exact datum, domain, kernel, divergence and canonical-solution interfaces |
| S0065 | Osgood reciprocal-modulus divergence; bounded time-measurable velocity gives global finite-horizon trajectories, uniqueness and backward flow |
| S0067 | Spatially smooth mollified velocity, bounded derivatives at fixed scale, divergence zero; the Jacobian ODE preserves volume |
| S0069 | Dominated convergence on a common bounded transported-support set, supplied by the displacement bound |
| S0081 | Chebyshev applied to the L1 near convolution at threshold lambda/2; zero-measure case is trivial |
| S0082 | Nonnegative layer cake, with weak-L2 distribution bound and bounded-velocity upper cutoff |
| S0104 | Plancherel contraction and dominated convergence against `|v0-hat|²` |
| S0110 | Absolute Fubini against compact tests using the translated-ball kernel bound and finite convolution masses |
| S0126 | Intermediate value theorem for the continuous Bessel power series and exact opposite endpoint signs |
| S0128 | Uniqueness for the regular linear Bessel ODE at positive beta, with zero value and derivative |
| S0214 | Fundamental theorem for a C1 map into L1; integrated triangle inequality over each finite row interval |
| S0232 | Minkowski/Bochner integration for finite-time translates of an explicitly bounded Lp profile, p>1 |
| S0256 | Approximate identities are uniformly convergent on compact L2 and L1 sets; continuity of squaring connects them |
| S0309 | Hölder pairs (3,3/2) and (2,2), with finite old global L3 norm on a compact interval |
| S0338 | Young exponents 2 and 6/5 to 3; `||rho_ell||_(6/5)=C ell^(-1/3)` |
| S0357 | Bounded sequence in global L2; Hilbert weak subsequence compactness, also obtainable by countable dense-test diagonal extraction |
| S0409 | Weyl for a locally integrable distribution with Delta h=0; the div/curl identity establishes this hypothesis componentwise |

## Edge cases and independent corroboration

- **Zero datum/zero prescribed stress:** the datum decomposition is zero when mu=0; LER explicitly uses the zero correction when delta=0. No zero amplitude is divided by in an active scan.
- **Zero directional coefficient:** an idle quarter-cycle is allowed; otherwise a fixed positive floor supplies positive B_i and positive radius. Vanishing original coefficients on individual coarse cells do not obstruct adding arbitrarily small floors.
- **Nonzero circulation/noncompact data:** the bounded C0 background absorbs the 1/|x| far field; no global L2 velocity or finite first moment is used. The canonical lemma uses only finite measure mass.
- **Signed cancellations:** all kernel and stress estimates use total variation or absolute norms. No positivity of the original vorticity or its Jordan components is assumed.
- **Spatial infinity:** the anti-divergence retains all first-moment cancellations, eliminating the nonintegrable generic 1/|x|² stress tail. The projected velocity has a 1/|x|² tail in every Lp, p>1, and old/new products use L3–L3/2, not an unjustified L2–L2 estimate for the background.
- **Circle/core interfaces:** exact Bessel identities match the streamfunction through two spatial derivatives; q=0 at the circle removes boundary vorticity/pressure terms. The polar origin is removable by the power series.
- **Temporal resets:** flat amplitude endpoints make the packet vanish, the full-cycle primitive makes Q vanish, and stress jumps are allowed because only spatial divergence acts on them. A change of smoothing scale occurs only at zero increment traces.
- **Approach to zero time:** stage energy need not approach the seed energy strongly. The anchor lemma supplies weak trace and the uniformly small L2 tail passes it to the limit. This is the exact continuity requested by the target.
- **Unbounded final stage derivatives/L3 norms:** fine profiles may have large derivatives and global L3 norms, but each finite stage satisfies LER and the convergence proof uses only the uniformly summable norms it actually establishes.

Exact rational arithmetic confirmed the alternating-series truncations `J1(3)` through k=3 as `669/2048=(3/2)(223/1024)` and `J1(4)` through k=4 as `-2/45`. The alternating remainder signs were checked analytically from the term ratio. Exact rational matrix tests at a mixed-sign and a zero stress agreed with `-S+(A+B)I`; the universal tensor equality was separately proved by component expansion, so the finite tests are corroboration only.

## Pass-D completeness certificate

- PASS — All received mathematical source for this pass was inventoried: one TeX file, 948 lines, no missing include.
- PASS — Every source line and byte is represented by the frozen 419-container partition; exact spans and digests were validated.
- PASS — Permanent identifiers and source bytes remained unchanged; the two boundary groups were retained.
- PASS — Every one of 252 compound containers was inspected with its single shared nested layer; all 834 shared children were checked.
- PASS — Every permanent container has one pass-D verdict: 388 VERIFIED and 31 NOT MATHEMATICAL; none is missing.
- PASS — All 388 mathematical containers, their shared children and four pass-D supplemental checks received affirmative mathematical checks.
- PASS — All 571 formula occurrences were inspected in full source context and their frozen spans/digests validated.
- PASS — All 106 algebra-bearing containers were independently re-derived, including signs, scales, normalization factors and inequalities.
- PASS — All 22 theorem-application containers received explicit hypothesis matching; the named primary source was retrieved.
- PASS — All 8 proofs were checked locally and globally, and all 8 major results have permanent-ID dependency maps.
- PASS — Degenerate, signed, noncompact, endpoint, zero-time and every-time cases were investigated.
- PASS — Definitions, scoped reused symbols, macro meanings and all 27 references were checked across the manuscript.
- PASS — No dropped target assumption, circular dependency, or propagated mathematical error was found by this pass.
- PASS — No pass-D substantive issue remains unresolved; its four verified supplemental checks have been sent to the coordinator for shared-ID consolidation.
- PASS — Computational corroboration is distinguished from proof; no failed computation or unavailable subagent is claimed as evidence.
- PASS — This certificate is limited to independent pass D: cross-pass escalation, reconciliation, other passes' coverage and the combined final certificate remain the coordinator's responsibility.
