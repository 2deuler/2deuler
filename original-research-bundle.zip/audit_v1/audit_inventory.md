# Neutral permanent-container inventory

Source SHA-256: `b6741b471ba2f128b147f5a5c05fea0afe639c2c3a535b99a5afaf03ea6d4a43`.

State: FROZEN. Exact texts and full digests are in audit_inventory.json.

| Container | Lines | Mode | Math | Children | Exact opening excerpt |
|---|---:|---|---|---:|---|
| S0001 | 1–1 | STRUCTURAL | no | 0 | `\documentclass[11pt]{article}` |
| S0002 | 2–2 | STRUCTURAL | no | 0 | `\usepackage[T1]{fontenc}` |
| S0003 | 3–3 | STRUCTURAL | no | 0 | `\usepackage{amsmath,amssymb,amsthm,mathtools,geometry,hyperref,array,xcolor}` |
| S0004 | 4–4 | STRUCTURAL | no | 0 | `\geometry{margin=1in}` |
| S0005 | 5–5 | STRUCTURAL | no | 0 | `\setlength{\emergencystretch}{3em}` |
| S0006 | 6–6 | STRUCTURAL | no | 0 | `\hypersetup{hidelinks}` |
| S0007 | 7–7 | STRUCTURAL | no | 0 | `\newtheorem{theorem}{Theorem}[section]` |
| S0008 | 8–8 | STRUCTURAL | no | 0 | `\newtheorem{lemma}[theorem]{Lemma}` |
| S0009 | 9–9 | STRUCTURAL | no | 0 | `\newtheorem{proposition}[theorem]{Proposition}` |
| S0010 | 10–10 | STRUCTURAL | no | 0 | `\theoremstyle{remark}\newtheorem{remark}[theorem]{Remark}` |
| S0011 | 11–11 | STRUCTURAL | yes | 0 | `\newcommand{\R}{\mathbb R}` |
| S0012 | 12–12 | STRUCTURAL | yes | 0 | `\newcommand{\M}{\mathcal M}` |
| S0013 | 13–13 | STRUCTURAL | yes | 0 | `\newcommand{\curl}{\operatorname{curl}}` |
| S0014 | 14–14 | STRUCTURAL | yes | 0 | `\newcommand{\Div}{\operatorname{div}}` |
| S0015 | 15–15 | STRUCTURAL | yes | 0 | `\newcommand{\supp}{\operatorname{supp}}` |
| S0016 | 16–16 | STRUCTURAL | yes | 0 | `\newcommand{\norm}[2]{\left\\|#1\right\\|_{#2}}` |
| S0017 | 17–17 | STRUCTURAL | yes | 0 | `\newcommand{\dd}{\,dx}` |
| S0018 | 18–18 | STRUCTURAL | no | 0 | `\title{Global weak Euler flows for finite signed vorticity on the plane}` |
| S0019 | 19–19 | STRUCTURAL | no | 0 | `\author{Research manuscript}` |
| S0020 | 20–20 | STRUCTURAL | no | 0 | `\date{8 October 2026}` |
| S0021 | 21–21 | STRUCTURAL | no | 0 | `\begin{document}` |
| S0022 | 22–22 | STRUCTURAL | no | 0 | `\maketitle` |
| S0023 | 23–24 | SENTENCE | no | 0 | `\noindent Research proof manuscript.` |
| S0024 | 24–26 | SENTENCE | no | 0 | `Verification status is recorded in the accompanying audit report; this source alone is not a verification certificate.` |
| S0025 | 26–28 | STRUCTURAL | no | 0 | `\paragraph{Exact target.}` |
| S0026 | 29–29 | SENTENCE | yes | 0 | `Let $K(x)=(-x_2,x_1)/(2\pi\|x\|^2)$.` |
| S0027 | 29–31 | SENTENCE | yes | 5 | `Given any finite signed Radon measure $\mu_0\in\M(\R^2)\cap H^{-1}(\R^2)$, with the \emph{inhomogeneous} Sobolev space a` |
| S0028 | 31–41 | SENTENCE | yes | 9 | `The requested conclusion is a global weak Euler solution \[  u\in C_w([0,\infty);L^2_{\rm loc}(\R^2;\R^2)),\qquad u(0)=u` |
| S0029 | 41–48 | SENTENCE | yes | 4 | `The velocity identity is precisely \[  \int_0^T\!\!\int_{\R^2}  \bigl(u\cdot\partial_t\varphi+(u\otimes u):\nabla\varphi` |
| S0030 | 48–50 | SENTENCE | yes | 5 | `No global kinetic-energy assumption, compact support, zero circulation, or energy inequality is added.` |
| S0031 | 50–52 | STRUCTURAL | no | 0 | `\section{Initial normalization and a bounded Euler background}` |
| S0032 | 53–56 | SENTENCE | yes | 4 | `We use $\nabla^\perp=(-\partial_2,\partial_1)$, $(\nabla v)_{ij}=\partial_jv_i$, $(\Div S)_i=\sum_j\partial_jS_{ij}$, an` |
| S0033 | 56–57 | SENTENCE | yes | 0 | `The multiplier of $K$ is $m(\xi)=-i\xi^\perp/\|\xi\|^2$.` |
| S0034 | 57–60 | SENTENCE | yes | 3 | `\begin{lemma}[Canonical velocity and the physical-space decomposition]\label{lem:decomp} Let $\mu\in\M\cap H^{-1}$ and $` |
| S0035 | 60–62 | SENTENCE | yes | 4 | `The convolution $K*\mu$ is defined almost everywhere, belongs to $L^2_{\rm loc}$, and has divergence zero and curl $\mu$` |
| S0036 | 62–63 | SENTENCE | yes | 4 | `Fix a nonnegative radial $a\in C_c^\infty(B_A)$ of integral one.` |
| S0037 | 63–67 | SENTENCE | yes | 4 | `Set \[  \nu_0=a*\mu,\quad \sigma_0=\mu-\nu_0,\quad  V_0=K*\nu_0,\quad v_0=(K-K*a)*\mu. \]` |
| S0038 | 67–74 | SENTENCE | yes | 8 | `Then $K*\mu=V_0+v_0$, $v_0\in L^1\cap L^2$, $V_0\in C_0\cap C^\infty$ is bounded, and \[  \norm{v_0}1\leq C_aM,\quad  \n` |
| S0039 | 74–77 | SENTENCE | yes | 2 | `All derivatives of $\nu_0$ belong to $L^1\cap L^\infty$, and every positive-order derivative of $V_0$ belongs to $L^2\ca` |
| S0040 | 78–80 | SENTENCE | yes | 4 | `\begin{proof} For a bounded ball $B$, $\sup_y\int_B\|K(x-y)\|\dd<\infty$; Tonelli gives the almost-everywhere definition a` |
| S0041 | 80–81 | SENTENCE | yes | 2 | `The kernel's divergence, curl, and Fourier identities give the distributional assertions.` |
| S0042 | 81–83 | SENTENCE | yes | 3 | `These identities extend from compactly supported to arbitrary finite measures by truncation in total variation.` |
| S0043 | 83–85 | SENTENCE | yes | 7 | `Equivalently, $m$ is locally integrable at frequency zero and integrable against Schwartz functions, so uniform converge` |
| S0044 | 85–90 | SENTENCE | yes | 2 | `For radial $a$, circulation gives \[  (K*a)(x)=K(x)\int_{\|y\|<\|x\|}a(y)\,dy. \]` |
| S0045 | 90–92 | SENTENCE | yes | 3 | `Consequently $L_a=K-K*a$ vanishes outside $B_A$ and has only the integrable $\|x\|^{-1}$ singularity at zero.` |
| S0046 | 92–93 | SENTENCE | yes | 2 | `Thus $L_a\in L^1$ and Young's inequality gives the $L^1$ estimate for $v_0$.` |
| S0047 | 93–97 | SENTENCE | yes | 3 | `Evenness gives $\|1-\widehat a(\xi)\|\leq C_a\min(\|\xi\|^2,1)$; hence \[  (1+\|\xi\|^2)\|(1-\widehat a(\xi))m(\xi)\|^2\leq C_a.` |
| S0048 | 97–98 | SENTENCE | yes | 0 | `Plancherel proves the $L^2$ estimate, using exactly the inhomogeneous hypothesis.` |
| S0049 | 98–100 | SENTENCE | yes | 5 | `The multipliers $m\widehat a$ and $\xi^\alpha m\widehat a$ are integrable; for $\|\alpha\|\geq1$ they are square integrabl` |
| S0050 | 100–101 | SENTENCE | yes | 2 | `Fourier inversion and the Riemann--Lebesgue lemma give the assertions about $V_0$.` |
| S0051 | 101–102 | SENTENCE | yes | 3 | `The convolution identities and remaining bounds follow by finite-measure convolution.` |
| S0052 | 102–104 | SENTENCE | yes | 2 | `In particular $K*\mu=V_0+v_0\in L^2_{\rm loc}$. \end{proof}` |
| S0053 | 105–106 | STRUCTURAL | no | 0 | `\paragraph{External input E1, used only here.}` |
| S0054 | 107–110 | STRUCTURAL | yes | 4 | `Crippa--Stefani, \emph{An elementary proof of existence and uniqueness for the Euler flow in localized Yudovich spaces},` |
| S0055 | 110–114 | SENTENCE | yes | 9 | `The specialization used here supplies a global Lagrangian vorticity solution for arbitrary signed $L^1\cap L^\infty$ dat` |
| S0056 | 114–116 | SENTENCE | yes | 3 | `Definition 3.2 includes the weak initial-value vorticity equation and the Lagrangian pushforward representation almost e` |
| S0057 | 116–116 | SENTENCE | yes | 3 | `It does not require compact support or finite global energy.` |
| S0058 | 116–118 | SENTENCE | yes | 3 | `The kernel hypotheses hold because $\|K(z)\|=(2\pi\|z\|)^{-1}$, $\|K(z)-K(w)\|=\|z-w\|/(2\pi\|z\|\|w\|)$, and $\Div K=0$.` |
| S0059 | 118–119 | SENTENCE | yes | 0 | `The source is not being used as an unquoted smoothness theorem.` |
| S0060 | 119–129 | SENTENCE | yes | 8 | `\begin{lemma}[Bounded background and its trace]\label{lem:background} The datum $\nu_0$ in Lemma~\ref{lem:decomp} has a ` |
| S0061 | 129–132 | SENTENCE | yes | 0 | `Moreover $\norm{V(t)-V_0}2\leq t\norm V{L^\infty_{t,x}}\norm{\nu_0}2$. \end{lemma}` |
| S0062 | 133–134 | SENTENCE | yes | 3 | `\begin{proof} Apply E1, using its $L^1$ and $L^\infty$ bounds and canonical velocity.` |
| S0063 | 134–135 | SENTENCE | yes | 0 | `No smoothness upgrade is needed in this construction.` |
| S0064 | 135–136 | SENTENCE | yes | 0 | `We first select an every-time representative.` |
| S0065 | 136–139 | SENTENCE | yes | 8 | `The log-Lipschitz modulus is Osgood, so the flow and its inverse are unique, continuous, and have bounded displacement o` |
| S0066 | 139–139 | SENTENCE | yes | 2 | `Mollify the velocity only in space by a probability kernel.` |
| S0067 | 139–141 | SENTENCE | yes | 3 | `The resulting smooth divergence-free flows preserve Lebesgue measure by the Jacobian equation.` |
| S0068 | 141–143 | SENTENCE | yes | 4 | `Their uniform Osgood modulus and uniform convergence of the velocities give convergence of flows and inverse flows on co` |
| S0069 | 143–145 | SENTENCE | yes | 5 | `For a compact continuous test, bounded displacement confines its transported support to a fixed bounded set; dominated c` |
| S0070 | 145–147 | SENTENCE | yes | 2 | `Define $\nu(t)=\nu_0\circ X_t^{-1}$ at every time.` |
| S0071 | 147–149 | SENTENCE | yes | 4 | `It agrees with the source solution almost everywhere in time and preserves the $L^1$, $L^2$, and $L^\infty$ norms.` |
| S0072 | 149–151 | SENTENCE | yes | 4 | `Approximating $\nu_0$ in $L^1$ or $L^2$ by compact smooth functions and using volume preservation and continuity of the ` |
| S0073 | 151–151 | SENTENCE | yes | 2 | `Set $V(t)=K*\nu(t)$ at every time.` |
| S0074 | 151–153 | SENTENCE | yes | 3 | `It agrees with the source velocity almost everywhere, so its equation is unchanged.` |
| S0075 | 153–156 | SENTENCE | yes | 3 | `For $f=\nu(t)-\nu(s)$ the near--far bound $\norm{K*f}\infty\leq r\norm f\infty+(2\pi r)^{-1}\norm f1$ shows continuity o` |
| S0076 | 156–157 | SENTENCE | yes | 3 | `Thus this representative has the canonical initial velocity and continuous positive-time local velocity pairings.` |
| S0077 | 157–163 | SENTENCE | yes | 2 | `The Biot--Savart near--far split also bounds the velocity: \[  \norm V\infty\leq C\bigl(r\norm\nu\infty+r^{-1}\norm\nu1\` |
| S0078 | 163–164 | SENTENCE | yes | 4 | `Thus $V\nu$ belongs to both $L^1$ and $L^2$ uniformly on finite horizons.` |
| S0079 | 164–169 | SENTENCE | yes | 3 | `For completeness, $K*\mu$ for any finite measure satisfies \[  \|\{\|K*\mu\|>\lambda\}\|\leq C\norm\mu\M^2\lambda^{-2}. \]` |
| S0080 | 169–172 | SENTENCE | yes | 3 | `Indeed split $K$ at radius $r=\norm\mu\M/(\pi\lambda)$; the far part has supremum at most $\lambda/2$, and the near part` |
| S0081 | 172–172 | SENTENCE | yes | 0 | `Chebyshev proves the bound.` |
| S0082 | 172–173 | SENTENCE | yes | 2 | `Combining it with boundedness of $V$ and layer cake gives $\norm V3^3\leq C\norm\nu1^2\norm V\infty$.` |
| S0083 | 173–178 | SENTENCE | yes | 3 | `Integrate the vorticity equation: \[  \nu(t)-\nu_0=-\Div F_t,\qquad F_t=\int_0^t V(s)\nu(s)\,ds\in L^1\cap L^2. \]` |
| S0084 | 178–180 | SENTENCE | yes | 2 | `The Fourier multiplier of $-K*\Div$ has operator norm at most one, yielding $V(t)-V_0=-K*\Div F_t$ and the stated estima` |
| S0085 | 180–181 | SENTENCE | yes | 0 | `Likewise $\partial_tV,\nabla V\in L^\infty_tL^2$.` |
| S0086 | 181–182 | SENTENCE | yes | 0 | `The same argument between any two times gives $\norm{V(t)-V(s)}2\leq C_T\|t-s\|$.` |
| S0087 | 182–184 | SENTENCE | yes | 2 | `With $B_T=\sup_t\norm{V(t)}\infty$, interpolation gives $\norm{V(t)-V(s)}3^3\leq2B_T\norm{V(t)-V(s)}2^2$.` |
| S0088 | 184–185 | SENTENCE | yes | 0 | `Therefore $V\in C([0,T];L^3)$.` |
| S0089 | 185–187 | SENTENCE | yes | 3 | `The vector $\partial_tV+(V\cdot\nabla)V$ is an $L^2$ curl-free field by transport; it is a pressure gradient in distribu` |
| S0090 | 187–189 | SENTENCE | yes | 0 | `Thus the velocity Euler equation used below is indeed available without a global-energy assumption on $V$. \end{proof}` |
| S0091 | 190–191 | STRUCTURAL | no | 0 | `\section{An initial Euler--Reynolds subsolution}` |
| S0092 | 192–198 | SENTENCE | yes | 3 | `The convention for Euler--Reynolds is \begin{equation}\label{eq:ER}  \partial_tu+\Div(u\otimes u)+\nabla p=\Div R,  \qqu` |
| S0093 | 198–199 | SENTENCE | yes | 3 | `Let $b=\mathcal F^{-1}(e^{-\|\xi\|^4})$ and $b_t(x)=t^{-2}b(x/t)$ for $t>0$.` |
| S0094 | 199–200 | SENTENCE | yes | 7 | `It is a real radial Schwartz kernel of integral one; it need not be positive.` |
| S0095 | 200–200 | SENTENCE | yes | 0 | `Write $C_b=\norm b1$.` |
| S0096 | 200–210 | SENTENCE | yes | 5 | `\begin{proposition}[Initial Euler--Reynolds seed]\label{prop:seed} For the preceding decomposition and background, put \` |
| S0097 | 210–211 | SENTENCE | yes | 0 | `This is a positive-time distributional solution of \eqref{eq:ER}.` |
| S0098 | 211–217 | SENTENCE | yes | 5 | `On $0<t\leq T$, \begin{align*}  \norm{u^{(0)}-V}2&\leq\norm{v_0}2,\\  \norm{\curl u^{(0)}}1&\leq\norm{\nu_0}1+C_b\norm{\` |
| S0099 | 217–219 | SENTENCE | yes | 2 | `It has strong $L^2_{\rm loc}$ initial trace $u_0$ and canonical velocity $u^{(0)}(t)=K*(\nu(t)+b_t*\sigma_0)$.` |
| S0100 | 219–222 | SENTENCE | yes | 4 | `On compact positive-time intervals $R^{(0)}\in C_tL^1$, $u^{(0)}\in C_tL^3$, and the velocity is strongly continuous in ` |
| S0101 | 223–225 | SENTENCE | yes | 2 | `\begin{proof} The multiplier of $b_t$ is $e^{-t^4\|\xi\|^4}$, so $\partial_tW=-4t^3\Delta^2W$.` |
| S0102 | 225–226 | SENTENCE | yes | 2 | `Since $\Div W=0$, $\Div[\nabla\Delta W+(\nabla\Delta W)^T]=\Delta^2W$.` |
| S0103 | 226–227 | SENTENCE | yes | 0 | `Expanding $(V+W)\otimes(V+W)$ proves \eqref{eq:ER} with the stated signs.` |
| S0104 | 227–228 | SENTENCE | yes | 2 | `Plancherel gives the $L^2$ bound and $W(t)\to v_0$ strongly in $L^2$.` |
| S0105 | 228–229 | SENTENCE | yes | 3 | `Finite-measure convolution gives $\curl W=b_t*\sigma_0$ and the curl bound.` |
| S0106 | 229–230 | SENTENCE | yes | 0 | `Furthermore $\norm W1\leq C_b\norm{v_0}1$.` |
| S0107 | 230–235 | SENTENCE | yes | 3 | `The identity $\Delta W=\nabla^\perp\curl W$ yields \[  \norm{\nabla\Delta W}1\leq C\norm{D^2b_t}1\norm{\sigma_0}\M  =Ct^` |
| S0108 | 235–237 | SENTENCE | yes | 3 | `Thus the derivative stress costs $Ct\norm{\sigma_0}\M$, and the other terms are bounded as displayed.` |
| S0109 | 237–237 | SENTENCE | yes | 0 | `Lemma~\ref{lem:background} proves the trace.` |
| S0110 | 237–239 | SENTENCE | yes | 0 | `Fubini against compact tests, or the Fourier identity, gives the canonical convolution.` |
| S0111 | 239–241 | SENTENCE | yes | 2 | `On positive-time compact intervals, convolution bounds give $W\in C_t(L^1\cap L^2\cap L^\infty)$ and hence $W\in C_tL^{3` |
| S0112 | 241–242 | SENTENCE | yes | 2 | `The derivative stress is continuous in $L^1$ by continuity of $D^2b_t$ in $L^1$.` |
| S0113 | 242–244 | SENTENCE | yes | 6 | `Products $W\otimes W$ are $L^1$-continuous by $C_tL^2$, while $V\otimes W$ and its transpose are $L^1$-continuous by $V\` |
| S0114 | 244–246 | SENTENCE | yes | 0 | `This proves all asserted continuity without differentiating the old background. \end{proof}` |
| S0115 | 247–250 | SENTENCE | yes | 2 | `\begin{remark}[Why a subcritical global increment norm is required]\label{rem:cross} Every repair below must have an \em` |
| S0116 | 250–252 | SENTENCE | yes | 0 | `Indeed, $\norm{V\otimes w}1\leq\norm V3\norm w{3/2}$ closes the whole-plane cross-stress bound.` |
| S0117 | 252–254 | SENTENCE | yes | 8 | `Finite energy and finite curl variation do not suffice: a smooth radial swirl equal to $e_\theta/(r\log r)$ for $r\geq e` |
| S0118 | 254–256 | SENTENCE | yes | 3 | `Against a smooth unit-circulation background equal to $e_\theta/(2\pi r)$ at infinity, $\int\|V\otimes w\|=\infty$ because` |
| S0119 | 256–258 | SENTENCE | yes | 0 | `Multiplying $w$ by a small constant does not repair this divergence. \end{remark}` |
| S0120 | 259–260 | STRUCTURAL | no | 0 | `\section{Endpoint repair: elementary building blocks}` |
| S0121 | 261–262 | STRUCTURAL | no | 0 | `\subsection{An exact translating dipole}` |
| S0122 | 263–265 | SENTENCE | yes | 2 | `The Bessel functions used below may be defined by their convergent power series, whose termwise derivatives give the Bes` |
| S0123 | 265–266 | SENTENCE | yes | 2 | `There is a positive zero $\beta\in(3,4)$ of $J_1$.` |
| S0124 | 266–269 | SENTENCE | yes | 4 | `For completeness, the alternating series gives $J_1(3)\geq(3/2)(223/1024)>0$ by truncating after its cubic term in $(3/2` |
| S0125 | 269–270 | SENTENCE | yes | 0 | `The omitted terms alternate with decreasing magnitudes.` |
| S0126 | 270–271 | SENTENCE | yes | 0 | `The intermediate value theorem gives the asserted zero.` |
| S0127 | 271–272 | SENTENCE | yes | 2 | `If $J_0(\beta)=0$ also, the recurrence gives $J_1'(\beta)=0$.` |
| S0128 | 272–274 | SENTENCE | yes | 2 | `Uniqueness for the regular second-order Bessel ODE near $\beta>0$ would then make $J_1$ identically zero, contrary to $J` |
| S0129 | 274–275 | SENTENCE | yes | 0 | `Thus $J_0(\beta)\ne0$.` |
| S0130 | 275–285 | SENTENCE | yes | 12 | `In polar coordinates set \[  \psi(\rho,\theta)=  \begin{cases}  -\rho\sin\theta+\dfrac{2J_1(\beta\rho)}{\beta J_0(\beta)` |
| S0131 | 285–287 | SENTENCE | yes | 4 | `With $q=\psi+x_2$, $D-e_1=\nabla^\perp q$ and $\curl D=-\beta^2q$ in $B_1$, while $\curl D=0$ outside.` |
| S0132 | 287–289 | SENTENCE | yes | 3 | `The relations $J_1(\beta)=0$ and $J_1'(\beta)=J_0(\beta)$ give the matching values and first derivatives of the stream f` |
| S0133 | 289–291 | SENTENCE | yes | 3 | `The Bessel equation also gives $J_1''(\beta)=-J_0(\beta)/\beta$, so the second radial derivatives match.` |
| S0134 | 291–293 | SENTENCE | yes | 3 | `Tangential differentiation of the matching traces gives the other second derivatives; hence the velocity is continuously` |
| S0135 | 293–295 | SENTENCE | yes | 2 | `In particular $q=0$ on the circle and $(D-e_1)\cdot\nabla\curl D=0$ distributionally.` |
| S0136 | 295–299 | SENTENCE | yes | 2 | `The pressure \[  P=-\tfrac12\|D-e_1\|^2-\tfrac{\beta^2}{2}q^2\mathbf1_{B_1} \] gives $-\partial_1D+\Div(D\otimes D)+\nabla` |
| S0137 | 299–301 | SENTENCE | yes | 2 | `This follows from $(w\cdot\nabla)w=(\curl w)w^\perp+\nabla(\|w\|^2/2)$, and matching on the circle leaves no boundary dist` |
| S0138 | 301–302 | SENTENCE | yes | 3 | `Outside the unit disk, $D=\nabla(-x_1/\|x\|^2)$; $D$ is even under $x\mapsto-x$.` |
| S0139 | 302–304 | SENTENCE | yes | 2 | `For a direction $\xi$, rotate this profile, and write $D_r(x)=r^{-1}D(x/r)$.` |
| S0140 | 304–305 | SENTENCE | yes | 0 | `The direction is suppressed where no confusion arises.` |
| S0141 | 305–314 | SENTENCE | yes | 6 | `Then \begin{equation}\label{eq:dipole}  -r^{-1}\partial_\xi D_r+\Div(D_r\otimes D_r)+\nabla P_r=0,  \quad \Div D_r=0, \e` |
| S0142 | 314–316 | SENTENCE | yes | 5 | `The constants are finite by boundedness in the core and the exterior $\|x\|^{-2}$ decay; the curl is supported in $B_r$.` |
| S0143 | 316–318 | STRUCTURAL | no | 0 | `\subsection{A symmetric globally integrable anti-divergence}` |
| S0144 | 319–327 | SENTENCE | yes | 7 | `For a vector field $f$ supported in $B_R$, with \[  \int f=0,\qquad \int x_jf_i(x)\dd=0\quad\hbox{for every }i,j, \] def` |
| S0145 | 327–328 | SENTENCE | yes | 3 | `It is symmetric and $\Div\mathcal Af=f$.` |
| S0146 | 328–328 | SENTENCE | yes | 0 | `Its kernel has degree $-1$.` |
| S0147 | 328–329 | SENTENCE | yes | 0 | `On $B_{3R}$, integration of that kernel gives $CR\norm f1$.` |
| S0148 | 329–331 | SENTENCE | yes | 3 | `Outside $B_{3R}$, subtract its constant and linear Taylor terms using the two moment conditions; the remainder is at mos` |
| S0149 | 331–334 | SENTENCE | yes | 0 | `Integration gives \begin{equation}\label{eq:anti}  \norm{\mathcal Af}1\leq CR\norm f1. \end{equation}` |
| S0150 | 334–335 | SENTENCE | yes | 2 | `The output need not be compactly supported.` |
| S0151 | 335–336 | SENTENCE | yes | 0 | `Cancellation of only the mean would leave a generally nonintegrable $\|x\|^{-2}$ far field.` |
| S0152 | 336–341 | SENTENCE | yes | 0 | `Differentiation of the profile gives \[  \partial_rD_r=r^{-1}D_r-\Div(D_r\otimes x/r). \]` |
| S0153 | 341–343 | SENTENCE | yes | 3 | `The vector $f_r=\Div(D_r\otimes x/r)$ is supported in $B_r$, because the exterior dipole is homogeneous of degree $-2$; ` |
| S0154 | 343–344 | SENTENCE | yes | 3 | `Evenness gives all first moments zero.` |
| S0155 | 344–346 | SENTENCE | yes | 0 | `Its mean is zero by the boundary flux on any circle outside $B_r$, since the angular mean of the exterior dipole is zero` |
| S0156 | 346–350 | SENTENCE | yes | 3 | `Therefore $F_r=-\mathcal Af_r$ satisfies \begin{equation}\label{eq:radial}  \partial_rD_r=r^{-1}D_r+\Div F_r,  \qquad \n` |
| S0157 | 350–352 | STRUCTURAL | no | 0 | `\subsection{Variable radius and a compact source}` |
| S0158 | 353–353 | SENTENCE | yes | 3 | `Let $r(t)>0$, $\eta(t)\geq0$, and $X'=\eta\xi/r$.` |
| S0159 | 353–359 | SENTENCE | yes | 3 | `By \eqref{eq:dipole}--\eqref{eq:radial}, the packet $v(t,x)=\eta(t)D_{r(t)}(x-X(t))$ satisfies, after adding gradients t` |
| S0160 | 359–366 | SENTENCE | yes | 6 | `Choose a radial cutoff $\chi$ equal to zero on $B_1$ and one outside $B_2$, let $\alpha=1/5$, and put \[  \Phi_\xi(x)=-\` |
| S0161 | 366–368 | SENTENCE | yes | 6 | `For small $r$, $Z_r$ is even and supported in $B_{2r^\alpha}$; direct radial integration gives $\norm{Z_r}1\leq Cr(1+\|\l` |
| S0162 | 368–370 | SENTENCE | yes | 2 | `Its integral is $2\pi r\xi$: on a large circle the respective boundary integrals for $D_r$ and $\nabla\Pi_r$ are $\pi r\` |
| S0163 | 370–371 | SENTENCE | yes | 3 | `Thus $S_r=Z_r/r$ has integral $2\pi\xi$ and all first moments zero.` |
| S0164 | 371–373 | SENTENCE | yes | 6 | `Let $U_H$ be a nonnegative radial smooth probability bump supported in $B_H$.` |
| S0165 | 373–375 | SENTENCE | yes | 2 | `If $2r^\alpha\leq H$, the difference $S_r-2\pi U_H\xi$ has its zeroth and first moments zero.` |
| S0166 | 375–378 | SENTENCE | yes | 0 | `Equation~\eqref{eq:anti} gives \[  \norm{\mathcal A(S_r-2\pi U_H\xi)}1\leq CH(1+\|\log r\|). \]` |
| S0167 | 378–388 | SENTENCE | yes | 4 | `Equation~\eqref{eq:packet} therefore becomes \begin{equation}\label{eq:packet-source}  \partial_tv+\Div(v\otimes v)+\nab` |
| S0168 | 388–389 | SENTENCE | yes | 2 | `The endpoint estimate $\norm{\curl v}1=\|\eta\|C_\omega$ is independent of $r$.` |
| S0169 | 389–391 | STRUCTURAL | no | 0 | `\section{Two-scale raster and local stress repair}\label{sec:repair-interface}` |
| S0170 | 392–393 | STRUCTURAL | no | 0 | `\subsection{Stress coefficients and a fixed cycle}` |
| S0171 | 394–395 | SENTENCE | yes | 2 | `For a prescribed symmetric stress piece $S$, use the directions $e_1,e_2,(e_1+e_2)/\sqrt2,(e_1-e_2)/\sqrt2$.` |
| S0172 | 395–397 | SENTENCE | yes | 5 | `For a fixed smooth compactly supported tensor $S$, choose a nonnegative compact smooth function $h$ equal to one on a ne` |
| S0173 | 397–402 | SENTENCE | yes | 3 | `For $\gamma>0$ put \[  A=\sqrt{S_{12}^2+\gamma^2h^2},\qquad  B=\sqrt{S_{11}^2+S_{22}^2+\gamma^2h^2}. \]` |
| S0174 | 402–404 | SENTENCE | yes | 3 | `These functions are smooth: near the zero set of $h$, the entries of $S$ already vanish, so both square roots reduce to ` |
| S0175 | 404–405 | SENTENCE | yes | 2 | `They satisfy $A\geq\|S_{12}\|$ and $B\geq\max(S_{11},S_{22})$.` |
| S0176 | 405–411 | BOUNDARY-GROUP | yes | 6 | `Define \[  a_1=B-S_{11},\quad a_2=B-S_{22},\quad  a_3=A-S_{12},\quad a_4=A+S_{12},\quad q=A+B \] Then $-S+qI=\sum_i a_i\` |
| S0177 | 411–413 | SENTENCE | yes | 6 | `All coefficients are smooth, compactly supported, and nonnegative, with $\sum_i\norm{a_i}1\leq C\norm S1+C\gamma\norm h1` |
| S0178 | 413–414 | SENTENCE | yes | 0 | `The final term can be made arbitrarily small before choosing fine scales.` |
| S0179 | 414–415 | SENTENCE | yes | 0 | `The discarded spatial tail remains a small residual.` |
| S0180 | 415–418 | SENTENCE | yes | 5 | `On a compact time interval, continuity into $L^1$ makes this tail truncation uniform: the continuous image is compact in` |
| S0181 | 418–420 | SENTENCE | yes | 2 | `Fix a coefficient and its rectangle in coordinates $(s,y)$ adapted to $\xi$.` |
| S0182 | 420–421 | SENTENCE | yes | 2 | `Write $a$ for the original compactly supported coefficient.` |
| S0183 | 421–423 | SENTENCE | yes | 4 | `On the scanning rectangle define $c=a+e$ with a strictly positive floor $e>0$, and use constant-$e$ longitudinal buffers` |
| S0184 | 423–425 | SENTENCE | yes | 2 | `Write $\varepsilon_{\rm floor}$ for the total added floor and buffer mass, including the fixed factors from the ramp dur` |
| S0185 | 425–426 | SENTENCE | yes | 0 | `This mass is chosen arbitrarily small.` |
| S0186 | 426–428 | SENTENCE | yes | 2 | `All rectangle, floor, and derivative constants are fixed before the fine parameter tends to zero.` |
| S0187 | 428–432 | SENTENCE | yes | 4 | `We use two distinct scales \begin{equation}\label{eq:scales}  d=H^2\quad\hbox{(row spacing)},\qquad  \tau\asymp H^6\quad` |
| S0188 | 432–433 | SENTENCE | yes | 0 | `The auxiliary bump has width $H$, not $d$.` |
| S0189 | 433–434 | SENTENCE | yes | 2 | `One packet visits rows $y=kd$ sequentially, with no simultaneous packets.` |
| S0190 | 434–435 | SENTENCE | yes | 2 | `On the interior of a row, $\eta$ is constant and $r(s)=r_0c(s,kd)$.` |
| S0191 | 435–440 | SENTENCE | yes | 2 | `Thus \[  dt=(r_0/\eta)c(s,kd)\,ds,  \qquad\int\eta^2U_H(x-X(t))\,dt  =\eta r_0\int c(s,kd)U_H(x-s\xi-kd\xi^\perp)\,ds. \` |
| S0192 | 440–443 | SENTENCE | yes | 3 | `At entry use a fixed smooth temporal ramp $\zeta:[0,1]\to[0,1]$, equal to zero to all orders at zero and equal to one wi` |
| S0193 | 443–444 | SENTENCE | yes | 0 | `At exit use the reversed ramp $\zeta(1-\cdot)$.` |
| S0194 | 444–445 | SENTENCE | yes | 2 | `Write $I_\zeta=\int_0^1\zeta>0$.` |
| S0195 | 445–446 | SENTENCE | yes | 0 | `Throughout either buffer $r=r_0e$ is constant.` |
| S0196 | 446–449 | SENTENCE | yes | 0 | `To traverse a buffer of length $L$, choose ramp duration $r_0eL/(\eta I_\zeta)$.` |
| S0197 | 449–451 | SENTENCE | yes | 0 | `Let $B_i$ be the sum over rows of the interior line integrals of $c_i=a_i+e_i$, plus $2e_iL/I_\zeta$ per row for the two` |
| S0198 | 451–456 | SENTENCE | yes | 3 | `Allocate $\tau_i=\tau/4$ to direction $i$, and set \begin{equation}\label{eq:normalization}  \eta_i^2=\frac{\tau dB_i}{2` |
| S0199 | 456–458 | SENTENCE | yes | 2 | `The full scan takes exactly $(r_{0,i}/\eta_i)B_i=\tau_i$, and its coefficient weight is exactly $2\pi\eta_ir_{0,i}/\tau=` |
| S0200 | 458–459 | SENTENCE | yes | 0 | `With sufficiently fine $d$, $dB_i\leq C\norm{a_i}1+C\varepsilon_{\rm floor}+o_H(1)$.` |
| S0201 | 459–463 | SENTENCE | yes | 2 | `Writing $\varepsilon_{\rm reg}$ for the earlier regularization mass gives $\eta_i\leq C\sqrt\delta+ C\sqrt{\varepsilon_{` |
| S0202 | 463–466 | SENTENCE | yes | 3 | `If a direction has zero mass it can be omitted; a positive floor otherwise makes \eqref{eq:normalization} unambiguous.` |
| S0203 | 466–469 | SENTENCE | yes | 3 | `On a ramp $\|(\eta r)'\|\leq C\eta_i^2$; on an interior row $\|\eta r'\|=\|(\eta r)'\|\leq\eta_i^2\norm{\partial_\xi\log c_i}\` |
| S0204 | 469–470 | SENTENCE | yes | 0 | `Constants are fixed before $H\downarrow0$.` |
| S0205 | 470–472 | SENTENCE | yes | 5 | `Accordingly $r_0\asymp H^8$, all radii are bounded above and below by fixed multiples of $H^8$, and $r^{1/5}=O(H^{8/5})=` |
| S0206 | 472–473 | SENTENCE | yes | 0 | `The intrinsic error \eqref{eq:E-bound} is $O(H\|\log H\|)+O(H^8)$.` |
| S0207 | 473–480 | SENTENCE | yes | 3 | `Integration by parts on a visit, using $\eta=0$ at its endpoints, gives \begin{equation}\label{eq:average}  \overline{\m` |
| S0208 | 480–481 | SENTENCE | yes | 0 | `Indeed $\frac d{dt}(\eta rU_H(x-X))=(\eta r)'U_H-\eta^2\xi\cdot\nabla U_H$.` |
| S0209 | 481–482 | SENTENCE | yes | 0 | `Write the tensor in parentheses, summed over four directions, as $A_{\rm av}$.` |
| S0210 | 482–488 | SENTENCE | yes | 0 | `The raster quadrature obeys \begin{equation}\label{eq:quad}  \left\\|d\sum_k\int a(s,kd)U_H(\,\cdot-s\xi-kd\xi^\perp)\,ds` |
| S0211 | 488–489 | SENTENCE | yes | 0 | `Here is the explicit Banach-valued rectangle-rule proof.` |
| S0212 | 489–491 | SENTENCE | yes | 0 | `Put $F(y)=\int a(s,y)U_H(\cdot-s\xi-y\xi^\perp)\,ds$, as an $L^1_x$-valued function.` |
| S0213 | 491–494 | SENTENCE | yes | 0 | `Differentiating it gives $\int\norm{F'(y)}1dy\leq\norm{\partial_\perp a}1+ \norm a1\norm{\partial_\perp U_H}1$.` |
| S0214 | 494–497 | SENTENCE | yes | 0 | `On each row interval of length $d$, the fundamental theorem of calculus bounds the integrated discrepancy from its endpo` |
| S0215 | 497–498 | SENTENCE | yes | 0 | `Summing yields the first two terms in \eqref{eq:quad}.` |
| S0216 | 498–500 | SENTENCE | yes | 0 | `The translation estimate $\norm{a*U_H-a}1\leq CH\norm{\nabla a}1$ gives the third.` |
| S0217 | 500–501 | SENTENCE | yes | 0 | `Estimate \eqref{eq:quad} applies to the original compact coefficient $a$.` |
| S0218 | 501–503 | SENTENCE | yes | 2 | `The added floor and the ramp-weighted buffers contribute at most $C\varepsilon_{\rm floor}+o_H(1)$ separately.` |
| S0219 | 503–504 | SENTENCE | yes | 0 | `Since $d=H^2$, the quadrature error tends to zero.` |
| S0220 | 504–506 | STRUCTURAL | no | 0 | `\subsection{Temporal correction and the stress identity}` |
| S0221 | 507–511 | BOUNDARY-GROUP | yes | 0 | `On each cycle $[t_k,t_k+\tau]$ put \[  Q(t)=-\mathbb P\int_{t_k}^t  (\mathcal U(s)-\overline{\mathcal U})\,ds, \]` |
| S0222 | 511–513 | SENTENCE | yes | 0 | `The average here is taken over the entire four-direction cycle, not separately on each direction slot.` |
| S0223 | 513–514 | SENTENCE | yes | 0 | `This ensures that its tensor is the sum of all four directional averages throughout the cycle.` |
| S0224 | 514–516 | SENTENCE | yes | 2 | `Here $\mathbb P=I-\nabla\Delta^{-1}\Div$ is used only on translates of the fixed bump $U_H\xi$ and their time integrals.` |
| S0225 | 516–517 | SENTENCE | yes | 0 | `Its needed bounds have a direct fixed-profile proof.` |
| S0226 | 517–520 | SENTENCE | yes | 2 | `Let $G=(2\pi)^{-1}\log\|x\|$ and \[  Z_{H,\xi}=U_H\xi-(D^2G*U_H)\xi. \]` |
| S0227 | 520–521 | SENTENCE | yes | 2 | `It has zero divergence and $\curl Z_{H,\xi}=\curl(U_H\xi)$.` |
| S0228 | 521–523 | SENTENCE | yes | 5 | `At $H=1$ it is smooth and bounded in the core: write the Hessian convolution as $\partial_iG*\partial_jU_1$, whose $\|x\|^` |
| S0229 | 523–525 | SENTENCE | yes | 4 | `Outside the bump support, radial averaging gives $G*U_1=G$, so $Z_{1,\xi}=-D^2G\xi=O(\|x\|^{-2})$.` |
| S0230 | 525–526 | SENTENCE | yes | 3 | `Hence $Z_{1,\xi}\in L^p$ for every $p>1$.` |
| S0231 | 526–529 | SENTENCE | yes | 0 | `Scaling gives \[  \norm{Z_{H,\xi}}p\leq C_p H^{2/p-2}. \]` |
| S0232 | 529–530 | SENTENCE | yes | 0 | `Minkowski applies to its translates in the time primitive.` |
| S0233 | 530–531 | SENTENCE | yes | 0 | `No general Calderón--Zygmund $L^p$ theorem is needed for this use of $\mathbb P$.` |
| S0234 | 531–535 | SENTENCE | yes | 3 | `For an explicit pressure sign, write $q_{H,\xi}=\xi\cdot\nabla(G*U_H)$ and let $\pi_{\mathcal U}(t)=2\pi(\eta r)'q_{H,\x` |
| S0235 | 535–536 | SENTENCE | yes | 0 | `Then $\mathcal U-\mathbb P\mathcal U=\nabla\pi_{\mathcal U}$.` |
| S0236 | 536–540 | SENTENCE | yes | 2 | `Taking $p_Q=-\pi_{\mathcal U}+\tau^{-1}\int_{\rm cycle}\pi_{\mathcal U}(s)\,ds$ gives the exact identity $\partial_tQ+\m` |
| S0237 | 540–546 | SENTENCE | yes | 3 | `If $B$ bounds $\|(\eta r)'\|$, bump scaling gives \begin{equation}\label{eq:Q}  \norm Q2\leq C\tau H^{-1}B,  \quad\norm Q{` |
| S0238 | 546–547 | SENTENCE | yes | 2 | `Here both $\mathcal U$ and its cycle average obey the needed norm bound.` |
| S0239 | 547–548 | SENTENCE | yes | 0 | `The curl estimate follows directly from $\norm{\nabla U_H}1=O(H^{-1})$.` |
| S0240 | 548–549 | SENTENCE | yes | 0 | `No $L^1$ boundedness of $\mathbb P$ is invoked.` |
| S0241 | 549–550 | SENTENCE | yes | 0 | `The corrector vanishes at both cycle endpoints.` |
| S0242 | 550–552 | SENTENCE | yes | 7 | `Its first time derivative may jump there, so the resulting velocity is continuous and piecewise smooth in time; it is no` |
| S0243 | 552–554 | SENTENCE | yes | 0 | `Given an old distributional Euler--Reynolds seed $(u,p,R)$, set $\widetilde u=u+v+Q$.` |
| S0244 | 554–565 | SENTENCE | yes | 4 | `Combining \eqref{eq:packet-source}, \eqref{eq:average}, and the equation for $Q$ gives, modulo a gradient, \[  \partial_` |
| S0245 | 565–566 | SENTENCE | yes | 2 | `The scalar $q$ is absorbed into pressure.` |
| S0246 | 566–568 | SENTENCE | yes | 3 | `Thus $\widetilde R=R-S+E_{\rm total}$, where the averaging error is $S+A_{\rm av}-qI$ and all remaining terms are shown ` |
| S0247 | 568–576 | SENTENCE | yes | 7 | `All displayed tensors are symmetric; the cross terms satisfy \begin{align*}  \norm{u\otimes v}1&\leq\norm u3\norm v{3/2}` |
| S0248 | 576–577 | SENTENCE | yes | 0 | `These terms tend to zero at fixed coarse seed as $H\downarrow0$.` |
| S0249 | 577–578 | SENTENCE | yes | 0 | `The same estimates give an arbitrarily small $L^{3/2}$ increment.` |
| S0250 | 578–580 | SENTENCE | yes | 2 | `A corrector on one direction slot alone would have the wrong instantaneous average stress and is not used.` |
| S0251 | 580–582 | STRUCTURAL | no | 0 | `\subsection{Spatial smoothing, without remollifying the old seed}` |
| S0252 | 583–585 | SENTENCE | yes | 4 | `The raw profile can be made spatially smooth on each fixed cycle by convolving the \emph{new packet equation} with a fix` |
| S0253 | 585–586 | SENTENCE | yes | 3 | `Keep $\ell$ constant throughout that cycle and take it below its positive minimum radius.` |
| S0254 | 586–587 | SENTENCE | yes | 0 | `Replace $v,Q,\mathcal U,E,A_{\rm av}$ by their convolutions consistently.` |
| S0255 | 587–592 | SENTENCE | yes | 2 | `The packet equation then gains the symmetric commutator \[  C_\ell=v_\ell\otimes v_\ell-(v\otimes v)_\ell, \] with the s` |
| S0256 | 592–595 | SENTENCE | yes | 4 | `Its $L^1$ norm tends uniformly to zero on the fixed cycle: the map $t\mapsto v(t)$ is continuous into $L^2$, its image i` |
| S0257 | 595–597 | SENTENCE | yes | 5 | `Norm bounds do not grow under probability convolution; evenness and the two moment cancellations are preserved.` |
| S0258 | 597–598 | SENTENCE | yes | 0 | `The constant smoothing scale eliminates any additional time derivative of the convolution kernel.` |
| S0259 | 598–599 | SENTENCE | yes | 2 | `Zero endpoint values of $v$ and $Q$ are preserved.` |
| S0260 | 599–600 | SENTENCE | yes | 2 | `The old seed is never remollified, so no new velocity jump is created at a pre-existing boundary.` |
| S0261 | 600–604 | SENTENCE | yes | 3 | `\begin{lemma}[Prescribed-piece local endpoint repair, LER]\label{ass:LER} Consider the following admissible class: posit` |
| S0262 | 604–605 | SENTENCE | yes | 4 | `Stresses are symmetric and locally bounded in $L^\infty_tL^1_x$.` |
| S0263 | 605–607 | SENTENCE | yes | 3 | `Their restrictions to the open pieces of a locally finite positive-time partition admit continuous $L^1$ extensions to e` |
| S0264 | 607–608 | SENTENCE | yes | 0 | `The two one-sided extensions need not agree at a boundary.` |
| S0265 | 608–610 | SENTENCE | yes | 2 | `Actual stress values at those discrete times are chosen separately subject to the same norm bound; they do not enter the` |
| S0266 | 610–611 | SENTENCE | yes | 0 | `The Euler--Reynolds equation holds in distributions.` |
| S0267 | 611–612 | SENTENCE | yes | 0 | `No derivative bound on the old velocity is required by the local construction.` |
| S0268 | 612–616 | SENTENCE | yes | 5 | `Let $(u,R)$ be any current pair in this class, $J\Subset(0,\infty)$ an open patch, and $S$ a prescribed symmetric tensor` |
| S0269 | 616–617 | SENTENCE | yes | 0 | `Write $\delta=\sup_J\norm S1$.` |
| S0270 | 617–629 | SENTENCE | yes | 9 | `For every $\varepsilon,\zeta,\kappa,r_*>0$ there are $w,E_{\rm total}$ compactly supported in time in $J$ such that \[  ` |
| S0271 | 629–632 | SENTENCE | yes | 6 | `The constant $C$ is independent of the seed derivatives, support, patch location, and patch length; fine parameters may ` |
| S0272 | 632–634 | SENTENCE | yes | 3 | `The new correction is continuous into $L^2\cap L^3\cap L^{3/2}$, and only finitely many new time boundaries are introduc` |
| S0273 | 634–635 | SENTENCE | yes | 0 | `Old boundaries are included in the new partition.` |
| S0274 | 635–636 | SENTENCE | yes | 0 | `Every principal radius can be required to be at most $r_*$.` |
| S0275 | 636–638 | SENTENCE | yes | 0 | `All outputs paste within the admissible class. \end{lemma}` |
| S0276 | 639–640 | SENTENCE | yes | 3 | `\begin{proof} If $\delta=0$, take $w=E_{\rm total}=0$.` |
| S0277 | 640–641 | SENTENCE | yes | 0 | `Suppose henceforth that $\delta>0$.` |
| S0278 | 641–642 | SENTENCE | yes | 0 | `Choose $[a,b]\Subset J$ containing the temporal support of $S$ in its interior.` |
| S0279 | 642–643 | SENTENCE | yes | 0 | `Only finitely many inherited partition boundaries meet this interval.` |
| S0280 | 643–650 | SENTENCE | yes | 5 | `On each closed one-sided continuity piece, uniform continuity into $L^1$ permits a finite coarse subdivision such that o` |
| S0281 | 650–652 | SENTENCE | yes | 2 | `In this display, $S$ on a closed $I_k$ means the one-sided continuous extension from its interior.` |
| S0282 | 652–653 | SENTENCE | yes | 0 | `No single actual boundary value is required to equal two different traces.` |
| S0283 | 653–656 | SENTENCE | yes | 3 | `First freeze $S$ at one time with error at most $\varepsilon_0/2$, then approximate that single $L^1$ tensor by a compac` |
| S0284 | 656–657 | SENTENCE | yes | 0 | `There are only finitely many coarse cells.` |
| S0285 | 657–659 | SENTENCE | yes | 3 | `Thus their chosen supports, spatial derivatives, and decomposition parameters have finite maxima.` |
| S0286 | 659–660 | SENTENCE | yes | 0 | `No derivative of the actual prescribed $S$ is taken.` |
| S0287 | 660–663 | SENTENCE | yes | 0 | `On each $I_k$, decompose the constant tensor $-S_k$ modulo $q_kI$ as above.` |
| S0288 | 663–665 | SENTENCE | yes | 3 | `Choose its regularization parameter and the positive floors so that all added coefficient mass is arbitrarily small.` |
| S0289 | 665–667 | SENTENCE | yes | 2 | `The rectangular buffers lie outside the support of the original coefficient, where its value is zero before adding the f` |
| S0290 | 667–669 | SENTENCE | yes | 2 | `The constant-floor buffer errors are bounded by a fixed multiple of their total added mass.` |
| S0291 | 669–671 | SENTENCE | yes | 2 | `In particular, shrinking those masses controls the averaging error and the additive amplitude slack independently of the` |
| S0292 | 671–673 | SENTENCE | yes | 2 | `Fix the coarse tensor, rectangles, floors, and ramp functions.` |
| S0293 | 673–674 | SENTENCE | yes | 0 | `Divide $I_k$ into $N_k$ equal complete four-direction cycles.` |
| S0294 | 674–675 | SENTENCE | yes | 3 | `Put $\tau_k=\|I_k\|/N_k$, $H_k=\tau_k^{1/6}$, and $d_k=H_k^2$.` |
| S0295 | 675–677 | SENTENCE | yes | 2 | `Consequently $\tau_k=H_k^6$ holds exactly, rather than only asymptotically, and every endpoint of $I_k$ is a complete-cy` |
| S0296 | 677–678 | SENTENCE | yes | 0 | `Use the exact normalization \eqref{eq:normalization} on each cycle.` |
| S0297 | 678–680 | SENTENCE | yes | 4 | `At fixed positive floors, the quantities $d_kB_i$ converge to positive finite limits as $N_k\to\infty$.` |
| S0298 | 680–682 | SENTENCE | yes | 6 | `The amplitudes therefore have positive lower and finite upper bounds independent of large $N_k$, with bounds permitted t` |
| S0299 | 682–687 | SENTENCE | yes | 0 | `The leading upper bound is \[  \eta_i\leq C\sqrt{\delta+\varepsilon_0}    +C\sqrt{\hbox{added mass and vanishing row-rul` |
| S0300 | 687–689 | SENTENCE | yes | 2 | `The constant multiplying $\sqrt{\delta+\varepsilon_0}$ depends only on the fixed four directions and dipole, not on deri` |
| S0301 | 689–692 | SENTENCE | yes | 4 | `All radii on the fixed coarse cell are bounded above and below by positive constant multiples of $H_k^8$.` |
| S0302 | 692–693 | SENTENCE | yes | 0 | `The constants may depend on its coefficients and floors.` |
| S0303 | 693–694 | SENTENCE | yes | 3 | `Thus $2r^{1/5}\leq H_k$ and $r\leq r_*$ hold for all sufficiently large $N_k$.` |
| S0304 | 694–697 | SENTENCE | yes | 5 | `The quantities $\|(\eta r)'\|$ and $\|\eta r'\|$ stay bounded independently of $N_k$, because their formulas involve only th` |
| S0305 | 697–699 | SENTENCE | yes | 0 | `Equation \eqref{eq:E-bound} makes the intrinsic stress $O(H_k\|\log H_k\|)+O(H_k^8)$.` |
| S0306 | 699–701 | SENTENCE | yes | 3 | `Equation \eqref{eq:Q} makes the corrector $O(H_k^5)$ in $L^2$ and curl $L^1$, and $O(H_k^{16/3})$ in $L^{3/2}$.` |
| S0307 | 701–702 | SENTENCE | yes | 0 | `The principal $L^{3/2}$ norm is $O(H_k^{8/3})$ at fixed coarse parameters.` |
| S0308 | 702–703 | SENTENCE | yes | 0 | `Equation \eqref{eq:quad} makes the quadrature error tend to zero.` |
| S0309 | 703–705 | SENTENCE | yes | 3 | `Every cross term with the actual old $u$ tends to zero by the displayed Hölder estimates and the finite bound $\sup_{[a,` |
| S0310 | 705–708 | SENTENCE | yes | 2 | `There is no time-freezing derivative estimate here: the constructed tensor $S_k$ is constant on the coarse cell, and the` |
| S0311 | 708–710 | SENTENCE | yes | 0 | `Finally choose a fixed spatial mollification scale on each complete cycle.` |
| S0312 | 710–711 | SENTENCE | yes | 3 | `The finite set of cycles has a positive minimum radius.` |
| S0313 | 711–713 | SENTENCE | yes | 3 | `The commutator can therefore be made smaller than any remaining stress budget, while convolution decreases all required ` |
| S0314 | 713–714 | SENTENCE | yes | 0 | `It changes the averaged tensor to its convolution.` |
| S0315 | 714–716 | SENTENCE | yes | 2 | `The resulting additional averaging error also tends to zero in $L^1$ as the mollification scale tends to zero, since tha` |
| S0316 | 716–717 | SENTENCE | yes | 0 | `No old field is mollified.` |
| S0317 | 717–720 | SENTENCE | yes | 0 | `The exact stress identity on $I_k$ is $\widetilde R=R-S_k+E_k^{\rm loc}$.` |
| S0318 | 720–723 | SENTENCE | yes | 3 | `It follows by adding the old equation to the new packet and corrector identities, taking the average over the whole four` |
| S0319 | 723–727 | SENTENCE | yes | 2 | `At times strictly inside a coarse cell, set \[  E_{\rm total}(t)=S(t)-S_k+E_k^{\rm loc}(t)\qquad(t\in I_k). \]` |
| S0320 | 727–728 | SENTENCE | yes | 0 | `Then $\widetilde R=R-S+E_{\rm total}$ exactly.` |
| S0321 | 728–730 | SENTENCE | yes | 2 | `Choose $\varepsilon_0\leq\varepsilon/2$ and all local stress errors at most $\varepsilon/2$.` |
| S0322 | 730–731 | SENTENCE | yes | 0 | `This proves the requested stress bound.` |
| S0323 | 731–733 | SENTENCE | yes | 0 | `Choose $\varepsilon_0$ also so that $C\sqrt\varepsilon_0\leq\zeta/3$.` |
| S0324 | 733–735 | SENTENCE | yes | 0 | `Next choose added coefficient masses small enough for their amplitude cost to be at most $\zeta/3$.` |
| S0325 | 735–737 | SENTENCE | yes | 3 | `Finally choose the cycle counts large enough that the row-rule amplitude error and the $L^2$ and curl cost of $Q$ use at` |
| S0326 | 737–739 | SENTENCE | yes | 0 | `Using $\sqrt{\delta+\varepsilon_0}\leq\sqrt\delta+\sqrt\varepsilon_0$ proves the independent leading increment estimate.` |
| S0327 | 739–741 | SENTENCE | yes | 2 | `The same cycle counts can make the two $L^{3/2}$ contributions sum to at most $\kappa$ and all radii at most $r_*$.` |
| S0328 | 741–743 | SENTENCE | yes | 2 | `All these requirements have already been shown to improve as the counts increase at fixed coarse data, so this is one co` |
| S0329 | 743–745 | SENTENCE | yes | 2 | `Every principal packet and $Q$ vanishes at each completed cycle endpoint.` |
| S0330 | 745–746 | SENTENCE | yes | 0 | `Extend $w$ by zero outside $[a,b]$.` |
| S0331 | 746–747 | SENTENCE | yes | 2 | `Its continuous zero traces exclude temporal delta functions.` |
| S0332 | 747–748 | SENTENCE | yes | 2 | `Define $E_{\rm total}=0$ outside this interval; the prescribed $S$ is zero there.` |
| S0333 | 748–751 | SENTENCE | yes | 4 | `On the finite set of inherited, coarse-cell, and full-cycle boundary times, choose $E_{\rm total}(t)=0$ and $\widetilde ` |
| S0334 | 751–753 | SENTENCE | yes | 3 | `These choices maintain the exact algebra and the pointwise error bound, and do not change the distributional equation or` |
| S0335 | 753–755 | SENTENCE | yes | 3 | `The error stress may jump at $a,b$ and at cycle boundaries, but spatial divergence creates no temporal delta from those ` |
| S0336 | 755–756 | SENTENCE | yes | 0 | `Both output supports are compact subsets of $J$.` |
| S0337 | 756–760 | SENTENCE | yes | 5 | `The principal packet is continuous in global $L^2$ and $L^{3/2}$ by positive-radius scaling and translation continuity, ` |
| S0338 | 760–762 | SENTENCE | yes | 2 | `Fixed spatial smoothing makes it continuous into $L^3$ by Young's inequality $\norm{\rho_\ell*v}3\leq C\ell^{-1/3}\norm ` |
| S0339 | 762–763 | SENTENCE | yes | 2 | `The projected-bump time integral makes $Q$ continuous into all three spaces.` |
| S0340 | 763–765 | SENTENCE | yes | 2 | `For each fixed construction these bounds are finite, without asserting a uniform $L^3$ bound through the infinite iterat` |
| S0341 | 765–767 | SENTENCE | yes | 2 | `Every local intrinsic stress is continuous into $L^1$ on its closed cycle.` |
| S0342 | 767–769 | SENTENCE | yes | 2 | `For the anti-divergence terms this follows from \eqref{eq:anti} on a common support ball and the $L^1$ continuity of the` |
| S0343 | 769–770 | SENTENCE | yes | 3 | `Translations and positive-radius rescalings preserve the asserted continuity.` |
| S0344 | 770–771 | SENTENCE | yes | 0 | `At packet resets the prefactors in those intrinsic stresses tend to zero.` |
| S0345 | 771–772 | SENTENCE | yes | 3 | `The commutator and quadratic terms are continuous by their $L^2$ products.` |
| S0346 | 772–778 | SENTENCE | yes | 2 | `The old--new terms are continuous because \[  \norm{u(t)\otimes w(t)-u(s)\otimes w(s)}1  \leq\norm{u(t)-u(s)}3\norm{w(t)` |
| S0347 | 778–779 | SENTENCE | yes | 2 | `Adding $S-S_k$ leaves the error piecewise continuous into $L^1$.` |
| S0348 | 779–780 | SENTENCE | yes | 2 | `Thus the new stress and velocity remain in the stated admissible class.` |
| S0349 | 780–782 | SENTENCE | yes | 2 | `Only finitely many coarse cells and cycles were used in $[a,b]$. \end{proof}` |
| S0350 | 783–784 | STRUCTURAL | no | 0 | `\section{Global time iteration and exact-target closure}` |
| S0351 | 785–789 | SENTENCE | yes | 6 | `\begin{lemma}[Zero initial trace from anchor times]\label{lem:anchors} Suppose $(U,R)$ and $(\widetilde U,\widetilde R)$` |
| S0352 | 789–791 | SENTENCE | yes | 4 | `Suppose $W=\widetilde U-U$ is uniformly bounded in global $L^2$ and $W(t_k)=0$ for a sequence $t_k\downarrow0$.` |
| S0353 | 791–793 | SENTENCE | yes | 0 | `Then $W(t)\rightharpoonup0$ in global $L^2$ as $t\downarrow0$. \end{lemma}` |
| S0354 | 794–801 | SENTENCE | yes | 3 | `\begin{proof} For a compact smooth divergence-free spatial test $\psi$, subtract the Euler--Reynolds equations: \[  \fra` |
| S0355 | 801–802 | SENTENCE | yes | 3 | `The right side is uniformly bounded.` |
| S0356 | 802–804 | SENTENCE | yes | 3 | `The pairing is Lipschitz, including across piecewise-time boundaries by the distributional equation and continuity, and ` |
| S0357 | 804–805 | SENTENCE | yes | 0 | `Any sequence of $W(t)$ has a weakly convergent $L^2$ subsequence.` |
| S0358 | 805–807 | SENTENCE | yes | 4 | `Its limit is divergence free and annihilates all such $\psi$; testing $\psi=\nabla^\perp\phi$ also makes its curl zero.` |
| S0359 | 807–810 | SENTENCE | yes | 3 | `Fourier variables force this global $L^2$ vector field to vanish: away from frequency zero it is both parallel and perpe` |
| S0360 | 810–811 | SENTENCE | yes | 0 | `All weak cluster points are zero, proving the claim. \end{proof}` |
| S0361 | 812–818 | SENTENCE | yes | 7 | `\begin{proposition}[Global iteration]\label{prop:iteration} The seed in Proposition~\ref{prop:seed} can be repaired on $` |
| S0362 | 819–825 | SENTENCE | yes | 4 | `\begin{proof} Choose a nonnegative $\eta\in C_c^\infty((1/2,2))$ whose dyadic dilates cover $(0,\infty)$ and set \[  I_j` |
| S0363 | 825–827 | SENTENCE | yes | 2 | `This is a locally finite partition of unity with $\supp\chi_j\Subset I_j$.` |
| S0364 | 827–827 | SENTENCE | yes | 0 | `Color patches by $j\bmod3$.` |
| S0365 | 827–829 | SENTENCE | yes | 3 | `Within each color the intervals are disjoint and leave gaps; for a given $j$ of that color, $3\cdot2^j$ lies between $I_` |
| S0366 | 829–830 | SENTENCE | yes | 0 | `These gap times tend to zero as $j\to-\infty$.` |
| S0367 | 830–830 | SENTENCE | yes | 0 | `Use $N=3$ as an overlap bound.` |
| S0368 | 830–833 | SENTENCE | yes | 5 | `Choose a smooth nondecreasing majorant $\Theta\geq1$, finite on every finite horizon including zero, such that $\norm{R^` |
| S0369 | 833–834 | SENTENCE | yes | 0 | `It exists from Proposition~\ref{prop:seed}.` |
| S0370 | 834–835 | SENTENCE | yes | 2 | `Let $\delta_q=16^{-q}$ and inductively require $\norm{R^{(q)}(t)}1\leq\delta_q\Theta(t)$.` |
| S0371 | 835–837 | SENTENCE | yes | 0 | `Freeze the prescribed pieces $S_{qj}=\chi_jR^{(q)}$ before any repair at stage $q$.` |
| S0372 | 837–837 | SENTENCE | yes | 3 | `Set $M_j=\sup_{I_j}\Theta$, $m_j=\inf_{I_j}\Theta\geq1$.` |
| S0373 | 837–843 | SENTENCE | yes | 3 | `For patch $j$ apply LER with \[  \varepsilon_{qj}=\delta_{q+1}m_j/N,\qquad  \zeta_{qj}=\sqrt{\delta_q}/N,\qquad  \kappa_` |
| S0374 | 843–844 | SENTENCE | yes | 0 | `Process the three colors in order.` |
| S0375 | 844–845 | SENTENCE | yes | 2 | `Within one color disjoint supports allow simultaneous pasting, with no cross term between different patches.` |
| S0376 | 845–847 | SENTENCE | yes | 2 | `Between colors use the current repaired pair as background, while still removing the originally frozen piece $S_{qj}$.` |
| S0377 | 847–848 | SENTENCE | yes | 0 | `This prescribed-piece feature is why LER is stated with $S$ independently of the current $R$.` |
| S0378 | 848–850 | SENTENCE | yes | 2 | `Each compact positive-time interval meets only finitely many patches, and LER introduces only finitely many new boundari` |
| S0379 | 850–851 | SENTENCE | yes | 2 | `Thus the finite-stage admissible class is retained.` |
| S0380 | 851–857 | SENTENCE | yes | 3 | `At the end of the stage, \[  u^{(q+1)}=u^{(q)}+w_q,\quad w_q=\sum_jw_{qj},\qquad  R^{(q+1)}=\sum_jE_{qj}. \]` |
| S0381 | 857–859 | SENTENCE | yes | 2 | `There are at most $N$ active summands at any time, and each has $m_j\leq\Theta(t)$.` |
| S0382 | 859–860 | SENTENCE | yes | 0 | `Therefore $\norm{R^{(q+1)}(t)}1\leq\delta_{q+1}\Theta(t)$.` |
| S0383 | 860–866 | SENTENCE | yes | 0 | `During a partially completed color stage the stress is \[  \left(1-\sum_{j\ \mathrm{processed}}\chi_j\right)R^{(q)}  +\s` |
| S0384 | 866–872 | SENTENCE | yes | 4 | `If $0<t\leq T$ and a patch is active, $I_j\subset(0,4T)$, so \begin{equation}\label{eq:increment-stage}  \sup_{0<t\leq T` |
| S0385 | 872–873 | SENTENCE | yes | 2 | `These bounds are summable in $q$ and also bound intermediate color increments.` |
| S0386 | 873–876 | SENTENCE | yes | 2 | `The arbitrary $L^{3/2}$ budgets give summable subcritical increments; their more immediate role is making each old--new ` |
| S0387 | 876–876 | SENTENCE | yes | 0 | `No uniform-in-stage $L^3$ norm is asserted.` |
| S0388 | 876–879 | SENTENCE | yes | 0 | `For each color the total correction vanishes at its gap times approaching zero.` |
| S0389 | 879–881 | SENTENCE | yes | 7 | `Both old and new stresses and local energies are uniformly bounded near zero, and the global $L^2$ correction is bounded` |
| S0390 | 881–882 | SENTENCE | yes | 0 | `Lemma~\ref{lem:anchors} shows it has weakly zero initial trace.` |
| S0391 | 882–882 | SENTENCE | yes | 0 | `There are only three colors.` |
| S0392 | 882–884 | SENTENCE | yes | 0 | `Induction therefore preserves exact initial trace at every stage without requiring small initial energy or a nearby-endp` |
| S0393 | 884–887 | SENTENCE | yes | 3 | `The correction series converges uniformly in global $L^2$ on $(0,T]$ for each finite $T$.` |
| S0394 | 887–888 | SENTENCE | yes | 4 | `At positive times the finite stages are locally strongly $L^2$ continuous, so their locally uniform limit is too.` |
| S0395 | 888–890 | SENTENCE | yes | 5 | `At zero, split the series into finitely many terms and a uniformly small $L^2$ tail; each finite correction has weakly z` |
| S0396 | 890–892 | SENTENCE | yes | 2 | `Together with the seed trace this gives $u\in C_w([0,\infty);L^2_{\rm loc})$ and $u(0)=u_0$.` |
| S0397 | 892–895 | SENTENCE | yes | 2 | `At each fixed $t>0$, the curl series converges absolutely in $L^1$ by \eqref{eq:increment-stage}, and its sum is the dis` |
| S0398 | 895–900 | SENTENCE | yes | 2 | `Consequently \[  \sup_{0<t\leq T}\norm{\curl u(t)}1\leq  \sup_{0<t\leq T}\norm{\curl u^{(0)}(t)}1+  [NC\sqrt{\Theta(4T)}` |
| S0399 | 900–901 | SENTENCE | yes | 0 | `Add the initial measure norm to obtain the bound including zero.` |
| S0400 | 901–902 | SENTENCE | yes | 0 | `Divergence zero is preserved distributionally.` |
| S0401 | 902–906 | SENTENCE | yes | 2 | `Strong $L^2$ convergence on compact positive-time cylinders passes the quadratic term to the limit in $L^1$, while $\nor` |
| S0402 | 906–907 | SENTENCE | yes | 0 | `Thus Euler holds on $(0,\infty)$.` |
| S0403 | 907–908 | SENTENCE | yes | 0 | `For a test meeting zero, use a temporal cutoff rising on $(\varepsilon,2\varepsilon)$.` |
| S0404 | 908–909 | SENTENCE | yes | 0 | `Uniform local energy makes the omitted convection integral tend to zero.` |
| S0405 | 909–911 | SENTENCE | yes | 2 | `Weak local $L^2$ continuity identifies the cutoff-derivative term with $\int u_0\cdot\varphi(0)$; replacing $\varphi(t)$` |
| S0406 | 911–913 | SENTENCE | yes | 0 | `This proves precisely the target's initial-value weak formulation. \end{proof}` |
| S0407 | 914–917 | SENTENCE | yes | 6 | `\begin{lemma}[Canonical normalization from a fixed background]\label{lem:canonical} Suppose $u=U+v$, where $U\in C_0(\R^` |
| S0408 | 917–918 | SENTENCE | yes | 0 | `Then $u=K*\mu$. \end{lemma}` |
| S0409 | 919–921 | SENTENCE | yes | 5 | `\begin{proof} The distribution $h=u-K*\mu$ has zero divergence and curl, so each component is harmonic; Weyl's lemma mak` |
| S0410 | 921–927 | SENTENCE | yes | 0 | `Its mean-value estimate on $B_R(x)$ gives \[  \|h(x)\|\leq\frac1{\|B_R\|}\int_{B_R(x)}\|U\|  +\frac{C\norm v2}{R}  +\frac1{\|B_` |
| S0411 | 927–929 | SENTENCE | yes | 0 | `The last term is at most $C\norm\mu\M/R$, because $\sup_y\int_{B_R(x)}\|K(z-y)\|\,dz\leq CR$.` |
| S0412 | 929–931 | SENTENCE | yes | 2 | `The first tends to zero since $U\in C_0$: separate a fixed large compact set from its uniformly small complement.` |
| S0413 | 931–932 | SENTENCE | yes | 2 | `Letting $R\to\infty$ proves $h=0$. \end{proof}` |
| S0414 | 933–937 | SENTENCE | yes | 2 | `\begin{theorem}[Global existence]\label{thm:global} For every datum in the exact target stated at the start of this docu` |
| S0415 | 938–941 | SENTENCE | yes | 4 | `\begin{proof} Proposition~\ref{prop:iteration} gives the global velocity, the exact weak initial trace and formulation, ` |
| S0416 | 941–943 | SENTENCE | yes | 4 | `At each time take $U=V_0$ and $v=(V(t)-V_0)+W(t)+\sum_qw_q(t)\in L^2$ in Lemma~\ref{lem:canonical}; at zero use the pres` |
| S0417 | 943–944 | SENTENCE | yes | 2 | `This proves the remaining canonical Biot--Savart identity at every time.` |
| S0418 | 944–946 | SENTENCE | yes | 2 | `No finite-horizon solutions have to be reconciled or restarted. \end{proof}` |
| S0419 | 947–948 | STRUCTURAL | no | 0 | `\end{document}` |
