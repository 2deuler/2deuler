import json, hashlib, collections
from pathlib import Path

BASE=Path('/workspace/scratch/de6aed6f6a22/audit_v1')
inv=json.loads((BASE/'audit_inventory.json').read_text())
source_hash=hashlib.sha256((BASE/'proof.tex').read_bytes()).hexdigest()
assert source_hash=='b6741b471ba2f128b147f5a5c05fea0afe639c2c3a535b99a5afaf03ea6d4a43'
notes={}
def add(block):
    for line in block.strip().splitlines():
        num, rationale=line.split('|',1)
        n=int(num)
        assert n not in notes,n
        notes[n]=rationale.strip()

add(r'''
11|The macro expands to the real-number symbol, consistently used for the spatial plane and time.
12|The macro expands to the measure-space symbol; the target identifies its finite signed Radon-measure meaning.
13|The macro is the curl operator; the stated planar orientation agrees with curl u=partial_1 u_2-partial_2 u_1.
14|The macro is divergence, with the row-divergence convention explicitly supplied in S0032.
15|The macro is support; its subsequent temporal and spatial uses have specified ambient variables.
16|Both arguments expand to the enclosed norm and its subscript; one-token exponents such as 1, 2, M, and infinity are read correctly.
17|The macro is dx, so all spatial integrals are two-dimensional Lebesgue integrals unless the measure is explicitly given.
26|The kernel has the stated clockwise-coordinate/positive-vorticity normalization: K=grad-perp(log|x|)/(2 pi).
27|The datum class and canonical convolution exactly match the supplied target; the convolution is justified independently in S0035-S0052.
28|Every-time curl, canonical velocity, locally uniform variation, weak local-L2 continuity and initial value are accurately transcribed requirements, not extra hypotheses.
29|Integrating the velocity equation against a compact divergence-free test gives precisely this sign of the initial term and removes pressure.
30|Comparison with the supplied target confirms none of the four additional restrictions is imposed.
32|Expanding components fixes the planar orientation, row divergence, gradient indices, and Fourier sign consistently.
33|Since Delta(log|x|/(2 pi))=delta_0, Fourier transformation of grad-perp Delta^{-1} gives -i xi-perp/|xi|^2.
34|The finite signed measure and inhomogeneous H^{-1} hypotheses are explicit; M is its nonnegative total variation.
35|Tonelli gives local L1 and an a.e. convolution; the low/high-frequency decomposition below gives local L2; distributional convolution gives div=0 and curl=mu.
36|A nonnegative radial compact smooth probability density exists by normalizing a radial bump; A may be any sufficiently large positive support radius.
37|Finite-measure convolution defines all four objects. Associativity follows against compact tests using the locally integrable kernel and its bounded tail.
38|The compact L1 kernel K-K*a gives the L1 bound; its multiplier is bounded from H^{-1} to L2. The smooth low-frequency part is C0 and bounded. Probability convolution and the triangle inequality give M and 2M.
39|D^alpha a*mu has L1 and Linfinity bounds by measure convolution. For positive-order V0 derivatives, xi^alpha m a-hat is in L1 and L2, and mu-hat is bounded.
40|For B=B_R, integration of |x-y|^{-1} over B is uniformly at most C R. Tonelli against |mu| proves local absolute integrability and hence a.e. definition.
41|Direct distributional differentiation of the fundamental solution gives div K=0, curl K=delta_0; convolution transfers these identities and the Fourier multiplier to mu.
42|The tail variation of mu restricted outside B_R tends to zero. The uniform local integral bound controls convolution against compact tests and passes all linear identities.
43|At zero |m| is O(|xi|^{-1}), which is integrable in dimension two; at infinity a Schwartz test dominates it. Uniform Fourier convergence follows from total-variation convergence.
44|A radial vorticity produces a tangential velocity. Stokes on B_r gives tangential speed (2 pi r)^{-1} times enclosed mass, proving the formula, with the origin interpreted by continuity.
45|Outside B_A the enclosed probability mass is one. Inside, K*a is bounded while K has an integrable 1/|x| singularity, so L_a is compactly supported and L1.
46|For the L1 kernel L_a and finite measure mu, Tonelli gives ||L_a*mu||_1 <= ||L_a||_1 ||mu||_M.
47|Evenness cancels the linear Fourier term. Taylor expansion gives O(|xi|^2) at zero, boundedness gives O(1) away, and multiplication by |m|=|xi|^{-1} proves the displayed weight bound.
48|Multiply the pointwise multiplier estimate by |mu-hat|^2/(1+|xi|^2), integrate, and apply Plancherel. This uses the inhomogeneous, not homogeneous, norm.
49|Both displayed multipliers are L1. Only the positive-order family xi^alpha m a-hat is L2; m a-hat itself has logarithmically divergent squared integral at zero. The pronoun 'they' has two materially different readings.
50|Multiplication by bounded mu-hat preserves the relevant L1 multiplier bounds. Fourier inversion gives bounded continuous derivatives and Riemann-Lebesgue gives decay; positive derivatives also use the L2 multiplier bounds.
51|Associativity against compact tests yields K*mu=K*(a*mu)+(K-K*a)*mu. Young/Tonelli gives ||a*mu||_1<=M and ||mu-a*mu||_M<=2M.
52|The low-frequency field is bounded on every bounded set and the remainder is globally L2, proving the asserted identity and local-L2 membership.
54|Independently opened the original Springer article and checked the stated bibliographic data, Theorem 3.3, Assumptions 2.1/3.1 and Definition 3.2; see the theorem matching in pass_b_report.md.
55|The primary theorem supplies a global signed L1-intersection-Linfinity Lagrangian solution, finite-horizon velocity/vorticity bounds and log-Lipschitz control; its definition fixes canonical velocity a.e. The divergence-free specialization preserves L1 by the flow argument below.
56|Original Definition 3.2 contains the initial-value vorticity identity and explicitly defines the pushforward representation for a.e. time. These are exactly the conclusions used.
57|The original hypotheses are integrability and kernel conditions. Neither compact support nor global velocity energy nor a sign restriction occurs.
58|Inversion z/|z|^2 obeys |I(z)-I(w)|=|z-w|/(|z||w|); rotation preserves length. Div K=0 distributionally and there is no boundary on R2, matching all kernel requirements.
59|No smoothness of the transported vorticity or differentiated background is taken from the external theorem; the later regularity follows from Fourier and transport estimates.
60|Starting with nu0 in L1-intersection-Linfinity, the theorem and the reconstructed representative give all bounds; weak-L2 plus Linfinity yields L3, while the flux multiplier yields relative-L2 continuity.
61|The integrated flux F_t has L2 norm <= t ||V||_infinity ||nu0||_2. The multiplier -K div has operator norm one, proving the coefficient and norm exactly.
62|nu0 satisfies the cited theorem's data hypotheses by probability smoothing; the kernel bounds, divergence, and absent boundary were independently matched. The cited conclusions include all properties taken here.
63|The construction only needs bounded transported vorticity and the derived Sobolev/continuity estimates, so no classical smooth Euler theorem is required.
64|This is a declared representative-selection step; the construction in S0065-S0076 specifies it at every time.
65|The log-Lipschitz modulus has divergent reciprocal integral near zero. Osgood uniqueness applies forward and backward; bounded speed gives displacement <=T sup|V| and prevents finite escape.
66|Spatial probability convolution is well-defined on the bounded velocity, retains divergence zero, and yields smooth spatial fields with the same uniform modulus.
67|For the spatially smooth, time-measurable velocity, the flow is absolutely continuous in time and the Jacobian solves J'=div(V_epsilon)J=0. Thus the change-of-variables determinant is one.
68|The convolution error is bounded by the common modulus at the mollifier scale. The Osgood stability inequality yields uniform convergence of flows on compact time-space sets; backward flows satisfy the same argument.
69|Bounded displacement confines all relevant preimages to a fixed ball. Uniform convergence of the flows gives pointwise convergence of compact continuous tests, and dominated convergence passes their volume identity.
70|The inverse flow exists at every time; composition with nu0 defines a measurable representative without changing its a.e. class.
71|Volume preservation turns the pushforward into nu0 composed with the inverse and preserves integrals of |nu|, |nu|^2 and essential supremum. The source's a.e. pushforward gives agreement.
72|For compact smooth approximants, flow continuity gives Lp continuity by bounded displacement and dominated convergence. Volume-preserving composition is an Lp isometry, so approximation passes this to p=1,2.
73|The every-time L1-intersection-Linfinity representative makes this canonical convolution absolutely defined and bounded for every time.
74|The new representative equals the original a.e. in spacetime, so distributional vorticity identities and canonical velocity are unchanged.
75|Integrating |K| over B_r gives r, and the far kernel bound is 1/(2 pi r). Uniform Linfinity control of f and its vanishing L1 norm prove the two-step continuity argument.
76|At t=0 the transported density equals nu0. Linfinity velocity continuity gives the canonical initial field and continuity of every compact local velocity pairing.
77|The near contribution is <=r||nu||_infinity and the far one <=M/(2 pi r), independently of support and sign.
78|Multiplying bounded V by nu in L1 and L2 proves both product bounds, uniformly on each finite horizon.
79|The independent near/far decomposition and Chebyshev yield weak-L2 norm <=C||mu||_M; for zero measure the assertion is immediate. Lambda is understood positive.
80|For M>0 and lambda>0, choose r=M/(pi lambda): the far convolution is <=lambda/2; the near convolution has L1 norm <=rM. The zero-measure case is separately trivial.
81|If the total convolution exceeds lambda, the near part exceeds lambda/2. Chebyshev gives (2/lambda)rM=C M^2/lambda^2.
82|Layer cake gives ||V||_3^3=3 int_0^{||V||infinity} lambda^2 distribution(lambda) d lambda <= C M^2 ||V||infinity.
83|Integrate the weak initial-value transport equation; the continuous L1 representative identifies endpoints. Vnu is Bochner-integrable in L1 and L2, so F_t belongs to both.
84|The multiplier is, up to sign, (xi-perp tensor xi)/|xi|^2, a rank-one operator of norm one. Fourier transformation of the integrated transport identity yields the stated relative velocity and Lipschitz L2 bound.
85|Time differentiation gives -K div(Vnu) in L2; spatial differentiation of K nu has a bounded degree-zero multiplier applied to nu in L2. Both estimates are uniform on finite horizons.
86|Apply the same integrated-flux multiplier between s and t; its L2 norm is <=sup||Vnu||_2 |t-s|.
87|Pointwise |V(t)-V(s)|<=2B_T, hence integrating |difference|^3 <=2B_T |difference|^2 gives the coefficient exactly.
88|Each V(t) is globally L3 and the interpolation estimate tends to zero with t-s, including at zero.
89|V is bounded with grad V in L2, so the nonlinear term is L2. Spatial approximation justifies curl((V dot grad)V)=div(Vnu); transport cancels it with partial_t nu. A curl-free distribution on R2 is a gradient.
90|Choosing the negative of that gradient as grad p_V yields the velocity Euler equation; only relative velocity energy was used.
92|This fixes a symmetric stress and the row-divergence convention. Against solenoidal tests its sign agrees with the later subtraction and stress estimates.
93|The inverse Fourier transform of exp(-|xi|^4) is well-defined and Schwartz; the two-dimensional dilation has Fourier transform exp(-t^4|xi|^4).
94|Fourier symmetry gives real radial b, the transform at zero gives mass one, and Schwartz invariance gives rapid decay. Positivity is not required or used.
95|Since b is Schwartz, C_b=||b||_1 is finite and independent of t under the specified dilation.
96|The stress is symmetric. Expanding the convection of V+W and integrating the biharmonic time derivative into the displayed symmetric gradient gives exactly this seed.
97|The background satisfies Euler and partial_t W=-4t^3 Delta^2 W; the divergence of the symmetric derivative stress is that same time derivative. Expanding the quadratic tensor proves the equation.
98|The Fourier multiplier is an L2 contraction; curl W=b_t*sigma0 gives its variation bound. Young, Holder, and t^3||D^2 b_t||_1=O(t) give the stated stress estimate for every positive t.
99|The approximate identity gives W(t)->v0 in L2 and V(t)->V0 locally strongly. Associativity or the Fourier identity gives W=K*(b_t*sigma0), hence the canonical formula.
100|The positive-time kernel family is continuous in its needed norms. W products are continuous by L2; background cross products use continuous L3 times continuous L3/2. The velocity is locally L2 continuous.
''')

add(r'''
101|Differentiating exp(-t^4|xi|^4) gives -4t^3 |xi|^4 times the multiplier, while Delta^2 has multiplier |xi|^4.
102|Convolution preserves div W=0. Componentwise divergence of grad Delta W is Delta^2 W and divergence of its transpose is grad Delta div W=0.
103|The V quadratic term cancels its Euler equation. The remaining three quadratic tensors and the negative biharmonic stress reproduce all terms with the printed signs.
104|The multiplier has absolute value <=1 and tends pointwise to one; dominated convergence against |v0-hat|^2 proves strong L2 convergence.
105|Curl commutes with convolution in distributions, curl v0=sigma0, and finite-measure Young gives ||curl W||_1<=C_b||sigma0||_M.
106|Tonelli/Young applied to the L1 kernel b_t gives ||W||_1<=||b_t||_1 ||v0||_1=C_b||v0||_1.
107|For divergence-free W, Delta W=grad-perp curl W componentwise. Two derivatives of the scaled kernel have L1 size Ct^{-2}, yielding both the inequality and its scaling.
108|Multiplication by 4t^3 turns the derivative bound into Ct. The quadratic term is bounded by ||v0||_2^2 and cross terms by 2||V||infinity||W||_1.
109|The background has V(t)-V0 tending to zero in L2, and W(t)->v0 there; adding yields the claimed local trace.
110|For compact tests, the kernel convolution is absolutely controlled by local K integrability and bounded tails; Fourier multipliers alternatively identify both sides. This gives the canonical seed at every positive time.
111|On a positive compact time interval b_t and its parameter derivatives are continuous in L1 and Linfinity; convolution gives the three stated spaces, and interpolation gives L3/2 and L3.
112|D^2 b_t varies continuously in L1 away from t=0; multiplication by t^3 and convolution with sigma0 preserve this continuity.
113|The bilinear estimates L2 times L2 to L1 and L3 times L3/2 to L1, applied to differences of products, prove each claimed continuity and its transpose.
114|All asserted seed continuity has been obtained from kernel continuity and product estimates; no derivative of the old background was required.
115|To make the global V-new cross stress small under only V in L3, the construction supplies an independently small L3/2 norm while retaining the critical L2 and curl bounds.
116|Holder with reciprocal exponents 1/3+2/3=1 gives the displayed whole-plane cross estimate.
117|For swirl f(r)=1/(r log r), energy tail is int dr/(r log^2 r)<infinity, curl=-1/(r^2 log^2 r) has finite L1 tail, but L3/2 tail is int r^{-1/2}(log r)^{-3/2}dr=infinity. Smooth cutoff handles the core.
118|For the stated unit-circulation background the product magnitude is (2 pi r^2 log r)^{-1}; planar integration produces int dr/(r log r), which diverges.
119|Multiplication by any nonzero small constant preserves divergence of the nonnegative product integral. The zero constant is a trivial excluded reading of this observation.
122|The entire power series J0=sum(-1)^k(z/2)^{2k}/(k!)^2 and J1=sum(-1)^k(z/2)^{2k+1}/(k!(k+1)!) can be differentiated locally uniformly and yield both identities; the recurrence has its removable value at zero.
123|The rational alternating-series bounds at 3 and 4 give opposite signs, so continuity places a positive root in the open interval.
124|Independent exact Fraction arithmetic gives the degree-three bracket 223/1024 at 3 and J1's degree-four partial sum -2/45 at 4. The next-term signs give respectively a lower and upper bound.
125|For the J1 tail, consecutive magnitude ratio is (z/2)^2/((k+1)(k+2)), below one after both stated cutoffs. Thus alternating-series remainder signs are justified.
126|The entire real J1 is continuous on [3,4]; the strict endpoint signs meet every intermediate-value-theorem hypothesis.
127|At a common zero with beta>0, J1'=J0-J1/beta is zero by direct substitution.
128|The Bessel ODE has continuous coefficients on a neighborhood of positive beta; zero value and derivative force its unique solution to vanish, contradicting its nonzero series coefficient near zero.
129|The contradiction excludes J0(beta)=0, validating every later denominator.
130|The denominator is nonzero, the two branches agree at rho=1, and the power series removes the apparent polar singularity at rho=0. D is consequently a well-defined planar velocity.
131|Grad-perp x2=-e1 gives D-e1=grad-perp q. The n=1 Bessel radial operator gives Delta psi=-beta^2 q inside; the exterior n=1 inverse-radius harmonic gives zero curl outside.
132|At rho=1, inner and outer stream functions both equal -sin(theta), and radial derivatives both equal sin(theta); tangential derivatives follow from the shared trace.
133|At a J1 root the ODE gives J1''=-J1'/beta=-J0/beta. Hence both radial second derivatives of psi equal -2 sin(theta).
134|The common trace, common normal derivative, and common second normal derivative supply every Hessian component after tangential differentiation. The stream function is C2, so D is C1 across the interface.
135|q has zero trace. Inside, curl D is a function of q and grad-perp q is tangent to q-levels; outside it is zero. The boundary trace contributes no distributional transport term.
136|Writing w=D-e1, w-perp=-grad q and curl w=-beta^2 q yields (w dot grad)w=grad(|w|^2/2+beta^2 q^2/2). The printed negative pressure cancels it, including the interface.
137|Component expansion verifies the vorticity-vector identity with the stated orientation. The pressure and velocity traces match, so no surface measure is introduced.
138|Differentiating -x2/|x|^2 with grad-perp gives grad(-x1/|x|^2). The stream function is odd under inversion, so its derivative D is even.
139|A unit direction determines a rotation; rotating both spatial and vector variables preserves divergence and Euler. The dilation is explicitly r^{-1}D(x/r).
140|The suppressed direction is fixed throughout each visit; later rotation/reset choices are made only at zero packet amplitude.
141|Change of variables gives all four norm scalings and div=0. The scaled Euler identity holds for P_r(x)=r^{-2}P(x/r), rotated with D, but the manuscript never defines P_r; this is a local notation ambiguity.
142|The explicit core is bounded, the exterior is O(|x|^{-2}) with gradient O(|x|^{-3}), and curl vanishes outside B_r; the asserted norm constants are finite.
144|For an integrable compactly supported vector field with the printed zeroth/first moment conditions, convolution with the derivative of the Newtonian kernel defines this tensor distribution; all indices range over 1,2.
145|Swapping i,j proves symmetry. Row differentiation cancels the two mixed grad-div terms and leaves Delta Delta^{-1}f=f componentwise.
146|Every tensor entry is a linear combination of first derivatives of log|x|/(2 pi), homogeneous of degree -1 away from zero.
147|For |y|<=R, integrate |x-y|^{-1} over |x|<=3R; the result is <=C R. Tonelli gives C R||f||_1.
148|Taylor expansion of the degree-minus-one kernel through first order is annihilated by the moments. Its second derivative is O(|x|^{-3}) for |x|>3R, giving C R^2|x|^{-3}||f||_1.
149|The exterior radial integral of R^2|x|^{-3} is O(R); add the core bound to obtain the global L1 estimate.
150|Newtonian derivative convolution generally retains a decaying multipole tail, so compact support of the input does not imply compact support of the output.
151|With only zero mean, the first nonzero moment creates a degree-minus-two tail; its absolute radial integral is int dr/r and need not be finite.
152|Directly differentiating r^{-1}D(x/r) gives -r^{-2}(D+y dot grad D). Expanding div(D_r tensor x/r)=(2D_r+x dot grad D_r)/r yields the printed identity.
153|Homogeneity of the exterior gives x dot grad D_r=-2D_r, so f_r vanishes there. In the core f_r(x)=r^{-2} f_1(x/r), giving constant L1 norm.
154|D_r is even and x is odd, so div(D_r tensor x/r) is even. Multiplication by any coordinate gives an odd compact integrable function with zero integral.
155|The integral of f_r equals (R/r) times the circular integral of D_r. Its exterior angular vector average is zero by the explicit double-angle formula, hence the mean vanishes.
156|The two moment cancellations allow the established anti-divergence estimate with support radius r. F_r=-A f_r changes the sign and gives ||F_r||_1<=Cr.
158|The positive radius and nonnegative amplitude ensure the stated trajectory has the intended direction. Temporal differentiability/absolute continuity is not included here although the next formula uses r' and eta'.
159|For C1 parameters, differentiating the translated packet cancels -eta^2 partial_xi D_r/r against its exact nonlinear traveling term; the residual is (eta'+eta r'/r)D_r+div(eta r'F_r). For merely positive r and nonnegative eta as stated, these products/derivatives are not justified.
160|For r<1, the smooth radial cutoff eliminates the singularity at zero and the exterior potential is the rotated dipole potential. The definitions have the stated spatial scale r^{1/5}.
161|Outside 2r^alpha the two fields coincide. Both are even. Integrating the 1/r core on radius r and the r/|x|^2 annulus up to 2r^alpha gives Cr(1+|log r|); cutoff derivatives cost only Cr.
162|On |x|=R, psi_r=-r sin(theta)/R gives integral D_r=pi r xi by the rotated-normal boundary formula, while Pi_r=-r cos(theta)/R gives integral grad Pi_r=-pi r xi. Their difference is 2 pi r xi.
163|Division by r gives total integral 2 pi xi; compact support and evenness give each first moment zero.
164|A radial nonnegative smooth probability bump with support in B_H exists. The source does not explicitly require the family U_H=H^{-2}U_1(x/H), which later scale-uniform derivative estimates need.
165|The support condition puts the difference inside B_H. Its mean is 2 pi xi-2 pi xi=0, and both summands are even, so every first moment vanishes.
166|The anti-divergence estimate with R=H and input norm <=C(1+|log r|)+2 pi proves this bound; this step uses no derivative scaling of U_H.
167|Split D_r/r into S_r plus a gradient, subtract/add 2 pi U_H xi, and apply div A to the zero-moment difference. The pressure absorbs the potential and the triangle inequality gives the printed stress estimate.
168|Curl of eta D_r is eta times the r^{-2} dilate of curl D; its L1 norm is |eta| C_omega, independently of r.
171|The four displayed directions are unit vectors. Their rank-one tensors span the symmetric 2-by-2 matrices after allowing an isotropic shift.
172|A smooth nonnegative compact cutoff equal to one near the compact support of S exists by a larger nested support construction.
173|Gamma is positive. The radicands are nonnegative scalar functions; where S can be nonzero, h=1 makes them strictly positive.
174|Near the zero set of h the support condition forces S=0, so the positive square roots are gamma h, including at h=0. Elsewhere strict positivity permits smooth composition.
175|Dropping nonnegative radicand terms proves A>=|S12| and B>=|S11|,|S22|, hence the stated weaker max bound.
176|The sum has diagonal entries B-S11+A and B-S22+A and off-diagonal (a3-a4)/2=-S12, exactly qI-S. All coefficient definitions and signs agree.
177|Nonnegativity follows from the previous bounds, and support/smoothness follow from A,B,S. Square-root triangle bounds give a universal coefficient L1 bound by ||S||_1+gamma||h||_1.
178|For the fixed cutoff h, gamma||h||_1 tends to zero as gamma tends to zero; choosing it before fine scales is noncircular.
179|Compact approximation of an L1 stress charges the discarded tail to the residual; no support assumption on the original stress is needed.
180|A continuous map from a compact time set into L1 has compact image. A finite L1 epsilon-net plus small tails for the net points gives a common tail radius.
''')

add(r'''
181|An orthonormal coordinate system (s,y) with axes xi,xi-perp preserves dx=ds dy; a compact coefficient fits in a finite rectangle.
182|This fixes the original smooth compact coefficient, separated from the later positive floor so that quadrature applies without boundary discontinuities.
183|The choice c=a+e>=e>0 makes travel time and log derivatives finite. The rectangle can be enlarged longitudinally so a vanishes in both buffers.
184|The additional mass includes fixed geometric buffer lengths and the fixed ramp integral factor. It is linear in the floors, once the rectangle/ramp are fixed.
185|At fixed finite geometry, positive floors may be chosen as small as desired while retaining strict positivity; their derivative constants need not remain uniform in this choice.
186|This parameter order freezes possibly large support and reciprocal-floor constants before H tends to zero, which is necessary for all later asymptotics.
187|These are compatible independent definitions of row spacing and cycle duration; later integer cycle counts realize tau=H^6 exactly.
188|The intended physical bump radius is H, larger than d=H^2 for small H. A precise fixed-dilation definition is still absent from the earlier U_H declaration.
189|A finite number of sampled rows covers the fixed rectangle. Sequential visits and resets at zero amplitude avoid packet-packet quadratic interactions.
190|On each row c is a smooth positive function and eta is a fixed positive amplitude, so r=r0 c is a positive smooth radius.
191|Since ds/dt=eta/(r0 c), inversion gives dt=(r0/eta)c ds. Substitution into eta^2 times the bump gives exactly eta r0 c ds and the displayed translated location.
192|A smooth flat transition with range [0,1] is obtained from standard flat cutoffs; it matches the constant-amplitude segment to all time orders.
193|Time reversal interchanges the flat endpoint values and retains smoothness and the same ramp integral.
194|The ramp is nonnegative and continuous with value one at the right endpoint, so its integral is strictly positive and finite.
195|The original coefficient vanishes throughout each buffer, so c=e and r=r0e there independently of the varying amplitude.
196|Integrating speed eta_i zeta/(r0e) over a ramp of duration T gives eta_i T I_zeta/(r0e). Setting this to L yields the printed duration.
197|Interior travel times are (r0/eta_i) times line integrals of c. Each of two ramps contributes (r0/eta_i)e L/I_zeta, giving exactly B_i.
198|Solving the two equations (r0/eta_i)B_i=tau_i and 2 pi eta_i r0/tau=d gives the two displayed positive formulas; tau_i=tau/4 is fixed.
199|Substitute eta_i^2=tau d B_i/(2 pi tau_i): r0 B_i/eta_i=tau_i. The second normalization substitutes directly to d, with no hidden asymptotic factor.
200|The scalar rectangle rule gives d times the sampled interior masses tending to their planar integrals. Floor and buffer terms are charged separately, leaving a vanishing row error.
201|Take the square root of eta_i^2=(2/pi)dB_i, use the universal coefficient mass bound, and split square roots subadditively. The row error also tends to zero after square root.
202|An unused zero-mass direction can be allotted an idle slot. Every scanned direction with a positive floor has B_i>0 and eta_i,r0 positive, so normalization divides by no zero.
203|On a ramp r eta'=eta_i^2 I_zeta zeta'/L, so it is uniformly bounded. In a row r'=r0 c_s eta_i/(r0 c)=eta_i partial_s log c, yielding both asserted equalities and bounds.
204|All logarithmic-derivative, ramp, geometry, and floor constants are fixed, so the source amplitude bound does not grow as the fine parameter shrinks.
205|For active directions dB_i tends to a positive finite mass, hence eta_i stays between positive constants. Then r0=tau d/(2 pi eta_i) is comparable to H^8, as is r0c; taking the fifth root gives H^{8/5}=o(H).
206|Insert the uniform source-coefficient bounds and r comparable to H^8 into the intrinsic estimate: the two terms are O(H^8) and O(H(1+|log H|)).
207|Integrate the time derivative of eta r U_H on each visit. Both endpoint products vanish; the remaining transport term is +int eta^2 partial_xi U_H. Summing visits gives the displayed divergence with positive sign.
208|The chain rule gives partial_t U_H(x-X)=-eta partial_xi U_H/r. Multiplication by eta r cancels r and yields exactly the printed derivative formula.
209|The four-direction sum is a well-defined symmetric time-independent tensor for a full cycle; each directional contribution is its nonnegative bump-weighted rank-one tensor.
210|The rectangle-rule derivation yields d(||partial_perp a||_1+||a||_1||partial_perp U_H||_1)+H||grad a||_1. Replacing the derivative norm by C/H needs the unprovided fixed-dilation convention for U_H.
211|The following argument is a Banach-valued quadrature derivation; it does not appeal to an unverified sampling theorem.
212|For compact smooth a and the smooth probability bump, the integral defines a Bochner L1_x-valued function of y and all displayed translations are measurable.
213|Differentiate both a and the bump translation. Minkowski/Tonelli gives the sum ||partial_perp a||_1+||a||_1||partial_perp U_H||_1 exactly.
214|For y in a mesh interval, ||F(y)-F(kd)||_1<=int_interval ||F'(z)||_1 dz. Integrating y contributes its length d, proving the per-interval bound.
215|Summing the preceding inequality proves a bound with ||partial_perp U_H||_1. The printed C H^{-1} replacement depends on the missing scale convention identified at S0210.
216|The translation identity a(x-z)-a(x)=-int_0^1 z dot grad a(x-theta z)dtheta gives L1 norm <=|z|||grad a||_1. Integrating a probability bump supported in B_H gives <=H||grad a||_1.
217|The original a is globally compact and smooth, so the rectangle rule has no floor discontinuity; the floor/buffer mass is estimated independently.
218|All these added contributions are nonnegative tensors of norm equal to scalar mass. On ramps int zeta^2<=int zeta, so the normalized buffer mass is <=d e L per ramp, controlled by the chosen floor budget and vanishing endpoint-row error.
219|With a fixed dilated bump, d/H=H and H both tend to zero. Under only support and probability for U_H, the derivative term need not tend to zero, so the statement is conditional on the unstated dilation convention.
221|The cycle-average subtraction has zero integral over a cycle. Applying the explicitly defined Leray projection to its finite bump-translate primitive defines a divergence-free corrector.
222|The definition subtracts one average over the entire interval of length tau, even while only one direction is active; it is not a direction-slot average.
223|Integrating the four sequential slots over the full cycle sums their directional tensors with the common factor 1/tau, so every instant receives the desired full tensor divergence.
224|The projection uses the Newtonian inverse with grad Delta^{-1} div. It acts only on translates of a fixed smooth bump and their finite time integrals in this construction.
225|The following projected-bump calculation supplies the particular Lp bounds, so a full endpoint singular-integral boundedness assertion is unnecessary.
226|G satisfies Delta G=delta_0. Componentwise grad Delta^{-1} div(U_H xi)=(D^2G*U_H)xi, so the displayed profile is exactly the Leray projection.
227|Taking divergence cancels div(U_H xi) against Delta G*div(U_H xi). The subtracted Hessian term is a gradient, whose curl is zero.
228|Moving one derivative to the smooth bump reduces the kernel to grad G, locally integrable like 1/|x|. Repeated derivatives may likewise be placed on the bump, proving spatial smoothness and boundedness on compact sets.
229|For |x| beyond the bump's supporting ball, angular averaging of log|x-y| gives log|x|. Thus the exterior Hessian equals D^2G and the projected field has O(|x|^{-2}) tail.
230|The core is bounded on finite area and int_1^infinity r^{1-2p}dr is finite exactly for p>1; the infinity case is also bounded.
231|If U_H=H^{-2}U_1(x/H), homogeneity gives Z_H=H^{-2}Z_1(x/H) and the norm exponent 2/p-2. The stated assumptions allow thinner bumps, so this scale-uniform conclusion is not established without that family definition.
232|For p>1 the projected profile is in Lp, translations preserve its norm, and the source coefficient is time-integrable; the Bochner/Minkowski inequality applies.
233|The projection bound needed here follows from the explicit core/tail profile and dilation, rather than a general Calderon-Zygmund operator bound. The dilation specification remains the only noted issue.
234|The scalar potential is the gradient component of U_H xi; multiplying by the active source coefficient and translation supplies precisely the required instantaneous potential, with zero in idle periods.
235|By the definition of the Leray projection, (I-P)U=grad Delta^{-1} div U, which equals the printed grad pi_U for each active translate.
236|Differentiate Q=-P primitive(U-avg U). Then partial_t Q+U=avg U+grad(pi_U-avg pi_U), so the negative instantaneous plus positive averaged pressure has the stated sign.
237|Minkowski gives at most C tau B times ||Z_H||_2, ||Z_H||_3/2, or ||grad U_H||_1. The displayed H-powers follow for a fixed dilated bump but are not uniform for every admissible bump family as stated.
238|The pointwise source coefficient bound and probability averaging in time bound the average by the same spatial norm bound; no additional factor proportional to the row count occurs.
239|Curl commutes with projection and is the first derivative of the unprojected bump. The asserted O(H^{-1}) is exactly the derivative scaling missing from the explicit definition of U_H.
240|Only projected-bump Lp norms for p>1 and the direct curl L1 norm are used, so an L1 boundedness theorem for the Leray projection is not invoked.
241|The primitive is zero at the initial endpoint and its integrand has zero cycle integral, so it is also zero at the final endpoint.
242|Continuity and possible jumps in the derivative at full-cycle endpoints are correct. Before spatial mollification, however, a translated C1 dipole is not piecewise C-infinity in time in L2: its third time derivative has a surface measure from the nonzero second-derivative jump of D. Later smoothing repairs the actually used increment.
243|Adding the divergence-free packet and projected corrector preserves divergence zero and gives a locally square-integrable velocity; the stress identity is obtained by direct expansion below.
244|Adding the three equations cancels U, leaves div A_av, and expands every old-new, packet-corrector, and Q-square term exactly once. Subtracting qI from the stress requires subtracting q from pressure, with the printed signs.
245|Since div(qI)=grad q, replacing the intermediate pressure by its value minus q gives exactly the stress with -qI.
246|Insert A_av-qI=-S+(S+A_av-qI). This algebra gives R-S plus the averaging, intrinsic, and explicitly enumerated cross errors without omitted quadratic terms.
247|The full stress and each paired cross sum are symmetric; individual displayed factors u tensor v, u tensor Q, and v tensor Q need not be. Holder gives all four norm inequalities/equalities. The phrase 'all displayed tensors' is therefore ambiguous unless restricted to the stress and paired sums.
248|For a fixed dilated bump, v in L3/2 is O(H^{8/3}) and Q in L2/L3/2 is O(H^5)/O(H^{16/3}); the fixed old L3 norm then makes every displayed cross term small. This uses the unprovided U_H family convention.
249|The triangle inequality bounds the increment's L3/2 norm by the principal O(H^{8/3}) plus projected O(H^{16/3}) terms, conditional on the same fixed-dilation specification.
250|A direction-slot average contains only its rank-one directional tensor, so at those times it does not subtract the full prescribed four-direction stress. The full-cycle definition avoids this mismatch.
252|Convolution of the new fields with a compact even smooth probability mollifier commutes with the linear time/spatial operations and makes their spatial profiles smooth without altering the old field.
253|At fixed positive coarse/fine parameters every radius has a positive minimum; one constant ell smaller than that minimum is available on a complete cycle.
254|Convolving the packet equation, corrector equation and average consistently preserves the source cancellation and averaged-stress identity; it is essential to convolve all five listed fields.
255|Subtract the convolved original quadratic tensor from the new quadratic tensor: partial_t v_ell+div(v_ell tensor v_ell)+grad p_ell=U_ell+div(E_ell+C_ell). The sign and symmetry are correct.
256|The cycle image in L2 is compact, including zero-amplitude resets. Approximation of the identity is uniform on this compact set; product continuity L2 times L2 to L1 gives uniform commutator convergence.
257|Probability convolution contracts all relevant Lp norms and curl variation. Evenness is preserved; mean and first moments are unchanged for a mean-zero input when the mollifier has mass one and zero first moments.
258|A cycle-constant ell makes partial_t(rho_ell*v)=rho_ell*partial_t v, so there is no scale-derivative forcing term.
259|Spatial convolution of the zero field is zero, so both endpoint traces remain zero.
260|Only the new correction is smoothed. Its zero trace at the old partition boundaries leaves the old continuous velocity untouched and creates no jump.
261|This is a definition of the admissible positive-time class; continuity is local in time and global in the stated spatial L3 norm, with no uniform-in-stage claim.
262|Symmetry and local L-infinity-time/L1-space boundedness are explicit admissibility assumptions, sufficient for distributional stress divergence and later testing.
263|A locally finite partition and one-sided continuous L1 extensions are explicit hypotheses; they permit finitely many compact-cell approximations on each patch.
264|The class allows different left/right stress traces; the velocity continuity requirement is not being weakened.
265|Changing stresses at discrete times changes neither their spacetime distribution nor a spatial divergence; separate actual values can therefore obey the desired pointwise bound.
266|The distributional Euler-Reynolds equation is an explicit class requirement, carried through the construction by exact identities and continuous pasting.
267|Every old-velocity use in the repair is an L3-times-L3/2 product estimate, so no old derivative bound is needed.
268|The current-pair and tensor hypotheses are explicit. 'Open patch' does not specify connectedness; the proof later requires a single compact interval inside J containing all the temporal support.
269|With finite one-sided continuous extensions on the locally finite inherited partition and compact temporal support, the stated supremum is finite; it bounds both actual values and all one-sided limits.
270|The local construction gives these conclusions after fixing a dilated bump family and interpreting J as an interval (or repairing components separately). Those conventions are missing as written, so the fully quantified lemma is not yet established literally; all scale exponents, symmetry and algebra were independently reconstructed.
271|The leading amplitude follows only from total coefficient mass and the dipole norms. Support, derivatives, floor reciprocals and patch length enter only the finite parameter thresholds, not this leading universal constant.
272|With finitely many cycles and spatial mollification, translations/rescalings give continuity in all three spaces and zero traces at resets; finitely many added boundaries follow from the finite coarse subdivision.
273|The coarse subdivision includes every inherited boundary inside the compact patch, so no old boundary is removed from the admissible partition.
274|At fixed coarse data the principal radii are comparable to H^8; taking enough cycles makes every radius smaller than any prescribed positive r_star.
275|Continuous zero endpoint velocity traces and spatial-only divergence of piecewise bounded stresses permit pasting; the support/connected-patch issue is isolated at S0278.
276|If delta=0, S(t)=0 in L1 at every time. The zero correction and zero error preserve the old pair and satisfy every budget.
277|The subsequent formulas are restricted to the nonzero case; zero mass was already handled, preventing a zero normalization denominator at lemma level.
278|A compact temporal support in an open interval J fits in a smaller closed interval with interior margin. For an arbitrary disconnected open J this need not exist; the source's word 'patch' has not specified the needed interval hypothesis.
279|Local finiteness of the old partition implies only finitely many boundary points meet any compact interval away from zero.
280|On each closed one-sided piece the compact L1-valued image is uniformly continuous. Choose finitely many small cells, freeze a value, then use symmetric smooth compact L1 approximation. Triangle inequalities give both displayed bounds.
281|The one-sided extension is well-defined by the admissible-class hypothesis and is used separately on adjacent closed cells, avoiding conflict at a shared boundary.
282|Actual boundary stress values are independent of the one-sided traces and affect no time distribution, so they need not match either or both traces.
283|Uniform continuity provides the first epsilon0/2. Density of compact smooth tensors in L1, followed by symmetrization, provides the second; their sum is epsilon0.
284|The original compact interval meets finitely many inherited pieces and each compact piece uses a finite uniform-continuity subdivision, so the number of coarse cells is finite.
285|A finite collection of smooth compact tensors and chosen positive floors has finite support/derivative/parameter maxima, even though these may depend on the coarse data.
286|Only frozen smooth approximants and their derivatives are used; S itself is charged through an L1 discrepancy and is never differentiated.
287|Applying the independently checked four-direction decomposition with S=S_k gives -S_k+q_k I, with nonnegative compact smooth coefficients.
288|Gamma and the finitely many positive floors can be chosen small after their supports are fixed, making their total added mass smaller than any positive budget.
289|Enlarge the longitudinal scanning rectangle around the compact coefficient support. The added end intervals are then regions where the original coefficient is identically zero.
290|Probability of the spatial bump and zeta^2<=zeta bound each buffer's average tensor norm by its normalized scalar added mass, with fixed ramp factors.
291|The error and extra amplitude depend on the added mass rather than rectangle area alone; one can decrease the floor inversely with any fixed area. Log-derivative constants are then fixed before fine scales.
292|This declares the coarse choices fixed before integer cycle counts grow, preventing their constants from varying during the asymptotic step.
293|A positive finite cell length can be divided into any positive integer number of equal complete cycles; no fractional endpoint visit is needed.
294|All three scales are positive; direct substitution defines H and d uniquely from the cell length and its integer count.
295|The chosen sixth root gives tau=H^6 identically, and an equal subdivision into complete cycles puts each coarse endpoint at a complete-cycle endpoint.
296|Each cycle uses the same previously solved time/weight normalization; its slots fit exactly and the raster coefficient weight is d.
297|At fixed positive floors, scalar Riemann sums of the smooth coefficient plus finite rectangle/buffer masses tend to a strictly positive finite planar mass for every active direction.
298|eta_i^2=(2/pi)dB_i therefore stays above a positive constant and below a finite constant for all large counts; the lower bound may depend on the fixed floor.
299|The universal coefficient mass bound gives the first square-root term, and subadditivity of square root splits the remaining added mass and vanishing Riemann-sum error.
300|No derivative, support diameter or cell length enters the coefficient-mass-to-amplitude calculation; only fixed rank-one decomposition and dipole constants enter the leading increment bound.
301|r0=tau d/(2 pi eta_i)=H^8/(2 pi eta_i), and fixed c has positive minimum and finite maximum. Their product gives both comparisons uniformly in large counts.
302|The comparisons legitimately use reciprocal amplitude bounds and min/max c, so coefficient and floor dependence is confined to fine-parameter thresholds.
303|r^{1/5}/H=O(H^{3/5}) tends to zero, and r=O(H^8) tends to zero; both inequalities hold simultaneously for sufficiently large counts.
304|The ramp formula has exact cancellation of r0 and the row formula uses eta_i^2 partial_s log c. eta_i is not literally fixed as counts vary, but its established uniform bound suffices for the asserted uniform source bound.
305|Insert r comparable to H^8, bounded source coefficients, and log r=8 log H+O(1) into the intrinsic error estimate.
306|The formal exponents are 6-1=5 and 6-2/3=16/3. Their validity depends on the fixed-dilation U_H estimates missing from the explicit assumptions.
307|The dipole norm scales as eta r^{1/3}; bounded eta and r=O(H^8) give O(H^{8/3}) independently of bump scaling.
308|The quadrature bound tends to zero for a fixed dilated bump since d/H=H. Without that convention the derivative contribution is not controlled, as noted at S0210.
309|The actual old velocity has finite sup L3 on the compact time interval by continuity. Holder then makes every cross term small provided the conditional Q estimates and principal norm estimates hold.
310|S_k is constant within a coarse cell and only S-S_k is left in the error. No time derivative of a frozen old velocity or stress occurs.
311|After fixing the finite fine construction, a positive fixed smoothing scale can be selected independently on each complete cycle.
312|Each finite cycle has strictly positive radius, and there are finitely many cycles, so their minimum over the compact patch is positive.
313|Uniform compact-image commutator convergence permits a sufficiently small ell. Probability convolution contracts the L2/L3/2 velocity and L1 curl norms, so it spends no amplitude budget.
314|Convolution commutes with time integration and fixed spatial derivatives, so the time-averaged tensor becomes A_av convolved with the same kernel.
315|A_av is a finite sum of time integrals of compact smooth probability-bump tensors and is L1. Approximation of the identity therefore makes its convolution error tend to zero in L1.
316|The construction convolves only newly added fields; the old distributional equation remains unchanged.
317|The exact unsmoothed stress identity plus the new commutator gives R-S_k+E_loc on each cell, with all additional errors explicitly included.
318|Adding the equations cancels the moving source and uses one full-cycle average. Since div(q_k I)=grad q_k, the new pressure is the intermediate pressure minus q_k, as asserted.
319|Defining E_total as the frozen discrepancy plus the local construction error gives an L1 tensor at every nonboundary time inside the cell.
320|Direct substitution gives R-S+(S-S_k+E_loc)=R-S_k+E_loc exactly, with no sign change.
321|One can first allocate epsilon0<=epsilon/2 and require the total of the finitely many local stress errors to be <=epsilon/2 pointwise; each vanishing component can be given a finite share of that budget.
322|The triangle inequality gives ||E_total||_1<=epsilon0+||E_loc||_1<=epsilon on cell interiors; explicit boundary choices later give zero error there.
323|Since zeta>0, choose epsilon0<=min(epsilon/2,(zeta/(3C))^2), making both stress and amplitude constraints compatible.
324|The mass-dependent amplitude slack tends to zero with the finitely many regularization/floor masses, which are chosen before counts grow.
325|At fixed coarse data the row amplitude error and the conditional projected-corrector L2/curl errors tend to zero, permitting the remaining zeta/3 allocation simultaneously.
326|Squaring or concavity proves sqrt(delta+epsilon0)<=sqrt(delta)+sqrt(epsilon0); together with the three allocated slacks this gives C sqrt(delta)+zeta.
327|The principal and conditional corrector L3/2 norms tend to zero, and all radii tend to zero. Thus the same sufficiently large counts work, once the missing fixed-dilation convention is supplied.
328|There are only finitely many coarse cells and finitely many limiting constraints on each. Each has an eventual threshold, so taking a maximum proves compatibility; the proof depends on the conditional U_H scaling estimates.
329|Every packet ends its exit ramp with eta=0, and the projected primitive has zero full-cycle integral. Smoothing preserves both zero endpoint traces.
330|A zero extension is well-defined because [a,b] is compact and the correction has zero endpoint values.
331|The distributional derivative of a piecewise continuous field has no interface delta when its two traces agree; here both traces are zero at the extension endpoints.
332|The temporal support assumption makes S zero outside [a,b]; choosing zero error there returns the old pair exactly outside that interval.
333|There are finitely many listed boundary times in the compact patch. Assigning the zero error and R-S at them preserves symmetry and the desired actual-value identity.
334|The algebra R-S+0 is exact and the error norm is zero at the modified points. A finite-time-point modification changes neither the equation nor one-sided limits.
335|Only spatial divergence is taken of the stress. Temporal jumps in a bounded piecewise stress therefore create no temporal Dirac source; continuous velocity handles the time derivative.
336|Both corrections vanish outside [a,b], whose compact inclusion in J is needed. This is valid for an interval patch, with the disconnected-patch caveat in S0278.
337|D_r belongs to L2 and L3/2; positive-radius scaling and translations are continuous in these spaces. eta tends to zero at every reset, giving continuity despite center/direction jumps there.
338|Young from L2 to L3 uses ||rho_ell||_{6/5}=C ell^{-1/3} in two dimensions; a fixed ell converts L2 continuity to L3 continuity.
339|The projected bump is in all three spaces and its coefficient is bounded on a finite cycle, so its Bochner time primitive is continuous there; endpoint zero permits pasting.
340|Every fixed ell and finite cycle count gives finite L3 norms. These constants may diverge across stages, which the iteration does not need to prevent.
341|Within a cycle the intrinsic coefficients and zero-moment profiles vary continuously, and their flat-zero reset prefactors give matching zero endpoint limits; the anti-divergence estimate makes this global-L1 continuity.
342|On a common compact support ball, ||A(f_t-f_s)||_1<=C R||f_t-f_s||_1 because the difference still has both moment cancellations. This transfers input L1 continuity to output L1 continuity.
343|Translation is strongly continuous in L1 and all finite Lp spaces; positive dilation parameters vary continuously. Finite-radius ranges ensure these operations preserve the asserted continuity.
344|On row interiors/ramp joins the coefficients match smoothly, while at resets eta and its time derivatives are flat zero and r is constant, so eta r' and (eta r)' tend to zero.
345|For continuous L2 fields, product differences are controlled by (||a_t||_2+||a_s||_2)||a_t-a_s||_2; the same reasoning applies to the commutator and all paired quadratic terms.
346|Add and subtract u(s) tensor w(t) and apply Holder to each difference. The old L3 continuity and new L3/2 continuity make both displayed terms vanish.
347|On each inherited/coarse one-sided cell S is L1-continuous and S_k is constant; adding their difference preserves piecewise L1 continuity.
348|The exact equation, symmetric piecewise-L1 stress, local/global velocity continuity, and finite partition properties established above meet every admissible-class item, conditional on the previously isolated construction conventions.
349|Every coarse piece has a finite integer number of cycles and there are finitely many coarse pieces, so no new positive-time accumulation occurs within the patch.
''')

add(r'''
351|These are the exact hypotheses needed for the trace argument: the velocity quadratic tensors are locally uniformly L1 and the stresses globally uniformly L1 on the stated finite horizon.
352|The global L2 bound supplies weak compactness and distributional solenoidality of cluster points; the zero anchor sequence is an explicit additional hypothesis.
353|The scalar pairing with every compact solenoidal test is Lipschitz with zero limit by anchors. Any global-L2 weak cluster point is both divergence-free and curl-free, hence zero; this proves the full weak limit.
354|Testing each Euler-Reynolds equation gives derivative pairing=quadratic contraction minus stress contraction. Subtracting gives exactly the printed signs, and pressure vanishes by div psi=0.
355|The compact support and bounded gradient of psi bound the convection term by the two local kinetic energies and the stress term by the two global L1 stress bounds.
356|A scalar distribution with bounded derivative has a Lipschitz representative. The given velocity continuity identifies it across boundaries. At anchors it is zero, so its limit as t decreases to zero must be zero.
357|For any sequence of times tending to zero, uniform boundedness in the Hilbert space L2 gives a weakly convergent subsequence by weak compactness and separability/reflexivity.
358|Weak L2 convergence preserves div W=0 and the tested zero pairings. Taking psi=grad-perp phi gives the distributional curl of the cluster point equal to zero, with the irrelevant test sign accounted for.
359|Fourier transformation gives xi dot W-hat=0 and xi-perp dot W-hat=0. For xi nonzero these two directions span R2, and an L2 Fourier transform cannot be supported at the measure-zero point xi=0 unless zero.
360|If weak convergence failed for any fixed L2 test, a sequence with a nonzero pairing limit would have a weak cluster point contradicting its just-proved vanishing. Thus the entire weak limit is zero.
361|The global iteration is independently valid provided the local repair's intended fixed-dilation convention is made explicit. The source-level local lemma remains conditional, so this proposition is not unconditionally verified as written.
362|Choose a nonnegative compact bump positive on an interval whose dyadic dilates cover positive time. At each t the denominator is a finite positive sum, so the smooth weights and intervals are well-defined.
363|On any compact subset of positive time only finitely many dyadic intervals occur; positivity of the denominator gives sum chi_j=1 and compact support inside I_j follows from the original bump support.
364|The integer residues modulo three partition all patches into three colors, so each patch is processed exactly once per stage.
365|I_j ends at 2^{j+1}=2 times 2^j and I_{j+3} begins at 2^{j+2}=4 times 2^j. Thus 3 times 2^j lies in their gap, and same-color intervals are disjoint.
366|For each fixed residue class, 2^j tends to zero as j tends to minus infinity, so its explicit gap sequence tends to zero.
367|The dyadic intervals actually have at most two interior overlaps, and three is a valid uniform upper bound, including harmless boundary counting.
368|The seed estimate bounds stress on every finite horizon including the limit t=0. An increasing smooth function above a staircase of these finite suprema gives the required majorant, enlarged to at least one.
369|The seed's uniform L2, L1 and bounded-background estimates give a finite stress supremum near zero and on every finite horizon, exactly what constructing the majorant requires.
370|delta_0=1 initializes the majorant bound, and delta_{q+1}=delta_q/16 fixes a positive summable stress schedule with square roots 4^{-q}.
371|Multiplying the old piecewise-L1 stress by smooth compactly supported chi_j gives prescribed pieces summing pointwise to R^(q); freezing them prevents later colors from changing what must be removed.
372|Theta is finite on the bounded interval I_j and at least one; therefore 1<=m_j<=M_j<infinity, with m_j<=Theta(t)<=M_j for t in I_j.
373|The prescribed S_qj has norm <=delta_q M_j, compact time support in the interval I_j, symmetry and the inherited one-sided regularity. Positive budgets meet LER's inputs; this application is conditional on the local lemma's unresolved bump-family specification.
374|Processing finitely many colors sequentially allows each old-new stress to be estimated against the current field, retaining every already-added correction in its background.
375|Within a color, at a given time at most one patch correction is nonzero. Thus products of distinct same-color corrections vanish, and local finiteness gives valid distributional pasting.
376|The local lemma accepts a prescribed S independent of the current stress, so subsequent colors can remove the original frozen S_qj while including all previous colors in the current velocity.
377|This is precisely the independent-prescribed-piece form of LER; an estimate formulated only with S=current R would not give the printed stage cancellation.
378|A positive compact interval meets finitely many dyadic patches, each with finitely many newly introduced boundaries. A finite union is locally finite at that stage.
379|Conditional on LER, finite local sums of continuous velocities and piecewise-L1 stresses retain every admissibility condition on positive compact time intervals.
380|Sum the individual updates over colors: the frozen S_qj sum to R^(q), so their removal leaves sum E_qj, while velocities add all w_qj. The sums are locally finite and pointwise have bounded overlap.
381|The supports lie inside I_j, with overlap at most N, and by definition m_j is no greater than Theta(t) for every active patch.
382|Triangle inequality gives sum_active delta_{q+1}m_j/N <=delta_{q+1}Theta(t). The same reasoning applies at chosen actual boundary times.
383|Inductively summing only processed updates gives the displayed remaining old stress. Since 0<=sum_processed chi_j<=1, its norm is <=delta_q Theta; error overlap adds <=delta_{q+1}Theta.
384|If t in I_j and t<=T, then 2^{j-1}<T and the upper endpoint 2^{j+1}<4T. LER gives each increment <=C sqrt(delta_q Theta(4T))+sqrt(delta_q)/N; at most N summands yield exactly the bracket.
385|The square-root schedule is 4^{-q}, so its series is finite. The same overlap and triangle bounds apply to any partial set of colors.
386|Summing at most N budgets kappa_qj<=2^{-q}/N gives ||w_q||_3/2<=2^{-q}, a summable sequence; locally this norm also closes every old-new cross estimate.
387|The construction requires only a finite old L3 norm at each fixed stage and patch; it does not use or derive a uniform L3 limit estimate.
388|At every same-color gap time no patch of that color is active, so its whole correction is exactly zero; the explicit gaps accumulate at zero.
389|The seed has uniform local energy and stress near zero. The finite sum of the stagewise bounded L2 corrections preserves local energy, and the partial-stage stress estimate gives a uniform stress bound; the color correction obeys the same global L2 estimate.
390|For each color, both pairs meet every anchor-lemma hypothesis: positive-time continuous local L2, uniform local energies and L1 stresses near zero, bounded global L2 difference, and a zero gap sequence. The lemma yields zero weak initial trace.
391|There are exactly the three residue classes 0,1,2; summing three weakly zero traces remains weakly zero.
392|Start from the seed's exact initial value. At every stage each color adds a weakly zero-trace correction, so induction preserves that value without a small-energy hypothesis.
393|The stage bound is uniform for all t in (0,T] and its right side is a constant times 4^{-q}; the Banach-valued Weierstrass argument gives uniform global-L2 convergence of the correction series.
394|On each positive compact interval, restrict global-L2 errors to a spatial ball. Uniform convergence of continuous local-L2 maps then gives a continuous local-L2 limit.
395|For any L2 test, a sufficiently far tail has uniformly small pairing by Cauchy-Schwarz. The finite initial sum has zero weak trace, so the full correction has zero weak trace.
396|Add the seed's strong local trace to the weakly zero correction. Positive-time strong local continuity and weak continuity at zero give the exact C_w class and prescribed initial value, conditional on existence of the repaired stages.
397|The curl L1 bounds are absolutely summable at every fixed positive time. Pairing the L1 curl sum and the L2 velocity sum against compact derivatives identifies their distributional relation without an a.e.-time exception.
398|Take the triangle inequality at each time, then the uniform supremum. The seed curl bound is finite and sum_q 4^{-q}=4/3, so the displayed finite bound follows.
399|At t=0 the curl is the original finite measure; taking the maximum with, or adding, its total variation gives the horizon bound including zero.
400|Divergence is continuous under distributional convergence. Every finite-stage velocity is solenoidal, hence so is the limit at every fixed time and in spacetime.
401|On a finite positive-time cylinder, uniform L2 convergence and uniform local L2 bounds imply product convergence in L1 by ||a tensor a-b tensor b||_1<=(||a||_2+||b||_2)||a-b||_2. The stress bound tends uniformly to zero on its time support.
402|The finite-stage solenoidal weak identities pass to the limit by the preceding linear, quadratic and stress convergence. This proves positive-time Euler conditional on the repaired stage construction.
403|A smooth cutoff vanishing up to epsilon and equal to one after 2epsilon keeps the test supported away from zero while retaining compactness and divergence freedom.
404|The omitted convection integral has time length O(epsilon) and is bounded by the fixed test-gradient norm times the uniform local kinetic energy, so it tends to zero.
405|The cutoff derivative has bounded L1 time norm and total mass one; weak local-L2 continuity makes the fixed initial test pairing converge. The smooth test difference is O(epsilon) in L2, producing O(epsilon) error under the uniform local L2 bound.
406|Combining the cutoff limit, linear test term, convection limit and positive initial boundary term gives exactly the target's initial-value weak identity, conditional only on the construction already isolated.
407|These are explicit hypotheses of a normalization lemma: a C0 background plus a global-L2 perturbation, solenoidality, and a finite distributional curl.
408|Subtracting the canonical convolution gives a distributionally harmonic field. Its mean-value bound decays as the ball grows by the C0 and L2 hypotheses and the finite-measure kernel bound, forcing equality.
409|K*mu is locally L1 by the uniform kernel integral bound. Div h=curl h=0 implies Delta h=0 componentwise. Weyl's lemma applies to this distribution and yields a smooth harmonic representative.
410|Apply the mean-value formula to each harmonic component and the triangle inequality. Cauchy-Schwarz bounds the v average by ||v||_2/|B_R|^{1/2}=C||v||_2/R.
411|For any center and shift, integrating 1/|z-y| over a radius-R ball is <=C R. Tonelli against |mu| and division by area give C||mu||_M/R.
412|Given epsilon, outside a fixed compact set |U|<=epsilon. Its contribution to any large-ball average is <=epsilon; the fixed compact contribution tends to zero after division by pi R^2.
413|Every right-side term in the mean-value estimate tends to zero for a fixed x, so |h(x)|=0. The smooth harmonic representative vanishes identically.
414|The final theorem follows from the independently reconstructed iteration and normalization if the local construction's missing bump-family convention is supplied. As written, that dependency remains conditional; no counterexample to the target theorem was established.
415|The iteration provides exactly the listed trace, initial weak identity, every-time curl and finite-horizon variation, but its proof inherits the unresolved literal U_H scale specification from LER.
416|V0 is C0 by the initial decomposition; V(t)-V0 is global L2, W(t) is L2, and the correction series converges there. Thus the canonical lemma's hypotheses match at each positive time; zero uses the prescribed datum directly.
417|The normalization lemma is pointwise in time and needs no exceptional-time selection, so the canonical identity follows for every constructed time, conditional on the global construction.
418|The dyadic iteration is constructed on the full positive half-line and uses only finite-horizon estimates for convergence, so no finite-horizon solution matching or restart is needed.
''')

# These are literal-source issues. Later independent derivations are recorded
# without silently editing the frozen manuscript or converting an ambiguity
# into an alleged counterexample to the intended existence construction.
statuses={
    49:'AMBIGUOUS',141:'AMBIGUOUS',158:'UNJUSTIFIED',159:'UNJUSTIFIED',
    164:'AMBIGUOUS',188:'AMBIGUOUS',210:'UNJUSTIFIED',215:'UNJUSTIFIED',
    219:'UNJUSTIFIED',231:'UNJUSTIFIED',237:'UNJUSTIFIED',239:'UNJUSTIFIED',
    242:'AMBIGUOUS',247:'AMBIGUOUS',248:'UNJUSTIFIED',249:'UNJUSTIFIED',
    268:'AMBIGUOUS',270:'UNJUSTIFIED',275:'AMBIGUOUS',278:'AMBIGUOUS',
    306:'UNJUSTIFIED',308:'UNJUSTIFIED',309:'UNJUSTIFIED',325:'UNJUSTIFIED',
    327:'UNJUSTIFIED',328:'UNJUSTIFIED',336:'AMBIGUOUS',348:'UNJUSTIFIED',
    361:'UNJUSTIFIED',373:'UNJUSTIFIED',379:'UNJUSTIFIED',384:'UNJUSTIFIED',
    396:'UNJUSTIFIED',397:'UNJUSTIFIED',398:'UNJUSTIFIED',401:'UNJUSTIFIED',
    402:'UNJUSTIFIED',406:'UNJUSTIFIED',414:'UNJUSTIFIED',415:'UNJUSTIFIED',
    416:'UNJUSTIFIED',417:'UNJUSTIFIED',
}

# Child-level status exceptions retain verified independent subclaims inside
# an aggregate ambiguous/unjustified container.
child_status={
    'S0049.C01':'VERIFIED','S0049.C02':'VERIFIED','S0049.C03':'VERIFIED',
    'S0141.C02':'VERIFIED','S0141.C03':'VERIFIED','S0141.C04':'VERIFIED','S0141.C05':'VERIFIED','S0141.C06':'VERIFIED',
    'S0158.C01':'VERIFIED','S0158.C02':'VERIFIED','S0158.C03':'VERIFIED',
    'S0159.C01':'VERIFIED','S0159.C02':'VERIFIED',
    'S0164.C01':'VERIFIED','S0164.C02':'VERIFIED','S0164.C03':'VERIFIED','S0164.C04':'VERIFIED','S0164.C05':'VERIFIED','S0164.C06':'VERIFIED',
    'S0242.C01':'VERIFIED','S0242.C02':'VERIFIED','S0242.C03':'VERIFIED','S0242.C06':'VERIFIED','S0242.C07':'VERIFIED',
    'S0247.C03':'VERIFIED','S0247.C04':'VERIFIED','S0247.C05':'VERIFIED','S0247.C06':'VERIFIED','S0247.C07':'VERIFIED',
    'S0268.C02':'VERIFIED','S0268.C03':'VERIFIED','S0268.C04':'VERIFIED','S0268.C05':'VERIFIED',
    'S0270.C02':'VERIFIED','S0270.C05':'VERIFIED','S0270.C06':'VERIFIED',
    'S0306.C01':'UNJUSTIFIED','S0306.C02':'UNJUSTIFIED','S0306.C03':'UNJUSTIFIED',
    'S0309.C02':'VERIFIED','S0309.C03':'VERIFIED',
    'S0327.C02':'VERIFIED',
    'S0384.C01':'VERIFIED','S0384.C02':'VERIFIED','S0384.C03':'VERIFIED',
    'S0401.C01':'VERIFIED',
    'S0416.C01':'VERIFIED','S0416.C04':'VERIFIED',
}
supplements={
  158:[{'description':'Temporal regularity of r, eta and the trajectory sufficient for the derivative and product identities in S0159.',
        'status':'UNJUSTIFIED','rationale':'Positivity alone does not give derivatives or define multiplication of their distributional jumps by a simultaneously discontinuous profile. C1 or piecewise smooth positive parameters suffice and are available in the later visits.'}],
  164:[{'description':'Cross-scale family definition for U_H, in particular fixed probability-profile dilation and constants uniform as H tends to zero.',
        'status':'AMBIGUOUS','rationale':'Support in B_H and probability do not imply ||grad U_H||_1=O(H^{-1}) or ||P(U_H xi)||_p=O(H^{2/p-2}). The later word scaling suggests, but does not define, U_H=H^{-2}U_1(x/H).'}],
}

records=[]
allowed={'VERIFIED','ERROR','UNJUSTIFIED','AMBIGUOUS','DEPENDS ON EARLIER ERROR','NOT MATHEMATICAL','NOT VERIFIABLE FROM PROVIDED MATERIAL'}
for s in inv['containers']:
    n=int(s['id'][1:])
    if s['mathematical']:
        assert n in notes, ('missing affirmative reconstruction',s['id'])
        rationale=notes[n]
        status=statuses.get(n,'VERIFIED')
    else:
        rationale='Structural/layout/title material only; inspected against the frozen source and contains no mathematical assertion or meaningful notation beyond the separately inventoried content.'
        status='NOT MATHEMATICAL'
    children=[]
    for c in s['nested_checks']:
        cs=child_status.get(c['id'],status)
        cr=rationale
        if not c['text'].strip() or c['text'].strip()=='\\end{cases}':
            cs='NOT MATHEMATICAL'
            cr='Empty alignment/cases structural separator; no additional mathematical assertion. The enclosing branch and endpoint conditions were checked at their substantive children.'
        children.append({'id':c['id'],'status':cs,'rationale':cr})
    records.append({'id':s['id'],'source_sha256':s['sha256'],'filename':s['filename'],
                    'source_lines':[s['line_start'],s['line_end']],'source_anchor':s['text'],
                    'mode':s['mode'],'mathematical':s['mathematical'],'status':status,'rationale':rationale,
                    'nested_checks':children,'supplemental_checks':supplements.get(n,[])})
assert len(records)==419
assert sum(len(r['nested_checks']) for r in records)==834
assert all(r['status'] in allowed for r in records)
assert all(c['status'] in allowed for r in records for c in r['nested_checks'])
assert [r['id'] for r in records]==[s['id'] for s in inv['containers']]
counts=collections.Counter(r['status'] for r in records)
formula_inventory=json.loads((BASE/'audit_formulas.json').read_text())
source_bytes=(BASE/'proof.tex').read_bytes()
for formula in formula_inventory['formulas']:
    raw=source_bytes[formula['byte_start']:formula['byte_end_exclusive']]
    assert raw.decode()==formula['text'],formula['id']
    assert hashlib.sha256(raw).hexdigest()==formula['sha256'],formula['id']
    parent=next(s for s in inv['containers'] if s['id']==formula['container_id'])
    assert parent['byte_start']<=formula['byte_start']<formula['byte_end_exclusive']<=parent['byte_end_exclusive']
out={
  'metadata':{
    'pass':'B','method':'Independent re-derivation from frozen source and stated hypotheses, followed by source-ordered comparison with every parent and shared child.',
    'source_file':'proof.tex','source_sha256':source_hash,
    'inventory_sha256':hashlib.sha256((BASE/'audit_inventory.json').read_bytes()).hexdigest(),
    'source_lines_examined':[1,948],'containers_examined':419,'shared_nested_checks_examined':834,
    'supplemental_checks_proposed':2,'formula_occurrences_checked':571,'inline_occurrences_checked':512,'display_occurrences_checked':59,
    'algebra_bearing_containers_checked':106,'external_theorem_containers_checked':22,'proof_environments_checked':8,
    'overall':'INCONCLUSIVE','overall_explanation':'No fatal obstruction to the intended construction was established. Literal source omissions/ambiguities, especially the cross-scale bump family, prevent unconditional verification as written; all downstream conditional derivations are recorded.',
    'status_counts':dict(counts),'uncovered_containers':0,'missing_shared_child_verdicts':0,
    'independence_provenance':{
      'initial_inputs':'Only the audit prompt, exact target, frozen proof, neutral inventory, and notation inventory were opened before independent reconstruction.',
      'primary_source_retrieval':'Independently retrieved Springer original HTML article before 2026-10-08T11:23:29Z and checked kernel estimates, divergence, absent boundary, datum class, weak/Lagrangian definition, and theorem conclusions. This check and the background reconstruction were reported to root before the accidental exposure. The HTML omitted the operator-domain/codomain display as an image; its full formula was not independently inspected before exposure.',
      'accidental_exposure':'A list_agents call solely to inspect available delegation slots automatically displayed the completed audit_c/external_theorem_c summary after B had reported its independently performed HTML theorem/background check. No other pass file was read. Root was immediately notified; no further list_agents calls were made.',
      'post_exposure_primary_recheck':'After exposure, B opened the original PDF and checked the previously image-only operator mapping in Assumption 3.1 (printed page 14, PDF index 13). This narrow mapping-hypothesis check is explicitly not claimed to have clean pre-exposure independence. The manuscript reconstruction and remaining ledger were not based on another pass.',
      'source_mutations':'None. Neither frozen proof nor inventory was modified.'
    },
    'primary_sources':[{'url':'https://link.springer.com/article/10.1007/s00526-024-02750-4','retrieval_refs':['turn80view0','turn81view0','turn81view1','turn81view2','turn81view3','turn87view0'],'used_for':'Original Theorem 3.3, Assumptions 2.1 and 3.1, Definition 3.2 and log-Lipschitz estimate; HTML mapping image not inspected before exposure.'},
                       {'url':'https://link.springer.com/content/pdf/10.1007/s00526-024-02750-4.pdf','retrieval_refs':['turn102view0','turn103view0'],'used_for':'Post-exposure primary recheck of the operator-domain/codomain display in Assumption 3.1; explicitly separate provenance.'}],
    'computations':[{'method':'Python fractions.Fraction exact rational arithmetic','input':'J1 partial sums with terms (-1)^k(z/2)^(2k+1)/(k!(k+1)!), (z,n)=(3,3),(4,4)','result':'669/2048=(3/2)(223/1024) and -2/45 exactly.'},
                    {'method':'Attempted symbolic checks','result':'SymPy unavailable in both system and primary-runtime Python; no symbolic-computation verification is claimed. Tensor, exterior-gradient, timing, and derivative identities were instead expanded by hand in this pass.'}]
  },
  'records':records
}
(BASE/'pass_b.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'containers':len(records),'shared_nested':sum(len(r['nested_checks']) for r in records),'counts':dict(counts)},indent=2))
