# Fresh audit of E1 and Lemma 1.2

**Verdict: PASS for the audited interface.** The cited existence result applies to the actual background datum, and the manuscript's upgrades to every-time canonical velocity, strong continuity, global relative $L^2$ control, $C_tL^3$, and the velocity Euler identity are valid. This is a narrow conclusion about E1 and Lemma 1.2, not a verdict on the later construction or main theorem.

## Scope and independence

- Frozen source: `audit_v1/proof.tex`, SHA-256 `b6741b471ba2f128b147f5a5c05fea0afe639c2c3a535b99a5afaf03ea6d4a43`, independently checked.
- Audited source containers: S0053–S0090, lines 105–189, bytes [4262, 8697). The datum definition in S0036–S0039 was also checked.
- Permitted neutral inventory supplied container identifiers and exact source spans. No route, checkpoint, earlier audit, other pass output, or dependency manifest was consulted. No agent-status listing was used.
- The original published primary article was read directly, including Assumptions 2.1 and 3.1, Definition 3.2, Theorem 3.3 and estimates (3.4)–(3.7), and the modulus (1.24).

## Primary-source verification and hypothesis map

Primary source: G. Crippa and G. Stefani, *An elementary proof of existence and uniqueness for the Euler flow in localized Yudovich spaces*, Calculus of Variations and Partial Differential Equations **63**, 168 (2024), published 5 July 2024. [Published article and DOI](https://link.springer.com/article/10.1007/s00526-024-02750-4).

Theorem 3.3 gives a global Lagrangian solution for $L^1\cap L^\infty$ initial vorticity under Assumptions 2.1/3.1. Definition 3.2 supplies the canonical integral velocity, the initial-value transport identity, and a pushforward representation almost everywhere in time. Estimates (3.4)–(3.7) give the needed finite-horizon bounds and log-Lipschitz modulus. Neither positivity, compact support, zero circulation, nor finite velocity energy appears among these hypotheses. The following column of checks is my verification for this manuscript.

| Source requirement or output | Manuscript location | Independent verification |
|---|---|---|
| Whole-plane setting | S0055; S0060 | $\Omega$ is $\mathbb R^2$; its boundary condition is empty. The article expressly includes this case. |
| Initial datum $L^1\cap L^\infty$ | S0036–S0039; S0062 | $\nu_0=a*\mu$, so $\|\nu_0\|_1\le\|a\|_1\|\mu\|_{\mathcal M}=M$ and $\|\nu_0\|_\infty\le\|a\|_\infty M$. Also $\|\nu_0\|_2^2\le\|\nu_0\|_1\|\nu_0\|_\infty$. No sign is used. |
| Kernel size, Assumption 2.1 (2.1) | S0058, lines 116–118 | $k(x,z)=K(x-z)$, with $C_1=1/(2\pi)$. |
| Kernel difference, Assumption 2.1 (2.2) | S0058 | Inversion gives $\left\lvert z/\lvert z\rvert^2-w/\lvert w\rvert^2\right\rvert=\lvert z-w\rvert/(\lvert z\rvert\lvert w\rvert)$. Rotation preserves its norm; hence $C_2=1/(2\pi)$. |
| Bounded divergence, Assumption 3.1 (3.1), with $p=\infty$ | S0058 | $\operatorname{div}K=0$ distributionally: away from the origin this is direct, and the small-circle normal flux is zero. Thus $\operatorname{div}(K*\omega)=0$, which satisfies the bound for any allowed positive $C_3$. |
| No-flow condition (3.2) | S0055/S0058 | Vacuous on the plane. |
| Canonical velocity and weak initial transport law | S0055–S0056; S0062 | Exactly the data from Definition 3.2 needed in the reconstruction below. |
| Lagrangian pushforward almost everywhere in time | S0056; S0071 | Used only after constructing the unique measure-preserving flow. |
| Uniform finite-horizon boundedness and log-Lipschitz control | S0055; S0065 | Theorem 3.3, (3.4)–(3.7). The Osgood integral diverges because the small-distance modulus is $r(1-\log r)$. |

The phrase “nonincreasing $L^1$ norm” in S0055 is harmless in this specialization. The displayed estimate (3.4) is a bound by the initial norm; exact conservation at every time follows below from incompressibility and the Lagrangian representation. No stronger conservation assertion is silently imported from the general-kernel theorem.

## Reconstruction of every-time representatives

**S0064–S0069, lines 135–145: PASS.** On a finite horizon, choose a common null set of times outside which the bounded continuous velocity has the stated spatial modulus and is divergence-free. Values on this null set may be set to zero; this changes neither the distributional equation nor any time-integral flow trajectory. Let its bound be $B_T$ and its Osgood modulus be $L_T\ell$.

The integral ODE has a unique global flow on the horizon: bounded speed prevents escape, and Osgood's inequality gives uniqueness and continuous dependence. Solving backwards from any terminal point gives the inverse map. Both maps are continuous in their time and space variables, and displacement is at most $B_TT$.

Take a compactly supported smooth nonnegative spatial approximate identity and set $V_\varepsilon=\rho_\varepsilon*V$. Then

\[
 \|V_\varepsilon-V\|_{L^\infty_{t,x}}
 \le L_T\sup_{|h|\le\varepsilon}\ell(|h|)\longrightarrow0,
 \qquad \operatorname{div}V_\varepsilon=0.
\]

Here the time supremum can first be essential; the chosen null-time representative removes any pointwise ambiguity. The mollified fields are smooth in space and measurable in time. Their flows are spatially smooth, absolutely continuous in time, and the Jacobian equation applies. Consequently each preserves Lebesgue measure. The common Osgood modulus and the displayed convergence imply convergence of the forward and backward flows uniformly on compact time-space sets, by the integral Osgood stability estimate.

For $g\in C_c(\mathbb R^2)$, the functions $g(X_t^\varepsilon(x))$ vanish outside one fixed bounded set, since all displacements are bounded. Dominated convergence gives

\[
 \int g(X_t(x))\,dx=\lim_{\varepsilon\to0}\int g(X_t^\varepsilon(x))\,dx
 =\int g(x)\,dx.
\]

This holds for every $t$, extends to measurable tests, and proves measure preservation of the limiting homeomorphism and its inverse. The wording “smooth flows” in S0067 needs only spatial smoothness; no unjustified time regularity is used.

**S0070–S0072, lines 145–151: PASS.** Define $\nu(t)=\nu_0\circ X_t^{-1}$ for all $t\ge0$. Uniqueness of trajectories identifies this flow with the source flow. Measure preservation turns its signed pushforward density into exactly this composition. Thus it agrees with the source vorticity for almost every time and

\[
 \|\nu(t)\|_p=\|\nu_0\|_p \qquad(p=1,2,\infty)
\]

at every time. The assertion for signed vorticity follows from composition of absolute values; positivity is unnecessary.

For $p=1,2$, approximate $\nu_0$ by $g\in C_c^\infty$ in $L^p$. The composition error has the same $L^p$ norm at all times. Continuity of the inverse flow, together with bounded displacement, gives $g\circ X_t^{-1}\to g\circ X_s^{-1}$ uniformly on a fixed bounded support as $t\to s$. The three-term approximation inequality proves $\nu\in C([0,T];L^1\cap L^2)$, including $t=0$.

## Canonical velocity and its finite-horizon norms

**S0073–S0078, lines 151–164: PASS.** Define $V(t)=K*\nu(t)$ at every time. This is the original velocity almost everywhere in time, hence preserves the source transport equation. For any $f\in L^1\cap L^\infty$, direct integration of the kernel gives

\[
 \|K*f\|_\infty\le r\|f\|_\infty+(2\pi r)^{-1}\|f\|_1,\qquad r>0.
\]

For $f=\nu(t)-\nu(s)$, its first term is at most $2r\|\nu_0\|_\infty$. Choose $r$ small, then use $C_tL^1$ in the second term. Therefore $V\in C([0,T];L^\infty)$ and $V(0)=K*\nu_0=V_0$. In particular the local $L^2$ initial trace is strong. The same estimate bounds $B_T=\sup_t\|V(t)\|_\infty$, and

\[
 \|V(t)\nu(t)\|_p\le B_T\|\nu_0\|_p\quad (p=1,2).
\]

Indeed $V\nu\in C_tL^1\cap C_tL^2$, so its subsequent time integrals are unambiguous Bochner integrals. As an optional consequence, every (V$t$) belongs to $C_0(\mathbb R^2)$: truncate vorticity in space and apply the same near–far bound to the $L^1$-small tail with its uniformly bounded $L^\infty$ norm.

**S0079–S0082, lines 164–173: PASS.** For a finite signed measure of mass norm $M>0$ and $\lambda>0$, take $r=M/(\pi\lambda)$. The far convolution is bounded by $M/(2\pi r)=\lambda/2$. The near convolution has $L^1$ norm at most $Mr$. Hence

\[
 |\{|K*\mu|>\lambda\}|\le\frac{2Mr}{\lambda}
 =\frac{2M^2}{\pi\lambda^2}.
\]

The zero-measure case is immediate and does not require choosing $r=0$. Layer cake, with the independent finite bound $B=\|V(t)\|_\infty$, gives

\[
 \|V(t)\|_3^3
 =3\int_0^B\lambda^2|\{|V(t)|>\lambda\}|\,d\lambda
 \le C\|\nu_0\|_1^2 B.
\]

This argument does not assume finite kinetic energy, finite spatial moments, or compact support.

## Global relative $L^2$: the low-frequency issue checked explicitly

**S0083–S0086, lines 173–182, and S0061, lines 129–132: PASS.** The weak transport equation, its initial trace, and $C_tL^1$ imply for every $t$

\[
 \nu(t)-\nu_0=-\operatorname{div}F_t,
 \qquad F_t=\int_0^t V(s)\nu(s)\,ds\in L^1\cap L^2.
\]

One can first integrate scalar compact-test pairings; continuity then removes any exceptional time. For the manuscript's Fourier convention, the operator $T=-K*\operatorname{div}$ has symbol

\[
 \widehat{TF}(\xi)
 =-\frac{\xi^\perp\,\xi^{\mathsf T}}{|\xi|^2}\widehat F(\xi),
 \qquad\xi\ne0.
\]

Its Euclidean operator norm is one. It follows by Plancherel that $T:L^2(\mathbb R^2;\mathbb R^2)\to L^2(\mathbb R^2;\mathbb R^2)$ has norm at most one.

There is no hidden polynomial, harmonic, or zero-frequency correction in identifying the actual velocities with this multiplier. Each canonical convolution has distributional Fourier transform $m(\xi)\widehat\nu(\xi)$, where $m=-i\xi^\perp/|\xi|^2$ is locally integrable. Since $F_t\in L^1$, its transform is bounded and

\[
 \widehat{\nu(t)-\nu_0}=-i\xi\cdot\widehat F_t
\]

is an equality of continuous functions. Multiplication by (m) makes the factor $\xi$ cancel its singularity. The resulting bounded-at-zero function is exactly the $L^2$ multiplier above; no distribution supported at zero is introduced. Thus

\[
 V(t)-V_0=TF_t,
 \qquad
 \|V(t)-V_0\|_2
 \le\int_0^t\|V(s)\nu(s)\|_2\,ds
 \le tB_T\|\nu_0\|_2.
\]

The same derivation on ([s,t]) gives

\[
 \|V(t)-V(s)\|_2\le B_T\|\nu_0\|_2|t-s|.
\]

Consequently $t\mapsto V(t)-V_0$ is globally $L^2$-valued and Lipschitz on each finite horizon. This conclusion concerns the difference; $V_0$ and (V$t$) may each have infinite global $L^2$ norm. The flux representation, not merely equality of total circulations, supplies the needed low-frequency cancellation.

Differentiating this $L^2$ identity yields $\partial_tV=T(V\nu)\in L^\infty_tL^2$. Separately, the multiplier of $\nabla K*\nu$ has bounded matrix norm; indeed its Frobenius norm is one away from zero. Therefore $\|\nabla V(t)\|_2=\|\nu(t)\|_2$, with the stated Fourier normalization, and the other assertion in S0085 also follows without absolute finite energy.

## $C_tL^3$, pressure, and initial-value velocity Euler identity

**S0087–S0088, lines 182–185: PASS.** Both velocities are individually in $L^3$ by the preceding weak-$L^2$ calculation. Their difference is in $L^2\cap L^\infty$, with $L^\infty$ norm at most $2B_T$. Hence

\[
 \|V(t)-V(s)\|_3^3
 \le\|V(t)-V(s)\|_\infty\|V(t)-V(s)\|_2^2
 \le2B_T^3\|\nu_0\|_2^2|t-s|^2.
\]

This proves the asserted strong continuity, including at zero; interpolation has been applied to a global finite-$L^2$ difference, never to either infinite-energy velocity separately.

**S0089–S0090, lines 185–189: PASS.** Put $H=\partial_tV+(V\cdot\nabla)V$. The preceding estimates imply $H\in L^\infty([0,T];L^2)$. With $V^\perp=(-V_2,V_1)$, the two-dimensional identity

\[
 (V\cdot\nabla)V=\nu V^\perp+\nabla\bigl(|V|^2/2\bigr)
\]

is valid distributionally for the present $V\in W^{1,2}_{\rm loc}\cap L^\infty$. It follows either by the weak product rule or by spatial mollification and strong local $W^{1,2}$ convergence. Taking curl gives

\[
 \operatorname{curl}H=\partial_t\nu+\operatorname{div}(V\nu)=0.
\]

A curl-free distributional vector field on the simply connected plane has a scalar potential. This can be made time-measurable by taking local $W^{1,2}$ potentials normalized to mean zero on one fixed ball and gluing them on nested balls. Thus there is a spacetime distribution $p_V$ with $\nabla p_V=-H$. This specifies the Euler pressure sign implicit in S0089. Since $\operatorname{div}V=0$, the convective term equals $\operatorname{div}(V\otimes V)$.

For a smooth compactly supported divergence-free test $\varphi$ on $[0,T)\times\mathbb R^2$, integrate on $(\varepsilon,T)$. The pressure pairing vanishes. Letting $\varepsilon\downarrow0$ is legitimate by the strong local $L^2$ trace; the nonlinear term is locally integrable because $V$ is bounded. One obtains exactly

\[
 \int_0^T\!\!\int_{\mathbb R^2}
 \bigl(V\cdot\partial_t\varphi+(V\otimes V):\nabla\varphi\bigr)\,dx\,dt
 +\int_{\mathbb R^2}V_0\cdot\varphi(0)\,dx=0.
\]

No evolution theorem for smooth velocity, global-energy identity, or unstated pressure integrability is needed.

## Edge cases and final disposition

- **Signed data:** all estimates use absolute values, total variation, or measure-preserving composition; cancellation is never treated as positivity.
- **Nonzero circulation / infinite energy:** the individual velocities need only be bounded and weak $L^2$, hence $L^3$; the differentiated multiplier controls the finite-energy difference.
- **Noncompact support / absence of moments:** bounded displacement handles the compact-test argument, and $L^1$ approximation handles continuity. The Fourier flux argument uses $F_t\in L^1\cap L^2$, not a spatial moment of $\nu_0$.
- **Exceptional times:** the source solution is first used almost everywhere; the flow composition and continuous canonical convolution then define all time slices consistently. The integrated transport law extends to every time by continuity.
- **Zero data:** all fields vanish; the weak-$L^2$ kernel split is handled separately instead of selecting radius zero.
- **Global time:** E1 is global, and every upgrade can be performed on arbitrary finite horizons using its single global flow. There is no incompatible patching choice between horizons.

**Issues requiring a failed or inconclusive status: none within S0053–S0090.** The minor wording clarifications above do not leave a missing mathematical step. All source claims in the audited interface can be justified from the actual cited theorem plus the explicit elementary upgrades reconstructed here.
