# Independent hostile probe of the prescribed-piece endpoint repair

**Frozen source:** `proof.tex`, SHA256 `b6741b471ba2f128b147f5a5c05fea0afe639c2c3a535b99a5afaf03ea6d4a43`.

**Scope and independence.** I read the exact target, the frozen manuscript, and the canonical container inventory. I did not read another audit, route packet, checkpoint, dependency manifest, or another pass's findings. No external theorem was used to validate the local construction. This is an independent reconstruction of the fragile local mechanism and its summability/trace interfaces, not an exhaustive source-container audit or a certification of the initial-background theorem.

**Result.** I obtained a detailed affirmative derivation of the assigned mechanism. In particular, the strongest spatial first-moment obstruction I tested is satisfied exactly, rather than merely approximately. I did not obtain a counterexample or a material gap in Lemma 4.1 from the listed mechanisms. The conclusion is scoped: the local construction and its stated interfaces are supported by the calculations below; the complete target theorem additionally requires the earlier initial decomposition, background, and seed claims, which this report does not independently certify.

The most informative independent check is

\[
 \left(\int_{\mathbb R^2}D_\xi\otimes D_\xi\,dx\right)^{\rm dev}
 =2\pi(\xi\otimes\xi)^{\rm dev}.
\]

Thus the factor \(2\pi\) in the compact source and the raster average is compatible with the actual dipole's anisotropic kinetic stress. Replacing that stress by an isotropic tensor would have produced a fatal obstruction, but that replacement is false for this profile.

## 1. A necessary full-cycle tensor moment test

Relevant source containers: **S0207–S0209**, **S0221–S0247**, **S0252–S0260**, **S0329–S0335**.

Consider one complete cycle, with correction \(w\) zero at both endpoints. Suppose the old/new velocities and stresses satisfy the claimed exact equations, and that the velocity-product differences and stress differences are globally \(L^1_x\). Integrating their difference in time gives

\[
 \operatorname{div}T+\nabla\Pi=0,
 \qquad
 T=\int_{\rm cycle}
 \bigl[(u+w)\otimes(u+w)-u\otimes u-(\widetilde R-R)\bigr]\,dt.
\]

Here \(T\) is a symmetric integrable tensor. A necessary condition is

\[
 \left(\int_{\mathbb R^2}T\,dx\right)^{\rm dev}=0. \tag{1}
\]

Indeed, applying curl to the displayed equation and taking Fourier transforms yields

\[
 \xi^\perp\cdot\widehat T(\xi)\xi=0.
\]

Continuity of \(\widehat T\) at zero, followed by \(\xi=\rho\theta\), \(\rho\downarrow0\), implies \(\theta^\perp\cdot M\theta=0\) for every direction, where \(M=\int T\). A symmetric \(2\times2\) matrix with that property is scalar. This argument does not assume pressure integrability or use a formally invalid linear test at spatial infinity.

For the construction before smoothing, expand the displayed stress in S0244. All old–new and \(Q\)-quadratic terms cancel in \(T\), leaving

\[
 T=\int_{\rm cycle}
 \bigl[v\otimes v-A_{\rm av}-E+qI\bigr]\,dt. \tag{2}
\]

Every intrinsic anti-divergence stress \(E(t)\) has spatial integral zero; this is proved in Section 3 below. Consequently (1) requires exactly

\[
 \int_{\rm cycle}\!\int (v\otimes v)^{\rm dev}\,dx\,dt
 =\tau\left(\int A_{\rm av}\,dx\right)^{\rm dev}. \tag{3}
\]

The independent dipole calculation in the next section verifies (3) with the precise coefficient and sign in the manuscript. Spatial smoothing does not alter this check: convolution preserves tensor integrals, and the commutator cancels the difference between \(v_\ell\otimes v_\ell\) and \((v\otimes v)_\ell\) in (2).

## 2. The dipole and its integrated anisotropy

Relevant source containers: **S0122–S0142**, especially **S0138–S0142**; compact-source normalization **S0160–S0167**.

Write the stream function for direction \(e_1\) as \(\psi=f(\rho)\sin\theta\). In the core,

\[
 f(\rho)=-\rho+\frac{2J_1(\beta\rho)}{\beta J_0(\beta)},
 \qquad J_1(\beta)=0,
\]

and outside the core \(f(\rho)=-1/\rho\). Define

\[
 A_0(\rho)=\frac{f'(\rho)+f(\rho)/\rho}{2},
 \qquad B_0(\rho)=\frac{f(\rho)/\rho-f'(\rho)}{2}.
\]

The velocity components are

\[
 D_1=-A_0-B_0\cos2\theta,
 \qquad D_2=-B_0\sin2\theta.
\]

Angular integration therefore gives

\[
 \int_0^{2\pi}(D_1^2-D_2^2)\,d\theta=2\pi A_0^2,
 \qquad \int_0^{2\pi}D_1D_2\,d\theta=0.
\]

Outside the core \(A_0=0\). Inside,

\[
 A_0=-1+\frac{J_0(\beta\rho)}{J_0(\beta)}.
\]

The Bessel identities give

\[
 \int_0^1\rho J_0(\beta\rho)\,d\rho
 =\frac{J_1(\beta)}{\beta}=0,
\]

\[
 \int_0^1\rho J_0(\beta\rho)^2\,d\rho
 =\frac{J_0(\beta)^2+J_1(\beta)^2}{2}
 =\frac{J_0(\beta)^2}{2}.
\]

The second formula follows directly by differentiating

\[
 \frac{\rho^2}{2}
 \bigl[J_0(\beta\rho)^2+J_1(\beta\rho)^2\bigr].
\]

It follows that \(\int_0^1\rho A_0^2\,d\rho=1\), hence

\[
 \int(D_1^2-D_2^2)\,dx=2\pi,
 \qquad \int D_1D_2\,dx=0. \tag{4}
\]

Scaling \(D_r=r^{-1}D(x/r)\) preserves its quadratic integral; rotation gives the announced identity. For \(v=\eta D_r(\cdot-X)\),

\[
 \left(\int v\otimes v\,dx\right)^{\rm dev}
 =2\pi\eta^2(\xi\otimes\xi)^{\rm dev}. \tag{5}
\]

Since \(\int U_H=1\), the definition of \(A_{\rm av}\) gives exactly the right side of (3) after summing (5) over the visits.

There is also an elementary check of the underlying traveling-wave sign. With \(q=\psi+x_2\), one has \(D-e_1=\nabla^\perp q\) and \(\operatorname{curl}D=-\beta^2q\) in the disk. Since \((\nabla^\perp q)^\perp=-\nabla q\),

\[
 ((D-e_1)\cdot\nabla)(D-e_1)
 =\nabla\left(\frac{|D-e_1|^2}{2}
 +\frac{\beta^2q^2}{2}\right)
\]

in the core. The matching traces make the stated negative pressure valid across the boundary. Outside the core, the vorticity term vanishes. Thus the translating equation has the sign required for cancellation with \(X'=\eta\xi/r\).

I checked the matching needed here: \(f(1)=-1\), \(f'(1)=1\), \(f''(1)=-2\), exactly as for \(-1/\rho\). There is no circle-supported defect in the velocity equation. The velocity is \(C^1\), bounded in the core, and \(O(|x|^{-2})\) at infinity, giving the norm scalings in S0141.

## 3. Global symmetric \(L^1\) anti-divergence really has the needed cancellations

Relevant source containers: **S0144–S0156**, **S0160–S0167**.

For compactly supported \(f\in L^1\) with zero mean and all first moments zero, define

\[
 (\mathcal Af)_{ij}
 =\partial_i\Delta^{-1}f_j+\partial_j\Delta^{-1}f_i
 -\delta_{ij}\operatorname{div}\Delta^{-1}f.
\]

Direct differentiation gives \(\operatorname{div}\mathcal Af=f\); the tensor is symmetric and, in dimension two, trace free. Its kernel is locally integrable of order \(1/|x|\). Integration over \(B_{3R}\) bounds its near part by \(CR\|f\|_1\). In the far part, the vanishing zeroth and first moments remove the first two Taylor terms of the kernel, leaving \(CR^2|x|^{-3}\|f\|_1\), whose integral is again \(CR\|f\|_1\). No \(L^1\) Calderón–Zygmund bound is hidden in this argument.

One additional consequence, useful in Section 1, is

\[
 \int\mathcal Af\,dx=0. \tag{6}
\]

Indeed, the two compact-support moment conditions give \(\widehat f(\xi)=O(|\xi|^2)\). The anti-divergence multiplier is \(O(|\xi|^{-1})\), so its Fourier transform tends to zero at the origin. Because \(\mathcal Af\in L^1\), that limit is its spatial integral.

For

\[
 f_r=\operatorname{div}(D_r\otimes x/r),
\]

the exterior homogeneity of degree \(-2\) makes \(f_r=0\) outside \(B_r\). It scales like \(r^{-2}\) in that disk, so its \(L^1\) norm is bounded. It is even, giving all first moments zero. Its mean is the exterior boundary flux

\[
 \int_{\partial B_R}D_r(x)\,(x\cdot n/r)\,dS,
\]

which vanishes because the angular mean of the exterior dipole is zero. Therefore \(F_r=-\mathcal Af_r\) is symmetric, globally integrable, has zero integral, and satisfies

\[
 \partial_rD_r=r^{-1}D_r+\operatorname{div}F_r,
 \qquad \|F_r\|_1\le Cr.
\]

For the other input, set \(\Pi_r=r\chi(x/r^{1/5})\Phi_\xi\) as in the source and \(Z_r=D_r-\nabla\Pi_r\). The two fields agree outside \(B_{2r^{1/5}}\) for sufficiently small \(r\). The core costs \(O(r)\) in \(L^1\), the annulus costs \(O(r|\log r|)\), and the cutoff annulus costs \(O(r)\). Thus the claimed compact support and norm bound follow directly.

The source's integral computation must be interpreted over finite disks; \(D_r\) itself is not absolutely integrable. For every sufficiently large centered disk,

\[
 \int_{B_R}D_r\,dx=\pi r\xi,
 \qquad \int_{B_R}\nabla\Pi_r\,dx=-\pi r\xi.
\]

Their difference is compactly supported, so it has the unambiguous integral \(2\pi r\xi\). Both terms are even, hence \(Z_r/r\) has zero first moments. Therefore

\[
 Z_r/r-2\pi U_H\xi
\]

has exactly the two cancellations needed by \(\mathcal A\), provided \(2r^{1/5}\le H\). Its anti-divergence has norm at most \(CH(1+|\log r|)\) and zero spatial integral. Translation does not destroy either moment cancellation, because the mean is zero before translation.

Both summands of \(E\) in S0167 consequently have zero integral. This proves the assertion used in the full-cycle obstruction test.

## 4. Packet identity, births/deaths, force moments, and the corrector

Relevant source containers: **S0158–S0168**, **S0190–S0209**, **S0221–S0242**.

Let \(a_*(t)=\eta(t)r(t)\). Direct differentiation, the traveling-wave equation, and the radial identity give

\[
 \partial_tv+\operatorname{div}(v\otimes v)+\nabla p_v
 =a_*'D_r/r+\operatorname{div}(\eta r'F_r).
\]

The transport term cancels because \(-\eta X'\cdot\nabla D_r=-\eta^2r^{-1}\partial_\xi D_r\). The remaining coefficient of \(D_r\) is \(\eta'+\eta r'/r=a_*'/r\). Decomposing \(D_r/r\) by the compact source from Section 3 and moving its gradient to pressure yields

\[
 \partial_tv+\operatorname{div}(v\otimes v)+\nabla p_v
 =\mathcal U+\operatorname{div}E,
 \qquad \mathcal U=2\pi a_*'U_H(\cdot-X)\xi. \tag{7}
\]

On an interior row \(r=r_0c(s,y)\), \(\eta=\eta_i\), and \(s'=\eta_i/(r_0c)\). Thus

\[
 \eta r'=a_*'=\eta_i^2\partial_s\log c.
\]

On a ramp, \(r=r_0e\), \(\eta=\eta_i\zeta(t/T)\), and \(T=r_0eL/(\eta_i I_\zeta)\), so

\[
 a_*'=\frac{\eta_i^2I_\zeta}{L}\zeta'(t/T).
\]

This is independent of the number of rows and of \(r_0\). At each row endpoint the amplitude is zero to all orders. The center and radius can be reset there without a delta in \(v\) or in the product \(a_*U_H(\cdot-X)\). The corrector \(Q\) need not vanish at each row or direction-slot reset; only the principal packet does. \(Q\) remains continuous there and vanishes at complete-cycle endpoints, which is what the argument uses.

On every visit,

\[
 \frac{d}{dt}[a_*U_H(\cdot-X)]
 =a_*'U_H(\cdot-X)-\eta^2\xi\cdot\nabla U_H(\cdot-X).
\]

Integrating over the visit has no endpoint term. Summing over the complete cycle gives

\[
 \overline{\mathcal U}=\operatorname{div}A_{\rm av},
 \quad
 A_{\rm av}=\frac{2\pi}{\tau}\int_{\rm cycle}
 \eta^2U_H(\cdot-X)\,\xi\otimes\xi\\,dt. \tag{8}
\]

The source's spatial force moments provide a separate exact check:

\[
 \int\mathcal U\,dx=2\pi a_*'\xi,
 \qquad
 \int x_j\mathcal U_i\,dx=2\pi a_*'X_j\xi_i.
\]

Over a visit, the first expression integrates to zero, and integration by parts in the second gives

\[
 \int_{\rm visit}\!\int x_j\mathcal U_i\,dx\,dt
 =-2\pi\int_{\rm visit}\eta^2\xi_j\xi_i\\,dt. \tag{9}
\]

This is symmetric, has zero torque, and is precisely the first-moment identity for \(\operatorname{div}(\tau A_{\rm av})\). There is no missing row-count factor or endpoint force in (8).

Now set

\[
 Q(t)=-\mathbb P\int_{t_k}^t(\mathcal U-\overline{\mathcal U})\,ds.
\]

Let \(\mathcal U-\mathbb P\mathcal U=\nabla\pi_{\mathcal U}\). Then

\[
 \partial_tQ+\mathcal U+
 \nabla(-\pi_{\mathcal U}+\overline{\pi_{\mathcal U}})
 =\overline{\mathcal U}. \tag{10}
\]

This checks the pressure sign in S0236. The average must be over the whole four-direction cycle to make the same \(A_{\rm av}\) appear throughout that cycle. The full-cycle time primitive is zero at both endpoints exactly.

The Leray projection is only applied to a fixed radial bump and translates. Its projected profile has smooth bounded core and \(O(|x|^{-2})\) exterior, so

\[
 \|\mathbb P(U_H\xi)\|_p\le C_pH^{2/p-2},\qquad p>1.
\]

The curl is \(\operatorname{curl}(U_H\xi)\), whose \(L^1\) norm is \(O(H^{-1})\). Minkowski therefore gives, with \(B=\sup|a_*'|\),

\[
 \|Q\|_2+\|\operatorname{curl}Q\|_1\le C\tau H^{-1}B,
 \qquad \|Q\|_{3/2}\le C\tau H^{-2/3}B.
\]

There is no invocation of an \(L^1\)-bounded Leray projection. The number of visits does not multiply these estimates: the cycle length is \(\tau\), and there is only one active principal source at a time.

### Additional circulation, impulse, and angular-impulse check

The packet vorticity is compactly supported. For its unscaled profile, Green's identity on a large disk, using the exterior stream function, gives

\[
 \int\Omega=0,
 \qquad \int y\,\Omega(y)\,dy=2\pi\xi^\perp,
 \qquad \int |y|^2\Omega(y)\,dy=0.
\]

The last identity also follows from oddness. Hence the translated packet has

\[
 \int x\,\operatorname{curl}v\,dx=2\pi a_*\xi^\perp,
 \quad
 \int|x|^2\operatorname{curl}v\,dx
 =4\pi a_*X\cdot\xi^\perp. \tag{11}
\]

For the bump force,

\[
 \int x\,\operatorname{curl}\mathcal U\,dx
 =2\pi a_*'\xi^\perp,
 \quad
 \int|x|^2\operatorname{curl}\mathcal U\,dx
 =4\pi a_*'X\cdot\xi^\perp.
\]

Both cycle averages vanish: \(a_*\) is zero at visit endpoints and \(X\cdot\xi^\perp\) is constant on a straight row. Taking curl in the definition of \(Q\) shows that its moments are the negatives of (11). Thus \(w=v+Q\) has zero circulation, zero first vorticity moment, and zero angular impulse at every time of the cycle. No angular-momentum obstruction to a symmetric global \(L^1\) stress remains. Even spatial smoothing preserves these zero moments: the bump has zero first moment, and the Laplacian moment correction multiplies the already-zero circulation.

## 5. Normalization and the increasing-row-count limit

Relevant source containers: **S0171–S0219**, **S0287–S0309**, **S0323–S0328**.

For the four stated directions, direct matrix addition gives

\[
 \sum_i a_i\xi_i\otimes\xi_i=-S_k+q_kI.
\]

The nonnegative coefficient mass is bounded by a universal multiple of \(\|S_k\|_1\), plus the chosen regularization mass. Positive floors are fixed before the fine scale tends to zero. They may make logarithmic derivative constants large, but finite. Those constants affect how small \(H\) must be; they do not alter the leading \(C\sqrt\delta\) estimate.

Let \(B_i\) have the exact definition in S0197. With \(\tau_i=\tau/4\), the proposed normalization gives

\[
 \eta_i^2=\frac{4dB_i}{2\pi},
 \qquad r_{0,i}=\frac{\tau d}{2\pi\eta_i},
\]

and therefore

\[
 (r_{0,i}/\eta_i)B_i=\tau/4,
 \qquad \frac{2\pi\eta_i r_{0,i}}\tau=d. \tag{12}
\]

These identities are exact, not asymptotic. At fixed positive floors, \(dB_i\) tends to a positive finite mass as \(d\downarrow0\). The number of rows is of order \(d^{-1}\), but this is already absorbed into \(B_i\); it does not cause the amplitude to grow. The estimate is

\[
 \eta_i\le C\sqrt{\|S_k\|_1}
 +C\sqrt{\text{regularization and floor mass}}+o(1).
\]

For ramps, the relevant contribution to the average tensor uses \(\int\zeta^2\), whereas their duration uses \(I_\zeta=\int\zeta\). Their averaged mass per row is proportional to

\[
 d\,eL\,\frac{\int_0^1\zeta^2}{I_\zeta}.
\]

Thus it is indeed charged to a fixed multiple of added floor/buffer mass; it is not an unaccounted leading coefficient. The floor added to the interior rectangle is handled the same way.

For the original compact coefficient \(a\), the row rule is a Banach-valued rectangle rule. With

\[
 F(y)=\int a(s,y)U_H(\cdot-s\xi-y\xi^\perp)\,ds,
\]

one has

\[
 \int\|F'(y)\|_1\,dy
 \le\|\partial_\perp a\|_1+C H^{-1}\|a\|_1.
\]

Comparing each endpoint sample with its row interval gives error at most \(d\int\|F'\|_1\); comparison of \(a*U_H\) with \(a\) gives \(CH\|\nabla a\|_1\). Thus the quadrature error is \(O(H)\) at fixed coarse data when \(d=H^2\). Using the auxiliary width \(H\), rather than \(d\), is essential for the term \(d/H\) to tend to zero.

On a coarse cell choose the integer cycle count first through

\[
 \tau=|I_k|/N_k,\quad H=\tau^{1/6},\quad d=H^2.
\]

Then \(r_0\asymp H^8\), and all radii lie between positive fixed multiples of \(H^8\). The lower constants can depend on the fixed floors. This makes the positive minimum radius available for subsequent smoothing, while \(2r^{1/5}=O(H^{8/5})\le H\) and \(r\le r_*\) eventually hold.

The full list of fine-scale costs is compatible:

| Quantity | Bound at fixed coarse coefficients/floors |
|---|---:|
| principal \(L^2\) and curl \(L^1\) | \(C\eta_i\) |
| principal \(L^{3/2}\) | \(O(H^{8/3})\) |
| intrinsic error | \(O(H|\log H|)+O(H^8)\) |
| \(Q\) in \(L^2\) and curl \(L^1\) | \(O(H^5)\) |
| \(Q\) in \(L^{3/2}\) | \(O(H^{16/3})\) |
| row quadrature error | \(O(H)\) |
| \(v\)-\(Q\) quadratic error | \(O(H^5)\) |
| \(Q\)-\(Q\) quadratic error | \(O(H^{10})\) |

The constants need not be uniform in the coarse data. That is allowed: the fine cycle count is selected after the coarse approximation, regularization, floors, rectangles, and ramps. The leading principal increment constant remains independent of those derivative/support constants. Nothing in this ordering requires the floor to tend to zero together with \(H\).

## 6. Full stress identity and derivative-free old-field interaction

Relevant source containers: **S0243–S0260**, **S0261–S0275**, **S0311–S0328**, **S0337–S0348**.

Adding (7) and (10) gives

\[
 \partial_t(v+Q)+\operatorname{div}(v\otimes v)
 +\nabla(p_v+p_Q)=\operatorname{div}(A_{\rm av}+E).
\]

Adding the old Euler–Reynolds equation and expanding \((u+v+Q)\otimes(u+v+Q)\) gives precisely

\[
 \begin{aligned}
 \widetilde R={}&R+A_{\rm av}-qI+E\\
 &+u\otimes(v+Q)+(v+Q)\otimes u\\
 &+v\otimes Q+Q\otimes v+Q\otimes Q.
 \end{aligned} \tag{13}
\]

The new pressure is the intermediate pressure minus \(q\). All stresses are symmetric. The sign of \(-qI\) is therefore consistent with the decomposition of \(-S_k\).

At a fixed coarse cell, \(M=\sup\|u(t)\|_3<\infty\). The old field is used only through

\[
 \|u\otimes v\|_1\le M\|v\|_{3/2},
 \qquad \|u\otimes Q\|_1\le M\|Q\|_{3/2}.
\]

These costs tend to zero as \(H\downarrow0\), even when \(M\) is very large. No derivative, time-freezing approximation, or mollification of \(u\) occurs. The claim depends essentially on the finite old global \(L^3\) bound; it is not a statement for an arbitrary old field known only to be locally \(L^2\).

Fixing a spatial smoothing scale on each cycle introduces

\[
 C_\ell=v_\ell\otimes v_\ell-(v\otimes v)_\ell
\]

on the right side, with the stated plus sign. The continuous \(L^2\) image of a fixed cycle is compact, so \(C_\ell\to0\) uniformly in time in \(L^1\). Since the number of cycles is finite after the fine parameters are chosen, scales can be selected small enough for every cycle. Convolution decreases the required \(L^p\) and curl \(L^1\) norms. It does not cost a time derivative because its scale is constant during a cycle.

One can either convolve \(q\) along with the new equation, or retain the original \(q\) and add \(\|q*\rho_\ell-q\|_1\) to the averaging budget. The latter tends to zero because \(q\in L^1\). Thus the consistent smoothing instruction does not conceal a nonintegrable scalar error.

For the prescribed piece \(S(t)\), independently of the current \(R\), approximate it on each one-sided coarse cell by \(S_k\) with error \(\varepsilon_0\). Equation (13) removes \(S_k\), and defining

\[
 E_{\rm total}=S-S_k+E_k^{\rm loc}
\]

gives exactly \(\widetilde R=R-S+E_{\rm total}\). No relation \(S=\chi R\) is required in this local algebra. This verifies the feature required for successive color repairs of pieces frozen earlier in the stage.

Choose the coarse approximation error first, then regularization/floor masses, then sufficiently large integer cycle counts, then smoothing scales. This order gives all three independent budgets: small stress error, leading increment \(C\sqrt\delta\) plus arbitrary slack, and arbitrary \(L^{3/2}\) increment. The positive lower radius is needed only after a particular finite construction has been chosen.

## 7. Temporal support and admissible-class interfaces

Relevant source containers: **S0261–S0286**, **S0329–S0349**.

There are finitely many inherited boundaries inside a compact positive-time patch. One-sided continuous \(L^1\) extensions of \(S\) allow a finite coarse subdivision and a compact smooth spatial approximation on each coarse cell. No approximation is imposed simultaneously on two unequal one-sided traces.

Every coarse cell consists of complete cycles. At its endpoints both the principal packet and \(Q\) are zero. Extending the correction by zero outside \([a,b]\Subset J\) therefore gives no temporal delta in the velocity equation. Stress jumps at those times are harmless because the equation contains spatial divergence of stress, not its temporal derivative.

Actual stress values at the finite boundary times can be assigned \(E_{\rm total}=0\), \(\widetilde R=R-S\), exactly as the manuscript's admissible class allows. The distributional equation and the one-sided traces are unchanged by these point values. This preserves the claimed pointwise error bound at those times, rather than merely almost everywhere.

The principal packet is continuous into \(L^2\) and \(L^{3/2}\) through its flat zero resets. The fixed-cycle mollifier makes it continuous into \(L^3\). The bump primitive \(Q\) is continuous in all three spaces. Different smoothing scales on adjacent cycles are harmless because both velocities vanish at the shared endpoint. The corrector's derivative and the stress are allowed to jump there.

Intrinsic anti-divergence terms are continuous in \(L^1\) along each visit by the bounded map established in Section 3 on a common support ball; their scalar prefactors vanish at resets. The \(L^2\)-quadratic terms are continuous in \(L^1\), and the old–new terms are continuous by the \(L^3\)-\(L^{3/2}\) product estimate. Adding the piecewise continuous discrepancy \(S-S_k\) gives precisely the required piecewise \(L^1\) stress class. Every row count and cycle count is finite in a fixed patch. No uniform \(L^3\) bound across the infinite iteration is needed or obtained here.

## 8. Conditional summability and exact-trace closure

Relevant source containers: **S0351–S0360**, **S0362–S0406**, and **S0407–S0417**.

This section assumes the manuscript's earlier seed has the claimed admissibility, uniform finite-horizon local energy/stress bounds, exact initial trace, and finite curl variation. Under those hypotheses, the local lemma just reconstructed does give the advertised closure; I did not locate an additional interface obstruction.

The dyadic patches \(I_j=(2^{j-1},2^{j+1})\) have uniformly bounded overlap. Coloring by \(j\bmod3\) makes each color's patches disjoint and supplies gap times \(3\cdot2^j\downarrow0\). Local finiteness away from zero permits simultaneous patchwise construction in one color. The current old \(L^3\) norm is finite on each compact patch at every finite stage, even though no global-in-stage bound is asserted.

Freezing \(S_{qj}=\chi_jR^{(q)}\) before the three colors are processed is legitimate because (13) removes an independently prescribed piece. After any subset of pieces is processed, the exact residual is

\[
 \left(1-\sum_{j\in\mathrm{processed}}\chi_j\right)R^{(q)}
 +\sum_{j\in\mathrm{processed}}E_{qj}.
\]

The coefficient of \(R^{(q)}\) is nonnegative and at most one. This supplies the uniform intermediate stress bound needed by the anchor lemma. After all colors, the old stress cancels completely and the residual is the sum of errors.

If \(t\le T\) belongs to an active patch, \(I_j\subset(0,4T)\). The local leading estimate therefore gives

\[
 \sup_{0<t\le T}
 \bigl(\|w_q(t)\|_2+\|\operatorname{curl}w_q(t)\|_1\bigr)
 \le [NC\sqrt{\Theta(4T)}+1]\,4^{-q}. \tag{14}
\]

The summation over all spatially unrestricted patches introduces only the overlap factor \(N\), not the infinite total number of patches. Formula (14) is summable. The \(L^{3/2}\) budgets are likewise summable pointwise in time, but their critical role for this construction is already the derivative-free old–new stress control.

For a single color correction \(W\), its gap times satisfy \(W(t_k)=0\). Subtracting the old and new equations against a fixed compact divergence-free test yields a uniformly bounded time derivative of its pairing, because local energies and global \(L^1\) stresses are uniformly bounded near zero. Its pairing is therefore Lipschitz and has limit zero along all times approaching zero, since it is zero at the anchors.

To upgrade this to global weak \(L^2\) convergence, take any weak cluster point using the uniform global \(L^2\) bound. It is divergence free and annihilates every compact divergence-free test. Taking tests \(\nabla^\perp\phi\) makes its curl zero. A global \(L^2\) vector field with both divergence and curl zero is zero by Fourier analysis. Thus every cluster point vanishes. This argument supplies weak, not strong, initial trace; weak trace is exactly what the target requests.

Finite stages preserve the exact initial trace by applying that argument three times per stage. For the infinite series, split it into finitely many corrections and a uniformly small global \(L^2\) tail using (14). This proves weak local \(L^2\) continuity at zero and retains \(u(0)=u_0\). At positive times the same uniform series is a strong local \(L^2\) limit of continuous finite stages.

At each fixed positive time the curl series is absolutely convergent in \(L^1\) by (14), and distributional differentiation of the \(L^2_{\rm loc}\) velocity limit identifies that sum with its curl. The bound is uniform on each finite horizon. This is an every-time conclusion; it does not rely on selecting representatives from an almost-everywhere time bound. The initial time is handled by the prescribed measure separately.

Strong local \(L^2\) convergence passes the velocity quadratic term on positive-time compact cylinders, while the geometric stress bound removes the residual stress. The initial weak formulation follows with a cutoff rising from zero on \((\varepsilon,2\varepsilon)\): uniform local kinetic energy makes the removed convection integral \(O(\varepsilon)\), and weak continuity identifies the cutoff-derivative term with the initial pairing. The sign is the target's plus initial term.

Finally, conditional on the initial normalization's fixed \(V_0\in C_0\) and \(V(t)-V_0\in L^2\), the summable global \(L^2\) corrections keep \(u(t)=V_0+v(t)\) with \(v(t)\in L^2\). The harmonic remainder \(u-K*\operatorname{curl}u\) is eliminated by its ball-average estimate: the \(C_0\) part has vanishing large-ball average, and the \(L^2\) and finite-measure Biot–Savart parts contribute \(O(R^{-1})\). This verifies the stated normalization interface without imposing zero circulation or finite total kinetic energy.

## 9. Scope of the affirmative conclusion

This report directly checked the proposed local mechanism against its most restrictive obvious necessary conditions and reconstructed its estimates without appealing to literature status. The following potential failures were specifically tested and did not occur:

1. A mismatch between actual dipole anisotropy and averaged directional stress: the exact factor is \(2\pi\), as required.
2. A nonintegrable anti-divergence tail from missing moment cancellation: both necessary cancellations hold for each intrinsic input.
3. Nonzero net force/torque or packet impulse left by births, deaths, or row resets: the exact source and corrector identities cancel them.
4. A hidden factor equal to the growing row count: it is already accounted for in the exact normalization and does not enter the sup-in-time corrector estimate.
5. Derivatives of the old background: only its finite global \(L^3\) norm enters local interaction estimates.
6. A temporal delta at cycle/paste endpoints: zero velocity traces exclude it; stress jumps are allowed by the stated class.
7. A need for uniform \(L^3\) bounds through the iteration: finite-stage patchwise \(L^3\) suffices, while the actual convergence uses summable \(L^2\) and curl \(L^1\) bounds.
8. Loss of the exact initial trace from patches accumulating at zero: color gap anchors and uniform summable \(L^2\) tails supply the required weak trace.

The result is an affirmative reconstruction of this vulnerable chain, not an exhaustive assertion that every claim in the manuscript has been validated. In particular, the external background input and the complete seed estimates remain outside this report's independently verified scope.
