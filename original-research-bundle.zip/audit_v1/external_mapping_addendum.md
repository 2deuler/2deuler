# Addendum: the mapping display in Crippa–Stefani Assumption 3.1

**Corrected disposition: the background application still passes using the explicit finite choice $p_0=3$. The initial audit's claim to have completely checked the printed interface needs qualification.** Its divergence check at $p=\infty$ was valid, but did not verify the full operator range displayed in Assumption 3.1. That omission is material to the audit record. The original report is preserved unchanged.

This addendum concerns manuscript S0054–S0058 (lines 107–118) and S0062 (lines 133–134). It does not change the reconstruction of S0064–S0090. I reopened the original [published PDF](https://link.springer.com/content/pdf/10.1007/s00526-024-02750-4.pdf), especially printed pages 10, 12–16, and 18–19, and inspected the full mapping extracted from page 14. No other auditor's output or agent-status list was consulted.

## The printed requirement and its quantifiers

On printed page 14, Assumption 3.1 fixes $p\in(2,\infty]$ and displays

\[
 K:L^1(\Omega)\cap L^p_{\mathrm{ul}}(\Omega)
   \longrightarrow C_b^{0,\,1-2/p}(\Omega;\mathbb R^2).
\]

It then requires the divergence estimate (3.1) for every vorticity in that domain, and (3.2) when a boundary is present. This is a hypothesis family indexed by a chosen $p$; it does not explicitly demand the displayed mapping simultaneously at every exponent. Theorem 3.3, page 15, does not separately assign that parameter the value $\infty$. Definition 3.2's bounded-vorticity specialization requires bounded continuous velocity, not Lipschitz velocity. Theorem 2.2, page 10, has finite $p$; Corollary 2.4 supplies the log-Lipschitz bound used in (3.9)–(3.10). Theorem 3.3's flow-limit argument on page 19 invokes Osgood continuity.

The preceding paragraph records the primary-source statements. The sufficiency argument and endpoint counterexample below are my independent mathematical checks.

There are two logically separate parameters to keep distinct:

1. The exponent $p_0$ used to verify the structural assumption on the operator's domain.
2. The boundedness of the data, approximations, and final solution supplied by the bounded-vorticity existence theorem.

A theorem that takes bounded data does not thereby require testing the operator assumption at its formal $p=\infty$ endpoint. Bounded integrable data belong to the operator's domain at any fixed finite $p_0>2$. The proof must still be checked to ensure it never needs the divergence/boundary property outside that finite-$p_0$ domain. That check is given below.

The theorem's reference to a parameterized assumption is compressed: it does not include an explicit phrase selecting a finite $p_0$. Thus the most precise application should state the selection and the inclusion argument. Even if one interprets the printed shorthand as intended to select $p=\infty$, the finite-$p_0$ sufficient version is justified by the actual proof; no Lipschitz hypothesis is used.

## Full verification at $p_0=3$

Set $\Omega=\mathbb R^2$ and $k(x,y)=K(x-y)$, with the manuscript's Biot–Savart kernel. S0058 already verifies the size and difference estimates of Assumption 2.1.

Let $f\in L^1(\mathbb R^2)\cap L^3_{\mathrm{ul}}(\mathbb R^2)$, and set
$A=\|f\|_1+\|f\|_{L^3_{\mathrm{ul}}}$.
The following checks cover the entire domain, not only the particular datum.

**Boundedness.** Split the convolution at radius one. Hölder with exponent $3/2$ for the kernel on the unit disk bounds the near part, while the far part is controlled by $\|f\|_1$. Thus $\|K*f\|_\infty\le CA$.

**The $1/3$-Hölder seminorm.** For $h=|x-y|\in(0,1/4)$, split the convolution difference into the disk of radius $2h$ around $x$, the annulus $2h<|x-z|<2$, and its complement.

- The near part lies in disks of radii at most $3h$ about the two singularities. The $L^{3/2}$ norm of $|z|^{-1}$ on such a disk is $O(h^{1/3})$.
- On the annulus the kernel difference is at most $Ch|x-z|^{-2}$. The $L^{3/2}$ norm of $|z|^{-2}$ on $2h<|z|<2$ is $O(h^{-2/3})$. A finite covering controls the local $L^3$ norm on the radius-two disk.
- Outside that disk the difference is bounded by $Ch$, so the integral is at most $Ch\|f\|_1$.

Consequently
\[
 |K*f(x)-K*f(y)|\le CAh^{1/3}.
\]
For $h\ge1/4$, boundedness yields the same estimate after increasing $C$. This independently proves the complete finite-exponent display
\[
 K:L^1\cap L^3_{\mathrm{ul}}\longrightarrow C_b^{0,1/3}.
\]
It is also exactly the choice $q=1,p=3$ available in the source's Theorem 2.2.

**Divergence and boundary.** For every $f$ in this domain, $\operatorname{div}(K*f)=0$ distributionally. Fubini against a compact smooth derivative test is justified by $f\in L^1$, the local integrability of $K$, and the uniform bound on the kernel integral against the test. Hence (3.1) holds for any permitted positive $C_3$. There is no boundary condition on the plane.

**Bounded-vorticity inclusion.** Every $f\in L^1\cap L^\infty$ satisfies
\[
 \|f\|_{L^3_{\mathrm{ul}}}\le |B_1|^{1/3}\|f\|_\infty
 =\pi^{1/3}\|f\|_\infty.
\]
In particular, $\nu_0=a*\mu$ from S0037 is admissible. This inclusion applies to all bounded intermediate vorticities, not just to $\nu_0$.

Therefore the full structural assumption is satisfied at $p_0=3$, including the previously omitted range display.

## Why the finite-exponent check suffices for the bounded construction

This is a sufficiency inference from the proof, not an assertion that $1/3$-Hölder continuity by itself gives unique trajectories. That Hölder modulus is not Osgood.

In the bounded construction the relevant functions consist of the initial datum, the frozen vorticities at the time-step endpoints, the transported vorticities within each step, and the bounded limit. Each is in $L^1\cap L^\infty$, and hence in $L^1\cap L^3_{\mathrm{ul}}$. Thus whenever a divergence bound or a boundary condition is needed, the verified $p_0=3$ structural assumption applies to exactly that function.

For these bounded functions, Assumption 2.1 independently gives the stronger logarithmic modulus. The near region contributes $Ch\|f\|_\infty$, the annular region contributes $Ch\log(1/h)\|f\|_\infty$, and the far region contributes $Ch\|f\|_1$. Thus
\[
 |K*f(x)-K*f(y)|
 \le C(\|f\|_1+\|f\|_\infty)\,h(1+|\log h|)
 \quad(0<h\le1/4).
\]
This is Osgood. Its derivation uses the kernel estimates and boundedness of the particular vorticity; it makes no claim that the full $L^\infty$ domain maps into Lipschitz functions.

Accordingly, the successive operations needed by the construction all have the required inputs:

| Operation | Inputs actually needed | Available with $p_0=3$? |
|---|---|---|
| Define each frozen velocity | Bounded convolution on the bounded-data class | Yes |
| Construct and identify trajectories | Uniform boundedness and the logarithmic Osgood modulus | Yes, by the direct kernel estimate above |
| Keep transported vorticity bounded | The divergence bound on the frozen vorticity | Yes, by the domain inclusion |
| Preserve the integrable class | Finite initial mass and the transport representation | Yes |
| Obtain compactness and canonical limiting velocity | Uniform boundedness, spatial equicontinuity, transport estimates, and kernel size control | Yes |
| Identify the limiting pushforward | Osgood flow stability and the same uniform bounds | Yes |

Concrete source-proof checkpoints are (3.9)–(3.12), (3.16)–(3.25), and Step 4 of Theorem 3.3. None requires a Lipschitz seminorm or the $p=\infty$ version of the displayed range. This establishes the sufficient interface
\[
 \text{Assumption 2.1}+\text{Assumption 3.1 at one finite }p_0>2
 \quad\Longrightarrow\quad
 \text{the bounded-vorticity conclusion used in E1},
\]
for the present whole-plane application.

## The literal endpoint range is false

If the displayed range at $p=\infty$ is interpreted with the usual meaning of $C_b^{0,1}$, it asserts
\[
 K:L^1\cap L^\infty\longrightarrow C_b^{0,1}.
\]
This is false for the plane Biot–Savart operator. It cannot be justified by $\operatorname{div}K=0$. The initial report must not be read as having verified this assertion.

For an explicit independent counterexample, use polar coordinates and define
\[
 f(r,\theta)=\mathbf1_{\{0<r<1\}}\sin(2\theta),\qquad f(0)=0.
\]
Then $f\in L^1\cap L^\infty$, and for $V=K*f$, symmetry gives $V_1(0)=0$. For small $h>0$, split the integral for
$V_1(he_1)-V_1(0)$ at $|y|=2h$. On the annulus,
\[
 K_1(he_1-y)-K_1(-y)
 =h\,\partial_1K_1(-y)+O(h^2|y|^{-3}),
 \qquad
 \partial_1K_1(-y)=\frac{\sin(2\theta)}{2\pi r^2}.
\]
The remainder integrates to $O(h)$. The inner disk contributes $O(h)$, by local integrability of both shifted kernels. Hence
\[
 \frac{V_1(he_1)-V_1(0)}h
 =\frac1{2\pi}\int_{2h}^{1}\frac{dr}{r}
       \int_0^{2\pi}\sin^2(2\theta)\,d\theta+O(1)
 =\frac12\log(1/h)+O(1),
\]
which is unbounded. Thus $V$ is not Lipschitz.

This diagnoses a printed endpoint imprecision in the range annotation if that annotation is intended to cover $p=\infty$ for the standard Biot–Savart operator. It is not a claim that an official correction has been published. Restricting that annotation to finite $p$, and using the log-Lipschitz class for bounded vorticity, matches the actual estimates and proof. The smoothness of the particular initial $\nu_0$ does not repair a universal operator-domain claim, so it is not a substitute for the finite-exponent resolution.

## Effect on the manuscript and on the first audit

| Item | Disposition |
|---|---|
| S0054–S0058 / S0062: applicability of the external existence input | **PASS with the explicit finite-$p_0$ instantiation above.** |
| Literal full Assumption 3.1 at $p=\infty$ for standard Biot–Savart | **Not satisfied** if its range means Lipschitz. This must not be asserted. |
| Initial report's table entry checking divergence “with $p=\infty$” | Its divergence calculation is correct, but it is incomplete as a full Assumption 3.1 check. |
| Initial report's “complete interface” coverage claim | **Qualified by this addendum.** The missing mapping display was not checked in that report. |
| Every-time representatives and upgrades S0064–S0090 | Their earlier derivations stand; they use bounded/log-Lipschitz velocity, never a general Lipschitz mapping. |

A precise expansion of the E1 invocation would say:

> Take $p_0=3$ in Assumption 3.1. Assumption 2.1 gives $K:L^1\cap L^3_{\mathrm{ul}}\to C_b^{0,1/3}$, the canonical kernel has zero divergence, and there is no boundary condition on $\mathbb R^2$. Every bounded integrable vorticity belongs to this domain. The bounded-vorticity construction in Theorem 3.3 uses the logarithmic modulus from the kernel estimates, not a Lipschitz endpoint mapping.

That paragraph is a clarification of an applicable external theorem interface; it introduces no stronger data assumption and changes none of Lemma 1.2's conclusions.
