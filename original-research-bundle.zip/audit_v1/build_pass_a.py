import json,hashlib,collections,re
from pathlib import Path
root=Path('audit_v1')
source=root/'proof.tex'; raw=source.read_bytes()
expected='b6741b471ba2f128b147f5a5c05fea0afe639c2c3a535b99a5afaf03ea6d4a43'
assert hashlib.sha256(raw).hexdigest()==expected
invpath=root/'audit_inventory.json'
invraw=invpath.read_bytes(); invhash=hashlib.sha256(invraw).hexdigest()
assert invhash=='efbd3fc4311f910b394581f46718f3b73a03f99a5891b38d2e7e2be24d7b9b71'
inv=json.loads(invraw)
notes={}
for line in (root/'pass_a_notes.tsv').read_text().splitlines():
 k,st,ra=line.split('|',2); assert k not in notes;notes[k]=(st,ra)
assert set(notes)=={c['id'] for c in inv['containers']}
overrides={
'S0242.C01':('VERIFIED','The corrector derivative is -P(U-Ubar) inside each cycle; successive cycle averages or bump scales can differ, giving a jump without changing Q\'s zero endpoint values.'),
'S0242.C02':('VERIFIED','The principal packet and Q have zero endpoint traces and continuous L2/L3/2 paths on each visit/cycle, so their concatenation is continuous.'),
'S0242.C03':('VERIFIED','Continuity follows from positive-radius translation/dilation and the zero-amplitude/zero-primitive endpoint traces; it needs no smooth-time assertion.'),
'S0242.C04':('AMBIGUOUS','Piecewise time smoothness is valid for Q and after spatial mollification. For the raw packet the core-circle second-derivative jump in D prevents C3 time regularity in L2 under nonzero translation; the sentence does not specify which velocity it means.'),
'S0242.C05':('AMBIGUOUS','The adjective smooth is correct for the projected-bump corrector, but not generally for the raw D-packet as a time-to-L2 map before spatial smoothing.'),
'S0242.C06':('VERIFIED','A derivative jump at cycle boundaries prevents global time smoothness; the source correctly does not claim that stronger property.'),
'S0242.C07':('VERIFIED','The negative assertion of globally smooth time dependence is consistent with changing cycle averages and the permitted derivative jumps.'),
'S0247.C01':('AMBIGUOUS','R, A_av, qI, E and the mixed terms grouped with their transposes are symmetric. An individual displayed product u tensor v need not be; for u=e1, v=e2 its transpose differs. The assertion needs a grouping qualifier.'),
'S0247.C02':('AMBIGUOUS','Symmetry holds for the complete stress and each explicitly symmetrized pair, not for every individual rank-one product appearing in the display.'),
'S0247.C03':('VERIFIED','Pointwise ||u tensor v||=|u||v| and 1/3+1/(3/2)=1, so Holder gives the stated L1 bound.'),
'S0247.C04':('VERIFIED','The packet norm equals eta times C_(3/2) r^(1/3), giving the second inequality with a fixed dipole constant.'),
'S0247.C05':('VERIFIED','The same Holder pair 3 and 3/2 gives ||u tensor Q||1<=||u||3||Q||_(3/2).'),
'S0247.C06':('VERIFIED','Cauchy-Schwarz on |v||Q| gives the L2 times L2 product bound.'),
'S0247.C07':('VERIFIED','The Euclidean/Frobenius tensor norm of Q tensor Q is |Q|^2, so integration gives exactly ||Q||2^2.'),
'S0304.C01':('VERIFIED','Both derivative prefactors are uniformly bounded in N by the explicit ramp/row formulas and the uniform amplitude bound S0298.'),
'S0304.C02':('AMBIGUOUS','The needed boundedness follows from |eta r\'|<=eta_i^2||partial_xi log c_i||infinity and the ramp bound. Eta_i is fixed in time for the row peak but not as N_k varies, since eta_i^2=(2/pi)d_k B_i. The scope of fixed amplitudes should be clarified.'),
'S0304.C03':('VERIFIED','Uniform boundedness is independently established from S0203 and S0298, without requiring amplitudes to be constant across different cycle counts.'),
'S0304.C04':('VERIFIED','The positive coefficient c_i=a_i+e_i is fixed before varying N_k; e_i>0 makes its logarithmic spatial derivatives finite and independent of N_k.'),
'S0304.C05':('VERIFIED','Positive fixed floors bound c_i away from zero on the fixed finite scan rectangle and buffers, making every logarithmic derivative well-defined.'),
}
records=[]
for c in inv['containers']:
 assert raw[c['byte_start']:c['byte_end_exclusive']].decode()==c['text']
 assert hashlib.sha256(c['text'].encode()).hexdigest()==c['sha256']
 st,ra=notes[c['id']]
 children=[]
 for n in c['nested_checks']:
  if n['id'] in overrides: ns,nr=overrides[n['id']]
  elif not re.sub(r'\\(?:end\{cases\}|\\)','',n['text']).strip():
   ns,nr='NOT MATHEMATICAL','The frozen focus consists only of alignment/case-closing or empty layout bytes; the surrounding formula and both cases are checked in the other children and parent reconstruction.'
  else:
   ns='VERIFIED' if st=='AMBIGUOUS' else st
   nr=ra
  children.append({'id':n['id'],'status':ns,'rationale':nr})
 records.append({'id':c['id'],'source_sha256':c['sha256'],'status':st,'rationale':ra,'nested_checks':children,'supplemental_checks':[]})
allowed={'VERIFIED','ERROR','UNJUSTIFIED','AMBIGUOUS','DEPENDS ON EARLIER ERROR','NOT MATHEMATICAL','NOT VERIFIABLE FROM PROVIDED MATERIAL'}
assert len(records)==419 and sum(len(r['nested_checks']) for r in records)==834
assert all(r['status'] in allowed and all(n['status'] in allowed for n in r['nested_checks']) for r in records)
precedence=['ERROR','DEPENDS ON EARLIER ERROR','UNJUSTIFIED','AMBIGUOUS','NOT VERIFIABLE FROM PROVIDED MATERIAL']
for r in records:
 states={n['status'] for n in r['nested_checks']}
 if states:
  agg=next((s for s in precedence if s in states), 'VERIFIED' if 'VERIFIED' in states else 'NOT MATHEMATICAL')
  assert agg==r['status'],(r['id'],agg,r['status'])
meta={
'pass':'A','focus':'Independent local source-ordered verification of all definitions, hypotheses, calculations, limits and theorem applications',
'source_filename':'proof.tex','source_sha256':expected,'inventory_sha256':invhash,
'source_lines_examined':[1,948], 'containers_examined':len(records),'nested_checks_examined':sum(len(r['nested_checks']) for r in records),
'supplemental_checks_proposed':0,'formulas_examined':571,'inline_formulas_examined':512,'display_formulas_examined':59,
'algebra_bearing_containers_examined':106,'external_theorem_containers_examined':22,'proof_environments_examined':8,
'mathematical_containers_examined':388,'non_mathematical_containers_examined':31,
'container_status_counts':dict(collections.Counter(r['status'] for r in records)),
'nested_status_counts':dict(collections.Counter(n['status'] for r in records for n in r['nested_checks'])),
'uncovered_containers':0,'missing_nested_verdicts':0,
'independence':'Read full source in order, exact target, neutral frozen inventory/formula/notation files and independently retrieved original external article. No earlier audit, route, checkpoint, dependency-provenance or other pass output was read. One agent-status listing exposed only names/statuses, no conclusions.',
'primary_source':{'url':'https://link.springer.com/article/10.1007/s00526-024-02750-4','inspected':'Assumptions 2.1 and 3.1, Definition 3.2, Theorem 3.3, equations 3.4-3.7','retrieval_refs':['turn78view0','turn79view0','turn79view1','turn79view2','turn79view3','turn83view0']},
'computational_check':{'method':'Python fractions.Fraction exact rational summation','inputs':'J1(3) terms m=0..3; J1(4) terms m=0..4','outputs':['669/2048','-2/45'],'scope':'Confirms exact displayed partial sums; alternating-series remainder direction proved analytically. No floating point used.'},
'overall':'INCONCLUSIVE','overall_scope':'Three minor interpretation issues remain at S0242, S0247 and S0304; no definite substantive error or fatal defect was established. The main mathematical chain was affirmatively reconstructed using the precise, available fixed-profile choices and proved uniform bounds.',
'child_rationale_convention':'Where one calculation proves all subclaims, the parent reconstruction is repeated in each child record. Explicit ambiguous subclaims have independent child-level rationales; layout-only frozen children are marked NOT MATHEMATICAL.'
}
(root/'pass_a.json').write_text(json.dumps({'metadata':meta,'records':records},ensure_ascii=False,indent=2)+'\n')
print(json.dumps(meta['container_status_counts']))
print(json.dumps(meta['nested_status_counts']))
print('pass_a.json bytes', (root/'pass_a.json').stat().st_size)
