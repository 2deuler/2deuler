# PASS B — independent re-derivation of frozen v1

**Overall: INCONCLUSIVE as written.** This pass reconstructed the intended main mechanism without finding a fatal obstruction to the existence construction. It did find literal source omissions and ambiguities, most consequentially the missing definition of the bump family across scales. The relevant estimates do not follow from support, positivity and unit mass alone. The ledger therefore retains `UNJUSTIFIED` for those estimates and their substantive descendants. This is not a counterexample to the target theorem.

## A. Scope, source identity, and independence

Examined `proof.tex`, lines 1–948, as the immutable copy of `candidate_proof.tex`. Its SHA-256 is `b6741b471ba2f128b147f5a5c05fea0afe639c2c3a535b99a5afaf03ea6d4a43`. The initial neutral inventory SHA-256 is `efbd3fc4311f910b394581f46718f3b73a03f99a5891b38d2e7e2be24d7b9b71`. No TeX inclusion or bibliography-file dependencies occur. All declared macros, theorem environments, equation references, source containers and inventoried formulas were inspected. No frozen source or inventory was edited.

The full audit prompt, exact target, source, neutral sentence/child inventory, formula inventory, and notation inventory were the audit inputs. The pass first read all 948 source lines, then independently reconstructed the background, seed, translating dipole, moving-source reduction, raster timing, averaging, temporal projection, stress update, parameter choices, time iteration, weak trace and normalization. Each source sentence and each of its shared children was then compared against those calculations. The permanent identifiers and boundaries were not changed.

There is one explicit independence limitation. The original HTML theorem/background check was performed and reported to the coordinator **before** an accidental exposure to another pass's result. A `list_agents` call, made solely to check for a spare delegation slot, automatically displayed the completed external-theorem subagent summary from PASS C. No other pass file was opened, no further agent inventory call was made, and the coordinator was notified immediately. The original HTML had rendered the operator-domain/codomain line of Assumption 3.1 as an image; that particular line had not yet been inspected. The subsequent original-PDF check of that line is therefore recorded as a **post-exposure primary recheck**, not as clean pre-exposure independence. The other manuscript derivations were independent. The coordinator has been told this exact chronology and can commission a fresh context for a revision.

The original primary source was retrieved directly at [Springer, DOI 10.1007/s00526-024-02750-4](https://link.springer.com/article/10.1007/s00526-024-02750-4), with a later [original-PDF recheck](https://link.springer.com/content/pdf/10.1007/s00526-024-02750-4.pdf). Retrieval references and chronology are in the JSON metadata.

Technical limitation: SymPy was unavailable in both Python environments tested. No successful symbolic-computation check is claimed. All tensor, differential, scaling and timing identities below were re-derived algebraically by hand. Python exact rational arithmetic independently checked the two Bessel partial sums.

## B. Coverage

| Item | PASS B coverage |
|---|---:|
| Source lines / represented lines | 948 / 948 |
| Permanent containers examined | 419 / 419 |
| Modes | 380 sentences, 37 structural, 2 boundary groups |
| Compound containers | 252 |
| Shared nested checks examined | 834 / 834 |
| Proposed supplemental checks | 2, under S0158 and S0164 |
| Mathematical containers examined | 388 / 388 |
| Non-mathematical containers inventoried | 31 / 31 |
| Inline formulas / displays examined | 512 / 59 |
| Algebra-bearing containers independently checked | 106 / 106 |
| Theorem-application containers examined | 22 / 22 |
| Proof environments / major results examined | 8 / 8 |
| Uncovered containers / missing B verdicts | 0 / 0 |
| Missing shared-child B verdicts | 0 |

All 571 formula occurrences were also checked against their exact source byte spans, source digests and parent containers. Counts remain those of the frozen inventory, not a newly invented denominator. There are 346 `VERIFIED`, 10 `AMBIGUOUS`, 32 `UNJUSTIFIED`, and 31 `NOT MATHEMATICAL` parent verdicts. No unconditional `ERROR` verdict was assigned: the potentially false statements below have materially different possible readings or missing construction specifications.

The 42 non-verified mathematical parents require coordinator escalation. This pass has not assigned reconciliation `R` identifiers or purported to resolve a dispute by comparison with another pass. The two additional child checks were audited immediately and notified to the coordinator for permanent local child IDs.

## C. Container and child ledger

`pass_b.json` contains **one record for every S0001–S0419**, in frozen source order, with its full unchanged source anchor, filename, inclusive lines, mode, mathematical classification, exact container SHA-256, B verdict, affirmative reconstruction or issue, all 834 shared child verdicts, and the two proposed supplemental checks. The parent SHA field is the digest of the container, not a copy of the whole-manuscript digest. Parent conclusions are not substituted for missing child verdicts; all shared child IDs are present.

The remaining sections preserve the independent calculations behind the concise ledger. A final table lists every parent requiring escalation, followed by its unchanged source anchor.

## D. Independent reconstruction

### Initial normalization, background and rough-data seed

The radial probability cutoff gives

\[
(K*a)(x)=\frac{x^\perp}{2\pi|x|^2}\int_{|y|<|x|}a(y)\,dy.
\]

Hence \(L_a=K-K*a\) is compactly supported and belongs to \(L^1\). For finite signed \(\mu\), Tonelli proves \(\|L_a*\mu\|_1\leq\|L_a\|_1\|\mu\|_{\mathcal M}\). Since \(a\) is even, \(1-\widehat a=O(|\xi|^2)\) near zero; consequently

\[
\sup_\xi(1+|\xi|^2)|(1-\widehat a(\xi))m(\xi)|^2<\infty.
\]

Multiplying by \(|\widehat\mu|^2/(1+|\xi|^2)\) establishes the global \(L^2\) remainder using exactly inhomogeneous \(H^{-1}\). The low-frequency velocity has an integrable Fourier transform, as do all its derivatives; positive derivatives also have square-integrable transforms. This proves the decomposition without requiring zero circulation or a global \(L^2\) canonical velocity. The wording issue in S0049 is isolated below.

The original Crippa–Stefani result supplies the bounded-vorticity Lagrangian background. Volume preservation can be recovered directly: mollified spatial flows have determinant one, their Osgood stability gives convergence forward and backward, and bounded displacement supplies a common compact set for dominated convergence. Thus the every-time transported representative is continuous in \(L^1\cap L^2\), including at zero. The near/far estimate gives \(V\in C_tL^\infty\). Signed weak-\(L^2\) control plus boundedness yields \(V\in L^3\) with

\[
\|V\|_3^3\leq C\|\nu\|_1^2\|V\|_\infty.
\]

Writing \(F_t=\int_0^tV\nu\,ds\), the integrated vorticity equation gives \(\nu(t)-\nu_0=-\operatorname{div}F_t\). The multiplier of \(-K\operatorname{div}\) is, up to sign, \(\xi^\perp\otimes\xi/|\xi|^2\), whose Euclidean operator norm is one. Therefore

\[
\|V(t)-V_0\|_2\leq t\|V\|_{L^\infty_{t,x}}\|\nu_0\|_2,
\quad
\|V(t)-V(s)\|_2\leq C_T|t-s|.
\]

The spatial derivative multiplier is also bounded on \(L^2\). This gives \(\nabla V,\partial_tV\in L_t^\infty L_x^2\). Spatial approximation justifies the curl of the nonlinear term, so transport makes \(\partial_tV+(V\cdot\nabla)V\) curl-free; a pressure exists on the simply connected plane. Interpolating the relative \(L^2\) difference with boundedness gives the printed \(L^3\) continuity. No smoothness upgrade was imported from the external theorem.

For the seed, the multiplier is \(e^{-t^4|\xi|^4}\), so

\[
\partial_tW=-4t^3\Delta^2W,
\qquad
\operatorname{div}\bigl(\nabla\Delta W+(\nabla\Delta W)^T\bigr)=\Delta^2W.
\]

These two identities independently fix the negative sign of the derivative stress. The cancellation \(\Delta W=\nabla^\perp\operatorname{curl}W\) turns its global \(L^1\) cost into \(t^3t^{-2}\|\sigma_0\|_{\mathcal M}=O(t)\|\sigma_0\|_{\mathcal M}\). All global cross stresses use \(W\in L^1\), not global energy of \(V\). The approximate identity gives the exact strong initial local trace.

### Dipole and variable radius

The Bessel partial sums were checked with rational arithmetic:

\[
\sum_{k=0}^3\frac{(-1)^k(3/2)^{2k+1}}{k!(k+1)!}=\frac{669}{2048}
=\frac32\frac{223}{1024},
\qquad
\sum_{k=0}^4\frac{(-1)^k2^{2k+1}}{k!(k+1)!}=-\frac2{45}.
\]

The next-term signs and decreasing tail ratios justify both inequalities. At a positive root \(\beta\), the recurrence and ODE give \(J_1'=J_0\neq0\) and \(J_1''=-J_0/\beta\). Both stream-function branches therefore have boundary values \(-\sin\theta\), first radial derivatives \(\sin\theta\), and second radial derivatives \(-2\sin\theta\). The velocity is \(C^1\), as stated.

For \(q=\psi+x_2\), let \(w=D-e_1=\nabla^\perp q\). Then \(w^\perp=-\nabla q\), and in the disk \(\operatorname{curl}w=-\beta^2q\). Consequently

\[
(w\cdot\nabla)w
=\nabla\left(\frac{|w|^2}{2}+\frac{\beta^2q^2}{2}\right).
\]

The pressure has the manuscript's sign. Matching traces and \(q=0\) eliminate boundary distributions. Spatial scaling gives the printed norm exponents: \(L^2\), curl \(L^1\), and gradient \(L^1\) are invariant; \(L^{3/2}\) is \(r^{1/3}\). The scaled pressure needs the explicit definition \(P_r=r^{-2}P(x/r)\), after rotation.

For radius differentiation, direct differentiation gives

\[
\partial_rD_r=-r^{-2}(D+y\cdot\nabla D),
\quad
\operatorname{div}(D_r\otimes x/r)=r^{-1}(2D_r+x\cdot\nabla D_r).
\]

Their combination is precisely S0152. The latter divergence vanishes in the exterior by homogeneity and has scale-invariant \(L^1\) norm. It is even, so all first moments vanish. Its integral is zero because the exterior dipole has zero circular vector average. The symmetric anti-divergence estimate follows independently by integrating a degree-minus-one kernel in the core and its degree-minus-three Taylor remainder in the exterior. **Both** moment cancellations are required for global \(L^1\).

For differentiable parameters, the trajectory speed \(X'=\eta\xi/r\) exactly cancels the traveling nonlinear term. The remaining coefficient is \(\eta'+\eta r'/r=(\eta r)'/r\), yielding the packet identity with the correct signs. Positivity alone is insufficient to state this identity for arbitrary temporal functions; later visits do supply piecewise smooth parameters.

The compact-source impulse was independently evaluated by the boundary integrals. On a circle of radius \(R\), the scaled stream function is \(-r\sin\theta/R\), while the exterior potential is \(-r\cos\theta/R\). Therefore

\[
\int_{B_R}D_r=\pi r\xi,
\qquad
\int_{B_R}\nabla\Pi_r=-\pi r\xi,
\qquad
\int Z_r=2\pi r\xi.
\]

The compact zero-moment difference can thus be inverted with global \(L^1\) stress. Integrating the core and annulus gives \(\|Z_r\|_1\leq Cr(1+|\log r|)\). This confirms the \(2\pi\) normalization and the intrinsic error estimate, rather than accepting them from resemblance to a known dipole.

### Exact raster timing, averaging, global integrability and parameters

On an interior row,

\[
\frac{ds}{dt}=\frac{\eta_i}{r_0c},
\qquad
dt=\frac{r_0c}{\eta_i}\,ds.
\]

On a ramp of duration \(T_b\), the traversed length is \(\eta_iT_b I_\zeta/(r_0e)\). Thus \(T_b=r_0eL/(\eta_iI_\zeta)\), and the total scan time is exactly \((r_0/\eta_i)B_i\). Solving this time equation simultaneously with the desired coefficient weight gives

\[
\eta_i^2=\frac{\tau dB_i}{2\pi\tau_i},
\qquad
r_{0,i}=\frac{\tau d}{2\pi\eta_i},
\qquad
\frac{2\pi\eta_i r_{0,i}}\tau=d.
\]

The full-cycle average sign follows from

\[
\frac d{dt}(\eta rU_H(x-X))
=(\eta r)'U_H-\eta^2\partial_\xi U_H.
\]

The endpoint term is zero on each visit. Summing all visits gives the divergence of the **sum of all four** rank-one tensor averages. Resets do not add time deltas because their amplitude and source coefficients have flat zero traces. Ramps contribute no excessive floor mass: \(\int\zeta^2\leq\int\zeta\).

The quadrature proof, without presupposing bump scaling, yields the precise bound

\[
\left\|d\sum_kF(kd)-a\right\|_1
\leq d\left(\|\partial_\perp a\|_1+
\|a\|_1\|\partial_\perp U_H\|_1\right)
+H\|\nabla a\|_1.
\]

This exposes exactly where the missing family definition enters. If \(U_H=H^{-2}U_1(\cdot/H)\), then the manuscript's bound follows and tends to zero with \(d=H^2\). Mere support in \(B_H\) does not provide it.

For the projection, direct use of \(\Delta G=\delta_0\) gives

\[
\mathbb P(U_H\xi)=U_H\xi-(D^2G*U_H)\xi.
\]

Moving one derivative to the bump proves bounded smooth core behavior. Radial logarithmic averaging gives a degree-minus-two exterior tail, hence membership in every finite \(L^p\), \(p>1\). For a fixed dilation, the norms are \(H^{2/p-2}\). No general \(L^1\) Leray-projection bound is used. Direct differentiation of the time primitive gives the manuscript's pressure sign

\[
p_Q=-\pi_{\mathcal U}+\overline{\pi_{\mathcal U}},
\qquad
\partial_tQ+\mathcal U+\nabla p_Q=\overline{\mathcal U}.
\]

The full tensor expansion contains every cross term once; subtracting \(qI\) from stress corresponds to subtracting \(q\) from pressure. Each old-new product is globally integrable by \(L^3\times L^{3/2}\), each packet-corrector product by \(L^2\times L^2\). This is genuinely needed: the manuscript's swirl counterexample has an integrable curl and finite energy but a nonintegrable product with a unit-circulation background, as direct radial integration confirms.

At fixed coarse data and positive floors, \(dB_i\) tends to a positive finite mass. Consequently \(\eta_i\) has fixed upper/lower bounds and \(r\asymp H^8\). The parameter table is:

| Quantity | Independently computed order, for a fixed dilated bump |
|---|---:|
| Row spacing / cycle time | \(H^2\), \(H^6\) |
| Principal radius | \(H^8\) |
| Compact-source radius divided by bump radius | \(r^{1/5}/H=O(H^{3/5})\) |
| Intrinsic stress | \(O(H|\log H|)+O(H^8)\) |
| Principal \(L^{3/2}\) | \(O(H^{8/3})\) |
| Corrector \(L^2\), curl \(L^1\) | \(O(H^5)\) |
| Corrector \(L^{3/2}\) | \(O(H^{16/3})\) |

All requirements have an eventual threshold after coarse approximation, regularization, floors and ramp geometry are frozen. Finite coarse subdivision lets one take the maximum of finitely many thresholds. There is no incompatible limit order, radius/floor circularity, time-freezing derivative loss, or uniform-in-stage \(L^3\) assertion in this reconstruction. The constant multiplying \(\sqrt\delta\) comes only from coefficient mass and fixed dipole/direction norms.

Spatial mollification adds

\[
C_\ell=v_\ell\otimes v_\ell-(v\otimes v)_\ell
\]

on the stress side with the printed positive sign. The fixed cycle image is compact in \(L^2\), so the commutator vanishes uniformly in \(L^1\). The already averaged tensor is integrable, so its convolution error also tends to zero. A cycle-constant mollification scale avoids a time derivative of the kernel, and no old field is remollified.

### Trace, every-time curl, and canonical normalization

The anchor lemma's derivative pairing has exactly the displayed signs. Local kinetic-energy bounds and global stress \(L^1\) bounds make it Lipschitz; zeros at anchor times force its limit to zero. A global \(L^2\) weak cluster point is divergence-free and annihilates all compact solenoidal tests. Testing with \(\nabla^\perp\phi\) also forces curl zero. Its Fourier transform therefore vanishes off zero, and an \(L^2\) transform cannot have a point mass at zero. This proves the full weak limit rather than only a solenoidal-test trace.

Dyadic intervals of the same residue modulo three have actual gaps: their consecutive endpoints are \(2\cdot2^j\) and \(4\cdot2^j\), with \(3\cdot2^j\) between. Frozen pieces sum to the old stress, so processing colors against the current background leaves precisely the sum of errors. At a time \(t\leq T\), every active patch lies inside \((0,4T)\); this yields the manuscript's exact stage bound. Its decay is \(4^{-q}\), summable. The separate subcritical budgets decay as \(2^{-q}\).

Conditional on LER, the correction series converges uniformly in global \(L^2\) on \((0,T]\), the curl series converges absolutely in \(L^1\) at **every fixed positive time**, and the trace follows from a finite-series/small-tail argument. Strong local \(L^2\) convergence passes the quadratic tensor in \(L^1\). A time cutoff at zero has an \(O(\varepsilon)\) omitted convection contribution; its derivative is a mass-one approximate identity for the weakly continuous local pairing. Hence the exact target initial-value formulation follows.

The final canonical lemma is valid independently of LER. The harmonic field \(h=u-K*\mu\) satisfies

\[
|h(x)|\leq\fint_{B_R(x)}|U|
+\frac{C\|v\|_2}{R}+\frac{C\|\mu\|_{\mathcal M}}R.
\]

The first term tends to zero by \(U\in C_0\); the others tend to zero explicitly. Thus \(h=0\). Taking the *fixed* \(U=V_0\) makes the global \(L^2\) perturbation hypotheses hold at every constructed time, with no new exceptional-time selection.

## E. Source findings and proposed repairs

No unconditional counterexample to the main construction or target theorem was established. The following issues are kept distinct from a claim that the intended construction is impossible.

1. **E3 — missing cross-scale bump specification; major for the literal derivation.** Earliest source declaration: S0164, lines 371–373. First displayed estimate requiring it: S0210, lines 482–488; also S0231, S0237, S0239. The source only says that \(U_H\) is a radial smooth probability bump supported in \(B_H\). Fix a radial smooth probability \(U\) and let \(U_H(x)=H^{-4}U(x/H^2)\) for \(0<H<1\). It meets that description, but \(\|\nabla U_H\|_1=H^{-2}\|\nabla U\|_1\), and \(\|\mathbb P(U_H\xi)\|_2=H^{-2}\|\mathbb P(U\xi)\|_2\), contradicting the asserted universal \(H^{-1}\) scaling. The projected profile is nonzero: its exterior Hessian tail is nonzero. This independently confirms failure by derivative scaling and projected-profile scaling. **Proposed repair:** explicitly set \(U_H=H^{-2}U_1(\cdot/H)\) for one fixed radial nonnegative smooth probability profile. That repairs the estimates used here; the simultaneous parameter derivation then works. It does not change the datum class or target. Descendants listed in the JSON retain `UNJUSTIFIED` until the repair is reviewed.

2. **E3 — missing temporal regularity for the packet identity; moderate locally, not a demonstrated downstream failure.** S0158–S0159, lines 353–359, assume only positive \(r\) and nonnegative \(\eta\) while using derivatives and products with a changing profile. Arbitrary discontinuous parameters do not justify this distributional product rule. **Proposed repair:** state the identity first for positive \(C^1\) parameters on a visit, then specify the piecewise smooth extension at flat-zero resets. The later actual construction supplies this regularity, so this repair restores the intended application without changing its estimates.

3. **E4 — undefined scaled pressure; minor.** S0141, lines 305–314, uses \(P_r\) without defining it. **Proposed repair:** define the rotated \(P_r(x)=r^{-2}P(x/r)\). The PDE scaling and all norm estimates were independently verified with this definition; no pressure coefficient or sign error was found.

4. **E7 — ambiguous square-integrability pronoun; minor.** S0049, lines 98–100, says the multipliers \(m\widehat a\) and \(\xi^\alpha m\widehat a\) are integrable and “for \(|\alpha|\geq1\) they are square integrable.” If “they” includes \(m\widehat a\), the statement is false: \(\widehat a(0)=1\), so its squared integral contains \(\int_0^\varepsilon dr/r\). Only the positive-order family is square-integrable. **Proposed repair:** replace the pronoun by the explicit positive-order multiplier. The derivative conclusions survive and were independently proved.

5. **E7 — unspecified topology/raw temporal smoothness; minor and repaired downstream by the already-present mollification.** S0242, lines 550–552, says the resulting velocity is piecewise smooth in time before smoothing the raw profile. In \(L^2\), that is false for a moving raw dipole: differentiating the Bessel ODE gives

   \[
   \partial_\rho^3\psi(1^-)= (6-2\beta^2)\sin\theta,
   \qquad
   \partial_\rho^3\psi(1^+)=6\sin\theta.
   \]

   Thus \(D\) has a nonzero second-derivative jump. On a row with nonzero translation speed, a third temporal derivative contains a surface measure and cannot belong to \(L^2\). Independently, the interior normal derivative of \(\omega=-\beta^2q\) has boundary value \(-2\beta^2\sin\theta\), while the exterior value is zero. These checks agree. The wording can instead mean smoothness in a distribution topology, or the later smoothed increment, so the parent is `AMBIGUOUS`, not an unconditional `ERROR`. **Proposed repair:** assert continuity for the raw field and reserve piecewise time smoothness in velocity norm spaces for the spatially mollified field. The construction only needs the continuity already proved.

6. **E10 — ambiguous symmetry scope; minor.** S0247, lines 568–576, says “All displayed tensors are symmetric,” while displaying norms of individual \(u\otimes v\), \(u\otimes Q\), and \(v\otimes Q\). A single cross tensor is not generally symmetric; its paired sum is. **Proposed repair:** name the total stress and paired cross sums explicitly. Their symmetry and every printed norm inequality are correct.

7. **E7 — open patch versus interval; minor for actual global application.** S0268 calls \(J\) an “open patch”; S0278 requires a single \([a,b]\Subset J\) containing all temporal support. This fails for a disconnected open set with support in separated components. **Proposed repair:** call \(J\) an open interval, or apply the same construction on finitely many disjoint subintervals covering the compact support. Actual global patches \(I_j\) are intervals, so the global application does not introduce this case.

The two proposed supplemental checks are: temporal regularity under S0158, and the cross-scale profile family under S0164. All other issues are already covered by existing full-sentence/shared-child scopes.

## F. External theorem and elementary theorem matching

For the one substantive cited research theorem, the source loci are Assumption 2.1, Assumption 3.1, Definition 3.2 and Theorem 3.3. The original theorem requires the specified size/difference kernel estimates and bounded divergence, with a no-flow condition only when there is a boundary. Its datum is \(L^1\cap L^\infty\); its conclusion is a global Lagrangian weak vorticity solution with canonical velocity, finite-horizon bounds and log-Lipschitz modulus. This matches the manuscript's use and imposes no sign, support or global-energy restriction. genui{"citation":{"refs":["turn81view0","turn81view1","turn81view2","turn81view3","turn87view0"]}}

The manuscript's kernel identity proves the required difference bound exactly, and \(\operatorname{div}K=0\) gives the divergence bound with any positive allowed constant. The plane has no boundary. S0037–S0039 give \(\nu_0\in L^1\cap L^\infty\). Every-time representatives, norm preservation, \(L^2\) relative velocity and the pressure are derived internally rather than silently claimed from Theorem 3.3.

The post-exposure PDF recheck verifies that Assumption 3.1 prints the mapping \(K:L^1\cap L^p_{ul}\to C_b^{0,1-2/p}\). Taking any finite \(p>2\), for example \(p=3\), matches this mapping for the present kernel; the bounded data also lie in that domain. This narrow formula check carries the independence limitation stated above. genui{"citation":{"ref":"turn103view0"}}

For the other 20 flagged theorem-bearing containers, the necessary hypotheses were checked directly:

| Containers | Rule and hypotheses checked |
|---|---|
| S0040, S0069, S0110 | Tonelli/Fubini/dominated convergence: nonnegative total-variation integrands or a common compact bounded dominator. |
| S0046, S0338 | Young: an \(L^1\) kernel with finite measure, or \(L^{6/5}\) mollifier with \(L^2\) input and \(1+1/3=5/6+1/2\). |
| S0048, S0050, S0104 | Plancherel/inversion/Riemann–Lebesgue: the explicitly bounded weighted multiplier and the stated \(L^1\)/\(L^2\) transforms; dominated convergence for the contractive multiplier. |
| S0065, S0067 | Osgood and flow Jacobian: bounded speed, common Osgood modulus, spatially smooth approximating fields, and zero divergence. |
| S0081, S0082 | Chebyshev/layer cake: positive threshold, nonnegative distribution function, near-convolution in \(L^1\), bounded upper velocity cutoff. |
| S0126, S0128 | IVT/ODE uniqueness: continuous Bessel function with strict opposite signs; regular ODE coefficients near positive \(\beta\), prescribed value and derivative. |
| S0214, S0232 | Banach-valued FTC/Minkowski: integrable \(L^1_x\) derivative and finite Bochner norms of projected-bump translates. |
| S0256, S0309 | Compact-image approximation and Hölder: continuous image of a compact cycle in \(L^2\); old continuous \(L^3\) and new \(L^{3/2}\). |
| S0357, S0409 | Weak compactness and Weyl: bounded sequence in the Hilbert space \(L^2\); a locally integrable distribution satisfying \(\Delta h=0\) on all of the plane. |

The elementary theorem applications themselves introduce no further missing hypotheses, apart from the explicit construction/notation conditions already identified.

## G. Major dependencies and error scope

| Major result | Principal parent dependencies | B conclusion |
|---|---|---|
| Canonical decomposition S0034–S0039 | S0040–S0052 | Established; S0049 needs only a wording clarification for its positive-order claim. |
| Background S0060–S0061 | S0037–S0039, S0054–S0058, S0062–S0090 | Established, with the narrowly limited external-mapping independence provenance disclosed. |
| Seed S0096–S0100 | S0038, S0060–S0061, S0101–S0114 | Established independently of local repair. |
| LER S0261–S0275 | S0130–S0168, S0171–S0219, S0221–S0260, S0276–S0349 | Conditional as written, chiefly through S0164 → S0210/S0231/S0237/S0239; proposed fixed-family definition repairs this dependency. |
| Anchor lemma S0351–S0353 | S0354–S0360 | Established independently of LER. |
| Global iteration S0361 | Seed, LER, S0362–S0406, anchor lemma | Conditional on LER; time covering, color processing, trace argument and limit passage independently check out. |
| Canonical lemma S0407–S0408 | S0040–S0042, S0409–S0413 | Established independently of LER. |
| Main theorem S0414 | S0361, S0396–S0406, S0407–S0417 | Not unconditionally verified as written because of the LER specification gap; no counterexample to the target was found. |

The raw temporal smoothness ambiguity, scaled pressure notation, and cross-tensor wording do not destroy any independent estimate used after the existing spatial mollification. The disconnected-patch interpretation is absent from the actual dyadic application. The bump-family issue is the only retained finding that reaches the main construction's smallness estimates.

Edge cases actually investigated include the zero datum/zero stress, omitted zero-mass directions and idle slots, arbitrary signs and noncompact support, nonzero circulation, near-zero Fourier frequency, positive-radius lower bounds, zero-amplitude resets with jumping centers, inherited unequal stress traces, every-time values at boundaries, endpoint cutoff signs, vanishing floors chosen before the fine scale, spatial tails, and the lack of a uniform \(L^3\) bound through iteration. Those checks are reflected in the per-container rationales rather than omitted after an early concern.

## H. Escalation anchors

The following automatically appended list preserves every non-verified mathematical parent and its full unchanged source text. These are B findings, not reconciled cross-pass conclusions.


### S0049 — AMBIGUOUS

`proof.tex`, lines 98–100; SHA-256 `7626a354b01faba65a25ebaace54918c064d15548b13c91cf9506479f4d06bf5`.

```tex

The multipliers $m\widehat a$ and $\xi^\alpha m\widehat a$ are integrable;
for $|\alpha|\geq1$ they are square integrable.
```

Both displayed multipliers are L1. Only the positive-order family xi^alpha m a-hat is L2; m a-hat itself has logarithmically divergent squared integral at zero. The pronoun 'they' has two materially different readings.

### S0141 — AMBIGUOUS

`proof.tex`, lines 305–314; SHA-256 `2d2cb24d2bcf82ead05965ce04de80a5ba01d28844f961e6e0bb41a39f3ed90f`.

```tex
 Then
\begin{equation}\label{eq:dipole}
 -r^{-1}\partial_\xi D_r+\Div(D_r\otimes D_r)+\nabla P_r=0,
 \quad \Div D_r=0,
\end{equation}
and
\begin{equation}\label{eq:dipole-norms}
 \norm{D_r}2=C_2,\quad \norm{\curl D_r}1=C_\omega,\quad
 \norm{D_r}{3/2}=C_{3/2}r^{1/3},\quad \norm{\nabla D_r}1=C_\nabla.
\end{equation}
```

Change of variables gives all four norm scalings and div=0. The scaled Euler identity holds for P_r(x)=r^{-2}P(x/r), rotated with D, but the manuscript never defines P_r; this is a local notation ambiguity.

### S0158 — UNJUSTIFIED

`proof.tex`, lines 353–353; SHA-256 `6cc8b9ab8cf9a8b5192e7e9f8c1489a99e964f2d49ef2cecac544bfdfbe6bc28`.

```tex
Let $r(t)>0$, $\eta(t)\geq0$, and $X'=\eta\xi/r$.
```

The positive radius and nonnegative amplitude ensure the stated trajectory has the intended direction. Temporal differentiability/absolute continuity is not included here although the next formula uses r' and eta'.

### S0159 — UNJUSTIFIED

`proof.tex`, lines 353–359; SHA-256 `841c57e5e71eb01a1e8f07177e476cbcdb019c3d266442233e1e0e80c897c88a`.

```tex
 By
\eqref{eq:dipole}--\eqref{eq:radial}, the packet
$v(t,x)=\eta(t)D_{r(t)}(x-X(t))$ satisfies, after adding gradients to pressure,
\begin{equation}\label{eq:packet}
 \partial_tv+\Div(v\otimes v)+\nabla p
 =(\eta r)'D_r/r+\Div(\eta r'F_r).
\end{equation}
```

For C1 parameters, differentiating the translated packet cancels -eta^2 partial_xi D_r/r against its exact nonlinear traveling term; the residual is (eta'+eta r'/r)D_r+div(eta r'F_r). For merely positive r and nonnegative eta as stated, these products/derivatives are not justified.

### S0164 — AMBIGUOUS

`proof.tex`, lines 371–373; SHA-256 `a5a9ff84d43640fc8b0f60b309f47f499bc8971390cffc22e6c094a8c57fb1be`.

```tex


Let $U_H$ be a nonnegative radial smooth probability bump supported in $B_H$.
```

A radial nonnegative smooth probability bump with support in B_H exists. The source does not explicitly require the family U_H=H^{-2}U_1(x/H), which later scale-uniform derivative estimates need.

### S0188 — AMBIGUOUS

`proof.tex`, lines 432–433; SHA-256 `2f71ca3e583a0b8447c2a93658ab0d8e96e7c256e3d18af7187dbb9da1587b2f`.

```tex

The auxiliary bump has width $H$, not $d$.
```

The intended physical bump radius is H, larger than d=H^2 for small H. A precise fixed-dilation definition is still absent from the earlier U_H declaration.

### S0210 — UNJUSTIFIED

`proof.tex`, lines 482–488; SHA-256 `6c2cb656228138ae6c23a139d7ef03aee61ed25390b9db3ffd2a4c74291edb0c`.

```tex

The raster quadrature obeys
\begin{equation}\label{eq:quad}
 \left\|d\sum_k\int a(s,kd)U_H(\,\cdot-s\xi-kd\xi^\perp)\,ds-a\right\|_1
 \leq C\left[d\bigl(\norm{\partial_\perp a}1+H^{-1}\norm a1\bigr)
 +H\norm{\nabla a}1\right].
\end{equation}
```

The rectangle-rule derivation yields d(||partial_perp a||_1+||a||_1||partial_perp U_H||_1)+H||grad a||_1. Replacing the derivative norm by C/H needs the unprovided fixed-dilation convention for U_H.

### S0215 — UNJUSTIFIED

`proof.tex`, lines 497–498; SHA-256 `b115861fdb3fee9bfcbd61d2dcef874a7c41d10a6370c960885285afc653d996`.

```tex

Summing yields the first two terms in \eqref{eq:quad}.
```

Summing the preceding inequality proves a bound with ||partial_perp U_H||_1. The printed C H^{-1} replacement depends on the missing scale convention identified at S0210.

### S0219 — UNJUSTIFIED

`proof.tex`, lines 503–504; SHA-256 `907e69031d85d54e551dbf93a8cd7ef700c5ef251e25b2b9f80926f285e32f86`.

```tex

Since $d=H^2$, the quadrature error tends to zero.
```

With a fixed dilated bump, d/H=H and H both tend to zero. Under only support and probability for U_H, the derivative term need not tend to zero, so the statement is conditional on the unstated dilation convention.

### S0231 — UNJUSTIFIED

`proof.tex`, lines 526–529; SHA-256 `a08b8f6786a3c532485fd2f637bcb95f9f88153d7a779f68502cb8cf50204275`.

```tex
 Scaling gives
\[
 \norm{Z_{H,\xi}}p\leq C_p H^{2/p-2}.
\]
```

If U_H=H^{-2}U_1(x/H), homogeneity gives Z_H=H^{-2}Z_1(x/H) and the norm exponent 2/p-2. The stated assumptions allow thinner bumps, so this scale-uniform conclusion is not established without that family definition.

### S0237 — UNJUSTIFIED

`proof.tex`, lines 540–546; SHA-256 `031f76919394837fa8e1fb29ef1094027ef0eb2356a75d86618b76a2c09862cf`.

```tex

If $B$ bounds $|(\eta r)'|$, bump scaling gives
\begin{equation}\label{eq:Q}
 \norm Q2\leq C\tau H^{-1}B,
 \quad\norm Q{3/2}\leq C\tau H^{-2/3}B,
 \quad\norm{\curl Q}1\leq C\tau H^{-1}B.
\end{equation}
```

Minkowski gives at most C tau B times ||Z_H||_2, ||Z_H||_3/2, or ||grad U_H||_1. The displayed H-powers follow for a fixed dilated bump but are not uniform for every admissible bump family as stated.

### S0239 — UNJUSTIFIED

`proof.tex`, lines 547–548; SHA-256 `6ac9fa68b8e0ff613f89d3839d67a775e82a4c358bec4cdbb3d87deac3d497f8`.

```tex

The curl estimate follows directly from $\norm{\nabla U_H}1=O(H^{-1})$.
```

Curl commutes with projection and is the first derivative of the unprojected bump. The asserted O(H^{-1}) is exactly the derivative scaling missing from the explicit definition of U_H.

### S0242 — AMBIGUOUS

`proof.tex`, lines 550–552; SHA-256 `1ecd9bfdabf3b36bdda36882845f536ef91a200bc18bbf6fab42b34a4c1f243a`.

```tex
 Its first time derivative may jump there, so the resulting
velocity is continuous and piecewise smooth in time; it is not asserted to
be globally time-smooth.
```

Continuity and possible jumps in the derivative at full-cycle endpoints are correct. Before spatial mollification, however, a translated C1 dipole is not piecewise C-infinity in time in L2: its third time derivative has a surface measure from the nonzero second-derivative jump of D. Later smoothing repairs the actually used increment.

### S0247 — AMBIGUOUS

`proof.tex`, lines 568–576; SHA-256 `06f878e9d63c5396981d720153f88327df6fecb88ce79ffb2a7a45d5df964f05`.

```tex
 All displayed tensors are symmetric;
the cross terms satisfy
\begin{align*}
 \norm{u\otimes v}1&\leq\norm u3\norm v{3/2}
 \leq C\norm u3\eta r^{1/3},&
 \norm{u\otimes Q}1&\leq\norm u3\norm Q{3/2},\\
 \norm{v\otimes Q}1&\leq\norm v2\norm Q2,&
 \norm{Q\otimes Q}1&=\norm Q2^2.
\end{align*}
```

The full stress and each paired cross sum are symmetric; individual displayed factors u tensor v, u tensor Q, and v tensor Q need not be. Holder gives all four norm inequalities/equalities. The phrase 'all displayed tensors' is therefore ambiguous unless restricted to the stress and paired sums.

### S0248 — UNJUSTIFIED

`proof.tex`, lines 576–577; SHA-256 `e20ecfcb1e8a9bf6d21cda50e303f6d7cc98a817476629409f9370888e62c055`.

```tex

These terms tend to zero at fixed coarse seed as $H\downarrow0$.
```

For a fixed dilated bump, v in L3/2 is O(H^{8/3}) and Q in L2/L3/2 is O(H^5)/O(H^{16/3}); the fixed old L3 norm then makes every displayed cross term small. This uses the unprovided U_H family convention.

### S0249 — UNJUSTIFIED

`proof.tex`, lines 577–578; SHA-256 `52d8c438376280939e27639bcb4a213c2dee786936f2c37d05087322dcd90c44`.

```tex

The same estimates give an arbitrarily small $L^{3/2}$ increment.
```

The triangle inequality bounds the increment's L3/2 norm by the principal O(H^{8/3}) plus projected O(H^{16/3}) terms, conditional on the same fixed-dilation specification.

### S0268 — AMBIGUOUS

`proof.tex`, lines 612–616; SHA-256 `1320d175405be645ed4e7a66b8a84faa998db6d29d743ff36769c331b18c8de6`.

```tex


Let $(u,R)$ be any current pair in this class, $J\Subset(0,\infty)$ an
open patch, and $S$ a prescribed symmetric tensor compactly supported in
time in $J$, piecewise continuous into $L^1$ on the inherited partition.
```

The current-pair and tensor hypotheses are explicit. 'Open patch' does not specify connectedness; the proof later requires a single compact interval inside J containing all the temporal support.

### S0270 — UNJUSTIFIED

`proof.tex`, lines 617–629; SHA-256 `2e1063ba8e712642f9a09537746268f01d66a52bcdf83441104ed406543ff6cd`.

```tex

For every $\varepsilon,\zeta,\kappa,r_*>0$
there are $w,E_{\rm total}$ compactly supported in time in $J$ such that
\[
 (\widetilde u,\widetilde R)=(u+w,R-S+E_{\rm total})
\]
is again an Euler--Reynolds pair in the admissible class,
$\Div w=0$, $E_{\rm total}$ is symmetric, and
\[
 \sup_J\norm{E_{\rm total}}1\leq\varepsilon,\qquad
 \sup_J\bigl(\norm w2+\norm{\curl w}1\bigr)\leq C\sqrt\delta+\zeta,
 \qquad \sup_J\norm w{3/2}\leq\kappa.
\]
```

The local construction gives these conclusions after fixing a dilated bump family and interpreting J as an interval (or repairing components separately). Those conventions are missing as written, so the fully quantified lemma is not yet established literally; all scale exponents, symmetry and algebra were independently reconstructed.

### S0275 — AMBIGUOUS

`proof.tex`, lines 636–638; SHA-256 `3e26ad725b91de90bd92bb13ec3b5847df569ec7fe6617c9570c0130a3611531`.

```tex

All outputs paste within the admissible class.
\end{lemma}

```

Continuous zero endpoint velocity traces and spatial-only divergence of piecewise bounded stresses permit pasting; the support/connected-patch issue is isolated at S0278.

### S0278 — AMBIGUOUS

`proof.tex`, lines 641–642; SHA-256 `f42a54892bb17e4c9e3fcde88987b14be771af84212db15c1bd4facaec073105`.

```tex

Choose $[a,b]\Subset J$ containing the temporal support of $S$ in its interior.
```

A compact temporal support in an open interval J fits in a smaller closed interval with interior margin. For an arbitrary disconnected open J this need not exist; the source's word 'patch' has not specified the needed interval hypothesis.

### S0306 — UNJUSTIFIED

`proof.tex`, lines 699–701; SHA-256 `9bf2c69f4b1930b1ebc76df2beea4f77035cecb6812a275f26164574db2f9ec8`.

```tex

Equation \eqref{eq:Q} makes the corrector $O(H_k^5)$ in $L^2$ and
curl $L^1$, and $O(H_k^{16/3})$ in $L^{3/2}$.
```

The formal exponents are 6-1=5 and 6-2/3=16/3. Their validity depends on the fixed-dilation U_H estimates missing from the explicit assumptions.

### S0308 — UNJUSTIFIED

`proof.tex`, lines 702–703; SHA-256 `5ee7458802c9d864844b14b8def983496310a04efd42aa8db8dce87613fd861a`.

```tex

Equation \eqref{eq:quad} makes the quadrature error tend to zero.
```

The quadrature bound tends to zero for a fixed dilated bump since d/H=H. Without that convention the derivative contribution is not controlled, as noted at S0210.

### S0309 — UNJUSTIFIED

`proof.tex`, lines 703–705; SHA-256 `f6133f1dfda1e856397ef86abc1f028ff4a8916a7541eb44015c19160539180a`.

```tex

Every cross term with the actual old $u$ tends to zero by the displayed
Hölder estimates and the finite bound $\sup_{[a,b]}\norm u3$.
```

The actual old velocity has finite sup L3 on the compact time interval by continuity. Holder then makes every cross term small provided the conditional Q estimates and principal norm estimates hold.

### S0325 — UNJUSTIFIED

`proof.tex`, lines 735–737; SHA-256 `157ee70378ac57999a1c9dc1951d0d0c6c9dab094ef51d535d6fcbdf5f00693c`.

```tex

Finally choose the cycle counts large enough that the row-rule amplitude
error and the $L^2$ and curl cost of $Q$ use at most the remaining $\zeta/3$.
```

At fixed coarse data the row amplitude error and the conditional projected-corrector L2/curl errors tend to zero, permitting the remaining zeta/3 allocation simultaneously.

### S0327 — UNJUSTIFIED

`proof.tex`, lines 739–741; SHA-256 `449c2b411cef1dd7cfffb2787e899c32789ffb076f34d7b62e6e231e16c0060d`.

```tex

The same cycle counts can make the two $L^{3/2}$ contributions sum to at
most $\kappa$ and all radii at most $r_*$.
```

The principal and conditional corrector L3/2 norms tend to zero, and all radii tend to zero. Thus the same sufficiently large counts work, once the missing fixed-dilation convention is supplied.

### S0328 — UNJUSTIFIED

`proof.tex`, lines 741–743; SHA-256 `d705e5a2426c1b5be8134c37f3019ccc3c1296d525eb62d09bc39b72964c0246`.

```tex

All these requirements have already been shown to improve as the counts
increase at fixed coarse data, so this is one compatible parameter choice.
```

There are only finitely many coarse cells and finitely many limiting constraints on each. Each has an eventual threshold, so taking a maximum proves compatibility; the proof depends on the conditional U_H scaling estimates.

### S0336 — AMBIGUOUS

`proof.tex`, lines 755–756; SHA-256 `e6a786e01336589555215704ec55d0b31d904b66cbb8af2b39b37dcceebe68e9`.

```tex

Both output supports are compact subsets of $J$.
```

Both corrections vanish outside [a,b], whose compact inclusion in J is needed. This is valid for an interval patch, with the disconnected-patch caveat in S0278.

### S0348 — UNJUSTIFIED

`proof.tex`, lines 779–780; SHA-256 `f0113bed848a15e64d889e3b43d5ae947fa4ae41c1809daed7cdacba9d63b6de`.

```tex

Thus the new stress and velocity remain in the stated admissible class.
```

The exact equation, symmetric piecewise-L1 stress, local/global velocity continuity, and finite partition properties established above meet every admissible-class item, conditional on the previously isolated construction conventions.

### S0361 — UNJUSTIFIED

`proof.tex`, lines 812–818; SHA-256 `1cae356502980f4a3a819c798539b5dd0f6e8e490f7c8d9e4c6f672d7217b466`.

```tex

\begin{proposition}[Global iteration]\label{prop:iteration}
The seed in Proposition~\ref{prop:seed} can be repaired
on $(0,\infty)$ to a global weak Euler solution with exact initial trace,
locally uniformly finite curl variation, and a globally $L^2$ perturbation
of the seed at each time, bounded uniformly on finite time horizons.
\end{proposition}

```

The global iteration is independently valid provided the local repair's intended fixed-dilation convention is made explicit. The source-level local lemma remains conditional, so this proposition is not unconditionally verified as written.

### S0373 — UNJUSTIFIED

`proof.tex`, lines 837–843; SHA-256 `5f672ad41b57618e297f258ef2077640bddfb7dfd0fb16e2c0cd621e7508b4bc`.

```tex

For patch $j$ apply LER with
\[
 \varepsilon_{qj}=\delta_{q+1}m_j/N,\qquad
 \zeta_{qj}=\sqrt{\delta_q}/N,\qquad
 \kappa_{qj}\leq2^{-q}/N.
\]
```

The prescribed S_qj has norm <=delta_q M_j, compact time support in the interval I_j, symmetry and the inherited one-sided regularity. Positive budgets meet LER's inputs; this application is conditional on the local lemma's unresolved bump-family specification.

### S0379 — UNJUSTIFIED

`proof.tex`, lines 850–851; SHA-256 `9582647361b57925465f048b120df56a1150cce16466b8c081ad23e43020dffa`.

```tex

Thus the finite-stage admissible class is retained.
```

Conditional on LER, finite local sums of continuous velocities and piecewise-L1 stresses retain every admissibility condition on positive compact time intervals.

### S0384 — UNJUSTIFIED

`proof.tex`, lines 866–872; SHA-256 `4c04663d57e3fe5c10bc3532153ca0873b4f6fcffb1f6aeff13ab25365d90913`.

```tex

If $0<t\leq T$ and a patch is active, $I_j\subset(0,4T)$, so
\begin{equation}\label{eq:increment-stage}
 \sup_{0<t\leq T}\left(\norm{w_q(t)}2+
 \norm{\curl w_q(t)}1\right)
 \leq[NC\sqrt{\Theta(4T)}+1]\sqrt{\delta_q}.
\end{equation}
```

If t in I_j and t<=T, then 2^{j-1}<T and the upper endpoint 2^{j+1}<4T. LER gives each increment <=C sqrt(delta_q Theta(4T))+sqrt(delta_q)/N; at most N summands yield exactly the bracket.

### S0396 — UNJUSTIFIED

`proof.tex`, lines 890–892; SHA-256 `f8fe76cc9e408a1f11a738c7bf0ea794132f744e844391fbfaf0a4e132d04182`.

```tex

Together with the seed trace this gives
$u\in C_w([0,\infty);L^2_{\rm loc})$ and $u(0)=u_0$.
```

Add the seed's strong local trace to the weakly zero correction. Positive-time strong local continuity and weak continuity at zero give the exact C_w class and prescribed initial value, conditional on existence of the repaired stages.

### S0397 — UNJUSTIFIED

`proof.tex`, lines 892–895; SHA-256 `01573838ff8374c8233494458d3ea72cda2d303ddd4633a187eda3c849adf889`.

```tex

At each fixed $t>0$, the curl series converges absolutely in $L^1$ by
\eqref{eq:increment-stage}, and its sum is the distributional curl of the
velocity limit.
```

The curl L1 bounds are absolutely summable at every fixed positive time. Pairing the L1 curl sum and the L2 velocity sum against compact derivatives identifies their distributional relation without an a.e.-time exception.

### S0398 — UNJUSTIFIED

`proof.tex`, lines 895–900; SHA-256 `e3a8c3162a15ddb48aef155e215d4f53eaeb535abd306aa0121eb21e91cd3dd3`.

```tex
 Consequently
\[
 \sup_{0<t\leq T}\norm{\curl u(t)}1\leq
 \sup_{0<t\leq T}\norm{\curl u^{(0)}(t)}1+
 [NC\sqrt{\Theta(4T)}+1]\sum_q\sqrt{\delta_q}<\infty.
\]
```

Take the triangle inequality at each time, then the uniform supremum. The seed curl bound is finite and sum_q 4^{-q}=4/3, so the displayed finite bound follows.

### S0401 — UNJUSTIFIED

`proof.tex`, lines 902–906; SHA-256 `3accb14ab0ecd4641588169debcd937da62aa2657056a27f4152f6571e1844a1`.

```tex


Strong $L^2$ convergence on compact positive-time cylinders passes the
quadratic term to the limit in $L^1$, while
$\norm{R^{(q)}(t)}1\leq\delta_q\Theta(t)$ removes the stress.
```

On a finite positive-time cylinder, uniform L2 convergence and uniform local L2 bounds imply product convergence in L1 by ||a tensor a-b tensor b||_1<=(||a||_2+||b||_2)||a-b||_2. The stress bound tends uniformly to zero on its time support.

### S0402 — UNJUSTIFIED

`proof.tex`, lines 906–907; SHA-256 `0ff74f34a8b9b1d8a7b2c6c14fb803671073dd6b4c3812b33a2e85d684e3dc45`.

```tex
 Thus Euler
holds on $(0,\infty)$.
```

The finite-stage solenoidal weak identities pass to the limit by the preceding linear, quadratic and stress convergence. This proves positive-time Euler conditional on the repaired stage construction.

### S0406 — UNJUSTIFIED

`proof.tex`, lines 911–913; SHA-256 `29972b360d969ec6e442cfd41353e23aa3f39b87e09269181545e99a7b52dcd2`.

```tex

This proves precisely the target's initial-value weak formulation.
\end{proof}

```

Combining the cutoff limit, linear test term, convection limit and positive initial boundary term gives exactly the target's initial-value weak identity, conditional only on the construction already isolated.

### S0414 — UNJUSTIFIED

`proof.tex`, lines 933–937; SHA-256 `0c96a792169e2b6b562ccceadbc3da1984469aa63f962448122f6a3b480c6ea6`.

```tex

\begin{theorem}[Global existence]\label{thm:global}
For every datum in the exact target stated at the start of this document,
there is a global velocity with all of its stated properties.
\end{theorem}

```

The final theorem follows from the independently reconstructed iteration and normalization if the local construction's missing bump-family convention is supplied. As written, that dependency remains conditional; no counterexample to the target theorem was established.

### S0415 — UNJUSTIFIED

`proof.tex`, lines 938–941; SHA-256 `c72d973572278aec13cdcb7fb0cf081063c4fd31c3b501765d93aa77edfe6b26`.

```tex
\begin{proof}
Proposition~\ref{prop:iteration} gives the global velocity, the exact weak
initial trace and formulation, and every-time finite measure curl with
locally uniform variation.
```

The iteration provides exactly the listed trace, initial weak identity, every-time curl and finite-horizon variation, but its proof inherits the unresolved literal U_H scale specification from LER.

### S0416 — UNJUSTIFIED

`proof.tex`, lines 941–943; SHA-256 `105fb39fbb3cbf60343451e7bccc7ff4c980bdabefe501e75fcb29c0d4a535da`.

```tex
 At each time take $U=V_0$ and
$v=(V(t)-V_0)+W(t)+\sum_qw_q(t)\in L^2$ in
Lemma~\ref{lem:canonical}; at zero use the prescribed datum directly.
```

V0 is C0 by the initial decomposition; V(t)-V0 is global L2, W(t) is L2, and the correction series converges there. Thus the canonical lemma's hypotheses match at each positive time; zero uses the prescribed datum directly.

### S0417 — UNJUSTIFIED

`proof.tex`, lines 943–944; SHA-256 `9b053da69233fff17206adcb18d31bd94b4d89f948abcea3ac019e3519b3d89b`.

```tex

This proves the remaining canonical Biot--Savart identity at every time.
```

The normalization lemma is pointwise in time and needs no exceptional-time selection, so the canonical identity follows for every constructed time, conditional on the global construction.

## Final completeness certificate for the original B pass

- [PASS] Every TeX file was inventoried: one frozen file, `proof.tex`, inspected in full.
- [PASS] Every source line belongs to at least one permanent container: 948/948 source lines and 419/419 frozen containers were checked against the shared inventory.
- [PASS] Permanent container identifiers remained unchanged after the inventory was frozen: S0001–S0419, no renumbering or edits.
- [PASS] Every compound mathematical container received exactly one non-recursive layer of nested checks: all 252 compound containers and all 834 shared children were inspected; two additional focuses were reported under existing parents.
- [FAIL] Every permanent container received a verdict from every required pass: this report supplies 419/419 B verdicts only; other-pass coverage is deliberately not examined here.
- [FAIL] Every final nested check and every remaining simple mathematical container was affirmatively checked by every pass: all 834 original shared children and 388 mathematical parents have B checks, but supplemental consolidation and other-pass coverage belong to the coordinator.
- [PASS] Every inventoried inline and display formula occurrence was checked by B: 512 inline plus 59 display occurrences, with exact byte-span/digest validation.
- [PASS] Every algebra-bearing container was independently re-derived by B: 106/106, including conditional/missing-hypothesis findings.
- [FAIL] Every theorem-application container received complete independent hypothesis matching: 22/22 were examined and mathematically matched, but the Assumption 3.1 mapping-display check has the disclosed post-exposure provenance limitation.
- [PASS] Every proof was checked locally and globally by B: 8/8 proof environments and 8/8 major-result dependencies.
- [PASS] Edge cases and attempted counterexamples were investigated: the report and container rationales state the cases and the explicit thinner-bump counterfamily.
- [PASS] Definitions and notation were checked across the manuscript: unresolved items include the scaled pressure, parameter regularity, bump family, smoothness topology and patch interpretation.
- [PASS] Dependencies and error propagation were traced: all eight major results are mapped, with 32 unjustified and 10 ambiguous parents retained.
- [FAIL] Every required escalation was reconciled through local dispute items: 42 B parents require coordinator reconciliation; this independent pass does not assign final dispute outcomes.
- [PASS] Every definite error was independently confirmed where feasible: no unconditional ERROR is claimed; the conditional failures were checked by explicit low-frequency integrals, derivative/profile scaling, and interface derivative jumps, with their interpretive scope stated.
- [FAIL] No source container, pass verdict, or dispute item remains unchecked: B has zero uncovered original containers and zero missing original child verdicts, but other passes, supplemental consolidation, and reconciliation are not claimed complete here.
