# Independent Pass A: source-ordered local verification

**Overall status: INCONCLUSIVE at the literal, every-assertion level.** Three minor interpretation issues remain, in S0242, S0247 and S0304. No definite substantive error or fatal defect was established by this pass. The main existence argument was affirmatively reconstructed; none of these three issues is needed for its estimates or closure under the precise readings explained below. This is an independent pass report, not the coordinator's four-pass reconciliation certificate.

## A. Scope and independence

Examined `proof.tex`, lines 1–948, every permanent container S0001–S0419, all 834 shared nested checks, and all mathematical content between those checks. The source SHA-256 is `b6741b471ba2f128b147f5a5c05fea0afe639c2c3a535b99a5afaf03ea6d4a43`. The frozen inventory SHA-256 is `efbd3fc4311f910b394581f46718f3b73a03f99a5891b38d2e7e2be24d7b9b71`.

Inputs read were the entire forensic audit prompt, the exact target, the source in source order, and the neutral inventory, formula and notation files. No earlier audit, route, checkpoint, dependency-provenance file, or other pass's mathematical output was read. One agent-status listing returned names and statuses only, and exposed no mathematical conclusions. No source or frozen inventory was edited.

There are no `input`, `include` or bibliography dependencies. All mathematical macros were resolved. The cited primary Springer article was independently retrieved and its relevant assumptions, definition and theorem inspected. The source's standard analytical theorem invocations were checked with their actual hypotheses; the local proofs below also reconstruct the needed special cases. No external result remained unavailable.

Every source/container/formula digest and byte anchor was checked against the frozen bytes. The permanent inventory's segmentation was retained. Its two boundary groups are S0176 (the unpunctuated definition followed by “Then”) and S0221 (the definition ending in a comma). No omitted source container or supplemental child was proposed by this pass.

## B. Coverage

| Item | Pass A count |
|---|---:|
| Source lines examined / represented | 948 / 948 |
| Permanent containers examined | 419 / 419 |
| Mathematical containers examined | 388 / 388 |
| Non-mathematical containers inventoried | 31 |
| Sentence / structural / boundary-group containers | 380 / 37 / 2 |
| Compound containers | 252 |
| Shared nested checks examined | 834 / 834 |
| Inline / display formula occurrences examined | 512 / 59 |
| Algebra-bearing containers examined | 106 / 106 |
| Theorem-invocation containers checked | 22 / 22 |
| Proof environments checked | 8 / 8 |
| Major-result dependency maps below | 8 |
| Uncovered containers / missing child verdicts | 0 / 0 |
| Supplemental children proposed by this pass | 0 |

| Aggregate container status | Count |
|---|---:|
| VERIFIED | 385 |
| AMBIGUOUS | 3 |
| NOT MATHEMATICAL | 31 |
| ERROR / UNJUSTIFIED / DEPENDS ON EARLIER ERROR / NOT VERIFIABLE FROM PROVIDED MATERIAL | 0 |

The nested status counts are 826 VERIFIED, 5 AMBIGUOUS and 3 NOT MATHEMATICAL. The latter three are empty/layout/case-closing focus spans in the neutral inventory; both mathematical branches and their common boundary were checked in their surrounding formula. Every parent and every shared child has a record in `pass_a.json`. Where one derivation proves all scoped subclaims, that reconstruction is retained in each child record. The ambiguous children have individual rationales.

Pass A requests escalation of three containers. This pass did not assign reconciliation identifiers, read the other passes, or decide coordinator disputes. Cross-pass counts and final consolidated child counts are therefore reserved for the coordinator.

## C. Methods and substantive reconstruction

The companion JSON gives one source-hash-anchored record for every permanent identifier, without omitting verified or formatting-only regions. Its rationales are the detailed source-ordered local ledger for this pass.

The initial decomposition was checked by a physical-space and frequency calculation. Radial convolution makes `K-K*a` vanish beyond the support of `a`; the only remaining singularity is integrable. Evenness makes `1-a-hat=O(|xi|^2)` near zero, and the multiplier bound uses exactly the inhomogeneous H^-1 weight. The low-frequency singularity of the canonical velocity is not incorrectly treated as global L2. Finite-measure truncation works in total variation and preserves local convolution and distributional identities without a first moment or zero circulation assumption.

The background's every-time representative, measure-preserving flow, strong L1/L2 vorticity continuity, Linfinity velocity continuity, L3 velocity bound and global L2 velocity differences were checked separately. In particular, integrating transport produces `nu(t)-nu_0=-div F_t`; the multiplier of `-K div` has operator norm one, and this proves the relative L2 estimate without assuming finite global energy of the background.

For the seed, differentiating `exp(-t^4|xi|^4)` gives `-4t^3 Delta^2 W`. Row-wise divergence of the stated symmetric derivative tensor is `Delta^2 W`, and the displayed negative stress sign is correct. The two spatial derivatives of the smoothing kernel cost `t^-2`, leaving an `O(t)` stress after multiplication by `t^3`.

The translating dipole was checked from its power series and boundary derivatives. With the radial stream coefficient `f`, the two branches have at radius one the common values `f=-1`, `f'=1`, `f''=-2`. The pressure sign follows from `w=D-e1=grad-perp q`, `w-perp=-grad q`, and `curl w=-beta^2 q`. The pressure is the negative of `|w|^2/2+beta^2 q^2/2` in the core. Matching excludes surface delta terms. Scaling gives the exact L3/2 exponent 1/3 and invariant L2/curl-L1/gradient-L1 norms.

For the anti-divergence, component differentiation cancels the first and third terms and leaves `div A f=f`. The degree-minus-one kernel is integrable locally. Both zeroth and first moments are necessary for the generally integrable far remainder of order `R^2|x|^-3`; integrating it gives `CR||f||1`. For the radial derivative source, compact support follows from exterior homogeneity, the first moments vanish by evenness, and its mean vanishes by an explicit exterior angular flux.

The compact-source normalization was checked directly: on a large circle the integral of the dipole is `pi r xi`, and that of the subtracted gradient is `-pi r xi`. Thus `integral S_r=2pi xi`, with the sign and factor used by the raster.

The cycle normalization simultaneously gives scan duration `tau_i` and coefficient weight `d`:

- `(r0_i/eta_i) B_i = tau d B_i/(2pi eta_i^2) = tau_i`;
- `2pi eta_i r0_i/tau = d`.

The temporal integration-by-parts identity has a positive divergence on its right. The full-cycle corrector satisfies `partial_t Q+U+grad p_Q=Ubar` with the displayed pressure sign. It is essential that its average include all four directions. With `d=H^2`, `tau=H^6` and fixed positive floors, the active radii are comparable to `H^8`. The source stress is `O(H|log H|)+O(H^8)`, Q is `O(H^5)` in L2 and curl L1 and `O(H^(16/3))` in L3/2, and the principal L3/2 norm is `O(H^(8/3))`. All exponents were re-derived.

Spatial smoothing only the new packet equation adds the commutator `v_ell tensor v_ell-(v tensor v)_ell` with the displayed positive right-hand-side sign. Uniform smallness follows from compactness of the cycle's L2 image and of its quadratic L1 image. Smoothing changes the averaged tensor to its convolution; this additional L1 error is explicitly budgeted. No derivative of the old velocity and no old-field remollification is needed.

For global closure, same-color intervals have genuine gap times tending to zero. The anchor lemma's compact divergence-free pairings have bounded time derivatives. Their zero anchor values imply zero weak global-L2 trace because any L2 weak cluster point is both divergence-free and curl-free. The sum of increments has uniform-in-time L2 and curl-L1 bounds proportional to `sum 4^-q=4/3`. Strong local L2 convergence passes the quadratic velocity term, and a cutoff near zero produces the exact initial term with the required sign. The final harmonic normalization lemma eliminates the possible whole-plane harmonic velocity using averages of the fixed C0 background, the L2 perturbation and the canonical finite-measure convolution.

## D. Items requiring local interpretation reconciliation

### S0242, lines 549–552 — E7, minor

Anchor: “Its first time derivative may jump there, so the resulting velocity is continuous and piecewise smooth in time; it is not asserted to be globally time-smooth.”

The corrector Q is piecewise smooth in time, and the new correction after the later spatial mollification has this property. The raw translating packet generally does not have arbitrary time differentiability as an L2-valued path. Differentiating the Bessel equation once more gives the interior third radial stream derivative `6-2beta^2`, whereas the exterior derivative is `6`. Thus D has a nonzero second-derivative jump across its core circle. A nonzero constant-speed translation is not C3 into L2; its third spatial derivative includes a nonzero surface distribution. Adding the smooth Q cannot cancel that defect.

This is a referent/regularity-space ambiguity, rather than an established false claim about the particular Q just discussed. The correction is continuous in the required spaces and later spatial smoothing cures the raw higher-derivative defect. No downstream theorem requires the disputed smooth-time assertion. Smallest clarification: refer explicitly to Q, or qualify the claim as applying after the spatial smoothing.

### S0247, lines 568–576 — E7, minor

Anchor: “All displayed tensors are symmetric; the cross terms satisfy” followed by the four product inequalities.

The total stress and its grouped mixed pairs are symmetric. Individual displayed rank-one products need not be: `e1 tensor e2` is not its transpose. The displayed inequalities themselves are all correct. The mathematical stress identity at S0244 already includes both orders of every mixed pair, so the admissible symmetric-stress property is unaffected. Smallest clarification: “All contributions to the stress, with mixed terms grouped with their transposes, are symmetric.”

### S0304, lines 695–697 — E10, minor

Anchor: “The quantities ... stay bounded independently of N_k, because their formulas involve only the fixed amplitudes, fixed ramp functions, and the fixed logarithmic derivatives of the positive coefficients.”

The bound is correct, but “fixed amplitudes” has two different possible scopes. Each peak `eta_i` is fixed in time within a chosen construction; it is not fixed as N_k varies, since `eta_i^2=(2/pi)d_k B_i` and the row sum changes with d_k. The source already proves uniform amplitude bounds at S0298, and those suffice in the exact ramp/row formulas. Smallest clarification: “uniformly bounded amplitudes.” No downstream estimate needs N-independent amplitude values.

These three containers are the earliest affected source locations. No definite mathematical error is asserted in this report, and no error propagation status is assigned: the disputed phrases do not supply a necessary unsupported estimate.

## E. External theorem match and implicit choices

The primary article was opened at [the cited Springer URL](https://link.springer.com/article/10.1007/s00526-024-02750-4). Theorem 3.3 and Definition 3.2 supply the signed L1/Linfinity Lagrangian vorticity solution, canonical velocity and finite-horizon bounds/modulus. The data meet those spaces by convolution. Kernel Assumption 2.1 follows from the two exact kernel estimates; Assumption 3.1 follows from divergence zero, with no boundary condition on the plane. No compact-support, zero-circulation, smoothness or finite-energy hypothesis is imported. The manuscript derives its additional representative and velocity properties separately.

Two conventional choices were made explicit in the local reconstruction rather than hidden:

- S0141's scaled pressure is `P_r(x)=r^-2 P(x/r)`, after rotating the profile. It gives the displayed equation directly.
- S0164's bump family is the available fixed-profile dilation `U_H(x)=H^-2 U_1(x/H)`, as indicated by S0225–S0231's fixed-profile/scaling proof. The bare assertion of support in B_H alone would not imply derivative or Lp scaling for an arbitrary varying family. This family is a freely selectable construction datum and fits every stated bump condition.

The word “patch” in LER was read as an open time interval, as in every actual application I_j. If arbitrary disconnected relatively compact open sets were intended, the proof's choice of one enclosing interval at S0278 should be replaced by a finite componentwise construction. This does not affect any global-iteration application.

## F. Computational verification and edge cases

An exact Python `fractions.Fraction` calculation summed the Bessel series at the stated truncation indices. It returned `669/2048` for z=3, m=0..3, and `-2/45` for z=4, m=0..4. The analytical successive-term ratio proves the remainder directions; numerical agreement is not used as a substitute for that argument. Symbolic-library probes were unavailable, so no computer-algebra verification is claimed.

Cases checked included: zero initial measure; arbitrary sign and nonzero circulation; noncompact finite-measure support; the low-frequency inhomogeneous Sobolev endpoint; positive level-set threshold with the zero-measure case separated; the Bessel origin and both sides of its matching circle; all four moment cancellations; zero prescribed stress; zero/omitted coefficient directions and inactive slots; positive but arbitrarily small floors; zero ramp amplitudes and resets; every full-cycle and inherited boundary value; finite but arbitrarily small time patches; infinitely many dyadic patches approaching zero; actual every-time values rather than almost-every-time classes; and the possible nonzero harmonic remainder at infinity.

## G. Major-result dependency map

| Major result | Necessary source containers | Pass A finding |
|---|---|---|
| Canonical decomposition, S0034–S0039 | S0032–S0033, S0040–S0052 | Verified by kernel, convolution and weighted multiplier calculations. |
| Bounded background, S0060–S0061 | S0038–S0039, S0054–S0058, S0062–S0090 | Verified after primary-source hypothesis match and independent all-time/velocity arguments. |
| Initial seed, S0096–S0100 | Decomposition/background, S0101–S0114 | Verified with the exact derivative stress sign, bounds and trace. |
| LER, S0261–S0275 | S0122–S0219, S0221–S0249, S0252–S0260, S0276–S0349 | Verified using grouped symmetric stress, fixed-profile dilation and uniform amplitude bounds; the three noted wording issues are not necessary premises. |
| Anchor lemma, S0351–S0353 | S0354–S0360 | Verified by bounded derivative pairings, weak compactness and Fourier uniqueness of L2 harmonic fields. |
| Global iteration, S0361 | Seed, LER, anchors, S0362–S0406 | Verified by dyadic overlap/error budgets, exact gap anchors and summable strong convergence. |
| Canonical normalization, S0407–S0408 | Arbitrary-finite-measure kernel identities at S0040–S0043, S0409–S0413 | Verified without assuming H^-1 or finite global energy of the total velocity at later times. |
| Global target, S0414 | Iteration, canonical normalization, S0415–S0418 | All exact target properties follow from the reconstructed chain; no fatal dependency defect identified by Pass A. |

## H. Pass A completeness certificate

- [PASS] Every TeX file was inventoried: one file, `proof.tex`.
- [PASS] Every source line belongs to at least one permanent container: 948/948 lines, with the exact byte partition validated.
- [PASS] Permanent container identifiers remained unchanged after the inventory was frozen: 419/419 preserved and all container hashes matched.
- [PASS] Every compound mathematical container received exactly one non-recursive layer of nested checks: the shared 252 compound containers and 834 children were retained unchanged.
- [FAIL] Every permanent container received a verdict from every required pass: Pass A supplies 419/419; the other independent passes are deliberately not inspected or certified here.
- [FAIL] Every final nested check and every remaining simple mathematical container was affirmatively checked by every pass: Pass A examined 834/834 shared children and all 419 parents; five child interpretations remain flagged, and final cross-pass consolidation is the coordinator's task.
- [PASS] Every inventoried inline and display formula occurrence was checked: 512 inline plus 59 display, all anchored inside examined containers.
- [PASS] Every algebra-bearing container was independently re-derived: 106/106 in Pass A.
- [PASS] Every theorem-application container received complete hypothesis matching: 22/22 in Pass A, including the independently retrieved E1 primary theorem.
- [PASS] Every proof was checked locally and globally: 8/8 proof environments, with eight major-result dependency maps above.
- [PASS] Edge cases and attempted counterexamples were investigated: the endpoint, zero, noncompact, scaling, boundary, trace and harmonic cases are recorded above and in the JSON rationales.
- [PASS] Definitions and notation were checked across the manuscript: all mathematical macros and all 419 source containers; three local wording scopes are flagged rather than silently repaired.
- [PASS] Dependencies and error propagation were traced: eight major-result maps; no definite error propagation established, and three nonessential ambiguous assertions isolated.
- [FAIL] Every required escalation was reconciled through local dispute items: three Pass A containers require coordinator reconciliation; this independent pass assigns no dispute verdicts.
- [PASS] Every definite error was independently confirmed where feasible: no definite error is asserted; the conditional raw-packet regularity and rank-one nonsymmetry witnesses are explicitly reconstructed.
- [FAIL] No source container, pass verdict, or dispute item remains unchecked: Pass A leaves zero source containers or shared children unexamined, but does not certify other pass verdicts and leaves three interpretation issues for reconciliation.
