"""Check source integrity and exhaustive audit coverage, not mathematical truth."""

from __future__ import annotations

import hashlib
import json
from collections import Counter
from pathlib import Path


ROOT = Path(__file__).resolve().parent
ALLOWED = {
    "VERIFIED", "ERROR", "UNJUSTIFIED", "AMBIGUOUS",
    "DEPENDS ON EARLIER ERROR", "NOT MATHEMATICAL",
    "NOT VERIFIABLE FROM PROVIDED MATERIAL",
}


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def records_of(document: object) -> list[dict]:
    if isinstance(document, list):
        return document
    if isinstance(document, dict):
        for key in ("containers", "records", "verdicts", "container_verdicts"):
            if isinstance(document.get(key), list):
                return document[key]
    raise ValueError("No supported container-record list found")


def main() -> None:
    inventory = json.loads((ROOT / "audit_inventory.json").read_text())
    source = (ROOT / "proof.tex").read_bytes()
    canonical = inventory["containers"]
    source_issues = []
    cursor = 0
    for item in canonical:
        start, stop = item["byte_start"], item["byte_end_exclusive"]
        if start != cursor:
            source_issues.append([item["id"], "noncontiguous source span"])
        piece = source[start:stop]
        if piece.decode() != item["text"] or digest(piece) != item["sha256"]:
            source_issues.append([item["id"], "source text/hash mismatch"])
        cursor = stop
        for child in item["nested_checks"]:
            piece = source[child["byte_start"]:child["byte_end_exclusive"]]
            if piece.decode() != child["text"] or digest(piece) != child["sha256"]:
                source_issues.append([child["id"], "child text/hash mismatch"])
    if cursor != len(source) or digest(source) != inventory["metadata"]["source_sha256"]:
        source_issues.append(["source", "length or whole-source digest mismatch"])

    expected = {item["id"]: item for item in canonical}
    result = {
        "scope": "Mechanical integrity and coverage only; no proof verdict is inferred.",
        "source_sha256": digest(source),
        "source_integrity_issues": source_issues,
        "expected_containers": len(expected),
        "expected_shared_children": sum(len(c["nested_checks"]) for c in canonical),
        "passes": {},
    }
    for name in "abcd":
        path = ROOT / f"pass_{name}.json"
        if not path.exists():
            result["passes"][name.upper()] = {"state": "NOT YET AVAILABLE"}
            continue
        try:
            data = json.loads(path.read_text())
            records = records_of(data)
        except (ValueError, TypeError) as error:
            result["passes"][name.upper()] = {"state": "UNREADABLE", "error": str(error)}
            continue
        issues, seen, statuses, checked_children = [], set(), Counter(), set()
        rationales = Counter()
        for record in records:
            identifier = record.get("id")
            if identifier in seen:
                issues.append([identifier, "duplicate container verdict"])
            seen.add(identifier)
            item = expected.get(identifier)
            if item is None:
                issues.append([identifier, "unknown permanent identifier"])
                continue
            record_hash = record.get("source_sha256", record.get("sha256"))
            if record_hash != item["sha256"]:
                issues.append([identifier, "missing or different source-container digest"])
            status = record.get("status")
            statuses[status] += 1
            if status not in ALLOWED:
                issues.append([identifier, "invalid aggregate status"])
            rationale = record.get("rationale", "")
            if not isinstance(rationale, str) or not rationale.strip():
                issues.append([identifier, "missing rationale"])
            elif item["mathematical"]:
                rationales[rationale.strip()] += 1
            required = {c["id"] for c in item["nested_checks"]}
            supplied = set()
            for child in record.get("nested_checks", []):
                child_id = child.get("id")
                if child_id in supplied:
                    issues.append([child_id, "duplicate child verdict"])
                supplied.add(child_id)
                if child_id not in required:
                    issues.append([child_id, "not in the shared child inventory"])
                else:
                    checked_children.add(child_id)
                if child.get("status") not in ALLOWED:
                    issues.append([child_id, "invalid child status"])
                if not str(child.get("rationale", "")).strip():
                    issues.append([child_id, "missing child rationale"])
            for missing in sorted(required - supplied):
                issues.append([missing, "missing shared child verdict"])
        missing = sorted(set(expected) - seen)
        result["passes"][name.upper()] = {
            "state": "COMPLETE MECHANICAL COVERAGE" if not missing and not issues else "INCOMPLETE OR INCONSISTENT",
            "records": len(records),
            "status_counts": dict(statuses),
            "checked_shared_children": len(checked_children),
            "missing_containers": missing,
            "issues": issues,
            "repeated_mathematical_rationales_for_human_review": [
                {"count": count, "rationale": rationale}
                for rationale, count in rationales.items() if count >= 5
            ],
        }
    print(json.dumps(result, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
