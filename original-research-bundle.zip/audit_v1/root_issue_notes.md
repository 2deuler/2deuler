# Root reconciliation notes — not an audit-pass verdict

The frozen source remains unchanged. These notes are withheld from the independent passes until their own reports are complete.

## Reported issues pending comparison

- S0049: the pronoun “they” can include both multipliers although m*a_hat is not L2 near zero; only xi^alpha*m*a_hat is L2 when |alpha|>=1. Root independently checks the polar near-zero integral of |m|² diverges. Clarify the latter-only assertion. The actual positive-derivative estimate remains valid.
- S0141 and preceding scaling definition: pressure P_r is not explicitly defined. The required choice is r^(-2) P(x/r), rotated with the profile. This follows by direct derivative scaling.
- S0164/S0231: support, radiality and probability mass alone do not give scale-uniform derivative or Lp bounds. Choose once U in Cc∞(B1), radial/nonnegative/unitmass, and define U_H(x)=H^(-2)U(x/H). The construction permits this; the source should state it.
- S0242: raw dipole is C1 but not C∞ across the core circle; translating it is not globally piecewise C∞ in time as an L2-valued field. Subsequent fixed spatial mollification repairs the actually used field. Restrict the statement to continuity and possible derivative jumps, or explicitly qualify smoothness after spatial mollification.

## Root's additional direct source check

- In the moving-packet identity and explicit E formula, translated profiles on the right are printed without x-X(t). At X nonzero the literal untranslated identity is false. The intended translation convention is clear from v and the auxiliary source, but must be made explicit: define T_X f(x)=f(x-X) and apply it to D_r,F_r and the antidivergence output in these formulas. Norm estimates are translation-invariant. Also state r,eta,X C1 on each visit when differentiating them; actual raster construction meets this.

## Independence provenance

Pass B reported an accidental exposure, via list_agents, to a C-support worker's external-theorem conclusion after B had already completed and messaged its own independent E1 derivation. B did not read any other ledger and will not use the exposed conclusion. A new context external_interface_fresh independently checks the entire external-theorem/upgrade interface, without prior conclusions, to provide additional clean provenance. This is to be disclosed accurately, not hidden.

No final global mathematical verdict is entered here. Every issue must be compared and reconciled using unchanged permanent parent IDs, with all affected source revisions and new checks re-audited.
