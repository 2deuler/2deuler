# Neutral protocol for a later source revision

This protocol does not edit or audit the manuscript. The governing v3 prompt freezes containers for an exact source snapshot and defines append-only additions for omissions. It does not specify arbitrary manuscript revisioning. The following versioned correspondence procedure preserves that frozen record and prevents cross-version hash mismatches from being treated as mathematical disagreements.

## Immutable records

Retain `audit_v1/proof.tex`, the original `audit_inventory.json`, formula inventory, and all v1 audit records unchanged. Finish the current append-only child supplement separately. Create any later reviewed source and inventory under a new revision directory, with a new revision identifier and source hash. Never run the segmentation generator over a revised source and renumber its output as though it were the old inventory.

Maintain a cumulative registry of all allocated permanent parent and child IDs. The 419 existing parent IDs remain allocated forever. A later active ledger is displayed in current source order, which need not be numeric ID order.

## Reviewed correspondence

Before freezing a revised inventory, prepare one correspondence record for every existing parent. It records the old ID and digest, whether the source object survives, its exact new byte span, the new digest, and the reason its identity is retained. Matching text or line numbers is only a candidate locator; repeated source text makes automatic identity matching unsafe.

An edit within an existing parent keeps that parent's ID only if the revised object still obeys the original container rule: one complete sentence with all grammatically attached math, one standalone display, one structural source object, or a genuinely uncertain boundary group. Changed formulas and additional claims inside the same sentence keep that parent ID. Update the complete exact text, byte span, inclusive lines, and digest from the revised source without normalizing its bytes.

New source inserted inside a surviving sentence or display remains in that parent. A genuinely new complete sentence or structural object inserted at a safe boundary receives the next globally unused parent ID, beginning with `S0420`; insert it at its actual source position without renumbering any surviving parent.

An edit that splits one frozen sentence into several, merges frozen sentences, moves a grammatically attached display across a parent boundary, or leaves ambiguous parent correspondence must stop automatic inventory migration. A reviewed decision must preserve valid sentence boundaries. `BOUNDARY-GROUP` must not be used merely to conceal an otherwise clear split or merge.

For complete deletion, retain the historical ID and original anchor in the cumulative registry, with a revision lifecycle record such as `RETIRED_DELETED`; it has no fabricated current source span or mathematical verdict. Arbitrary split/merge replacement would require an explicit extension recording retired IDs, new replacement IDs, and their lineage. It cannot simultaneously preserve an unchanged active sentence partition and exact coverage of the restructured source. Under the strict preservation method for a local repair revision, avoid these operations and retain one valid source container for each surviving old ID.

## One-layer children

When the same factual check continues, keep its child ID and re-anchor it within the revised parent. Its exact text and digest may change with the revised assertion, but the correspondence must be recorded. Append newly necessary checks using the next unused local suffix; never split a child into grandchildren. New claims do not generate new global parent IDs.

If an original simple parent becomes compound, create its one child layer covering all current items. A removed check remains historically allocated and receives a lifecycle record; do not silently repurpose its number. Freeze the final active shared list for the new revision before independent auditing.

## Mechanical acceptance checks

Validate the following before marking a revised inventory frozen:

1. Every original ID is present either as an active corresponding object or as an explicit historical lifecycle record; none is reused or renumbered.
2. Active parent byte spans form a disjoint, contiguous partition of the exact revised source, including formatting bytes. Concatenating their exact texts reconstructs that source byte-for-byte.
3. Every parent, formula, and child digest matches its exact source bytes. Every active child is contained in its unchanged parent identity and has no recursive child layer.
4. Inclusive line positions are recalculated from source line delimiters. Original bytes, including any CRLF, are not rewritten to compute anchors.
5. All formula occurrences, labels, references, macro definitions, proof environments, and major-result spans are regenerated against the revised source and mapped to the retained parent IDs.
6. A change manifest records old/new parent digests, new child IDs, inserted parent IDs, and any historical retirements. It contains no mathematical verdicts.

## Audit identity and comparison

Each independent pass record must bind its findings to the revision ID, complete source-bundle hash, parent-ledger hash, consolidated child-list hash, permanent parent ID, parent digest, and pass identifier. Before comparing passes, require identical values for all source and inventory identity fields. A mismatch is an orchestration failure: stop that comparison and restore identical inputs. A matching parent digest alone does not suffice if a macro, hypothesis, reference, or dependency changed elsewhere.

Cross-revision correspondence is a change record, not a mathematical dispute. Every changed or added parent and child needs all four required checks in the new revision. Dependencies and global consistency must be reviewed against that new source. To claim procedural completeness for the revised manuscript, obtain current-revision attestations from all four passes for every active parent and every final active child; do not silently copy v1 verdicts forward.

The safest data flow is: immutable revised source, reviewed parent correspondence, exact re-anchoring, append-only new IDs, source-coverage validation, shared revised inventory freeze, then independent revised-source audit records.
