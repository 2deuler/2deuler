OUTCOME: PROVED

Global weak Euler flows for every finite signed Radon measure in inhomogeneous H^{-1}(R^2), with the exact weak trace, every-time finite measure curl and canonical Biot-Savart velocity, and finite-horizon uniform total variation required in the launch target.

Start with vortex_sheet_proof.pdf (13 pages) or its exact TeX source. Read vortex_sheet_audit.html for the complete A-H audit. It contains every one of the419 permanent source-container rows; audit_final/audit_ledger.json contains the861 child focuses and all four complete pass records. The exact user target is preserved in checkpoint.md and audit_v3/target_problem.txt.

Authoritative final proof: audit_v3/proof.tex
SHA-256: 8743ce99900bfb3df37bb4ccdae9aa9269cff12fc0a6abff7e4989a4eb426230

Verification level: LLM mathematical reconstruction, four independent source-bound audit passes, direct coordinator reconciliation and a separate hostile whole-proof audit. This is not a formal proof-assistant certificate. final_gate.json records the actual decision and binds its evidence hashes. No novelty or global literature-status claim is made.

All57 local audit disputes across54 historical parents were directly resolved, with explicit repairs and current-source dependency rechecks. Original errors and partial-audit limitations remain in the historical records. The final hostile report is audit_v3/final_hostile_whole_proof.md. Each independent pass file is immutable. A later disclosed parent-comparison role is separate from independent PASS A.

Historical route packets and earlier proof/audit revisions are included for provenance. Some contain provisional, rejected or superseded claims. They do not override the final v3 proof or its final gate. The final proof's active dependency closure is its internal lemmas plus the explicitly checked Crippa-Stefani bounded-vorticity theorem; all interfaces are recorded in the audit. Primary article URLs are provided rather than copies of the entire articles.

The project began2026-10-08T09:42:55Z with a six-hour authorized window ending15:42:55Z. The VERIFIED_COMPLETE gate occurred at 2026-10-08T12:46:34.391724+00:00. The project stops under that condition, not budget exhaustion. No future background continuation is asserted.

Manifest.json records the SHA-256 of every included file except itself. Report-generation and evidence-integrity scripts check coverage and source binding; they are not mathematical truth verifiers.
