"""Exact byte, identifier, formula and verdict coverage checks; no truth oracle."""
from pathlib import Path
from collections import Counter
import hashlib
import json

ROOT=Path(__file__).resolve().parents[1]
def sha(b): return hashlib.sha256(b).hexdigest()
def read(p): return json.loads(p.read_text())
def records(d):
    for k in ('records','containers','verdicts','container_verdicts'):
        if isinstance(d.get(k),list):return d[k]
    raise ValueError('No records')

def main():
    src=(ROOT/'audit_v3/proof.tex').read_bytes()
    inv=read(ROOT/'audit_v3/audit_inventory.json')
    forms=read(ROOT/'audit_v3/audit_formulas.json')
    problems=[];cursor=0
    parents={c['id']:c for c in inv['containers']}
    children={c['id']:c for p in parents.values() for c in p['nested_checks']}
    def check_span(o,kind):
        b=src[o['byte_start']:o['byte_end_exclusive']]
        if b.decode()!=o['text'] or sha(b)!=o['sha256']:problems.append([kind,o.get('id'),'text/digest mismatch'])
    for c in parents.values():
        if c['byte_start']!=cursor:problems.append(['parent',c['id'],'partition gap/overlap'])
        check_span(c,'parent');cursor=c['byte_end_exclusive']
        for child in c['nested_checks']:
            check_span(child,'child')
            if not c['byte_start']<=child['byte_start']<=child['byte_end_exclusive']<=c['byte_end_exclusive']:problems.append(['child',child['id'],'outside parent'])
    if cursor!=len(src):problems.append(['source','length mismatch'])
    for f in forms['formulas']:check_span(f,'formula')
    meta=inv['metadata']
    if meta['source_sha256']!=sha(src):problems.append(['source','metadata digest mismatch'])
    output={'scope':'Mechanical evidence integrity and coverage only; mathematical decisions require direct reconstruction.','source_sha256':sha(src),'inventory_sha256':sha((ROOT/'audit_v3/audit_inventory.json').read_bytes()),'source_bytes':len(src),'source_lines':len(src.splitlines()),'parents':len(parents),'children':len(children),'formulas':len(forms['formulas']),'problems':problems,'passes':{}}
    for a in 'abcd':
        p=ROOT/f'audit_v3/pass_{a}.json';report=ROOT/f'audit_v3/pass_{a}_report.md'
        if not p.exists() or not report.exists():output['passes'][a.upper()]={'state':'PENDING'};continue
        doc=read(p);rs=records(doc);issues=[];seen=set();cseen=set();statuses=Counter();cs=Counter()
        if doc['metadata'].get('source_sha256')!=sha(src):issues.append(['metadata','wrong source'])
        if doc['metadata'].get('inventory_sha256')!=output['inventory_sha256']:issues.append(['metadata','wrong inventory'])
        for r in rs:
            sid=r['id'];c=parents.get(sid)
            if sid in seen or c is None:issues.append([sid,'duplicate/unknown parent']);continue
            seen.add(sid);statuses[r['status']]+=1
            if r.get('source_sha256',r.get('sha256'))!=c['sha256']:issues.append([sid,'wrong parent digest'])
            if not r.get('rationale','').strip():issues.append([sid,'missing rationale'])
            child_required={x['id'] for x in c['nested_checks']};child_seen=set()
            for q in r.get('nested_checks',[]):
                qid=q['id'];cc=children.get(qid)
                if qid in cseen or qid not in child_required or cc is None:issues.append([qid,'duplicate/unknown/misassigned child']);continue
                child_seen.add(qid);cseen.add(qid);cs[q['status']]+=1
                digest=q.get('source_sha256',q.get('focus_sha256',q.get('sha256')))
                if digest!=cc['sha256']:issues.append([qid,'wrong child digest'])
                if not q.get('rationale','').strip():issues.append([qid,'missing rationale'])
            if child_seen!=child_required:issues.append([sid,'missing children',sorted(child_required-child_seen)])
        if set(parents)!=seen:issues.append(['parents','missing',sorted(set(parents)-seen)])
        if set(children)!=cseen:issues.append(['children','missing',sorted(set(children)-cseen)])
        output['passes'][a.upper()]={'state':'PASS' if not issues else 'FAIL','source_bound_records':len(seen),'source_bound_children':len(cseen),'parent_statuses':dict(statuses),'child_statuses':dict(cs),'issues':issues,'json_sha256':sha(p.read_bytes()),'report_sha256':sha(report.read_bytes())}
    v1=read(ROOT/'audit_v1/audit_inventory_supplemented.json');v2=read(ROOT/'audit_v2/audit_inventory.json')
    ids=lambda d:[x['id'] for x in d['containers']]
    output['permanent_id_preservation']=(ids(v1)==ids(v2)==list(parents))
    cids=lambda d:{x['id'] for c in d['containers'] for x in c['nested_checks']}
    output['append_only_children']=cids(v1)<=cids(v2)<=set(children)
    output['historical_supplement_counts']={}
    v1children={x['id']:x for c in v1['containers'] for x in c['nested_checks']}
    original=read(ROOT/'audit_v1/audit_inventory.json')
    new_v1=cids(v1)-cids(original)
    for a in 'abcd':
        s=read(ROOT/f'audit_v1/pass_{a}_supplement.json')
        seen={r['child_id'] for r in s['records']};issues=[]
        if seen!=new_v1:issues.append('Supplemental identifier coverage mismatch')
        for r in s['records']:
            if r.get('child_source_sha256',r.get('child_sha256'))!=v1children[r['child_id']]['sha256']:issues.append(r['child_id']+' digest mismatch')
            if not r.get('rationale','').strip():issues.append(r['child_id']+' missing rationale')
        output['historical_supplement_counts'][a.upper()]={'sha256':sha((ROOT/f'audit_v1/pass_{a}_supplement.json').read_bytes()),'checked':len(seen),'issues':issues}
    out=ROOT/'audit_final/evidence_integrity.json';out.write_text(json.dumps(output,indent=2)+'\n')
    print(json.dumps({k:v for k,v in output.items() if k!='historical_supplement_counts'},indent=2))

if __name__=='__main__':main()
