"""Post-audit parent comparison; never modifies independent pass artifacts."""
from pathlib import Path
from collections import Counter
import hashlib
import json
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[1]
V = ROOT / 'audit_v3'
OUT = ROOT / 'audit_final'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def records(doc):
    return doc.get('records', doc.get('containers'))

inv = json.loads((V / 'audit_inventory.json').read_text())
docs = {a: json.loads((V / f'pass_{a.lower()}.json').read_text()) for a in 'ABCD'}
by = {a: {r['id']: r for r in records(d)} for a, d in docs.items()}
source_hash = sha(V / 'proof.tex')
assert source_hash == '8743ce99900bfb3df37bb4ccdae9aa9269cff12fc0a6abff7e4989a4eb426230'
assert sha(V / 'audit_inventory.json') == '312e27c6941704d244f102a3907c290d82db5d41e68208e88b592b68d32adce7'
inputs = {}
for a, d in docs.items():
    assert d['metadata']['source_sha256'] == source_hash
    assert len(records(d)) == len(by[a]) == 419
    assert set(by[a]) == {c['id'] for c in inv['containers']}
    for name in [f'pass_{a.lower()}.json', f'pass_{a.lower()}_report.md']:
        inputs[f'audit_v3/{name}'] = sha(V / name)

# These are comparator notes recorded after reading all four complete parent
# rationales, not an automatic semantic assessment by this script.
regions = [
    (1, 25, 'Formatting classifications and mathematical macro meanings agree. The real/measure/curl/divergence/norm/integration macros are treated as mathematical; administrative structure is not.'),
    (26, 52, 'The rationales use the same signed finite-measure domain, canonical kernel orientation and inhomogeneous low-frequency split. They consistently restrict positive-derivative L2 multiplier integrability and do not impose zero circulation.'),
    (53, 90, 'The full finite-p source interface, every-time representative, Osgood flow, volume preservation, relative-L2 multiplier and curl-free pressure arguments agree in scope. Norm bounds and a.e.-time versus every-time conclusions are kept distinct.'),
    (91, 119, 'Seed multiplier differentiation, symmetric derivative stress sign, curl and mixed-product estimates, positive-time continuity and the nonintegrable swirl example have matching calculations and endpoints.'),
    (120, 142, 'Exact Bessel tail bounds, nonzero denominator, Cartesian origin extension, circle matching, pressure orientation, simultaneous rotation and radius scaling are mutually consistent.'),
    (143, 168, 'The two moment cancellations, degree-minus-three far-field remainder, translated C1 packet chain rule, two boundary fluxes and fixed bump dilation agree. No rationale applies an unrestricted L1 singular-integral estimate.'),
    (169, 219, 'Coefficient decomposition, positive floors, exact scan-time/weight normalization, bounded amplitude, radius exponent, integration-by-parts sign and two-scale quadrature agree. Sharper ramp bounds in A and weaker sufficient bounds in other passes are compatible.'),
    (220, 260, 'Full-cycle averaging, explicit projected profile, exterior radial identity, dilation exponents, pressure and mollifier-commutator signs, assembled symmetry and zero endpoint traces agree. Interior support holes are explicitly excluded from the exterior identity.'),
    (261, 295, 'The admissible class and prescribed-piece LER hypotheses agree, including interval patches, zero stress, separate one-sided traces, actual boundary representatives and finite coarse approximation. Coarse-dependent constants are not confused with the universal leading amplitude constant.'),
    (296, 330, 'All parameter choices and fine-scale exponents agree; the rationales use convergence on a tail of large cycle counts, not literal monotonicity of every Riemann sum. Exact residual identities and independent stress/amplitude/subcritical budgets match.'),
    (331, 350, 'Distributional gluing, separately assigned boundary stress values, velocity continuity, Young exponent and locally finite partition preservation agree. None differentiates stress in time or assumes smoothness of the old velocity.'),
    (351, 360, 'All four verify the same anchor hypotheses, pairing signs, Lipschitz representative and zero-time weak-L2 cluster argument. Global L2 is required only for the velocity difference.'),
    (361, 392, 'The positive dyadic plateau, finite overlap and colors, frozen prescribed-piece subtraction, exact error telescope, horizon factor 4T and anchor trace preservation agree. Finite-stage L3 bounds are not promoted to a uniform-in-stage estimate.'),
    (393, 419, 'Uniform L2 and curl-L1 series, every-time rather than a.e.-time curl, local quadratic convergence, positive initial term, harmonic normalization and single global-time construction have compatible quantified conclusions.'),
]
critical = {
    'S0058': 'All four explicitly verify the full L1 intersection L3_ul to bounded C^(1/3) map with q=1,p=3, zero divergence and empty boundary. They separately identify Corollary 2.4 as the source of log-Lipschitz control and match the bounded-vorticity inputs actually used in Theorem 3.3.',
    'S0164': 'All four use the same fixed U and explicit H^-2 dilation. C and D spell out H-independent derivative constants; A and B supply the same dilation premise. This supports the quadrature and projected-profile dependencies.',
    'S0229': 'Angular averaging and harmonic mean value are two compatible proofs on the exact current domain |x|>1. All four exclude interior support holes and obtain the same Hessian tail.',
    'S0247': 'All four distinguish symmetry of the assembled tensor from symmetry of an individual mixed dyad, and use matching Holder conjugates and the exact Q self-product norm.',
    'S0270': 'Each rationale identifies the construction rather than assuming the local repair conclusion: coarse approximation, positive masses, finite fine counts, fixed mollification, exact stress identity, independent budgets and zero-trace gluing. A/D explicitly map the output classes; B/C state the same sufficient chain.',
    'S0280': 'All four reconstruct one-sided uniform continuity plus compact smooth symmetric density with two half-error budgets. No simultaneous approximation of unequal actual/one-sided boundary values is required.',
    'S0333': 'All four assign actual isolated-time stress values algebraically and separately from one-sided traces. This is compatible with the spatial-only divergence in the equation and the pointwise error bound.',
    'S0357': 'A/C/D expressly identify sequences tending to zero; B independently reconstructs Hilbert weak sequential compactness for the bounded sequence in the parent context. B does not assert a different time regime. The following parent rationales all use zero-time pairing limits.',
    'S0362': 'The floor-log index formula in A/C and the tiling-interval argument in B/D prove the same positive denominator, including common endpoints. All four retain locally finite sums and compact support inside the stated dyadic intervals.',
    'S0373': 'All four match the prescribed piece to LER with positive epsilon/zeta/kappa/radius budgets. Fixed upper subcritical caps do not prevent smaller actual increments for the independent stress tolerance; no lower radius is imposed.',
    'S0380': 'All four use the original frozen R^(q), not an updated stress, in every partition piece. Sequential cross-color errors and disjoint same-color supports therefore give the same exact all-time cancellation.',
    'S0384': 'Each rationale derives I_j subset (0,4T) for an active patch and sums at most N costs, giving exactly [NC sqrt(Theta(4T))+1]sqrt(delta_q).',
    'S0390': 'All four explicitly list the before/after-color ER pairs, local continuity, local energies, global stress bound, global-L2 difference and exact gap anchors. No omitted anchor-lemma hypothesis was found.',
    'S0397': 'All four use absolute curl-L1 convergence for every actual positive time and identify it with distributional curl using local-L2 velocity convergence. No a.e.-time conclusion is substituted.',
    'S0406': 'All four reproduce the positive initial term from a rising temporal cutoff, after bounding discarded convection and the time-dependent test replacement. The target test class and every finite horizon agree.',
    'S0414': 'All four support the exact target by the proved iteration and separate fixed-background normalization, not by an external theorem claiming the final signed-measure conclusion.',
    'S0416': 'Every fixed-time canonical-lemma input is accounted for: V0 in C0, V(t)-V0 and W(t) in L2, convergent L2 correction series, divergence zero, finite curl; the initial identity is treated directly at zero.',
}

rows = []
for c in inv['containers']:
    rid = c['id']; n = int(rid[1:])
    pos = {}
    for a in 'ABCD':
        r = by[a][rid]
        assert r['source_sha256'] == c['sha256']
        assert r['rationale'].strip()
        pos[a] = {'aggregate_status': r['status'], 'full_parent_rationale': r['rationale'], 'container_sha256': r['source_sha256']}
    statuses = {v['aggregate_status'] for v in pos.values()}
    assert len(statuses) == 1 and statuses <= {'VERIFIED', 'NOT MATHEMATICAL'}
    note = critical.get(rid, next(t for lo, hi, t in regions if lo <= n <= hi))
    rows.append({
        'id': rid, 'source_sha256': c['sha256'],
        'source_file': 'audit_v3/proof.tex', 'source_lines': [c['line_start'], c['line_end']],
        'mathematical': c['mathematical'], 'passes': pos,
        'full_parent_rationales_read': ['A', 'B', 'C', 'D'],
        'comparison_result': 'COMPATIBLE',
        'materially_incompatible_reasons': False,
        'materially_incomplete_dependency_support': False,
        'escalated_by_this_comparison': False,
        'escalation_triggers_7_2': [],
        'comparison_rationale': note,
        'root_final_status': None,
    })

doc = {
    'metadata': {
        'role': 'Separate disclosed post-audit comparator role performed by the completed PASS A worker',
        'created_utc': datetime.now(timezone.utc).isoformat(),
        'independence_boundary': 'All four immutable v3 JSON and report files existed before this role read another pass. Independent PASS A had already been issued and remains unchanged. This comparison is not an additional independent pass and is not root reconciliation closure.',
        'method': 'Read all 419 full parent aggregate records and all 1676 full parent rationales in source order. Compared mathematical assertions, domains, signs, constants, quantifiers and supporting methods under prompt 7.1/7.2. Parent IDs were the initial matching key; no nested verdict voting or majority rule was used. Existing own full-source derivations supplied context. Checked theorem applications, major conclusions and dependency-critical interfaces for materially incomplete support.',
        'source_sha256': source_hash,
        'inventory_sha256': sha(V / 'audit_inventory.json'),
        'immutable_pass_artifacts': inputs,
        'parent_count': 419, 'parent_rationales_read': 1676,
        'parents_by_common_label': dict(Counter(r['passes']['A']['aggregate_status'] for r in rows)),
        'digest_mismatches': 0, 'missing_or_duplicate_parent_verdicts': 0,
        'aggregate_status_disagreements': 0, 'adverse_current_parent_labels': 0,
        'material_rationale_incompatibilities_found': 0,
        'materially_incomplete_dependency_critical_support_found': 0,
        'new_mandatory_mathematical_escalations': 0,
        'historical_reconciliation': 'The existing 54 historical escalated parents and 57 local disputes are not closed or overwritten by compatible current rationales.',
        'conclusion': 'No new mandatory mathematical escalation found in this parent-level comparison. Root reconciliation and the final procedural gate remain pending; no final PASS or procedural completeness is certified here.',
        'nested_checks': 'Nested records were not used as the initial comparison key. Child coverage remains independently documented in the four immutable ledgers and must be verified by the coordinator before finalization.',
    },
    'comparisons': rows,
    'mandatory_mathematical_escalations': [],
    'focused_dependency_quality_control': list(critical),
}
(OUT / 'final_parent_comparison.json').write_text(json.dumps(doc, ensure_ascii=False, indent=2) + '\n')
for name, digest in inputs.items():
    assert sha(ROOT / name) == digest
print(json.dumps({'rows': len(rows), 'rationales': 4*len(rows), 'new_escalations': 0, 'sha256': sha(OUT / 'final_parent_comparison.json')}))
