"""Render the version-bound audit evidence. Never infer mathematical closure by vote."""
from pathlib import Path
from collections import Counter
from html import escape
import hashlib
import json

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'audit_final'
V3 = ROOT / 'audit_v3'

def read(path):
    return json.loads(path.read_text())

def records(doc):
    for key in ('records', 'containers', 'verdicts', 'container_verdicts'):
        if isinstance(doc.get(key), list):
            if len({r['id'] for r in doc[key]}) != len(doc[key]):
                raise ValueError('Duplicate permanent parent IDs')
            return {r['id']: r for r in doc[key]}
    raise ValueError('Missing records')

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def e(x):
    return escape(str(x), quote=True)

def p(x):
    return '<p>' + e(x) + '</p>'

def pre(x):
    return '<pre>' + e(x) + '</pre>'

def detail(title, body, opened=False):
    return '<details' + (' open' if opened else '') + '><summary>' + e(title) + '</summary>' + body + '</details>'

def table(headers, rows, cls=''):
    return '<div class="scroll"><table class="'+cls+'"><thead><tr>'+''.join('<th>'+e(h)+'</th>' for h in headers)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+x+'</td>' for x in row)+'</tr>' for row in rows)+'</tbody></table></div>'

def main():
    inv = read(V3/'audit_inventory.json')
    parents = inv['containers']
    byid = {c['id']: c for c in parents}
    meta = inv['metadata']
    assert sha(V3/'proof.tex') == meta['source_sha256']
    docs = {a: read(V3/f'pass_{a.lower()}.json') for a in 'ABCD' if (V3/f'pass_{a.lower()}.json').exists() and (V3/f'pass_{a.lower()}_report.md').exists()}
    passes = {a: records(d) for a,d in docs.items()}
    historical = {a: records(read(ROOT/'audit_v1'/f'pass_{a.lower()}.json')) for a in 'ABCD'}
    v2 = {a: records(read(ROOT/'audit_v2'/f'pass_{a.lower()}.json')) for a in 'ABCD'}
    recpath = OUT/'reconciliation_final.json'
    rec = read(recpath if recpath.exists() else OUT/'reconciliation_work.json')
    gate = read(OUT/'final_gate.json') if (OUT/'final_gate.json').exists() else {'state':'PENDING','checklist':[]}
    closed = gate.get('state') == 'VERIFIED_COMPLETE'
    # Root decisions are required even when all four pass statuses agree.
    finals = gate.get('parent_final_statuses', {})
    counts = Counter(finals.values())
    source_hash = meta['source_sha256']
    dispute_count=sum(len(x['dispute_items']) for x in rec['entries'])
    if closed:
        assert set(passes)==set('ABCD')
        assert set(finals)==set(byid)==set(gate['parent_root_rationales'])
        assert len(gate['checklist'])==16 and all(c['status']=='PASS' for c in gate['checklist'])
        assert gate['resolved_disputes']==dispute_count
        assert gate['source_sha256']==source_hash
        assert not gate['current_errors']
        for name,digest in gate['bound_artifacts'].items():
            assert sha(ROOT/name)==digest, name+' changed after gate'
        for a,rs in passes.items():
            assert set(rs)==set(byid)
            assert docs[a]['metadata']['source_sha256']==source_hash
            for sid,r in rs.items():
                assert r['source_sha256']==byid[sid]['sha256']
                assert {x['id'] for x in r['nested_checks']}=={x['id'] for x in byid[sid]['nested_checks']}
        assert all(d['closure_state'].startswith('RESOLVED') for x in rec['entries'] for d in x['dispute_items'])
    body = ['<h1>Vortex-sheet existence: source audit</h1>']
    body += [p('Current source: frozen revision v3. Verification level: LLM mathematical reconstruction and independent hostile review, with exact source-integrity checks; no proof assistant or formal proof certificate.'), p('Gate state: '+gate['state'])]
    body.append('<nav>'+ ' · '.join('<a href="#'+x+'">'+x+'</a>' for x in 'ABCDEFGH')+'</nav>')

    body += ['<section id="A"><h2>A. Audit scope</h2>',p('Final TeX source: audit_v3/proof.tex, lines 1–951 (45,329 bytes). Historical frozen sources audit_v1/proof.tex, lines 1–948, and audit_v2/proof.tex, lines 1–949, were also examined. candidate_proof.tex is the byte-identical v1 assembly alias. No included TeX files, unresolved macros, unavailable dependencies or missing source pages remain. Standard installed TeX packages compiled successfully.'),pre('v3 source SHA-256: '+source_hash+'\nv3 inventory SHA-256: '+sha(V3/'audit_inventory.json'))]
    body += [p('Segmentation: TeX-aware permanent source containers form an exact disjoint contiguous byte partition. Sentence-ending punctuation determines prose units while attached formulas remain in their enclosing sentence; structural declarations are separately inventoried. Leading layout bytes attach to the following unit and environment-closing bytes to the preceding unit. S0176 and S0221 are the two declared BOUNDARY-GROUP containers. Their exact ambiguity notes appear in the ledger. Compound containers have exactly one non-recursive layer of shared child checks, always read with the whole parent. All 419 parent identities survive both revisions without splits, mergers, deletions or renumbering.'),p('Nested checks grew by append-only consolidation: 834 original, six v1 supplemental, fifteen v2 and six v3 additions, giving 861. The original empty/whitespace/layout-only focuses S0130.C05, S0130.C10 and S0130.C11 are retained as NOT MATHEMATICAL; they are not counted as mathematical claims. The child texts and all four focus-specific verdicts are included in audit_ledger.json.'),p('Independent passes: A is source-ordered local verification; B is independent re-derivation; C is adversarial counterexample search; D is global dependency verification. Final B uses a clean fresh context begun at v2. Original v1 B accidentally saw a C support-agent external-theorem conclusion after its own partial source check but before seeing the complete mapping display; it is retained only as disclosed historical evidence. A separate fresh external audit also initially omitted that display; its mapping addendum corrects the earlier completeness claim. Every final pass independently checked the entire finite-p mapping and its actual use in the original theorem. Final auditors reused only their own earlier derivations after current-source identity and dependency review.'),p('The mechanically verified digests and counts establish what was checked, not that a theorem is true. Mathematical closure rests on affirmative derivations, direct dispute reconstruction, theorem-hypothesis matching and the final hostile whole-proof review. No verdict is obtained by majority vote. Completed independent checks and direct reconstructions were performed during this bounded run; the final gate state determines whether reconciliation and certification have also closed.'),'</section>']

    body += [p('After issuing its immutable independent verdict, the A worker performed a separate disclosed comparator role. It read all 419 parent rows and all 1,676 full parent rationales, finding no new mandatory escalation. This later exposure to the other completed passes does not belong to independent PASS A and is not a fifth independent audit. Its report review identified evidence housekeeping, which the coordinator addressed before release.')]
    body += ['<section id="B"><h2>B. Coverage summary</h2>']
    rows = [ ['Source lines represented',e('951 / 951')], ['Source containers',e('419: 380 SENTENCE, 37 STRUCTURAL, 2 BOUNDARY-GROUP')], ['Compound containers / final nested checks',e('253 / 861 (858 mathematical, 3 scaffolding)')], ['Mathematical / non-mathematical parents',e('388 / 31')], ['Formula occurrences',e('584: 525 inline, 59 top-level displays')], ['Algebra-bearing containers',e('106; no separate count of semantic transitions claimed')], ['Theorem-application containers',e('23, including standard analytic principles and the specialized external theorem interface')], ['Proof environments / major dependency maps',e('8 / 8')], ['Escalated parents / local disputes',e(str(len(rec['entries']))+' / '+str(dispute_count))], ['Directly reconstructed disputes',e(rec['metadata']['mathematically_reconstructed_items'])], ['Final-revision closed / open disputes',e(str(gate.get('resolved_disputes',0))+' / '+str(dispute_count-gate.get('resolved_disputes',0)))], ['Current final parent statuses',e(dict(counts) if closed else 'PENDING root reconciliation closure')], ['Uncovered source bytes / lines / containers',e('0 / 0 / 0 (neutral inventory integrity)')], ['Unchecked mathematical parents',e(0 if closed else 'Final gate pending')], ['Missing current pass verdicts',e(sum(len(set(byid)-set(passes.get(a,{}))) for a in 'ABCD'))] ]
    body.append(table(['Measure','Count'],rows))
    prows=[]
    for a in 'ABCD':
        rs=passes.get(a,{})
        prows.append([e(a),e(len(rs)),e(sum(len(r.get('nested_checks',[])) for r in rs.values())),e(dict(Counter(r['status'] for r in rs.values()))),e('Complete source/formula/dependency attestations in pass report' if rs else 'Pending')])
    body.append(table(['Pass','Parents','Children','Parent statuses','Attestation'],prows))
    body += [p('Historical v1 independent labels differed materially, chiefly over the unspecified bump dilation family. The first parent-level comparison escalated 52 containers and 55 disputes; root quality control added two containers and two disputes. V2 A independently found the annular-bump scope error. All original judgments, supplemental revisions and downstream effects remain in the evidence bundle. Current agreement alone does not overwrite those records.'),'</section>']

    body += ['<section id="C"><h2>C. Complete permanent-container ledger</h2>',p('Every source container is represented below in source order. Exact anchors and full digests are preserved, including non-mathematical containers. Open an anchor or rationale to inspect it. The companion JSON includes every child focus and every pass rationale.'),'<label>Find a container or phrase <input id="find" type="search" placeholder="e.g. S0229, trace, multiplier"></label><p id="shown">419 containers shown</p>']
    ledger=[];rows=[]
    for c in parents:
        rid=c['id'];prs={a:passes[a][rid] for a in passes if rid in passes[a]}
        final=finals.get(rid,'PENDING')
        rationales=''.join(detail('Pass '+a+': '+r['status'],p(r['rationale'])) for a,r in prs.items())
        if c.get('boundary_note'):rationales+=p('Boundary note: '+c['boundary_note'])
        rootnote=gate.get('parent_root_rationales',{}).get(rid,'Root final status pending.' if not closed else 'Current source and dependency reconstruction accepted; see the four affirmative methods and any local dispute entry.')
        ledger.append({'source':c,'passes':prs,'root_final_status':final,'root_rationale':rootnote})
        rows.append([ '<strong>'+e(rid)+'</strong>',e('audit_v3/proof.tex '+str(c['line_start'])+'–'+str(c['line_end'])), '<code>'+e(c['sha256'])+'</code>',detail('Exact source',pre(c['text'])),e(c['mode']),e('yes' if c['mathematical'] else 'no'),e(', '.join(x['id'] for x in c['nested_checks']) or '—'),*[e(prs[a]['status'] if a in prs else 'PENDING') for a in 'ABCD'],e(final),p(rootnote)+rationales])
    body.append(table(['Container','File and lines','Source digest','Exact source anchor','Mode','Mathematical content?','Nested checks','Pass A','Pass B','Pass C','Pass D','Final status','Sentence-level verification or finding'],rows,'ledger'))
    body.append('</section>')

    body += ['<section id="D"><h2>D. Escalated-container and dispute report</h2>',p('The immutable historical anchors below identify the assertions actually disputed. Current revised anchors remain in Section C. Historical status and current status are separate. Every resolution is a direct derivation or counterexample, followed by a versioned repair and renewed dependency checks.')]
    for item in rec['entries']:
        rid=item['parent_id'];body.append('<article id="dispute-'+rid+'"><h3>'+e(rid)+'</h3>')
        body += [p('Historical proof.tex lines '+str(item['source_lines'])+'; anchor SHA-256 '+item['source_sha256']),pre(item['exact_source_anchor'])]
        pos=item['dispute_items'][0].get('original_pass_positions')
        if pos:
            body.append(table(['Pass','Original status','Supplemented status','Original rationale / supplemental reason'],[[e(a),e(x['original_status']),e(x['supplemented_aggregate_status']),p(x['original_rationale'])+pre(json.dumps(x.get('supplemental_reasons',[]),ensure_ascii=False))] for a,x in pos.items()]))
        else:
            body.append(table(['Pass','Original aggregate status','Original rationale'],[[e(a),e(historical[a][rid]['status']),p(historical[a][rid]['rationale'])] for a in 'ABCD']))
        if rid=='S0229':
            body.append(table(['V2 pass','Status','Rationale'],[[e(a),e(v2[a][rid]['status']),p(v2[a][rid]['rationale'])] for a in 'ABCD']))
        for dispute in item['dispute_items']:
            a=dispute['coordinator_reconciliation'];body += ['<h4>'+e(dispute['id']+' — '+dispute.get('title','Local issue'))+'</h4>',p(dispute.get('assertion_to_rederive','Issue is the exact anchored assertion and its necessary hypotheses.')),p('Historical reconciliation: '+a['reconciled_original_status']+'; '+a['classification']),p('Additional check: '+a['additional_derivation']),p('Repair / disposition: '+a['smallest_repair_or_disposition']),p('Current closure: '+dispute.get('closure_state','PENDING'))]
        if item.get('reconciled_historical_parent_status'):
            body.append(p('Reconciled historical parent: '+item['reconciled_historical_parent_status']))
        body += [p('Current parent: '+finals.get(rid,'PENDING'))]
        for a in 'ABCD':
            r=passes.get(a,{}).get(rid)
            if r:body.append(detail('Current pass '+a+': '+r['status'],p(r['rationale'])))
        body.append('</article>')
    body.append('</section>')

    body += ['<section id="E"><h2>E. Numbered list of definite errors</h2>',p('No current-source definite error is asserted unless listed in the final gate. One definite historical source error was confirmed. Ambiguities and missing specifications, including false interpretations of ambiguous wording, are distinguished in Section F.')]
    err=next(x for x in rec['entries'] if x['parent_id']=='S0229')
    error_locations=[]
    for version in ('v1','v2'):
        old=next(c for c in read(ROOT/f'audit_{version}/audit_inventory.json')['containers'] if c['id']=='S0229')
        error_locations.append('audit_'+version+'/proof.tex lines '+str(old['line_start'])+'–'+str(old['line_end']))
    body += ['<h3>1. Exterior identity asserted throughout a bump-support complement</h3>',p('Classification E1 — definite mathematical error. Severity: minor. Location: '+ '; '.join(error_locations)+', S0229, local dispute S0229.R01.'),pre(err['exact_source_anchor']),p('Assumptions: U is any nonnegative radial smooth probability supported in the unit disk; G=(2π)⁻¹ log|x|. An annular bump is allowed.'),p('Explanation and two independent confirmations: for U supported in 1/2<|y|<3/4, angular averaging makes G*U constant on 0<|x|<1/2. The radial Poisson flux identity independently gives zero radial derivative there. G itself is not constant; consequently Z=0 in the hole but −D²G ξ is generally nonzero. The earliest false step is “Outside the bump support, ... G*U₁=G”.'),p('Downstream scope: S0230–S0232 use the profile tail bound; S0237–S0239 use the resulting corrector estimates; LER, global iteration and the final theorem depend on those estimates. Their intended conclusions are not false: the separately established bounded-core estimate handles the entire unit disk, including holes.'),p('Repair, explicitly marked: replace “Outside the bump support” by “For |x|>1”, as done in frozen v3 S0229. Radial averaging then proves the identity. The core/exterior decomposition restores the Lp bounds and all downstream uses. Current revision audits and the direct counterexample check determine the repair status; see Section D.')]
    body += [p('Earlier pre-freeze route calculations also exposed and corrected a reversed mollifier-commutator sign and a one-scale raster rule. Those rejected drafts are research history, not errors in the frozen v1–v3 manuscript; checkpoint.md identifies them and the active proof uses the corrected sign and two scales.'),'</section>']

    body += ['<section id="F"><h2>F. Unjustified, ambiguous, and source-dependent items</h2>',p('Current unresolved mathematical items: '+('none recorded after root reconciliation and final audits.' if closed else 'final gate pending; no completeness claim is made.'))]
    frows=[]
    for item in rec['entries']:
        for d in item['dispute_items']:
            a=d['coordinator_reconciliation']
            if a['reconciled_original_status'] not in ('VERIFIED','ERROR','NOT MATHEMATICAL'):
                frows.append([e(d['id']),e(a['reconciled_original_status']),e(a['classification']),p(a['additional_derivation']),p(a['smallest_repair_or_disposition']),e(finals.get(item['parent_id'],'PENDING'))])
    body.append(table(['Item','Historical status','Class','Missing condition or ambiguity / check','Repair or disposition','Current parent status'],frows))
    body += [p('Specialized external source: Crippa–Stefani, Calculus of Variations and PDE 63, 168 (2024), DOI 10.1007/s00526-024-02750-4. Theorem 3.3 supplies the signed L1∩L∞ Lagrangian background on the plane. Assumption 2.1 requires the kernel size and difference estimates. Assumption 3.1 is applied at finite p=3: domain L1∩L3_ul, range bounded Hölder-1/3 velocities, zero divergence, and no plane boundary. Theorem 2.2 with q=1 supplies that map. Theorem 3.3 applies its divergence bound to bounded integrable densities; its log-Lipschitz modulus follows separately from Corollary 2.4. No endpoint L∞→Lipschitz map is assumed. The every-time representative, relative L2 continuity and velocity formulation are proved in this manuscript.'),'<p><a href="https://link.springer.com/article/10.1007/s00526-024-02750-4">Primary article</a> · <a href="https://link.springer.com/content/pdf/10.1007/s00526-024-02750-4.pdf">Original PDF</a></p>',p('Mechanism credit and mismatch: the moving Lamb-dipole/time-averaging approach is informed by Bruè–Colombo–Kumar, arXiv:2408.07934v1. That paper is not invoked as a theorem proving this target: its torus and endpoint approximation interfaces differ from the present whole-plane arbitrary weak trace. The manuscript supplies its own packet, localization, cross-stress and trace calculations. No novelty or global literature-status conclusion is inferred here.'),'<p><a href="https://arxiv.org/abs/2408.07934v1">Bruè–Colombo–Kumar primary preprint</a></p>','</section>']

    body += ['<section id="G"><h2>G. Dependency and error-propagation report</h2>']
    dd=docs.get('D',{})
    for dep in dd.get('dependency_maps',[]):
        body += ['<h3>'+e(dep['result'])+'</h3>',p('Statement containers: '+', '.join(dep['statement_ids'])),p('Local proof containers: '+', '.join(dep['proof_ids']))]
        for group in dep.get('prerequisites',[]):
            body.append(p(group['role']+': '+', '.join(group['container_ids'])+'. Current final statuses: '+str(dict(Counter(finals.get(x,'PENDING') for x in group['container_ids'])))))
        body += [p('Local statement/proof status: '+str(dict(Counter(finals.get(x,'PENDING') for x in dep['statement_ids']+dep['proof_ids'])))),p(dep.get('explanation','')),p('Survival: '+('the current proof survives the identified historical errors after explicit repairs and renewed dependency checks.' if closed else 'final dependency closure pending.'))]
    body += ['<h3>Theorem and standard-principle hypothesis matching</h3>']
    body.append(table(['Container','Principle','Hypotheses checked','Conclusion used','Status'],[[e(t['container_id']),e(t['principle']),p(t['hypotheses_checked']),p(t['conclusion_used']),e(finals.get(t['container_id'],'PENDING'))] for t in dd.get('theorem_hypothesis_checks',[])]))
    body += [p('Propagation is version-specific. The original missing fixed dilation at S0164 left the row-rule and projected-profile scales unjustified, then the corrector, LER and final theorem unproved by that literal source. It did not prove their negations. The explicit family repairs that branch. C1 visits, translated profiles, interval patches and post-smoothing regularity repair local interfaces; the anchor-time clarification repairs the trace scope. S0229 was false in the central hole but its corrected exterior claim supplies the same downstream tail estimate. The p=3 and positive-plateau refinements close the remaining theorem and partition ambiguity. No original adverse label was erased.'),p('Edge and quantifier checks: zero datum and zero stress; arbitrary signs; nonzero circulation; noncompact support; inhomogeneous H−1; exact weak initial trace; every positive-time curl series in L1; uniform variation including t=0; one global-time series rather than incompatible finite horizons; absence of a harmonic velocity discrepancy. No energy inequality, strong initial convergence, transport renormalization, sign condition or solution selection was silently imposed.'),p('Strongest final hostile whole-proof audit: '+gate.get('hostile_verdict','PENDING')+'. The complete source-bound report is audit_v3/final_hostile_whole_proof.md. Additional fragile-interface and primary-theorem reports, parameter reconstruction and all versioned source records are retained in the bundle.'),'</section>']

    body += ['<section id="H"><h2>H. Final completeness certificate</h2>']
    checklist=gate.get('checklist',[])
    if not checklist:
        checklist=[{'status':'FAIL','text':'Final source, four passes, reconciliation and hostile whole-proof closure remain pending.','support':'No terminal mathematical verdict issued.'}]
    body.append('<ul>'+''.join('<li><strong>'+e(c['status'])+'</strong> — '+e(c['text'])+' '+e(c['support'])+'</li>' for c in checklist)+'</ul></section>')
    # The checklist is the literal final report content. Scripts and styles precede it.
    css='''body{font:15px/1.55 system-ui,sans-serif;color:#17202b;margin:36px auto;max-width:1500px;padding:0 24px}h1,h2,h3{line-height:1.2}h2{border-top:2px solid #ccd5de;padding-top:24px;margin-top:42px}p{max-width:1100px}nav{position:sticky;top:0;background:#fff;padding:12px;border-bottom:1px solid #ccd5de;z-index:3}a{color:#165a8b}table{border-collapse:collapse;width:100%;font-size:13px}th,td{padding:10px;border:1px solid #d4dce4;text-align:left;vertical-align:top}th{background:#edf2f6}td code{overflow-wrap:anywhere;font-size:11px}.scroll{overflow:auto;margin:16px 0}.ledger{min-width:2300px}.ledger td:nth-child(1){position:sticky;left:0;background:white}.ledger td:last-child{min-width:400px}.ledger td:nth-child(4){min-width:280px}pre{white-space:pre-wrap;overflow-wrap:anywhere;font:12px/1.45 ui-monospace,monospace;background:#f4f6f8;padding:12px}details{margin:5px 0}summary{cursor:pointer;color:#165a8b}article{border-top:1px solid #ccd5de;padding-top:16px;margin-top:24px}input{font:inherit;padding:8px;min-width:260px}li{margin:10px 0}@media print{nav,input,label,#shown{display:none}details{display:block}.scroll{overflow:visible}.ledger{min-width:0;font-size:7px}}'''
    script='''document.addEventListener('DOMContentLoaded',()=>{const f=document.getElementById('find');f.addEventListener('input',()=>{let n=0;document.querySelectorAll('.ledger tbody tr').forEach(r=>{const ok=r.textContent.toLowerCase().includes(f.value.toLowerCase());r.hidden=!ok;n+=ok?1:0});document.getElementById('shown').textContent=n+' containers shown'})});'''
    html='<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Vortex-sheet existence audit</title><style>'+css+'</style><script>'+script+'</script></head><body>'+''.join(body)+'</body></html>'
    (OUT/'audit_report.html').write_text(html)
    (OUT/'audit_ledger.json').write_text(json.dumps({'metadata':{'source_sha256':source_hash,'gate_state':gate['state'],'container_count':419,'nested_check_count':861},'containers':ledger},ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'state':gate['state'],'report_bytes':len(html.encode()),'ledger_rows':len(ledger),'completed_pass_files':list(docs),'disputes':sum(len(x['dispute_items']) for x in rec['entries'])}))

if __name__=='__main__':
    main()
