# V2 neutral identity and source correspondence

All 419 permanent parents survive with their identifiers and source order unchanged. Twelve exact reviewed replacements reconstruct the complete revised source. No parent was split, merged, inserted, or deleted.

V2 source SHA-256: `1ffbeee20c4208e954396b55c3f4bc5289e478d76555579b09d5e7fbfae975bd`.
V1 source SHA-256: `b6741b471ba2f128b147f5a5c05fea0afe639c2c3a535b99a5afaf03ea6d4a43`.
V1 consolidated ledger SHA-256: `6c93b60ef4b6b83665605caf389746d2009bb6f4e7520be9f01dfa67cd5082e2`.
V2 ledger SHA-256: `6f43080009e044109938412d2f40e6ba7374ec8777e8be2962c7c1489ea8e0eb`.

All 840 allocated child identities are retained; 15 new children are appended, giving 855 in 253 compound parents. The three scaffolding-only S0130 spans remain allocated. Exact old/new anchor hashes and byte positions for every parent and child appear in identity_correspondence_manifest.json.

| Changed parent | Identity/scope correspondence |
|---|---|
| S0049 | The positive-order square-integrability clause now expressly refers to the latter multiplier family; its property-check role persists. |
| S0139 | The direction and joint rotation clause is revised; the existing velocity scaling definition persists, while the new unit-type condition and pressure definition receive new children. |
| S0158 | The existing temporal-regularity supplement now anchors the express C1 data clause; positivity and center-motion checks persist. |
| S0159 | The packet-equation role persists with explicit translations in its revised exact formula. |
| S0164 | Nonnegative/radial/smooth/probability adjectives now describe the fixed base U rather than directly describing U_H; this defining-profile role is preserved explicitly. The B_H support clause remains about U_H. The old dilation supplement now anchors the explicit definition. |
| S0167 | The intrinsic-stress definition role persists with explicit translations in the revised exact formula. |
| S0242 | Continuity and time-regularity checks now concern the new correction, not the arbitrary old seed. The first smooth occurrence denotes piecewise smoothness; the last remains in the global-smoothness disclaimer. |
| S0247 | The symmetry-check subject is the assembled stress expression rather than all individually displayed tensor factors. |
| S0268 | The old patch-data clause now explicitly gives J interval type. |
| S0304 | The original bounded adjective focus remains the first occurrence, about derivative quantities; the peak-amplitude property is newly explicit. |
| S0357 | The previously simple weak-subsequence statement is now explicitly quantified over sequences of times decreasing to zero and states boundedness; its first one-layer decomposition is appended. |
| S0373 | The kappa-budget role persists with equality in place of inequality. The existing radius-selection supplement now anchors the express r_*=1 choice. |

## Appended child identities

- S0139.C03
- S0139.C04
- S0158.C05
- S0159.C04
- S0159.C05
- S0164.C08
- S0167.C05
- S0167.C06
- S0242.C08
- S0247.C08
- S0268.C06
- S0304.C06
- S0357.C01
- S0357.C02
- S0357.C03

All current source bytes, line positions, parent/child/formula digests, formula-parent containment, and one-layer child depth were validated. The exact target_problem.txt bytes were copied from v1. Original v1 artifacts were checked again and remain unchanged.

Every v2 pass must use the v2 source and frozen v2 inventory hashes. No mathematical verdict from v1 was read or copied. This is a source-identity certificate only.
