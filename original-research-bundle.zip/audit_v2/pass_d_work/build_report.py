"""Write the v2 report from this auditor's rechecked dependency calculations."""
from pathlib import Path
ROOT=Path('/workspace/scratch/de6aed6f6a22')
P=ROOT/'audit_v2'
old=(ROOT/'audit_v1/pass_d_report.md').read_text()
body=old[old.index('## Dependency maps'):old.index('## Pass-D completeness certificate')]
body=body.replace('## Dependency maps','## G. Dependency and global consistency report',1)
body=body.replace('| Explicit translating dipole | S0122–S0142 | Correct speed, pressure, core matching and critical L2/curl norms |','| Explicit translating dipole | S0122–S0142 | Unit directions, simultaneous rotation, explicit pressure scaling, core matching and critical L2/curl norms |')
body=body.replace('| Compact packet source | S0158–S0168 | Exact `2pi(eta r)\' U_H xi` source and small intrinsic error |','| Compact packet source | S0158–S0168 | C1 visit hypotheses, explicit translations, fixed bump dilation, exact source and small intrinsic error |')
body=body.replace('Boundedness in the Hilbert space L2 supplies subsequential weak compactness.','For each expressly stipulated sequence of times decreasing to zero, boundedness in the Hilbert space L2 supplies subsequential weak compactness.')
body=body.replace('The frozen pieces sum to the original stage stress even after earlier colors change the background.','The exact choices `kappa_qj=2^-q/N` and `r_*=1` are positive and satisfy LER; the upper L3/2 budget does not prevent making an increment still smaller to meet the stress tolerance. The frozen pieces sum to the original stage stress even after earlier colors change the background.')
body=body.replace('At fixed coarse data, the principal radii are comparable to H⁸,','The peaks depend on the integer cycle counts but are uniformly bounded; all derivative estimates use this uniform bound. The single fixed bump U in S0164 gives `||grad U_H||1=H^-1||grad U||1` and the exact projected-profile dilation. At fixed coarse data, the principal radii are comparable to H⁸,')
body=body.replace('was inspected at Assumptions 2.1 and 3.1, Definition 3.2, and Theorem 3.3.','was independently retrieved again for this revision and inspected at Assumptions 2.1 and 3.1, Definition 3.2, and Theorem 3.3. The current retrieval references are recorded in `pass_d.json`.')
body=body.replace('| S0357 | Bounded sequence in global L2; Hilbert weak subsequence compactness, also obtainable by countable dense-test diagonal extraction |','| S0357 | The current statement explicitly takes every sequence `t_n` decreasing to zero; the uniform global L2 bound gives a Hilbert weak subsequence, in the regime needed for the next zero-pairing argument |')
body=body.replace('Exact rational arithmetic confirmed','Exact rational arithmetic was rerun against the current formulas and confirmed')

opening='''# Independent pass D — frozen revision v2

## A. Audit scope

**Independent mathematical verdict: PASS.** This verdict is bound to the current source identified below. It does not certify another pass or the coordinator's cross-pass reconciliation.

I reread the entire `proof.tex`, lines 1–949, in source order, every one of its 419 permanent containers, all 855 current shared children, all 579 formula occurrences, the neutral Markdown and JSON inventories, the notation ledger, the exact `target_problem.txt`, and the entire audit instructions. All mathematical content was reconsidered against this version, including unchanged steps, changed hypotheses, affected downstream uses, and the final target. Own earlier calculation notes were used as calculation references only after comparison with the current source; no earlier verdict was adopted without a current check.

The frozen source SHA-256 is `1ffbeee20c4208e954396b55c3f4bc5289e478d76555579b09d5e7fbfae975bd`. The frozen inventory SHA-256 is `6f43080009e044109938412d2f40e6ba7374ec8777e8be2962c7c1489ea8e0eb`. The snapshot filename is `proof.tex`; the neutral inventory records its original filename as `candidate_proof.tex`. Exact complete source anchors, current inclusive line spans, parent digests, modes, mathematical classifications, and child focus digests are included in the JSON ledger.

No other auditor's output, change/reconciliation manifest, route packet, or dependency-provenance file was opened. I did not call `list_agents` or communicate with other auditors. No mathematical work was delegated for this revision. No source or neutral inventory was edited, and the v1 outputs remain untouched.

There are no missing `input`, `include`, bibliography, or macro dependencies. All seven meaning-bearing macros were inspected. All 25 labels are unique and all 27 references have defined, semantically correct destinations. The inventory is an exact disjoint contiguous partition of all 45,127 source bytes. The permanent modes remain 380 SENTENCE, 37 STRUCTURAL, and two BOUNDARY-GROUP containers. S0176 and S0221 retain their frozen boundary-group identity; their complete formulas and grammatical scopes are mathematically determinate.

The named primary paper was independently retrieved and its exact interface checked. No external theorem needed by this pass remains unavailable. Standard analytic principles were matched to concrete hypotheses and, where helpful, reduced to explicit integrals, multiplier estimates, or difference bounds. Exact arithmetic and source-integrity computations are corroboration and are distinguished from mathematical proof.

## B. Coverage summary

| Item | Checked by current pass D | Frozen total |
|---|---:|---:|
| Source lines | 949 | 949 |
| Permanent containers | 419 | 419 |
| Mathematical containers | 388 | 388 |
| Nonmathematical containers | 31 | 31 |
| Compound containers | 253 | 253 |
| Shared children | 855 | 855 |
| Inline formula occurrences | 520 | 520 |
| Display formula occurrences | 59 | 59 |
| Algebra-bearing containers | 106 | 106 |
| External-theorem flagged containers | 22 | 22 |
| Proof environments | 8 | 8 |
| Major-result dependency maps | 8 | 8 |
| Uncovered source lines/containers | 0 | 0 |
| Unchecked mathematical containers/children | 0 | 0 |
| Missing pass-D verdicts | 0 | 0 |

The current parent outcomes are **388 VERIFIED** and **31 NOT MATHEMATICAL**; every other allowed status has count zero. Child outcomes are **852 VERIFIED** and **3 NOT MATHEMATICAL**. The three mechanical focus spans are S0130.C05 (empty), S0130.C10 (whitespace), and S0130.C11 (the cases delimiter); the full mathematical two-branch definition was checked in its complete parent scope.

All six previously appended neutral focus obligations and all fifteen newly appended v2 children are included in the 855 and were directly checked. No additional omitted mathematical item requiring a new supplemental child was found. This pass created no local dispute items and has no unresolved mathematical concern; cross-pass escalation and dispute counts are reserved to the coordinator rather than inferred from unavailable other-pass outputs.

## C. Permanent-container ledger

The machine-readable companion `pass_d.json` contains one source-ordered record for every permanent container and one nested record for every current child. Each parent supplies the current exact source text, source file and line span, current SHA-256, mode, mathematical classification, aggregate status, and affirmative rationale. Each child supplies its current exact focus, digest, status, and rationale read with the entire parent. Where several focused fragments belong to one calculation, the complete affirmative parent calculation is repeated so no fragment is judged outside its hypotheses.

The ledger also contains eight explicit permanent-ID dependency maps, 22 theorem-hypothesis records, primary-source retrieval metadata, computation inputs/results, and empty issue/error-propagation lists. The report below explains the same dependency decisions in prose. It does not replace the exhaustive ledger with a selection of representative claims.

## D. Escalations and current-version sensitive checks

No container requires escalation on this independent pass's evidence. The following current formulations received explicit fresh checks together with their downstream dependencies:

| Containers | Current statement checked | Direct verification and downstream use |
|---|---|---|
| S0049 | Only the differentiated low-frequency multipliers are also L2 | Near zero their order is `|xi|^(|alpha|-1)` for positive alpha; the undifferentiated `1/|xi|` multiplier is claimed only L1. This preserves nonzero-circulation data. |
| S0139, S0141 | Unit directions, simultaneous velocity/pressure rotation, `P_r=r^-2 P(x/r)` | Orthogonal rotation preserves the equation; all three scaled equation terms acquire `r^-3`. Norms have exactly the displayed powers. |
| S0158–S0159 | C1 visit parameters and an explicit translation operator | The time chain rule is justified by the stated hypotheses. Its translation term cancels dipole motion, and both remaining right-hand profiles carry the same translation. |
| S0164, S0214–S0217, S0225–S0239 | One fixed smooth radial probability bump and its explicit dilation | Change of variables yields the uniform gradient and projected-profile scaling. The quadrature and corrector estimates now follow from the actual defined family. |
| S0167 | Both intrinsic stress terms explicitly translated | Spatial divergence commutes with translation, and L1 norm is translation invariant. No derivative of the stress in time is taken. |
| S0242, S0252–S0260, S0337–S0344 | Piecewise time smoothness is asserted for the new correction after fixed spatial mollification | Actual scan parameters are smooth on visits; convolution gives the needed spatial derivatives. Zero traces preserve continuity at resets, and old-background smoothness is not used. |
| S0247 | Symmetry of the assembled stress from transpose pairs | Every mixed dyad occurs with its transpose; all other displayed stress terms are symmetric. The individual Holder bounds remain valid for the unpaired dyads. |
| S0268, S0278 | J is an open interval | A compact temporal support has a containing `[a,b]` compactly inside J. Every global dyadic patch meets this interface. |
| S0304 | Peak amplitudes are uniformly bounded in the cycle count | `eta_i^2=(2/pi)dB_i` may vary but stays bounded at fixed coarse data and floors. Interior and ramp derivative formulas use only this bound and fixed logarithmic derivatives. |
| S0357–S0360 | Weak subsequences explicitly use `t_n` decreasing to zero | The uniform global L2 bound gives a subsequence, and the established zero-time pairings identify its divergence-free/curl-free limit as zero. |
| S0373, S0384–S0386 | Exact positive `kappa_qj=2^-q/N` and `r_*=1` | These meet every LER budget. An upper increment bound still permits choosing a smaller increment for cross-stress tolerance; no later common radius schedule is needed. |

The other consolidated focuses were also independently checked: S0084.C03 follows from a Lipschitz L2 Bochner integral and the norm-one multiplier; S0130.C13 follows from the Cartesian Bessel power series at the origin; S0162.C03 follows from the negative gradient boundary flux. Their explicit focused rationales appear in the ledger.

## E. Definite mathematical errors

None was found in the current frozen source by this pass. There is no earliest erroneous current container and no propagated-error descendant list. This conclusion follows from affirmative local and global checks, rather than absence of a quickly found counterexample.

## F. Unjustified, ambiguous, or source-dependent items

None remains on this pass. No missing regularity, profile choice, normalization, source theorem, or time-representative assumption is silently inserted into the current proof. The target does not require an energy inequality, uniqueness, transported or renormalized limiting vorticity, or a uniform-in-stage global L3 bound; those stronger properties are neither used nor certified.

'''

certificate='''## H. Pass-D completeness certificate

- PASS — The entire received v2 TeX source was inventoried and examined: one file, 949 lines, no missing include or mathematical source dependency.
- PASS — Every source byte and line belongs to the frozen 419-container partition; all 45,127 bytes, parent hashes, child spans and formula spans were validated.
- PASS — All permanent parent and child identifiers and frozen source bytes remained unchanged during this pass.
- PASS — All 253 compound containers were inspected with the single shared non-recursive layer; all 855 children were checked in their current parent scope.
- PASS — Every permanent container has a current pass-D verdict: 388 VERIFIED and 31 NOT MATHEMATICAL; zero missing D verdicts.
- PASS — All 388 mathematical parents, all 852 mathematical child focuses, and all remaining simple or parent-scope mathematical content received affirmative checks; three mechanical child spans were explicitly inventoried as nonmathematical.
- PASS — All 579 formula occurrences were checked: 520 inline and 59 display occurrences; their exact spans and digests match the current source.
- PASS — All 106 algebra-bearing containers were independently re-derived, including signs, powers, constants, pressure conventions, translations and moment cancellations.
- PASS — All 22 theorem-application containers have explicit hypothesis matching; the named primary theorem was retrieved independently for this revision.
- PASS — All eight proof environments were checked locally and globally, and all eight major results have current permanent-ID dependency maps.
- PASS — Degenerate, signed, noncompact, spatial-infinity, interface, temporal-reset, zero-time and every-time cases were investigated.
- PASS — Definitions, parameter scopes, all seven meaning-bearing macros, 25 labels and 27 references were checked throughout the source.
- PASS — Assumption preservation, constants, limiting order, admissible classes, dependencies, exact target matching and potential error propagation were checked; no current error chain was found.
- PASS — This independent pass has no unresolved mathematical finding, omitted shared check or required local dispute; zero new supplemental checks were needed.
- PASS — Computation inputs and exact results are recorded separately from analytic proof; no unavailable source or unperformed method is claimed as evidence.
- PASS — The certificate is strictly for independent current-version pass D. Other passes' coverage, cross-pass escalation/reconciliation and the combined final certificate remain the coordinator's responsibility and are not asserted here.
'''
(P/'pass_d_report.md').write_text(opening+body+certificate)
print('Wrote',P/'pass_d_report.md')
