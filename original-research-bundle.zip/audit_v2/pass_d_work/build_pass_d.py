"""Assemble the independently reread v2 pass-D ledger; do not alter frozen input.

The v1 notes supply this auditor's prior calculations, not inherited statuses.
Every current parent and child was reread in source order before this assembly.
"""
import collections
import datetime
import hashlib
import json
import re
from fractions import Fraction
from pathlib import Path

ROOT = Path('/workspace/scratch/de6aed6f6a22')
P = ROOT / 'audit_v2'
inv = json.loads((P / 'audit_inventory.json').read_text())
forms = json.loads((P / 'audit_formulas.json').read_text())
src = (P / 'proof.tex').read_bytes()
source_hash = hashlib.sha256(src).hexdigest()
inventory_hash = hashlib.sha256((P / 'audit_inventory.json').read_bytes()).hexdigest()
assert source_hash == '1ffbeee20c4208e954396b55c3f4bc5289e478d76555579b09d5e7fbfae975bd'
assert inventory_hash == '6f43080009e044109938412d2f40e6ba7374ec8777e8be2962c7c1489ea8e0eb'

# All of these derivations were checked against the full current source and its
# children before retaining them. The twelve edited parents and dependency-
# sensitive downstream explanations are stated afresh below.
reasons = {}
for line in (ROOT / 'audit_v1/pass_d_work/notes.tsv').read_text().splitlines():
    sid, _old_status, calculation = line.split('\t', 2)
    assert sid not in reasons
    reasons[sid] = calculation

reasons.update({
    'S0049': 'Polar integration near zero gives L1 for m a-hat, behaving like |xi|^-1, and for xi^alpha m a-hat. For positive |alpha| the latter behave like |xi|^(|alpha|-1) and are L2; Schwartz decay handles infinity. The current sentence explicitly restricts its L2 claim to the latter multipliers, so nonzero circulation is allowed.',
    'S0084': 'The Fourier symbol -m(xi) i xi-dot has operator norm one. Applying it to the integrated vorticity identity gives V(t)-V0=-K div F_t in L2, without a harmonic addition because both velocities are canonical. The Bochner integral F_t is Lipschitz in L2, so the same bounded operator proves strong relative-L2 continuity at every time including zero.',
    'S0115': 'This specifies the norm needed for the global Holder closure, rather than adding an input condition. S0249 and S0270 supply an arbitrarily small L^(3/2) correction, while S0247 proves its pairing with the current global L3 velocity is integrable.',
    'S0139': 'For a rotation O with O e1=xi, define the rotated velocity by O D(O^T x) and the rotated pressure by P(O^T x); unit length is explicitly stipulated. D_r=r^-1 D(x/r) and P_r=r^-2 P(x/r) then give the same r^-3 factor in the translating, quadratic-divergence and pressure-gradient terms. Orthogonal rotations preserve the norms.',
    'S0141': 'The explicit jointly rotated definitions in S0139 give r^-3 times the unit-profile equation and divergence zero. In dimension two, ||r^-1 D(x/r)||_p=r^(2/p-1)||D||_p; curl and gradient scale as r^-2. Thus L2, curl-L1 and gradient-L1 are invariant and L^(3/2) scales as r^(1/3); finiteness follows from the matched core and r^-2 exterior decay.',
    'S0158': 'The current hypotheses explicitly require C1 time dependence of r, eta and X, r>0, eta>=0 and Xprime=eta xi/r. Together with the C1 spatial dipole these justify the packet chain rule on each visit. The declared translation T_X f(x)=f(x-X) fixes the sign of its derivative. Later visits have smooth parameters, and their zero endpoint traces justify separate pasting.',
    'S0159': 'Differentiate eta T_X D_r: eta-prime T_X D_r+eta r-prime T_X partial_r D_r-eta Xprime dot T_X grad D_r. The translation term cancels the nonlinear dipole term because Xprime=eta xi/r. Substituting partial_r D_r=D_r/r+div F_r combines the first two scalar coefficients into (eta r)prime/r. Spatial divergence commutes with T_X, so both displayed right-hand profiles are translated as written; the scaled dipole gradient is absorbed into pressure.',
    'S0162': 'For xi=e1 and a large circle of radius R, the exterior streamfunction gives integral_B D_r=pi r e1. Since Pi_r=-r cos(theta)/R on that circle, integral_B grad Pi_r=integral n Pi_r R dtheta=-pi r e1. Their compact difference therefore has integral 2pi r e1. Simultaneous rotation gives the two fluxes and difference for every unit xi.',
    'S0164': 'A nonnegative radial C-infinity function compactly supported in B1 can be normalized to unit integral and then fixed once. Its explicitly stated dilation H^-2 U(x/H) is nonnegative, radial, smooth, unit mass and supported in B_H for H>0. Change of variables gives ||grad U_H||1=H^-1||grad U||1 and first moment at most H; the fixed choice supplies uniform cross-scale constants in quadrature and projection estimates.',
    'S0167': 'Translate the decomposition D_r/r=S_r+grad(Pi_r/r) and div A(S_r-2pi U_H xi)=S_r-2pi U_H xi. Its gradient goes into pressure. This yields source 2pi(eta r)prime U_H(x-X)xi and exactly the two translated stress terms shown. Translation preserves L1; ||F_r||1<=Cr and the zero-moment anti-divergence estimate <=CH(1+|log r|) prove both terms of the bound. No time derivative is applied to the stress.',
    'S0225': 'The current fixed dilation at S0164 gives the projected profile Z_H(x)=H^-2 Z_1(x/H): the homogeneous order-zero multiplier commutes with dilation and rotations. This identity uses a single chosen U, so constants in all ensuing H estimates are uniform. The regularized Newtonian potential is smooth in the core and has the radial harmonic exterior.',
    'S0242': 'The actual scan parameters are smooth on each visit and the complete-cycle primitive is smooth on its time pieces. Fixed spatial convolution of the new packet makes all spatial derivatives needed for repeated time chain rules available. The new correction is continuous at zero packet/corrector endpoints, though time derivatives may jump there; no time smoothness of the old background is claimed.',
    'S0247': 'R, the averaged tensor, E and qI are symmetric, and each mixed product in the displayed assembled stress appears with its transpose. Holder with (3,3/2) bounds u tensor v and u tensor Q, with (2,2) bounds v tensor Q, and the pointwise tensor norm gives ||Q tensor Q||1=||Q||2^2. The dipole norm gives the additional factor eta r^(1/3). No individual mixed dyad is claimed symmetric.',
    'S0268': 'The current pair is in the explicitly stated admissible class. J is now expressly an open interval compactly contained in positive time; a compact temporal support consequently has a compact containing interval inside J. The independently prescribed symmetric S retains one-sided L1 continuity on the inherited partition, exactly the input used in coarse approximation and later frozen-piece cancellation.',
    'S0278': 'Because J is an open interval and supp_t S is a compact subset of J, choose a below its minimum and b above its maximum with [a,b] contained in J. If S is zero the trivial correction already handles it. This choice has positive distance to zero time and the boundary of J, as required by the subsequent finite partition.',
    'S0304': 'For interior motion, r=r0 c(s) and sprime=eta/(r0 c), so eta rprime=eta^2 cprime/c and (eta r)prime has the same bound when eta is constant. On a ramp r=r0 e and eta=eta_i zeta, so r eta-prime is bounded by a fixed multiple of eta_i^2 because ramp duration is r0 e L/(eta_i I_zeta). The peak eta_i are uniformly bounded in N_k by S0298; fixed floors keep cprime/c bounded. Thus both claimed quantities are uniform without assuming eta_i independent of N_k.',
    'S0357': 'For any explicitly stipulated sequence t_n decreasing to zero, the lemma hypothesis sup_t ||W(t)||2<infinity gives a bounded sequence in global L2. Weak sequential compactness of this Hilbert space yields a weakly convergent subsequence. The stated zero-time regime is exactly the one needed to use the pairing limits in S0356 at the next step.',
    'S0358': 'The subsequence in S0357 approaches zero, so its weak L2 limit preserves div W=0 and has zero pairing with every compact solenoidal psi by S0356. For any compact scalar phi, psi=nabla-perp phi is admissible and its pairing is minus the distributional curl pairing. Hence the limit has both zero divergence and zero curl.',
    'S0373': 'The displayed choices epsilon=delta_(q+1)m_j/N, zeta=sqrt(delta_q)/N and kappa=2^-q/N are all strictly positive because m_j>=1 and delta_q>0; r_*=1 is an explicit positive radius budget. LER takes size at most delta_q M_j. These upper budgets can be met simultaneously since its fine scale can make the L^(3/2) increment smaller still when the current old-L3 cross-stress estimate requires it. No later argument needs radii tending to zero with q.',
    'S0386': 'At most N patches are active and each has the actual positive choice kappa_qj=2^-q/N, so the triangle inequality gives ||w_q||_(3/2)<=2^-q. LER can choose a smaller increment than this upper bound to satisfy its independent stress tolerance; the fixed numerical budget does not force a nonzero lower size.',
})

# Focus-specific notes for all six consolidated supplementary obligations and
# all fifteen newly appended v2 children, plus revised scope-sensitive children.
child_reasons = {
    'S0084.C03': 'V nu is bounded in L2 on each finite horizon, so F_t=integral_0^t V nu is Lipschitz into L2. The norm-one multiplier -K div carries it to V(t)-V0, proving the separately asserted relative-L2 continuity at every time including zero.',
    'S0130.C13': 'The interior term J1(beta rho) sin(theta) is (beta/2)y plus a convergent series of y(x^2+y^2)^k. It has a smooth Cartesian extension at rho=0; the polar origin is removable and introduces no extra vortex or singularity.',
    'S0158.C04': 'C1 time dependence is now an express hypothesis for all three functions. Positive r makes dilation differentiable on each visit, and D is C1 in space; all subsequent first derivatives, products and chain rules are therefore defined under the stated data.',
    'S0162.C03': 'On a large circle Pi_r=-r cos(theta)/R for xi=e1. Thus integral grad Pi_r=integral n Pi_r R dtheta=-pi r e1, while integral D_r=pi r e1. Rotating gives the two asserted fluxes and hence compact mean 2pi r xi.',
    'S0164.C07': 'The cross-scale family is explicitly H^-2 U(x/H) for one fixed U. Therefore ||grad U_H||1=H^-1||grad U||1 and P(U_H xi)=H^-2 P(U xi)(x/H); constants cannot vary through a hidden H-dependent choice of profile.',
    'S0373.C04': 'The displayed r_*=1 is positive and meets the LER input. Fineness can always enforce the strict upper radius bound for each patch; no subsequent estimate demands another radius schedule.',
    'S0139.C03': 'The direction is explicitly restricted to the unit circle, permitting an orthogonal rotation taking e1 to xi; hence no unaccounted direction-length factor enters speed or norm formulas.',
    'S0139.C04': 'After simultaneous rotation, P_r(x)=r^-2 P(x/r) has gradient r^-3 grad P(x/r). This is the same factor as the convective and translating terms of the scaled dipole equation.',
    'S0158.C05': 'T_X f(x)=f(x-X) is an explicitly defined spatial translation. Its time derivative is T_X(partial_t f)-Xprime dot T_X grad f, which fixes the signs used in S0159.',
    'S0159.C04': 'The eta-prime and radius-derivative linear terms combine to [eta-prime+eta rprime/r]T_X D_r=(eta r)prime T_X D_r/r. Retaining T_X is necessary and is now explicit.',
    'S0159.C05': 'The radius derivative contributes eta rprime T_X div F_r. Translation commutes with spatial divergence and the coefficient is spatially constant, yielding precisely div(eta rprime T_X F_r).',
    'S0164.C08': 'Fixing one U in C_c-infinity(B1), with the separately stated nonnegativity, radiality and unit mass, is possible by normalizing a standard radial bump. Compact support lies strictly inside B1 and dilates inside B_H.',
    'S0167.C05': 'The radial derivative stress remains eta rprime T_X F_r from the packet equation. Its L1 norm is translation invariant and bounded by C|eta rprime|r.',
    'S0167.C06': 'Applying the spatial anti-divergence before translating gives div T_X A(f)=T_X f. With f=S_r-2pi U_H xi, zero moments and support in B_H give its L1 bound; the temporal scalar is (eta r)prime, and no time derivative of this stress is asserted.',
    'S0242.C08': 'A fixed spatial mollifier on each cycle makes the new packet a smooth spatial profile; composing with the actual smooth scan parameters permits arbitrarily many time derivatives on each visit. This qualification applies to the new correction, and does not assert smoothness of the old field.',
    'S0247.C08': 'For vectors a,b, (a tensor b)^T=b tensor a. The actual expression contains u/v, u/Q and v/Q cross terms in such pairs, while all remaining terms are symmetric. Thus the assembled stress is symmetric.',
    'S0268.C06': 'J is explicitly an open interval with compact closure in (0,infinity). Compactly supported S therefore admits [a,b] compactly inside J, and all later global I_j applications meet this interval hypothesis.',
    'S0304.C06': 'The normalization eta_i^2=(2/pi)dB_i may depend on the cycle count, but dB_i tends to a finite positive fixed-profile quantity at fixed coarse data and floors. Hence peak amplitudes are uniformly bounded for large N_k, exactly what the derivative estimates require.',
    'S0357.C01': 'The quantifier is every sequence t_n decreasing to zero, so subsequent use of the zero-time limits of compact test pairings is valid. Any counterexample to weak convergence near zero has such a decreasing subsequence.',
    'S0357.C02': 'The lemma expressly assumes a uniform global-L2 bound for W on (0,T). Sampling at the positive times t_n preserves the same bound.',
    'S0357.C03': 'L2 is a Hilbert space and hence reflexive; a bounded sequence has a weakly convergent subsequence. Equivalently one can extract pairings on a countable dense set and extend by the uniform bound.',
}

def ids(a, b):
    return [f'S{i:04d}' for i in range(a, b + 1)]

def dep(role, numbers):
    return {'role': role, 'container_ids': numbers, 'status': 'VERIFIED'}

maps = [
 {'result':'Canonical velocity and physical-space decomposition','statement_ids':ids(34,39),'proof_ids':ids(40,52),'prerequisites':[dep('Exact datum class, kernel, curl and Fourier conventions',ids(26,33))],'outcome':'VERIFIED','explanation':'Low frequencies remain in bounded C0 V0; radial cancellation gives v0 in L1, and the inhomogeneous-H^-1 multiplier estimate gives v0 in L2. Only differentiated low-frequency multipliers are claimed L2.'},
 {'result':'Bounded background and trace','statement_ids':ids(60,61),'proof_ids':ids(62,90),'prerequisites':[dep('Smoothed signed L1/Linfinity datum and canonical V0',ids(34,52)),dep('Primary Crippa-Stefani theorem and kernel hypotheses',ids(54,59))],'outcome':'VERIFIED','explanation':'The a.e. source representative is replaced by an every-time volume-preserving flow representative before continuity and relative-L2 estimates. The velocity equation follows from a curl-free L2 acceleration.'},
 {'result':'Initial Euler-Reynolds seed','statement_ids':ids(96,100),'proof_ids':ids(101,114),'prerequisites':[dep('Physical-space initial decomposition',ids(34,52)),dep('Global background with exact trace',ids(60,90)),dep('ER convention and quartic kernel',ids(92,95))],'outcome':'VERIFIED','explanation':'The derivative stress costs Ct times the initial measure variation, so the seed stress is bounded at zero. All positive-time velocity and one-sided stress classes needed below are proved.'},
 {'result':'Prescribed-piece local endpoint repair (LER)','statement_ids':ids(261,275),'proof_ids':ids(276,349),'prerequisites':[dep('Dipole, unit rotations, explicit pressure scaling and critical norms',ids(122,142)),dep('Symmetric integrable anti-divergence and radial derivative',ids(144,156)),dep('C1 visit data, translations, fixed bump dilation and exact packet stress',ids(158,168)),dep('Directional coefficients, raster, normalization and quadrature',ids(171,219)),dep('Full-cycle projected-bump corrector, pressure and new-correction time regularity',ids(221,242)),dep('Symmetric nonlinear stress and all cross estimates',ids(243,250)),dep('Fixed-cycle smoothing and signed commutator',ids(252,260))],'outcome':'VERIFIED','explanation':'The interval input, positive floors, uniformly bounded peaks and explicit dilation support all scales. Coarse data precede floors, cycle counts and smoothing. Only the current compact-time L3 bound is used; the leading L2/curl constant is universal.'},
 {'result':'Zero initial trace from anchor times','statement_ids':ids(351,353),'proof_ids':ids(354,360),'prerequisites':[dep('ER stress and solenoidal-test convention',['S0092'])],'outcome':'VERIFIED','explanation':'Uniform Lipschitz compact-test pairings and zero anchors give zero limits. The weak subsequence is explicitly taken along times decreasing to zero, so its global-L2 limit has zero div and curl and is zero.'},
 {'result':'Global iteration','statement_ids':['S0361'],'proof_ids':ids(362,406),'prerequisites':[dep('Admissible seed, finite-horizon bounds and exact trace',ids(96,114)),dep('LER independent prescribed piece and all simultaneous budgets',ids(261,349)),dep('Anchor-time trace lemma',ids(351,360))],'outcome':'VERIFIED','explanation':'Frozen chi_j R pieces cancel after sequential colors. Exact positive budgets and r_*=1 meet LER. Geometric L2/curl convergence gives every-time finite curl and strong positive-time continuity; anchor traces and a bounded-energy temporal cutoff give the exact initial formulation.'},
 {'result':'Canonical normalization from fixed background','statement_ids':ids(407,408),'proof_ids':ids(409,413),'prerequisites':[dep('Finite-measure convolution local integrability and distributional kernel identities',ids(40,43))],'outcome':'VERIFIED','explanation':'The harmonic residual has mean bounded by a vanishing C0 average, C||v||2/R and C||mu||/R. Thus no harmonic addition survives and no later-time H^-1 assumption is required.'},
 {'result':'Global existence for the exact target','statement_ids':['S0414'],'proof_ids':ids(415,418),'prerequisites':[dep('Exact target',ids(26,30)),dep('Global iteration, every-time curl and exact weak initial equation',ids(361,406)),dep('Fixed-background normalization',ids(407,413)),dep('V0 is C0',['S0038','S0050']),dep('Every-time relative background L2',['S0060','S0084','S0086']),dep('Every-time seed perturbation L2',['S0098','S0104']),dep('Every-time summable global L2 correction',['S0384','S0393'])],'outcome':'VERIFIED','explanation':'The one global construction has all target properties. At each positive time u-V0 is L2 and its curl is a finite measure, so the normalization lemma applies; the prescribed canonical initial datum handles zero.'},
]

theorem_rows = [
 ('S0040','Tonelli','The absolute kernel integrand is nonnegative; its integral over any translated radius-R ball is at most CR, and |mu| is finite.','Local L1 and a.e. existence of the finite-measure Biot-Savart convolution.'),
 ('S0046','Young/measure convolution','L_a is compactly supported with an integrable 1/r singularity; |mu| has mass M. Direct Tonelli establishes the estimate.','||L_a*mu||1<=||L_a||1 M.'),
 ('S0048','Plancherel','The squared high-frequency multiplier times 1+|xi|^2 is bounded, and the datum has precisely the inhomogeneous H^-1 Fourier integral.','Global L2 of v0 without a zero-mass restriction.'),
 ('S0050','Fourier inversion and Riemann-Lebesgue','mu-hat is bounded; all low-frequency multipliers and their polynomially differentiated versions are L1 by the current S0049.','Bounded smooth V0, vanishing at infinity with every derivative.'),
 ('S0054','Crippa-Stefani primary interface','Assumptions 2.1 and 3.1, Definition 3.2 and Theorem 3.3 were retrieved. The stated whole-plane, signed L1/Linfinity, canonical Lagrangian interface matches.','The precise bounded-vorticity source theorem is available.'),
 ('S0062','Crippa-Stefani existence','S0039 gives signed nu0 in L1 and Linfinity. S0058 verifies size and difference kernel bounds, zero divergence and the vacuous plane boundary condition.','One global source Lagrangian solution, with a.e.-time representative scope retained before the local refinement.'),
 ('S0065','Osgood flow uniqueness and continuation','The reciprocal integral of r(1+|log r|) diverges at zero. Time measurability and finite-horizon bounded velocity give Caratheodory trajectories, displacement bounds and global continuation.','Unique forward/backward flow with continuous dependence.'),
 ('S0067','Jacobian ODE','At each fixed spatial mollification scale the velocity is spatially smooth with bounded derivatives, time measurable, and divergence free.','The determinant solves Jprime=0 and the flow preserves Lebesgue measure.'),
 ('S0069','Dominated convergence','A compact test can be reached only from a common bounded set because displacement is uniformly bounded; mollified flows converge on it.','Measure preservation passes to the limiting flow.'),
 ('S0081','Chebyshev','The near convolution is L1 with bound rM and the far field is at most lambda/2; M=0 is treated separately.','Distribution function bounded by C M^2/lambda^2.'),
 ('S0082','Layer cake','The nonnegative distribution function bound is integrated only to the finite Linfinity cutoff B.','||V||3^3<=C||nu||1^2||V||infinity.'),
 ('S0104','Plancherel and dominated convergence','v0 is L2; exp(-t^4|xi|^4) is bounded by one and tends to one pointwise.','L2 contraction and strong trace for W.'),
 ('S0110','Absolute Fubini','The translated-ball integral of |K| is uniformly finite, b_t has finite L1 norm and sigma0 has finite variation.','Associativity against compact tests yields W=K*(b_t*sigma0).'),
 ('S0126','Intermediate value theorem','The Bessel power series is continuous on [3,4] and exact alternating bounds give strict opposite endpoint signs.','A root beta belongs to (3,4).'),
 ('S0128','Linear ODE uniqueness','The Bessel equation is regular at beta>0; zero value and derivative determine the zero solution on the positive axis.','J0(beta) cannot vanish, because J1 has nonzero linear Taylor coefficient at zero.'),
 ('S0214','Banach-space fundamental theorem of calculus','The row map is C1 into L1; its derivative norm is integrable over the fixed finite rectangle.','Rectangle-rule error bounded by d times the integrated L1 derivative.'),
 ('S0232','Minkowski and Bochner integration','The explicitly dilated projected profile lies in Lp for p>1, translation is strongly continuous, and the finite-cycle source coefficients are integrable.','Corrector Lp bounds by the time integral of the source coefficient norm.'),
 ('S0256','Uniform approximate identities on compact sets','The closed-cycle packet image is compact in L2, its square image compact in L1, and fixed probability convolution is a contraction.','Uniformly small spatial commutator and convolution errors after the cycle is fixed.'),
 ('S0309','Holder','The current field has finite compact-time global L3 norm, the principal/corrector have small L^(3/2), and both new fields have the stated L2 bounds.','All old/new and new/new products belong globally to L1 and vanish in the chosen fine-scale limit.'),
 ('S0338','Young convolution','1+1/3=1/2+1/(6/5); the fixed mollifier has L^(6/5) norm C ell^(-1/3).','Fixed smoothing converts the new L2 time continuity into L3 time continuity.'),
 ('S0357','Hilbert weak sequential compactness','The current source explicitly takes t_n decreasing to zero and assumes a uniform global-L2 bound for W.','A weak L2 subsequence exists in exactly the regime needed for the next zero-pairing step.'),
 ('S0409','Weyl lemma','The residual is locally L1 by the measure-kernel bound; zero div and curl imply zero Laplacian componentwise.','A smooth harmonic representative exists and obeys the mean-value identity.'),
]
theorem_checks = [{'container_id':s,'principle':t,'hypotheses_checked':h,'conclusion_used':c,'status':'VERIFIED'} for s,t,h,c in theorem_rows]
assert {c['id'] for c in inv['containers'] if c['external_theorem_invocation']} == {x['container_id'] for x in theorem_checks}

records=[]
end=0
md_rows={line.strip('| ').split(' | ')[0]:line for line in (P/'audit_inventory.md').read_text().splitlines() if line.startswith('| S')}
for c in inv['containers']:
    assert c['byte_start']==end
    end=c['byte_end_exclusive']
    assert src[c['byte_start']:end].decode()==c['text']
    assert hashlib.sha256(c['text'].encode()).hexdigest()==c['sha256']
    assert '`'+c['sha256'][:16]+'`' in md_rows[c['id']]
    assert int(md_rows[c['id']].strip('| ').split(' | ')[4])==len(c['nested_checks'])
    if c['mathematical']:
        status='VERIFIED'
        reason=reasons[c['id']]
    else:
        status='NOT MATHEMATICAL'
        if c['id'] in ids(1,10):
            reason='Formatting, package or theorem-environment declaration only; the entire current span was inspected and contains no mathematical assertion or operator definition.'
        elif c['id'] in ids(18,25):
            reason='Document title, attribution, date, structural command, status prose or heading only; no mathematical assertion occurs in the current span.'
        elif c['id']=='S0419':
            reason='Document closing command only; no mathematical content.'
        else:
            reason='Section or subsection heading only; mathematical content is separately checked in the subsequent permanent containers.'
    nested=[]
    for ch in c['nested_checks']:
        assert src[ch['byte_start']:ch['byte_end_exclusive']].decode()==ch['text']
        assert hashlib.sha256(ch['text'].encode()).hexdigest()==ch['sha256']
        if ch['id'] in ('S0130.C05','S0130.C10','S0130.C11'):
            st='NOT MATHEMATICAL'
            why='The exact focus is empty, whitespace or the cases delimiter. Both mathematical branches and their domains were affirmatively checked in the complete parent and neighboring focuses.'
        else:
            st='VERIFIED'
            why=child_reasons.get(ch['id'],reason)
        nested.append({'id':ch['id'],'status':st,'rationale':why,'focus_sha256':ch['sha256'],'source_text':ch['text']})
    records.append({'id':c['id'],'source_sha256':c['sha256'],'status':status,'rationale':reason,'nested_checks':nested,'supplemental_checks':[],'source_file':'proof.tex','original_source_file':'candidate_proof.tex','line_start':c['line_start'],'line_end':c['line_end'],'source_text':c['text'],'mode':c['mode'],'mathematical':c['mathematical'],'review_basis':'Entire current-v2 parent, every current shared child and all remaining parent-scope mathematical content reread and affirmatively rechecked.'})
assert end==len(src)
for f in forms['formulas']:
    assert src[f['byte_start']:f['byte_end_exclusive']].decode()==f['text']
    assert hashlib.sha256(f['text'].encode()).hexdigest()==f['sha256']
assert len(records)==419 and sum(len(r['nested_checks']) for r in records)==855
counts=collections.Counter(r['status'] for r in records)
childcounts=collections.Counter(n['status'] for r in records for n in r['nested_checks'])
assert counts=={'VERIFIED':388,'NOT MATHEMATICAL':31}
assert childcounts=={'VERIFIED':852,'NOT MATHEMATICAL':3}
labels=re.findall(r'\\label\{([^}]+)\}',src.decode())
refs=re.findall(r'\\(?:eqref|ref)\{([^}]+)\}',src.decode())
assert len(labels)==len(set(labels))==25 and len(refs)==27 and not set(refs)-set(labels)

def j1_truncated(z,n):
    return Fraction(z,2)*sum((-Fraction(z*z,4))**k/Fraction(__import__('math').factorial(k)*__import__('math').factorial(k+1)) for k in range(n+1))
assert j1_truncated(3,3)==Fraction(669,2048)
assert j1_truncated(4,4)==-Fraction(2,45)
for s11,s22,s12,a,b in [(2,-3,5,7,8),(0,0,0,1,1)]:
    a1,a2,a3,a4=b-s11,b-s22,a-s12,a+s12
    got=((a1+Fraction(a3+a4,2),Fraction(a3-a4,2)),(Fraction(a3-a4,2),a2+Fraction(a3+a4,2)))
    assert got==((a+b-s11,-s12),(-s12,a+b-s22))

obj={
 'metadata':{
  'pass':'D','revision_id':'v2','focus':'Independent global consistency, dependency, theorem-interface and exact-target verification with local re-derivation of every current container and child',
  'source_filename':'proof.tex','source_sha256':source_hash,'inventory_sha256':inventory_hash,'source_lines_examined':[1,949],'source_bytes':len(src),
  'permanent_container_count':419,'containers_examined':419,'shared_nested_checks_examined':855,'new_supplemental_checks_examined':0,'mathematical_containers_examined':388,'non_mathematical_containers_examined':31,'compound_containers_examined':253,
  'formula_occurrences_examined':579,'inline_formula_occurrences_examined':520,'display_formula_occurrences_examined':59,'algebra_bearing_containers_rederived':106,'external_theorem_containers_matched':22,'proof_environments_examined':8,'major_result_dependency_maps':8,
  'uncovered_containers':0,'uncovered_source_lines':0,'unchecked_mathematical_containers':0,'unexamined_shared_children':0,'status_counts':dict(counts),'shared_child_status_counts':dict(childcounts),
  'independence':'Only the exact current source, neutral inventories, notation, target, original audit instructions, this auditor\'s own v1 calculations, and independently retrieved primary theorem were used. No other pass output, change/reconciliation manifest, prior audit from another context, route packet or dependency-provenance file was read. No inter-auditor communication or list_agents call was made.',
  'revision_review':'All 419 current parents and 855 children were reread in source order and mathematically reconsidered. This auditor\'s prior calculation notes were retained only after current-source comparison; changed claims and all affected dependency interfaces were freshly derived. No v1 status was copied into the current verdict decision.',
  'overall_verdict':'PASS','verdict_scope':'Independent revision-bound pass D only; cross-pass comparison and final multi-pass certification remain with the coordinator.','frozen_source_modified':False,'frozen_inventory_modified':False,'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()
 },
 'records':records,'dependency_maps':maps,'theorem_hypothesis_checks':theorem_checks,'critical_errors':[],'unjustified_or_ambiguous_items':[],'earliest_affected_containers':[],'propagated_error_descendants':[],'new_supplemental_checks':[],
 'primary_sources':[{'title':'Crippa-Stefani, An elementary proof of existence and uniqueness for the Euler flow in localized Yudovich spaces','url':'https://link.springer.com/article/10.1007/s00526-024-02750-4','current_retrieval_refs':['turn112view0','turn112view1','turn112view2','turn112view3'],'interfaces_inspected':['Assumption 2.1','Assumption 3.1','Definition 3.2','Theorem 3.3'],'status':'VERIFIED','matching_summary':'Signed L1/Linfinity data, whole-plane kernel hypotheses, bounded-vorticity canonical Lagrangian solution and a.e.-time source scope match. Every-time representatives, relative-L2 continuity and the velocity equation are established separately in the manuscript.'}],
 'computational_checks':[
  {'method':'fractions.Fraction, rerun against v2 formulas','claim':'Bessel endpoint truncations S0124','inputs':'J1(3), k=0..3; J1(4), k=0..4','result':'669/2048 and -2/45 exactly','scope':'Finite arithmetic corroboration; alternating remainders and the root/ODE argument were checked analytically.'},
  {'method':'Exact rational tensor arithmetic and independent component derivation','claim':'S0176 coefficient identity','inputs':'(S11,S22,S12,A,B)=(2,-3,5,7,8) and (0,0,0,1,1)','result':'Each matrix equals -S+(A+B)I.','scope':'Finite tests corroborate the universal component proof; numerical agreement is not used as proof.'},
  {'method':'SHA256, exact source spans, contiguous partition and Markdown-row comparison','claim':'Current-version coverage and anchoring','result':'419 exact parent hashes, 855 exact child hashes, 579 formula hashes and all 419 Markdown rows match; the parent partition covers all 45127 bytes.','scope':'Procedural integrity only.'},
  {'method':'Exact label/reference extraction plus semantic source reading','claim':'Cross-reference integrity','result':'25 unique labels, 27 references, no undefined references.','scope':'Syntactic checks corroborate the independently inspected semantic dependencies.'}
 ],
 'notation_clarifications_not_findings':[],
 'cross_pass_reconciliation':{'performed_by_this_independent_pass':False,'reason':'Other passes and coordinator conclusions were deliberately not inspected.'}
}
(P/'pass_d.json').write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n')
(P/'pass_d_work/notes.tsv').write_text('\n'.join(r['id']+'\t'+r['status']+'\t'+r['rationale'] for r in records if r['mathematical'])+'\n')
print(json.dumps({'source_sha256':source_hash,'inventory_sha256':inventory_hash,'parents':len(records),'children':sum(len(r['nested_checks']) for r in records),'parent_statuses':dict(counts),'child_statuses':dict(childcounts),'major_maps':len(maps),'theorem_checks':len(theorem_checks),'bytes':len(src)}))
