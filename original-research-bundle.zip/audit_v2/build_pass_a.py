import json, hashlib, collections
from pathlib import Path

root = Path(__file__).resolve().parent
raw = (root / 'proof.tex').read_bytes()
source_hash = '1ffbeee20c4208e954396b55c3f4bc5289e478d76555579b09d5e7fbfae975bd'
inventory_hash = '6f43080009e044109938412d2f40e6ba7374ec8777e8be2962c7c1489ea8e0eb'
assert hashlib.sha256(raw).hexdigest() == source_hash
invraw = (root / 'audit_inventory.json').read_bytes()
assert hashlib.sha256(invraw).hexdigest() == inventory_hash
inv = json.loads(invraw)

# These are this auditor's own algebraic reconstruction notes, reaffirmed after
# reading every current v2 parent and child in source order. No other pass,
# reconciliation, change manifest, route, or dependency-provenance file is read.
# Old status labels are discarded: the current verdicts below are v2 judgments.
reconstructions = {}
for line in (root.parent / 'audit_v1' / 'pass_a_notes.tsv').read_text().splitlines():
    ident, ignored_old_status, rationale = line.split('|', 2)
    reconstructions[ident] = rationale

current = {
'S0049': 'The current sentence explicitly restricts square integrability to the latter, positive-order multipliers. At zero m*a-hat has size |xi|^-1 and is L1 but generally not L2; xi^alpha*m*a-hat has size |xi|^(|alpha|-1), which is L1 and L2 for |alpha|>=1. Schwartz decay handles infinity.',
'S0084': 'The multiplier of -K div is -xi-perp tensor xi/|xi|^2, with operator norm one away from zero. V*nu is strongly continuous into L2: use C_t Linfinity of V, C_t L2 of nu, and bounded norms. Its Bochner primitive is C_t L2; applying the bounded multiplier gives the canonical relative velocity identity and strong L2 continuity, including zero.',
'S0130': 'The denominator beta J0(beta) is nonzero by the preceding recurrence/ODE argument. At zero the interior profile equals x2[-1+1/J0(beta)-beta^2|x|^2/(8J0(beta))+O(|x|^4)], a convergent power series in Cartesian coordinates; this defines its removable value and all derivatives. The branches agree at rho=1, and the exterior formula is never used at zero.',
'S0139': 'The direction is now explicitly unit length. Rotate velocity by the rotation matrix and pressure by composition with its inverse; this preserves Euler and the unit translation speed. For r>0 the explicitly defined D_r=r^-1 D(x/r) and P_r=r^-2 P(x/r) make convection, pressure gradient and r^-1 directional derivative all scale as r^-3.',
'S0141': 'The explicitly defined pressure P_r=r^-2 P(x/r) has gradient scaling r^-3, as do convection and r^-1 partial_xi D_r. Change of variables gives ||D_r||p=r^(2/p-1)||D||p; a spatial derivative costs r^-1. Thus L2, curl L1 and gradient L1 are invariant, and the L3/2 exponent is 1/3.',
'S0158': 'The current hypotheses explicitly give C1 time paths on every visit, r>0, eta>=0 and X\'=eta xi/r. Thus division and the following chain/product rules are legitimate on visits. T_X is explicitly the spatial translation f(x-X); the later construction pastes visits by zero velocity traces.',
'S0159': 'Direct differentiation gives eta\' T_XD_r+eta r\' T_X partial_rD_r-eta^2/r T_X partial_xiD_r. The last term and self-convection cancel up to the scaled pressure by the dipole equation. Substitution of partial_rD_r=D_r/r+div F_r leaves (eta r)\' T_XD_r/r+div(eta r\' T_XF_r), with both translations now explicit.',
'S0162': 'For xi=e1, integrate D_r=grad-perp psi_r on a large radius-R circle: psi_r=-r sin(theta)/R gives integral D_r=(pi r,0). On that circle Pi=-r cos(theta)/R, and integral grad Pi=integral_boundary Pi n=(-pi r,0). Subtraction gives 2pi r e1; rotations give 2pi r xi. The negative gradient boundary integral is essential.',
'S0164': 'The source now fixes U in C_c-infinity(B1), nonnegative, radial, with integral one, and defines U_H=H^-2 U(x/H) for positive H. Change of variables gives unit mass and support in B_H; radial symmetry cancels first moments. All later derivative/scaling constants are consequently norms of this one fixed profile.',
'S0167': 'Use T_XD_r/r=T_XS_r+grad(T_XPi_r/r). Absorb the latter gradient into pressure. The zero-moment decomposition S_r=2pi U_H xi+div A(S_r-2pi U_H xi), followed by translation, gives the displayed E=eta r\' T_XF_r+(eta r)\' T_X A(S_r-2pi U_H xi). Translation is an L1 isometry, so the two stated norm terms follow with exactly their coefficients.',
'S0229': 'ERROR, minor E1 scope overstatement. The asserted identities are correct for |x|>1, but not on the entire complement of supp U. Choose a smooth radial unit-mass U supported in 1/2<|x|<3/4, allowed by S0164. For |x|<1/2, angular averaging makes G*U constant, while G=(2pi)^-1 log|x| is nonconstant; consequently Z=0 there but -D2G xi is nonzero for xi!=0. The O(|x|^-2) far-field conclusion remains true. Replace the opening scope by For |x|>1.',
'S0230': 'The bounded-core proof S0228 applies on the entire closed unit disk, including any holes of the bump support. For |x|>1, the valid radial averaging identity gives Z=-D2G xi=O(|x|^-2). Therefore the tail integral integral_1^infinity rho^(1-2p) d rho converges for every finite p>1; boundedness also gives p=infinity. This does not use the false extension of S0229 into holes.',
'S0231': 'S0164 now explicitly defines a fixed dilation family. Distributional Hessian scaling gives Z_H(x)=H^-2 Z_1(x/H), since the additive log H term disappears under two derivatives. Changing variables yields ||Z_H||p=H^(2/p-2)||Z_1||p for finite p>1, and H^-2 for p=infinity; S0230 gives the finite constants.',
'S0242': 'The source explicitly concerns the new correction after the fixed spatial mollification for its piecewise time smoothness. On each raster visit the coefficient/ramp paths are smooth and radii positive; convolution makes the translated/scaled profile smooth in space and hence smooth in time. Q is a projected smooth-bump primitive. Both fields have matching zero endpoint values; Q\' may jump when the full-cycle average changes, so the stated failure of global time smoothness is consistent.',
'S0247': 'The assertion is now symmetry of the assembled displayed Rtilde: R, A_av, qI, E and Q tensor Q are symmetric, and each mixed product is explicitly paired with its transpose. Holder with 1/3+2/3=1 gives the old-new bounds; ||v||_(3/2)=C eta r^(1/3), Cauchy-Schwarz gives the v-Q bound, and ||Q tensor Q||1=||Q||2^2.',
'S0268': 'The current statement explicitly takes J to be a relatively compact open interval in positive time. Prescribed S is independent of current R, symmetric, time-compact in J and piecewise L1-continuous on the inherited partition with its stated one-sided extension convention. These hypotheses supply the compact interval and finite coarse subdivisions used below.',
'S0270': 'The finite-cell raster supplies divergence-free w=v_ell+Q_ell with compact time support. The valid bounded-core/exterior profile estimates give Q small in L2, L3/2 and curl L1. Intrinsic, averaging, mixed and smoothing errors can be made <=epsilon; coefficient-mass control gives C sqrt(delta)+zeta, and positive powers of H give L3/2<=kappa. The endpoint definitions and continuity checks preserve the full stated class. No identity inside holes of supp U is needed.',
'S0278': 'Because J is explicitly an open interval and the temporal support of S is a compact subset of J, there is a closed interval [a,b] compactly contained in J with that support in its interior. This follows by choosing endpoints strictly between the support extrema and the endpoints of J; the empty support was already handled by delta=0.',
'S0304': 'The revised phrase uniformly bounded peak amplitudes matches S0298: eta_i may vary with N_k but stays bounded. On rows, eta r\'=(eta r)\'=eta_i^2 partial_xi log c_i; on ramps, |(eta r)\'|<=eta_i^2 I_zeta||zeta\'||infinity/L and r\'=0. Positive fixed floors bound log derivatives, so both prefactors remain bounded independently of N_k.',
'S0348': 'The constructed stress is symmetric, locally bounded in L1 and has the required one-sided L1 extensions; the velocity is continuous into local L2 and global L3 and satisfies Euler-Reynolds distributionally. The explicit time-smoothness qualification at S0242 is consistent with, and stronger than needed for, this admissible class.',
'S0357': 'The current sentence explicitly quantifies over every sequence t_n decreasing to zero. Uniform global L2 boundedness and weak sequential compactness of the Hilbert space L2 supply a weakly convergent subsequence of W(t_n), with no assumption of global L2 for the background velocity.',
'S0373': 'All four LER parameters are now explicit and positive: epsilon=delta_(q+1)m_j/N, zeta=sqrt(delta_q)/N, kappa=2^-q/N and r_*=1. Frozen S_qj has supremum <=delta_q M_j, compact support in I_j and the inherited one-sided continuity. Thus every LER hypothesis matches for the current pair; further smallness of actual increments can be imposed through fine parameters under these upper budgets.',
'S0386': 'At most N active local increments each have L3/2 norm <=2^-q/N, giving stage norm <=2^-q and a summable series. In each LER application its separate stress tolerance already forces the actual mixed products small against that current finite old L3 norm; increasing the cycle count can make the realized norm smaller still while respecting the prescribed upper cap. No uniform-in-stage old L3 bound is used.',
'S0414': 'The initial decomposition accepts every target signed finite inhomogeneous-H^-1 datum. The seed, local repair and dyadic iteration establish every weak equation, continuity and curl bound; the fixed-background lemma establishes the canonical identity at every time. These deductions use the valid |x|>1 radial identity plus the bounded-core estimate, not the erroneous support-complement extension in S0229; the minor local error therefore does not obstruct this reconstructed theorem.',
}
reconstructions.update(current)
assert set(reconstructions) == {c['id'] for c in inv['containers']}

child_rationales = {
'S0084.C03': 'V*nu is C_t L2 by ||(V(t)-V(s))nu(t)||2+||V(s)(nu(t)-nu(s))||2. Thus F_t is a strong Bochner primitive; the norm-one L2 multiplier gives strong relative L2 continuity at every time, including zero.',
'S0130.C13': 'The apparent polar-origin singularity is removable: J1(beta rho)/rho has an everywhere convergent power series in rho^2. Consequently psi=x2[-1+1/J0(beta)-beta^2|x|^2/(8J0(beta))+...] extends smoothly at x=0, and D is its smooth rotated gradient there.',
'S0139.C03': 'xi is explicitly required to belong to S1. A proper rotation sends e1 to xi, so the translation speed and all normalization constants are preserved.',
'S0139.C04': 'The source now explicitly rotates P with D and sets P_r=r^-2 P(x/r). Its gradient is r^-3 times the rotated gradient of P, exactly matching the other two scaled Euler terms.',
'S0158.C04': 'C1 time regularity is explicitly stated for r, eta and X on each visit, and r>0 makes the quotient speed and every displayed chain/product rule meaningful.',
'S0158.C05': 'The definition T_X f(x)=f(x-X) is a spatial translation, applied componentwise to vector fields and tensors. At fixed time it commutes with spatial derivatives and preserves Lp norms.',
'S0159.C04': 'The term from amplitude/radius differentiation is ((eta r)\'/r)D_r(x-X), precisely ((eta r)\'/r)T_X D_r. No unshifted source remains.',
'S0159.C05': 'The radius anti-divergence appears as eta r\' F_r(x-X); since the scalar coefficient is spatially constant, its spatial divergence is eta r\' T_X div F_r.',
'S0162.C03': 'On a large circle Pi=-r(x dot xi)/|x|^2, so integral grad Pi=integral Pi n dS=-r integral (n dot xi)n dtheta=-pi r xi. The minus sign is direct and makes the Z mean 2pi r xi.',
'S0164.C07': 'The fixed scaling U_H(x)=H^-2 U(x/H) is now explicit. It yields ||grad U_H||1=H^-1||grad U||1 and all profile scaling used later, with constants independent of H.',
'S0164.C08': 'A single nonnegative radial compact smooth unit-mass U in B1 exists by normalizing any nonzero radial nonnegative bump. These hypotheses allow annular support; no positivity throughout the disk is stated or needed for the estimates.',
'S0167.C05': 'The first intrinsic tensor is explicitly eta r\' T_XF_r; translation preserves the Cr norm bound for F_r and commutes with its divergence.',
'S0167.C06': 'The second intrinsic tensor is explicitly (eta r)\' T_X A(S_r-2pi U_H xi). Translating after applying A preserves its L1 norm and translates its divergence to the desired centered compact source.',
'S0229.C01': 'For an allowed radial probability U supported in 1/2<|y|<3/4 and |x|<1/2, angular averaging gives (G*U)(x)=(2pi)^-1 integral log|y| U(y)dy, constant in x. It cannot equal (2pi)^-1 log|x| on that hole. The asserted equality is valid on |x|>1, but the stated complement-of-support scope is broader.',
'S0229.C02': 'Radiality of the fixed U is stated at S0164. Angular averaging correctly gives average_theta log|r-s e^(i theta)|=log(max(r,s)); the scope issue is in setting max(r,s)=r when r can lie in an inner hole.',
'S0229.C03': 'In the central hole of an annular U, both U and D2(G*U) vanish, so Z=0. For x!=0 there, D2G(x)=(2pi|x|^2)^-1(I-2 e_r tensor e_r) is invertible and D2G xi!=0 for unit xi. Thus the displayed equality fails on that allowed part of the stated domain; it holds for |x|>1.',
'S0229.C04': 'D2G(x)=(2pi)^-1[I/|x|^2-2x tensor x/|x|^4], so its operator norm is exactly (2pi)^-1|x|^-2. The stated O(|x|^-2) behavior at infinity is correct, including for annular bumps.',
'S0242.C01': 'Inside a cycle Q\'=-P(U-Ubar); a different full-cycle average or bump scale can give a derivative jump at a joining time despite matching zero Q values.',
'S0242.C02': 'The current subject is the new velocity correction v+Q. Its L2 and L3/2 paths have zero matching endpoint values by flat ramps and the full-cycle primitive, giving continuity after concatenation.',
'S0242.C03': 'Positive-radius scaling and translation give norm continuity within each visit; zero amplitude and zero primitive give continuity at resets and cycle endpoints. Fixed convolution preserves it.',
'S0242.C04': 'The source now qualifies piecewise smoothness by the fixed spatial mollification. Smooth raster paths acting on mollified profiles are smooth in time on each visit, while the projected smooth-bump primitive is smooth within its time pieces.',
'S0242.C05': 'After spatial convolution the new packet has arbitrary spatial derivatives in the relevant Lp spaces; differentiating smooth translation/scaling paths therefore gives arbitrary time derivatives inside a visit. This is the qualified smoothness now asserted.',
'S0242.C06': 'A jump of Q\' at a cycle boundary is compatible with the source statement that the new correction need not be globally smooth in time.',
'S0242.C07': 'The explicit nonclaim of global time smoothness is correct because cycle-average changes can change one-sided derivatives, while values remain continuous.',
'S0242.C08': 'The added phrase after the fixed spatial mollification below supplies the necessary qualification for time smoothness of the translated dipole. The raw profile is only C1 across its core circle; the current claim no longer asserts arbitrary time regularity of its raw translations.',
'S0247.C01': 'The current assertion concerns the complete displayed Rtilde. The symmetric old/intrinsic/average/scalar/quadratic terms and each explicitly transposed mixed pair sum to a symmetric tensor.',
'S0247.C02': 'Transposing the assembled formula fixes R, A_av, qI, E and Q tensor Q, and exchanges the two members of each mixed pair, so Rtilde^T=Rtilde.',
'S0247.C03': 'Pointwise |u tensor v|=|u||v|; Holder exponents 3 and 3/2 are conjugate, proving ||u tensor v||1<=||u||3||v||_(3/2).',
'S0247.C04': 'The norm ||v||_(3/2)=eta r^(2/(3/2)-1)||D||_(3/2)=C eta r^(1/3), so the second inequality has exactly exponent 1/3.',
'S0247.C05': 'Holder with the same conjugate exponents gives ||u tensor Q||1<=||u||3||Q||_(3/2).',
'S0247.C06': 'Cauchy-Schwarz applied to |v||Q| gives ||v tensor Q||1<=||v||2||Q||2.',
'S0247.C07': 'The Euclidean/Frobenius norm of Q tensor Q is |Q|^2, so its L1 norm equals ||Q||2^2 exactly.',
'S0247.C08': 'Each mixed product in the assembled stress appears with its transpose: u-v, u-Q and v-Q. That pairing, explicitly cited in the revised wording, supplies symmetry without claiming symmetry of an individual unsymmetrized rank-one tensor.',
'S0268.C06': 'J is now explicitly an open interval, relatively compact in (0,infinity), so any compact temporal support inside J can be enclosed by one closed interval compactly inside J.',
'S0304.C01': 'The row/ramp derivative formulas bound both prefactors by a fixed constant times eta_i^2, and S0298 bounds these peak amplitudes uniformly in the cycle count.',
'S0304.C02': 'On rows eta r\'=(eta r)\'=eta_i^2 partial_xi log c_i; on ramps r\'=0 and (eta r)\'=r0 e eta_i zeta\'/T=eta_i^2 I_zeta zeta\'/L. All remaining constants are fixed.',
'S0304.C03': 'S0298 gives eta_i<=C uniformly for sufficiently large N_k, while fixed positive floors give finite logarithmic derivative bounds. Their product gives the asserted N_k-independent bound.',
'S0304.C04': 'The coefficients c_i=a_i+e_i are fixed before N_k varies and have a strictly positive lower bound on their finite rectangles; their logarithmic spatial derivatives are finite fixed constants.',
'S0304.C05': 'Strictly positive fixed floors keep c_i away from zero, so no division in partial log c_i becomes singular during a visit or as N_k increases.',
'S0304.C06': 'The revised phrase uniformly bounded peak amplitudes is exactly what follows from eta_i^2=(2/pi)d_k B_i with d_k B_i converging to a finite positive limit. No claim that eta_i is identical for different N_k remains.',
'S0357.C01': 'Every sequence t_n decreasing to zero lies in the near-zero horizon eventually; the assumed uniform L2 bound applies to W(t_n).',
'S0357.C02': 'Uniform boundedness in L2 is an anchor-lemma hypothesis; it concerns the velocity difference W, whose global L2 norm is available.',
'S0357.C03': 'L2 is a reflexive Hilbert space, so every bounded sequence in it has a weakly convergent subsequence. The explicit sequence of times makes the asserted compactness conclusion precise.',
'S0373.C04': 'The current text supplies the formerly unused radius parameter explicitly as r_*=1>0. The LER construction can impose this simultaneously with all other tolerances by making the radii, which are O(H^8), sufficiently small.',
}

records = []
for c in inv['containers']:
    ident = c['id']
    assert raw[c['byte_start']:c['byte_end_exclusive']].decode() == c['text']
    assert hashlib.sha256(c['text'].encode()).hexdigest() == c['sha256']
    status = ('NOT MATHEMATICAL' if not c['mathematical'] else
              'ERROR' if ident == 'S0229' else 'VERIFIED')
    children = []
    for n in c['nested_checks']:
        assert hashlib.sha256(raw[n['byte_start']:n['byte_end_exclusive']]).hexdigest() == n['sha256']
        ns = ('NOT MATHEMATICAL' if n['id'] in inv['scaffolding_only_child_ids'] else
              'ERROR' if n['id'] in {'S0229.C01', 'S0229.C03'} else 'VERIFIED')
        nr = child_rationales.get(n['id'], reconstructions[ident])
        if ns == 'NOT MATHEMATICAL':
            nr = 'This frozen focus contains only case/alignment closing or empty layout bytes; the complete formula and both cases are checked in the surrounding mathematical children and parent.'
        children.append({'id': n['id'], 'source_sha256': n['sha256'], 'status': ns, 'rationale': nr})
    records.append({'id': ident, 'source_sha256': c['sha256'], 'status': status,
                    'rationale': reconstructions[ident], 'nested_checks': children,
                    'supplemental_checks': []})

assert len(records) == 419
assert sum(len(r['nested_checks']) for r in records) == 855
assert set(child_rationales) <= {n['id'] for r in records for n in r['nested_checks']}
for r in records:
    statuses = {n['status'] for n in r['nested_checks']}
    if statuses:
        aggregate = ('ERROR' if 'ERROR' in statuses else 'VERIFIED' if 'VERIFIED' in statuses else 'NOT MATHEMATICAL')
        assert aggregate == r['status'], (r['id'], aggregate, r['status'])

metadata = {
 'pass': 'A', 'revision_id': 'v2',
 'focus': 'Independent source-ordered local verification: definitions, types, domains, quantifiers, every algebraic calculation, signs, factors, exponents, denominators, endpoints, limits, derivatives and integrals.',
 'source_filename': 'proof.tex', 'original_source_filename': 'candidate_proof.tex',
 'source_sha256': source_hash, 'inventory_sha256': inventory_hash,
 'source_lines_examined': [1, 949], 'source_bytes_examined': len(raw),
 'containers_examined': 419, 'nested_checks_examined': 855,
 'supplemental_checks_proposed': 0,
 'formulas_examined': 579, 'inline_formulas_examined': 520, 'display_formulas_examined': 59,
 'mathematical_containers_examined': 388, 'non_mathematical_containers_examined': 31,
 'compound_containers_examined': 253,
 'algebra_bearing_containers_examined': 106, 'external_theorem_containers_examined': 22,
 'proof_environments_examined': 8, 'major_result_dependency_maps_examined': 8,
 'container_status_counts': dict(collections.Counter(r['status'] for r in records)),
 'nested_status_counts': dict(collections.Counter(n['status'] for r in records for n in r['nested_checks'])),
 'uncovered_source_bytes': 0, 'uncovered_source_lines': 0, 'uncovered_containers': 0,
 'unchecked_mathematical_containers': 0, 'missing_pass_a_verdicts': 0, 'missing_nested_verdicts': 0,
 'independence': 'The full current source, 419 current parents and 855 current children were reread in source order, and current formula/notation/target inventories inspected. This auditor rechecked the current mathematics and affected dependencies before reaffirming its own prior derivations. No other pass output, reconciliation/change manifest, route, checkpoint or dependency-provenance file was read; no agent-status listing or communication with other auditors occurred in this revision pass.',
 'revision_method': 'Old verdict labels were discarded. Current statuses are assigned from current source checks. This auditor\'s own v1 algebraic notes are reused only as reconstruction text for claims explicitly reaffirmed in v2; all changed clauses and newly explicit assumptions have fresh rationales, as do affected dependent statements. The v1 files remain unchanged.',
 'primary_source': {'url': 'https://link.springer.com/article/10.1007/s00526-024-02750-4',
  'inspected': 'Assumptions 2.1/3.1, Definition 3.2, Theorem 3.3 and equations 3.4-3.7 reopened from the original primary article for v2.',
  'retrieval_refs': ['turn113view0','turn114view0','turn114view1','turn114view2','turn114view3','turn115view0']},
 'computational_check': {'method': 'Python fractions.Fraction exact rational arithmetic, rerun in v2',
  'inputs': ['J1(3) series terms m=0..3', 'J1(4) series terms m=0..4'],
  'outputs': ['669/2048', '-2/45'], 'scope': 'Exact finite sums; the alternating-tail sign and decreasing magnitude were established analytically.'},
 'source_integrity_check': 'Every parent and child text/hash was checked against its exact source byte span; parents form a contiguous disjoint full-byte partition. Every one of 579 formula spans/texts/hashes was checked and lies within its stated parent. Source and inventory SHA256 match the supplied frozen hashes.',
 'overall': 'FAIL',
 'overall_scope': 'One minor definite literal scope error at S0229.C01/C03. No fatal defect was established. The later Lp and temporal-corrector estimates use only the valid exterior identity and separately proved bounded core, so their mathematical conclusions and the global construction survive the smallest local repair.',
 'child_rationale_convention': 'Where the same direct calculation proves several children, its parent reconstruction is repeated in those records. New or scope-sensitive children receive separate affirmative rationales. The three frozen layout-only children are NOT MATHEMATICAL.',
}
(root / 'pass_a_notes.tsv').write_text('\n'.join(r['id']+'|'+r['status']+'|'+r['rationale'] for r in records)+'\n')
(root / 'pass_a.json').write_text(json.dumps({'metadata': metadata, 'records': records}, ensure_ascii=False, indent=2)+'\n')
print(json.dumps(metadata['container_status_counts']))
print(json.dumps(metadata['nested_status_counts']))
print('pass_a.json bytes', (root / 'pass_a.json').stat().st_size)
