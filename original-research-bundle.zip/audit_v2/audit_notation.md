# Neutral v2 source and notation inventory

Source `proof.tex`, immutable revision of `candidate_proof.tex`; 949 lines; SHA-256 `1ffbeee20c4208e954396b55c3f4bc5289e478d76555579b09d5e7fbfae975bd`.

No correctness conclusions are recorded. No TeX input/include/bibliography commands occur.

## Macro and theorem declarations

- S0007, lines 7–7: `\newtheorem{theorem}{Theorem}[section]`
- S0008, lines 8–8: `\newtheorem{lemma}[theorem]{Lemma}`
- S0009, lines 9–9: `\newtheorem{proposition}[theorem]{Proposition}`
- S0010, lines 10–10: `\theoremstyle{remark}\newtheorem{remark}[theorem]{Remark}`
- S0011, lines 11–11: `\newcommand{\R}{\mathbb R}`
- S0012, lines 12–12: `\newcommand{\M}{\mathcal M}`
- S0013, lines 13–13: `\newcommand{\curl}{\operatorname{curl}}`
- S0014, lines 14–14: `\newcommand{\Div}{\operatorname{div}}`
- S0015, lines 15–15: `\newcommand{\supp}{\operatorname{supp}}`
- S0016, lines 16–16: `\newcommand{\norm}[2]{\left\|#1\right\|_{#2}}`
- S0017, lines 17–17: `\newcommand{\dd}{\,dx}`

## External URLs and source pointers

- S0054, lines 107–110: `Crippa--Stefani, \emph{An elementary proof of existence and uniqueness for the Euler flow in localized Yudovich spaces}, Calc. Var. PDE 63, 168 (2024), Theorem 3.3, with Assumptions 2.1 and 3.1 and Definition 3.2, \url{https://link.springer.com/article/10.1007/s00526-024-02750-4}.`

## Labels and references

| Label | Declared in | Used in |
|---|---|---|
| `lem:decomp` | S0034 | S0060 |
| `lem:background` | S0060 | S0109 |
| `eq:ER` | S0092 | S0097, S0103 |
| `prop:seed` | S0096 | S0361, S0369 |
| `rem:cross` | S0115 | — |
| `eq:dipole` | S0141 | S0159 |
| `eq:dipole-norms` | S0141 | — |
| `eq:anti` | S0149 | S0166, S0342 |
| `eq:radial` | S0156 | S0159 |
| `eq:packet` | S0159 | S0167 |
| `eq:packet-source` | S0167 | S0244 |
| `eq:E-bound` | S0167 | S0206, S0305 |
| `sec:repair-interface` | S0169 | — |
| `eq:scales` | S0187 | — |
| `eq:normalization` | S0198 | S0202, S0296 |
| `eq:average` | S0207 | S0244 |
| `eq:quad` | S0210 | S0215, S0217, S0308 |
| `eq:Q` | S0237 | S0306 |
| `ass:LER` | S0261 | — |
| `eq:coarse-approx` | S0280 | S0310 |
| `lem:anchors` | S0351 | S0390 |
| `prop:iteration` | S0361 | S0415 |
| `eq:increment-stage` | S0384 | S0389, S0397 |
| `lem:canonical` | S0407 | S0416 |
| `thm:global` | S0414 | — |

## Definition and data-declaration locations

- S0026, lines 29–29: `Let $K(x)=(-x_2,x_1)/(2\pi|x|^2)$.`
- S0027, lines 29–31: `Given any finite signed Radon measure $\mu_0\in\M(\R^2)\cap H^{-1}(\R^2)$, with the \emph{inhomogeneous} Sobolev space and no sign restriction, set $u_0=K*\mu_0$.`
- S0032, lines 53–56: `We use $\nabla^\perp=(-\partial_2,\partial_1)$, $(\nabla v)_{ij}=\partial_jv_i$, $(\Div S)_i=\sum_j\partial_jS_{ij}$, and $\widehat f(\xi)=\int e^{-ix\cdot\xi}f(x)\dd$.`
- S0034, lines 57–60: `\begin{lemma}[Canonical velocity and the physical-space decomposition]\label{lem:decomp} Let $\mu\in\M\cap H^{-1}$ and $M=\norm\mu\M$.`
- S0036, lines 62–63: `Fix a nonnegative radial $a\in C_c^\infty(B_A)$ of integral one.`
- S0037, lines 63–67: `Set \[  \nu_0=a*\mu,\quad \sigma_0=\mu-\nu_0,\quad  V_0=K*\nu_0,\quad v_0=(K-K*a)*\mu. \]`
- S0069, lines 143–145: `For a compact continuous test, bounded displacement confines its transported support to a fixed bounded set; dominated convergence passes volume preservation to the original flow $X_t$.`
- S0070, lines 145–147: `Define $\nu(t)=\nu_0\circ X_t^{-1}$ at every time.`
- S0073, lines 151–151: `Set $V(t)=K*\nu(t)$ at every time.`
- S0092, lines 192–198: `The convention for Euler--Reynolds is \begin{equation}\label{eq:ER}  \partial_tu+\Div(u\otimes u)+\nabla p=\Div R,  \qquad \Div u=0, \end{equation} where $R$ is symmetric.`
- S0093, lines 198–199: `Let $b=\mathcal F^{-1}(e^{-|\xi|^4})$ and $b_t(x)=t^{-2}b(x/t)$ for $t>0$.`
- S0095, lines 200–200: `Write $C_b=\norm b1$.`
- S0096, lines 200–210: `\begin{proposition}[Initial Euler--Reynolds seed]\label{prop:seed} For the preceding decomposition and background, put \[  W(t)=b_t*v_0,\qquad u^{(0)}=V+W,\qquad p^{(0)}=p_V, \] \[  R^{(0)}=W\otimes W+V\otimes W+W\otimes V  -4t^3\bigl[\nabla\Delta W+(\nabla\De`
- S0130, lines 275–285: `In polar coordinates set \[  \psi(\rho,\theta)=  \begin{cases}  -\rho\sin\theta+\dfrac{2J_1(\beta\rho)}{\beta J_0(\beta)}\sin\theta,  &\rho\leq1,\\  -\sin\theta/\rho,&\rho\geq1,  \end{cases}  \qquad D=\nabla^\perp\psi. \]`
- S0139, lines 302–304: `For a unit direction $\xi\in\mathbb S^1$, rotate the velocity and pressure profiles together, and write $D_r(x)=r^{-1}D(x/r)$ and $P_r(x)=r^{-2}P(x/r)$.`
- S0144, lines 319–327: `For a vector field $f$ supported in $B_R$, with \[  \int f=0,\qquad \int x_jf_i(x)\dd=0\quad\hbox{for every }i,j, \] define \[  (\mathcal Af)_{ij}=\partial_i\Delta^{-1}f_j+  \partial_j\Delta^{-1}f_i-\delta_{ij}\Div\Delta^{-1}f. \]`
- S0158, lines 353–353: `On each visit take $r,\eta,X$ to be $C^1$ in time, with $r(t)>0$, $\eta(t)\geq0$, and $X'=\eta\xi/r$, and write $T_X f(x)=f(x-X)$.`
- S0160, lines 359–366: `Choose a radial cutoff $\chi$ equal to zero on $B_1$ and one outside $B_2$, let $\alpha=1/5$, and put \[  \Phi_\xi(x)=-\xi\cdot x/|x|^2,\quad  \Pi_r(x)=r\chi(x/r^\alpha)\Phi_\xi(x),\quad  Z_r=D_r-\nabla\Pi_r. \]`
- S0164, lines 371–373: `Fix a nonnegative radial smooth probability bump $U\in C_c^\infty(B_1)$ and define $U_H(x)=H^{-2}U(x/H)$, supported in $B_H$.`
- S0172, lines 395–397: `For a fixed smooth compactly supported tensor $S$, choose a nonnegative compact smooth function $h$ equal to one on a neighborhood of its support.`
- S0173, lines 397–402: `For $\gamma>0$ put \[  A=\sqrt{S_{12}^2+\gamma^2h^2},\qquad  B=\sqrt{S_{11}^2+S_{22}^2+\gamma^2h^2}. \]`
- S0174, lines 402–404: `These functions are smooth: near the zero set of $h$, the entries of $S$ already vanish, so both square roots reduce to $\gamma h$.`
- S0176, lines 405–411: `Define \[  a_1=B-S_{11},\quad a_2=B-S_{22},\quad  a_3=A-S_{12},\quad a_4=A+S_{12},\quad q=A+B \] Then $-S+qI=\sum_i a_i\xi_i\otimes\xi_i$.`
- S0181, lines 418–420: `Fix a coefficient and its rectangle in coordinates $(s,y)$ adapted to $\xi$.`
- S0182, lines 420–421: `Write $a$ for the original compactly supported coefficient.`
- S0183, lines 421–423: `On the scanning rectangle define $c=a+e$ with a strictly positive floor $e>0$, and use constant-$e$ longitudinal buffers where $a=0$.`
- S0184, lines 423–425: `Write $\varepsilon_{\rm floor}$ for the total added floor and buffer mass, including the fixed factors from the ramp durations below.`
- S0187, lines 428–432: `We use two distinct scales \begin{equation}\label{eq:scales}  d=H^2\quad\hbox{(row spacing)},\qquad  \tau\asymp H^6\quad\hbox{(cycle duration)}. \end{equation}`
- S0194, lines 444–445: `Write $I_\zeta=\int_0^1\zeta>0$.`
- S0196, lines 446–449: `To traverse a buffer of length $L$, choose ramp duration $r_0eL/(\eta I_\zeta)$.`
- S0197, lines 449–451: `Let $B_i$ be the sum over rows of the interior line integrals of $c_i=a_i+e_i$, plus $2e_iL/I_\zeta$ per row for the two ramps.`
- S0198, lines 451–456: `Allocate $\tau_i=\tau/4$ to direction $i$, and set \begin{equation}\label{eq:normalization}  \eta_i^2=\frac{\tau dB_i}{2\pi\tau_i},\qquad  r_{0,i}=\frac{\tau d}{2\pi\eta_i}. \end{equation}`
- S0209, lines 481–482: `Write the tensor in parentheses, summed over four directions, as $A_{\rm av}$.`
- S0221, lines 507–511: `On each cycle $[t_k,t_k+\tau]$ put \[  Q(t)=-\mathbb P\int_{t_k}^t  (\mathcal U(s)-\overline{\mathcal U})\,ds, \]`
- S0226, lines 517–520: `Let $G=(2\pi)^{-1}\log|x|$ and \[  Z_{H,\xi}=U_H\xi-(D^2G*U_H)\xi. \]`
- S0228, lines 521–523: `At $H=1$ it is smooth and bounded in the core: write the Hessian convolution as $\partial_iG*\partial_jU_1$, whose $|x|^{-1}$ singularity is integrable.`
- S0234, lines 531–535: `For an explicit pressure sign, write $q_{H,\xi}=\xi\cdot\nabla(G*U_H)$ and let $\pi_{\mathcal U}(t)=2\pi(\eta r)'q_{H,\xi}(\cdot-X(t))$ for the active direction, with zero value when no packet is active.`
- S0243, lines 553–555: `Given an old distributional Euler--Reynolds seed $(u,p,R)$, set $\widetilde u=u+v+Q$.`
- S0268, lines 613–617: `Let $(u,R)$ be any current pair in this class, $J\Subset(0,\infty)$ an open interval, and $S$ a prescribed symmetric tensor compactly supported in time in $J$, piecewise continuous into $L^1$ on the inherited partition.`
- S0269, lines 617–618: `Write $\delta=\sup_J\norm S1$.`
- S0277, lines 641–642: `Suppose henceforth that $\delta>0$.`
- S0278, lines 642–643: `Choose $[a,b]\Subset J$ containing the temporal support of $S$ in its interior.`
- S0288, lines 664–666: `Choose its regularization parameter and the positive floors so that all added coefficient mass is arbitrarily small.`
- S0292, lines 672–674: `Fix the coarse tensor, rectangles, floors, and ramp functions.`
- S0311, lines 709–711: `Finally choose a fixed spatial mollification scale on each complete cycle.`
- S0312, lines 711–712: `The finite set of cycles has a positive minimum radius.`
- S0319, lines 724–728: `At times strictly inside a coarse cell, set \[  E_{\rm total}(t)=S(t)-S_k+E_k^{\rm loc}(t)\qquad(t\in I_k). \]`
- S0321, lines 729–731: `Choose $\varepsilon_0\leq\varepsilon/2$ and all local stress errors at most $\varepsilon/2$.`
- S0323, lines 732–734: `Choose $\varepsilon_0$ also so that $C\sqrt\varepsilon_0\leq\zeta/3$.`
- S0324, lines 734–736: `Next choose added coefficient masses small enough for their amplitude cost to be at most $\zeta/3$.`
- S0325, lines 736–738: `Finally choose the cycle counts large enough that the row-rule amplitude error and the $L^2$ and curl cost of $Q$ use at most the remaining $\zeta/3$.`
- S0332, lines 748–749: `Define $E_{\rm total}=0$ outside this interval; the prescribed $S$ is zero there.`
- S0333, lines 749–752: `On the finite set of inherited, coarse-cell, and full-cycle boundary times, choose $E_{\rm total}(t)=0$ and $\widetilde R(t)=R(t)-S(t)$.`
- S0351, lines 786–790: `\begin{lemma}[Zero initial trace from anchor times]\label{lem:anchors} Suppose $(U,R)$ and $(\widetilde U,\widetilde R)$ are positive-time Euler--Reynolds pairs with continuous local $L^2$ velocities, uniformly bounded local kinetic energies and global $L^1$ s`
- S0352, lines 790–792: `Suppose $W=\widetilde U-U$ is uniformly bounded in global $L^2$ and $W(t_k)=0$ for a sequence $t_k\downarrow0$.`
- S0362, lines 820–826: `\begin{proof} Choose a nonnegative $\eta\in C_c^\infty((1/2,2))$ whose dyadic dilates cover $(0,\infty)$ and set \[  I_j=(2^{j-1},2^{j+1}),\qquad  \chi_j(t)=\frac{\eta(t/2^j)}{\sum_{k\in\mathbb Z}\eta(t/2^k)}. \]`
- S0368, lines 831–834: `Choose a smooth nondecreasing majorant $\Theta\geq1$, finite on every finite horizon including zero, such that $\norm{R^{(0)}(t)}1\leq\Theta(t)$.`
- S0370, lines 835–836: `Let $\delta_q=16^{-q}$ and inductively require $\norm{R^{(q)}(t)}1\leq\delta_q\Theta(t)$.`
- S0372, lines 838–838: `Set $M_j=\sup_{I_j}\Theta$, $m_j=\inf_{I_j}\Theta\geq1$.`
- S0407, lines 915–918: `\begin{lemma}[Canonical normalization from a fixed background]\label{lem:canonical} Suppose $u=U+v$, where $U\in C_0(\R^2;\R^2)$, $v\in L^2$, $\Div u=0$, and $\mu=\curl u\in\M$.`
- S0412, lines 930–932: `The first tends to zero since $U\in C_0$: separate a fixed large compact set from its uniformly small complement.`

## Revised explicit definitions and conditions

- S0139.C03: Explicit unit-direction membership and its type. Exact focus: `a unit direction $\xi\in\mathbb S^1$`
- S0139.C04: Definition of the scaled pressure profile. Exact focus: `$P_r(x)=r^{-2}P(x/r)$`
- S0158.C05: Definition and argument convention of the translation operator. Exact focus: `$T_X f(x)=f(x-X)$`
- S0159.C04: Explicit translation of the profile term in the packet identity. Exact focus: `(\eta r)'T_XD_r/r`
- S0159.C05: Explicit translation of the radial correction tensor in the packet identity. Exact focus: `\Div(\eta r'T_XF_r)`
- S0164.C08: Membership and compact support of the fixed base bump. Exact focus: `$U\in C_c^\infty(B_1)$`
- S0167.C05: Explicit translation of the first intrinsic-stress contribution. Exact focus: `\eta r'T_XF_r`
- S0167.C06: Explicit translation of the anti-divergence contribution. Exact focus: `(\eta r)'T_X\mathcal A(S_r-2\pi U_H\xi)`
- S0242.C08: Mollification qualification attached to piecewise time smoothness. Exact focus: `after the fixed spatial mollification below`
- S0247.C08: Stated paired-transpose justification for symmetry of the assembled expression. Exact focus: `since each mixed product occurs with its transpose`
- S0268.C06: Explicit open-interval type and relative compactness of J. Exact focus: `$J\Subset(0,\infty)$ an open interval`
- S0304.C06: Uniform boundedness of the peak amplitudes in the stated parameter regime. Exact focus: `uniformly bounded peak amplitudes`
- S0357.C01: Sequence quantifier and limiting regime. Exact focus: `For any sequence $t_n\downarrow0$`
- S0357.C02: Boundedness of the velocity-difference sequence. Exact focus: `the bounded sequence $W(t_n)$`
- S0357.C03: Weak-subsequence conclusion and function-space type. Exact focus: `has a weakly convergent $L^2$ subsequence`

Existing supplemental identities now directly anchor temporal C1 regularity (S0158.C04), the fixed bump dilation (S0164.C07), and r_*=1 (S0373.C04).

S0130.C05, C10, C11 remain allocated as empty, whitespace-only, and TeX-environment-closure focus spans; these are source-scaffolding descriptions, not mathematical verdicts.
