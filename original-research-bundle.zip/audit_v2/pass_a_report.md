# Independent PASS A — frozen revision v2

**Pass A outcome: FAIL for the literal manuscript, owing to one minor definite scope error at S0229.** The counterexample does not invalidate the later estimates: the proof needs only the valid identity for `|x|>1`, together with its separately established bounded-core estimate. No fatal obstruction to the global construction was established by this pass. This is an independent pass result, not a four-pass certificate or a reconciliation result.

## A. Audit scope

The examined TeX file is `audit_v2/proof.tex`, the frozen copy of `candidate_proof.tex`, lines 1–949, all 45,127 bytes. Its SHA-256 is `1ffbeee20c4208e954396b55c3f4bc5289e478d76555579b09d5e7fbfae975bd`. The neutral `audit_v2/audit_inventory.json` SHA-256 is `6f43080009e044109938412d2f40e6ba7374ec8777e8be2962c7c1489ea8e0eb`.

The entire current source was read in source order through all complete permanent-container texts. Every current shared child was read with its full current parent. The exact target, notation ledger, Markdown inventory and formula inventory were also inspected. Each of the 419 parent texts and 855 child texts was checked against its exact byte span and SHA-256; the parents form a contiguous, disjoint partition of the full source. All 579 formula texts, spans, hashes and parent containments were validated. These mechanical checks establish anchoring, not mathematical correctness.

The frozen segmentation was used without splitting, merging or renumbering: sentence-attached mathematics remains in its sentence; entire aligned displays remain intact; structural declarations and formatting remain represented; two boundary groups are retained. There are no input/include dependencies missing, no unresolved macros affecting the mathematics, and no missing mathematical bibliography source. The only substantive cited external input was independently reopened from its primary URL for this revision. Standard integration, Fourier, compactness and ODE tools were matched to their hypotheses directly in the reconstructions.

The v1 files were preserved. After rechecking the current source, this auditor reused its own unchanged algebraic derivations as explanatory text where they still prove the current assertion; old verdict labels were discarded. Every changed mathematical clause and its affected dependencies received a current-version derivation. No other pass output, change/reconciliation manifest, route, checkpoint or dependency-provenance file was read. No agent-status listing or communication with other auditors occurred in this revision pass. Findings were sent only to the coordinator.

Limitations: this is a mathematical audit, not a proof-assistant formalization. Exact rational arithmetic was used for the Bessel partial sums; no unavailable symbolic package or numerical experiment is claimed as proof. Cross-pass comparison and dispute reconciliation belong to the coordinator and are not presumed here.

## B. Coverage summary

| Item | Pass A coverage |
|---|---:|
| Source lines represented and examined | 949 / 949 |
| Source bytes represented and examined | 45,127 / 45,127 |
| Permanent containers examined | 419 / 419 |
| Sentence / structural / boundary-group containers | 380 / 37 / 2 |
| Compound containers | 253 / 253 |
| Mathematical containers examined | 388 / 388 |
| Non-mathematical containers inventoried | 31 / 31 |
| Shared nested checks examined | 855 / 855 |
| Inline / display formulas examined | 520 / 59 |
| Total formula occurrences examined | 579 / 579 |
| Algebra-bearing containers re-derived | 106 / 106 |
| External/standard theorem-invocation containers matched | 22 / 22 |
| Proof environments checked | 8 / 8 |
| Major-result dependency maps | 8 / 8 |
| Supplemental mathematical children proposed | 0 |
| Uncovered source lines / bytes / containers | 0 / 0 / 0 |
| Unchecked mathematical containers | 0 |
| Missing Pass A parent / child verdicts | 0 / 0 |

| Current parent status | Count |
|---|---:|
| VERIFIED | 387 |
| ERROR | 1 |
| UNJUSTIFIED | 0 |
| AMBIGUOUS | 0 |
| DEPENDS ON EARLIER ERROR | 0 |
| NOT VERIFIABLE FROM PROVIDED MATERIAL | 0 |
| NOT MATHEMATICAL | 31 |

The child statuses are 850 VERIFIED, 2 ERROR and 3 NOT MATHEMATICAL. The three non-mathematical children are the frozen layout-only focuses S0130.C05, S0130.C10 and S0130.C11; the enclosing cases and all their mathematical content are checked elsewhere in the same parent. The erroneous children are S0229.C01 and S0229.C03. S0229.C02 and S0229.C04 are affirmatively verified.

One parent is submitted for mandatory escalation: S0229. No coordinator-owned `R` identifiers were invented by this independent pass. Consequently there are zero local reconciliation items created or resolved here, and one parent-level finding awaiting cross-pass reconciliation. Other passes' coverage and verdicts have not been inspected.

## C. Permanent-container and child ledger

`audit_v2/pass_a.json` contains exactly one source-ordered record for each S0001–S0419, including all verified and non-mathematical containers, with current container hashes, aggregate verdicts, affirmative reconstruction or precise issue, all 855 allocated child verdicts and child hashes, and empty supplemental lists. The exact complete source anchors, filenames, spans, modes and mathematical classifications are in the unchanged `audit_inventory.json`; joining by permanent ID and checking the included digest supplies the full source-anchored ledger without normalizing the TeX. `pass_a_notes.tsv` is the compact current parent-rationale index. This report does not substitute representative examples for that exhaustive ledger.

The following reconstruction details summarize particularly important checks; the JSON contains the individual affirmative checks for every remaining container.

1. **Initial normalization, S0026–S0052.** With `G=(2π)^(-1)log|x|`, the convention `∇⊥=(-∂2,∂1)` gives `K=∇⊥G`, `curl K=δ0` and multiplier `-i ξ⊥/|ξ|²`. The local integral of `|K|` over any translated radius-R disk is at most `CR`; Tonelli and truncation in total variation justify arbitrary noncompact finite measures. Radial averaging gives `K*a=K` beyond the support disk, so `K-K*a` is compactly supported and L1. Evenness gives `|1-â|≤C min(|ξ|²,1)`, hence `(1+|ξ|²)|(1-â)m|²≤C`, exactly the inhomogeneous H^-1 to L2 estimate. At zero `mâ` is L1 but generally not L2; the revised sentence S0049 explicitly makes square integrability a claim about the positive-order differentiated multipliers. No zero circulation, first moment or global initial kinetic energy is used.

2. **Bounded background, S0054–S0090.** The cited existence input applies to signed `ν0=a*μ0∈L1∩L∞`. The manuscript then derives its own all-time representative. Spatially mollified divergence-free bounded velocities have Jacobian one; the common Osgood modulus yields convergence of flows and inverses, and bounded displacement gives a fixed support enlargement for passing volume preservation by dominated convergence. Pullback of ν0 preserves L1, L2 and L∞ norms, and approximation by compact smooth functions gives `ν∈C_t L1∩C_t L2`. The near/far bound gives `V∈C_t L∞`; weak L2 plus layer cake gives `||V||3³≤C||ν||1²||V||∞`. For `F_t=∫_0^t Vν`, the product is strongly continuous in L2. The multiplier of `-K div` is `-ξ⊥⊗ξ/|ξ|²`, of operator norm one, so `V(t)-V0` is a strong L2-continuous primitive and has the stated coefficient-one bound. The curl of the L2 acceleration vanishes by transport; its negative potential is pressure. This requires no global L2 norm of V itself.

3. **Seed and the mixed-stress endpoint, S0092–S0119.** The multiplier `exp(-t⁴|ξ|⁴)` gives `∂tW=-4t³Δ²W`; `div(∇ΔW+(∇ΔW)^T)=Δ²W` since `div W=0`. Thus the derivative stress has precisely the displayed negative sign and factor four. Two derivatives of `b_t` cost `t^-2` in L1, leaving `O(t)||σ0||M` after multiplication by `t³`. The curl estimate uses `||b||1`, not positivity of b. Products with the old background use exponents 3 and 3/2. The illustrative swirl has finite energy and curl variation but divergent L3/2 tail; its product with a `1/r` circulation background has integral comparable to `∫dr/(r log r)`, so that example and its stated limitation are correct.

4. **Dipole, S0122–S0142.** Exact Python `Fraction` summation was rerun: the J1(3) sum through m=3 is `669/2048=(3/2)(223/1024)>0`; the J1(4) sum through m=4 is `-2/45<0`. The ratio of successive magnitudes is `(z/2)²/((m+1)(m+2))`, strictly below one throughout the relevant tails, so the next-term signs justify both bound directions. The Bessel ODE at a common hypothetical zero of J1 and J0 would give zero value and derivative at a regular point, contradicting `J1(z)=z/2+O(z³)`. At the origin the interior ψ is a Cartesian power series times x2; no polar singularity remains. At radius one the radial values and first two derivatives match as `-1,1,-2`, making D C1. With `q=ψ+x2`, `D-e1=∇⊥q` and `curl D=-β²q`, direct component expansion gives the displayed pressure sign. S0139 explicitly provides unit directions and rotated, scaled pressure `P_r=r^-2P(x/r)`. Norm scaling gives L2 and curl L1 invariance and the L3/2 exponent 1/3.

5. **Anti-divergence and variable radius, S0144–S0168.** Componentwise differentiation of A cancels the two gradient-divergence terms and leaves f. Its degree-minus-one kernel has an `L1(B3R)` contribution at most `CR||f||1`. Canceling both zeroth and first moments leaves `CR²|x|^-3||f||1` outside B3R, whose radial integral is again `CR||f||1`. Only mean cancellation would leave a generally nonintegrable degree-minus-two term. The radius derivative satisfies `∂rD_r=D_r/r-div(D_r⊗x/r)`; exterior homogeneity makes that divergence compactly supported. Evenness cancels first moments and the exterior angular flux cancels its mean. The current C1 visit hypotheses justify all time chain rules, and both translated tensor terms are explicitly present. For the compact source, the two large-circle integrals are `πrξ` and `-πrξ`, so their difference is `2πrξ`. The fixed dilation `U_H=H^-2U(x/H)` now explicitly supplies all uniform bump constants.

6. **Raster and normalization, S0171–S0219.** Expanding the four rank-one directions gives diagonal `A+B-Sii` and off-diagonal `(a3-a4)/2=-S12`, hence `-S+qI` without a missing factor. Positive floors and nonzero ramp integral make every speed and normalization denominator legitimate. On a row `dt=(r0/η)c ds`; each ramp time is `r0 e L/(η Iζ)`. Substitution in the normalization gives exactly the allocated scan time `τi` and weight `2πη_i r0_i/τ=d`. Fixed positive floors make `dB_i` converge to a positive finite limit; η_i is uniformly bounded above and below, not independent of the cycle count. Thus `r≈H⁸`, `r^(1/5)=O(H^(8/5))=o(H)`. On rows `ηr'=(ηr)'=η_i²∂ξlog c`; on ramps the bound is `η_i² Iζ||ζ'||∞/L`. Integration by parts in time gives the positive averaged-divergence sign. The Banach-valued rectangle rule has error `d∫||F'||1`, with `∫||F'||1≤||∂⊥a||1+C H^-1||a||1`; convolution contributes `H||∇a||1`. Setting d=H² makes all terms vanish. Floor and ramp mass are estimated separately and are never differentiated as if they were a globally smooth coefficient.

7. **Temporal correction and stress, S0221–S0260.** `Q=-P∫(U-Ubar)` subtracts the average of the entire four-direction cycle. The projected bump has zero divergence and the same curl as `U_H ξ`. Its core is smooth and bounded by transferring one derivative to U. Its tail for `|x|>1` is the Hessian of G, giving every required Lp bound. The one overbroad support-complement statement is the error below; its false part is not needed for the norms. Fixed dilation gives `||Z_H||p=H^(2/p-2)||Z_1||p`. The pressure `p_Q=-π_U+average π_U` yields exactly `∂tQ+U+∇p_Q=Ubar`. Corrector bounds are `τH^-1` in L2 and curl L1 and `τH^-2/3` in L3/2. Endpoint values vanish exactly. The revised time-smoothness sentence explicitly applies after spatial mollification. Expanding the full quadratic tensor gives both orders of all three mixed pairs and Q⊗Q; the revised symmetry assertion concerns that assembled tensor. Absorbing `-qI` into the stress requires subtracting q from pressure. The mollification commutator sign is `v_ell⊗v_ell-(v⊗v)_ell`; compactness of the cycle's continuous L2 image makes its L1 norm uniformly small. The old seed is untouched.

8. **LER parameter order and pasting, S0261–S0349.** J is explicitly an interval and S is compactly supported in time, so a single `[a,b]⊂⊂J` encloses its support. The case δ=0 is handled by zero correction. Finitely many inherited continuity pieces admit finite uniform coarse approximation, including their separate one-sided extensions; actual boundary values are not forced to equal conflicting traces. Choose coarse errors, regularization masses and floors first, then finite cycle counts, then fixed mollification scales. With `τ=H⁶`, the intrinsic stress is `O(H|log H|)+O(H⁸)`, Q costs `O(H⁵)` in L2/curl and `O(H^(16/3))` in L3/2, and the main packet costs `O(H^(8/3))` in L3/2. Actual old-new products tend to zero using the old finite C_t L3 norm; no old derivative is used. All conditions hold on tails of sufficiently large counts, so literal monotonicity of a Riemann sum is unnecessary. The ε half-budgets and ζ thirds are compatible. Zero velocity traces exclude temporal deltas; arbitrary bounded actual stress values at finitely many boundaries do not change its spatial-divergence distribution. Fixed convolution maps C_t L2 to C_t L3 with kernel norm `C ell^-1/3`, the correct Young exponent.

9. **Anchors and global closure, S0351–S0418.** Subtracting the two equations gives a positive quadratic-test term and negative stress-test term. Uniform local energy and global stress bounds make compact divergence-free pairings Lipschitz. The anchor values force their zero-time limits to vanish. The revised statement explicitly extracts a weak L2 subsequence from any `t_n↓0`; the cluster limit is both divergence- and curl-free, and its L2 Fourier transform cannot be supported only at zero. Three dyadic colors have gaps at `3·2^j`, and at most N=3 patches overlap. Frozen prescribed pieces telescope the old stress exactly; partial-color stresses are bounded by `(δq+δq+1)Θ`. The local parameters now explicitly include `κ=2^-q/N` and `r_*=1`. The increment estimate is `[NC sqrt(Θ(4T))+1]sqrt(δq)`, with `sqrt(δq)=4^-q` summable. No uniform L3 bound in q is used. The resulting L2 series is uniform on `(0,T]`; finite heads have weakly zero trace and uniformly small tails give the exact initial trace. Curl series converge absolutely in L1 at every positive time. Strong local L2 convergence passes the quadratic flux, while temporal cutoffs recover the plus initial term. Finally, `u=V0+v` with `V0∈C0`, `v∈L2` and finite measure curl has no harmonic remainder: its mean-value bound is a vanishing C0 average plus `C(||v||2+||μ||M)/R`. This yields the canonical velocity at every time, including the initial definition at zero.

### Theorem-hypothesis matching

The original Crippa–Stefani article, [Theorem 3.3 with Assumptions 2.1/3.1 and Definition 3.2](https://link.springer.com/article/10.1007/s00526-024-02750-4), was reopened for v2. It requires signed `L1∩L∞` initial vorticity and the stated kernel size/difference and bounded-divergence conditions. Here `ν0=a*μ0` has those norms, the kernel constants are `1/(2π)`, its divergence is zero, and the plane has no boundary condition. The source gives global Lagrangian weak transport, canonical bounded velocity and finite-horizon log-Lipschitz control; no compact-support or global-energy assumption is needed. Its a.e.-time pushforward is upgraded by the manuscript's own flow argument, not silently by citation. No uniqueness or smooth-background theorem is imported. genui{"citation":{"refs":["turn114view0","turn114view1","turn114view3","turn115view0"]}}

| Invocation container(s) | Hypotheses matched and conclusion checked |
|---|---|
| S0040 | Tonelli: nonnegative absolute kernel, finite measure, uniform disk integral; gives local L1 and almost-everywhere finiteness. |
| S0046 | Measure Young inequality: L_a is L1 and μ finite; its proof is the nonnegative iterated integral. |
| S0048 | Plancherel: the weighted multiplier times the H^-1 transform is square integrable; gives global L2 of the residual only. |
| S0050 | Fourier inversion and Riemann–Lebesgue: every relevant multiplier times bounded μ-hat is L1; positive derivatives additionally L2. |
| S0054, S0062 | The primary-source invocation and its actual application match the hypotheses summarized above. |
| S0065 | Osgood comparison: bounded measurable-in-time field, uniform modulus r(1-log r), divergent reciprocal integral; forward and backward uniqueness and continuous dependence follow. |
| S0067 | Jacobian equation: spatially smooth mollified velocity, locally integrable Lipschitz bounds and zero divergence; Jacobian stays one. |
| S0069 | Dominated convergence: bounded compact test, common bounded support enlargement and convergent flows. |
| S0081 | Chebyshev: near convolution is L1 and far convolution is at most λ/2; λ>0, with M=0 handled separately. |
| S0082 | Layer cake: bounded V and its weak-L2 distribution bound; cancellation of λ² against λ^-2 makes the integral finite. |
| S0104 | Plancherel and dominated convergence: multipliers are at most one and tend pointwise to one against an L2 transform. |
| S0110 | Fubini on compact tests: the same uniform local kernel integral and integrable smoothing kernel dominate the absolute iterated integrals. |
| S0126 | Intermediate value theorem: continuous J1 with strictly opposite signs at 3 and 4. |
| S0128 | ODE uniqueness: continuous regular coefficients near the positive root and zero Cauchy data; continuation through the connected positive axis contradicts the series. |
| S0214 | Banach-valued fundamental theorem: F has an integrable L1-valued derivative; integration over each row interval gives the factor d. |
| S0232 | Minkowski: translated fixed profiles belong to each relevant Lp, with an integrable bounded time coefficient on a finite cycle. |
| S0256 | Approximation of the identity: uniformly bounded convolution operators and a compact continuous image in L2, plus its quadratic compact image in L1. |
| S0309 | Hölder: old u has finite supremum in L3 on the fixed compact interval; new v,Q tend to zero in L3/2. |
| S0338 | Young: `1+1/3=1/2+1/(6/5)` and the mollifier L6/5 norm scales as ell^-1/3. |
| S0357 | Weak sequential compactness: the bounded sequence of global L2 differences is in a reflexive Hilbert space. |
| S0409 | Weyl's lemma: the locally integrable difference has componentwise zero distributional Laplacian from zero divergence and curl. |

### Endpoint and adversarial checks

The checks included the zero datum and M=0 weak-L2 split; δ=0 local repair; a zero coefficient direction and inactive slots; positive but arbitrarily small floors and ramp integral; the polar origin and the matching circle; nonzero total circulation and noncompact signed data; negative stress eigenvalues and zero off-diagonal entries; tails that fail L1 or L3/2; arbitrary center resets at zero amplitude; distinct one-sided stress traces and isolated actual values; all cycle endpoints; the small-H and small-ell order of limits; all finite horizons including zero; and possible harmonic velocity additions. The annular radial bump below is an actual counterexample to one literal local sentence. All other verified items were established by the derivations in the per-container records, not merely by unsuccessful counterexample searches.

## D. Escalated-container report

**S0229, `proof.tex`, lines 523–525.** Container SHA-256: `8feac95adbf38ff50287cbefc52396a79d7238c92eeaae0791f50c9d7b9adfe0`.

The exact unchanged source anchor is:

```tex

Outside the bump support, radial averaging gives $G*U_1=G$, so
$Z_{1,\xi}=-D^2G\xi=O(|x|^{-2})$.
```

Pass A assigns ERROR. The focus is the domain claimed for the first two equalities, S0229.C01 and S0229.C03. Radiality itself and the Hessian tail rate, S0229.C02 and S0229.C04, are correct. Other passes' statuses are deliberately not known here. No local `R` item has been allocated by this pass; reconciliation is pending with the coordinator.

## E. Numbered definite errors

1. **E1 — definite mathematical error; minor.** Location: S0229.C01/C03, `proof.tex` lines 523–525. The first incorrect step is asserting `G*U1=G` on all points outside the bump support.

   S0164 allows any fixed nonnegative radial smooth probability U compactly supported in B1. In particular, let U be the normalization of

   \[
   U(x)=\begin{cases}
   \exp\!\left(-\dfrac1{(|x|-1/2)(3/4-|x|)}\right),&1/2<|x|<3/4,\\
   0,&\text{otherwise}.
   \end{cases}
   \]

   This is smooth, radial, nonnegative and supported in the allowed unit disk, with positive finite integral before normalization. Its complement of support contains `0<|x|<1/2`.

   **Confirmation by angular averaging.** The angular mean of `log|r-s e^{iθ}|` is `log(max(r,s))`. Hence for `0<|x|<1/2`,

   \[
   (G*U)(x)=\frac1{2\pi}\int_{\mathbb R^2}\log|y|\,U(y)\,dy,
   \]

   independent of x. It is strictly greater than `(2π)^(-1)log(1/2)`, whereas `G(x)` is strictly less than that number. Thus the stated equality fails throughout that punctured hole.

   **Independent confirmation by radial Poisson flux.** Put `F=G*U`. This is a smooth radial solution of `ΔF=U`. If `M(r)=∫_{B_r}U`, integration of the radial Poisson equation yields `2πr F'(r)=M(r)`, with no singular integration constant because F is smooth at zero. On `r<1/2`, M(r)=0, so F is constant and D²F=0. Since U=0 there, the definition gives Z=0. But for x≠0,

   \[
   D^2G(x)=\frac1{2\pi|x|^2}(I-2e_r\otimes e_r),
   \]

   which has nonzero eigenvalues and therefore does not annihilate a unit ξ. The second equality in the sentence also fails on this hole.

   **Propagation.** The error does not propagate into S0230: S0228 already bounds the whole core, including holes, and the equality in S0229 is valid for `|x|>1`. The tail bound, all projected-profile norm estimates, LER and the global iteration need only those two valid facts. Their records therefore remain VERIFIED, with this dependence restriction stated explicitly rather than treating the false clause as a premise.

   **Smallest proposed repair, not applied:** replace “Outside the bump support” by “For `|x|>1`”. This restores the literal sentence for every permitted U and leaves all downstream estimates unchanged. An alternative is to restrict the equality to the unbounded exterior of a disk containing the support; no positivity assumption on U is needed. The frozen source was not edited.

## F. Unjustified, ambiguous and source-dependent items

No additional parent is assigned UNJUSTIFIED, AMBIGUOUS or NOT VERIFIABLE FROM PROVIDED MATERIAL in this revision. The current text explicitly supplies the C1 visit hypothesis, translated tensors, fixed bump dilation, unit direction and pressure scaling, mollification qualification, paired stress symmetry, interval domain, uniform amplitude bound, sequence quantifier and radius budget needed at their respective uses. Their adequacy was checked directly; revision itself was not treated as evidence of correctness.

The scope problem in S0229 is recorded as a definite literal error rather than silently interpreting “outside support” as “outside an enclosing disk.” In the surrounding far-field argument that intended narrower scope is clear enough to establish the following estimates, but it does not make the literal set-complement equality true.

## G. Dependency and error-propagation report

| Major result | Current dependencies and reconstruction | Pass A judgment |
|---|---|---|
| Canonical decomposition, S0034–S0039 | S0026–S0033 fix conventions; S0040–S0052 supply Tonelli, truncation, radial cancellation and weighted Fourier estimates. All VERIFIED. | VERIFIED for arbitrary target signed finite H^-1 data. |
| Bounded background, S0060–S0061 | S0034–S0052 give ν0 and V0; S0054–S0058 match the primary theorem; S0062–S0090 construct the all-time representative, norms, relative energy continuity and pressure. All VERIFIED. | VERIFIED without global background energy. |
| Initial seed, S0096–S0100 | Decomposition and background above; S0092–S0095 conventions/kernel; S0101–S0114 exact equation, norms, trace and continuity. All VERIFIED. | VERIFIED in the local-repair class. |
| LER, S0261–S0275 | S0122–S0168 give dipole, moments, translated variable-radius stress; S0171–S0219 give coefficients, exact scan normalization and quadrature; S0221–S0260 give full-cycle corrector, stress and smoothing; S0276–S0349 give parameter order and pasting. S0229 alone has a minor overbroad clause; the valid exterior equality plus S0228 prove all needed profile estimates. | VERIFIED reconstruction using only the true restriction of S0229; local source correction still required for a clean manuscript. |
| Anchor lemma, S0351–S0353 | S0354–S0360 give bounded derivative pairings, anchor limit, weak compactness and Fourier uniqueness of the zero cluster point. All VERIFIED; independent of the profile scope error. | VERIFIED. |
| Global iteration, S0361 | Seed, LER and anchors; S0362–S0392 give locally finite patches, frozen-piece telescoping, summable bounds and exact finite-stage trace; S0393–S0406 give uniform convergence, curl and initial-value weak identity. All used assertions VERIFIED. | VERIFIED reconstruction on a single global time axis. |
| Canonical normalization, S0407–S0408 | Arbitrary-finite-measure kernel identities from S0040–S0043; S0409–S0413 harmonicity and expanding-ball bound. All VERIFIED. | VERIFIED; rules out constants and other harmonic additions without assuming zero circulation. |
| Global existence, S0414 | S0034–S0052, S0060–S0090, S0096–S0114, the verified LER/iteration chain and S0407–S0413; S0415–S0418 explicitly supply the all-time canonical relation with fixed U=V0. | The target conclusions survive the identified minor local error. The manuscript as a whole is not assigned PASS while S0229 remains literally false. |

There is no cycle in this dependency chain. Internal statements sometimes refer forward to their proofs, but no later theorem is used to prove itself. All final claims concern the same sequence and limit on the whole positive time axis; estimates on finite horizons do not splice independently constructed solutions. The source gives no energy inequality, uniqueness assertion or extra global-energy assumption beyond the exact target.

## H. Final completeness certificate

- [PASS] Every TeX file was inventoried — 1/1 current file; no missing include.
- [PASS] Every source line belongs to at least one permanent container — 949/949 lines and 45,127/45,127 bytes; zero uncovered.
- [PASS] Permanent container identifiers remained unchanged after the inventory was frozen — S0001–S0419 retained; all current hashes match.
- [PASS] Every compound mathematical container received exactly one non-recursive layer of nested checks — 253 compound containers; 855 allocated children checked by Pass A.
- [FAIL] Every permanent container received a verdict from every required pass — Pass A has 419/419; this independent report does not inspect or certify the other required passes.
- [FAIL] Every final nested check and every remaining simple mathematical container was affirmatively checked by every pass — Pass A checked 855/855 current children and all 388 mathematical parents; other-pass coverage awaits the coordinator.
- [PASS] Every inventoried inline and display formula occurrence was checked — Pass A, 520 inline plus 59 display, total 579/579.
- [PASS] Every algebra-bearing container was independently re-derived — Pass A, 106/106 current containers.
- [PASS] Every theorem-application container received complete hypothesis matching — Pass A, 22/22; substantive primary source reopened for v2.
- [PASS] Every proof was checked locally and globally — Pass A, 8/8 proofs and 8/8 major-result dependency maps.
- [PASS] Edge cases and attempted counterexamples were investigated — zero, degenerate, origin, tail, sign, endpoint, boundary-value, parameter-order and infinite-time cases recorded; annular-bump counterexample established.
- [PASS] Definitions and notation were checked across the manuscript — all mathematically meaningful macros and all current uses inspected.
- [PASS] Dependencies and error propagation were traced — 8 result maps; false hole-domain extension at S0229 is not used by the later bounded-core/exterior estimates.
- [FAIL] Every required escalation was reconciled through local dispute items — S0229 is submitted for coordinator reconciliation; no cross-pass reconciliation is claimed here.
- [PASS] Every definite error was independently confirmed where feasible — the single minor E1 finding has both angular-averaging and radial-Poisson-flux confirmations.
- [FAIL] No source container, pass verdict, or dispute item remains unchecked — no missing Pass A source or child verdict, but the other passes and mandatory reconciliation are outside this independent report and remain uncertified here.
