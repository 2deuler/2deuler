# Frozen v2 permanent-container inventory

Source SHA-256: `1ffbeee20c4208e954396b55c3f4bc5289e478d76555579b09d5e7fbfae975bd`.
Parent identities: 419 preserved; allocated children: 840 retained plus 15 appended.
Exact full texts, spans, full digests, and nested checks are in audit_inventory.json.

| Container | Lines | Mode | Math | Children | Digest prefix | Exact opening excerpt |
|---|---|---|---|---|---|---|
| S0001 | 1–1 | STRUCTURAL | no | 0 | `d05362ce28577ffa` | `\documentclass[11pt]{article}` |
| S0002 | 2–2 | STRUCTURAL | no | 0 | `42de0505d6a4abf5` | `\usepackage[T1]{fontenc}` |
| S0003 | 3–3 | STRUCTURAL | no | 0 | `6e39654a1cd7441e` | `\usepackage{amsmath,amssymb,amsthm,mathtools,geometry,hyperref,array,xcolor}` |
| S0004 | 4–4 | STRUCTURAL | no | 0 | `02aad8893108080d` | `\geometry{margin=1in}` |
| S0005 | 5–5 | STRUCTURAL | no | 0 | `1b0f4947d2b4adbb` | `\setlength{\emergencystretch}{3em}` |
| S0006 | 6–6 | STRUCTURAL | no | 0 | `f3fa7772026095fe` | `\hypersetup{hidelinks}` |
| S0007 | 7–7 | STRUCTURAL | no | 0 | `1f8948b700d50257` | `\newtheorem{theorem}{Theorem}[section]` |
| S0008 | 8–8 | STRUCTURAL | no | 0 | `7e8bfffa04201fe4` | `\newtheorem{lemma}[theorem]{Lemma}` |
| S0009 | 9–9 | STRUCTURAL | no | 0 | `6c2dd7774dba1b4b` | `\newtheorem{proposition}[theorem]{Proposition}` |
| S0010 | 10–10 | STRUCTURAL | no | 0 | `10e56e6cf8f2bd0a` | `\theoremstyle{remark}\newtheorem{remark}[theorem]{Remark}` |
| S0011 | 11–11 | STRUCTURAL | yes | 0 | `cc6e93ea02d4156e` | `\newcommand{\R}{\mathbb R}` |
| S0012 | 12–12 | STRUCTURAL | yes | 0 | `e5758a1808651ba8` | `\newcommand{\M}{\mathcal M}` |
| S0013 | 13–13 | STRUCTURAL | yes | 0 | `63911a372c869279` | `\newcommand{\curl}{\operatorname{curl}}` |
| S0014 | 14–14 | STRUCTURAL | yes | 0 | `edb47c0bb87248b9` | `\newcommand{\Div}{\operatorname{div}}` |
| S0015 | 15–15 | STRUCTURAL | yes | 0 | `dd50315279c1eb82` | `\newcommand{\supp}{\operatorname{supp}}` |
| S0016 | 16–16 | STRUCTURAL | yes | 0 | `4865c232467c9d37` | `\newcommand{\norm}[2]{\left\\|#1\right\\|_{#2}}` |
| S0017 | 17–17 | STRUCTURAL | yes | 0 | `736607bd2d0202d9` | `\newcommand{\dd}{\,dx}` |
| S0018 | 18–18 | STRUCTURAL | no | 0 | `15de9d94ae24823f` | `\title{Global weak Euler flows for finite signed vorticity on the plane}` |
| S0019 | 19–19 | STRUCTURAL | no | 0 | `2ee949f1b3465bcd` | `\author{Research manuscript}` |
| S0020 | 20–20 | STRUCTURAL | no | 0 | `d36663cf72713d6a` | `\date{8 October 2026}` |
| S0021 | 21–21 | STRUCTURAL | no | 0 | `6c30cf119c9b45ee` | `\begin{document}` |
| S0022 | 22–22 | STRUCTURAL | no | 0 | `f42e6024c896bc86` | `\maketitle` |
| S0023 | 23–24 | SENTENCE | no | 0 | `30a55318a6a78e82` | `\noindent Research proof manuscript.` |
| S0024 | 24–26 | SENTENCE | no | 0 | `91cbd7b97dcb7029` | `Verification status is recorded in the accompanying audit report; this source alone is not a verific` |
| S0025 | 26–28 | STRUCTURAL | no | 0 | `4dc3d3d6884cdd70` | `\paragraph{Exact target.}` |
| S0026 | 29–29 | SENTENCE | yes | 0 | `ad8ea51b695373f7` | `Let $K(x)=(-x_2,x_1)/(2\pi\|x\|^2)$.` |
| S0027 | 29–31 | SENTENCE | yes | 5 | `6506b459a25e24fb` | `Given any finite signed Radon measure $\mu_0\in\M(\R^2)\cap H^{-1}(\R^2)$, with the \emph{inhomogene` |
| S0028 | 31–41 | SENTENCE | yes | 9 | `3f72255b8d149f47` | `The requested conclusion is a global weak Euler solution \[  u\in C_w([0,\infty);L^2_{\rm loc}(\R^2;` |
| S0029 | 41–48 | SENTENCE | yes | 4 | `46103fd3ae952e1d` | `The velocity identity is precisely \[  \int_0^T\!\!\int_{\R^2}  \bigl(u\cdot\partial_t\varphi+(u\oti` |
| S0030 | 48–50 | SENTENCE | yes | 5 | `4950a36cfa567abf` | `No global kinetic-energy assumption, compact support, zero circulation, or energy inequality is adde` |
| S0031 | 50–52 | STRUCTURAL | no | 0 | `c3363f86d4b31e1d` | `\section{Initial normalization and a bounded Euler background}` |
| S0032 | 53–56 | SENTENCE | yes | 4 | `ac550367d84f9fe7` | `We use $\nabla^\perp=(-\partial_2,\partial_1)$, $(\nabla v)_{ij}=\partial_jv_i$, $(\Div S)_i=\sum_j\` |
| S0033 | 56–57 | SENTENCE | yes | 0 | `845761f4c52d1969` | `The multiplier of $K$ is $m(\xi)=-i\xi^\perp/\|\xi\|^2$.` |
| S0034 | 57–60 | SENTENCE | yes | 3 | `c9be91345fb587b4` | `\begin{lemma}[Canonical velocity and the physical-space decomposition]\label{lem:decomp} Let $\mu\in` |
| S0035 | 60–62 | SENTENCE | yes | 4 | `c6cb39434fe82452` | `The convolution $K*\mu$ is defined almost everywhere, belongs to $L^2_{\rm loc}$, and has divergence` |
| S0036 | 62–63 | SENTENCE | yes | 4 | `06c411eed3b768f2` | `Fix a nonnegative radial $a\in C_c^\infty(B_A)$ of integral one.` |
| S0037 | 63–67 | SENTENCE | yes | 4 | `b28afd5fb6c534d5` | `Set \[  \nu_0=a*\mu,\quad \sigma_0=\mu-\nu_0,\quad  V_0=K*\nu_0,\quad v_0=(K-K*a)*\mu. \]` |
| S0038 | 67–74 | SENTENCE | yes | 8 | `2954470d217fb979` | `Then $K*\mu=V_0+v_0$, $v_0\in L^1\cap L^2$, $V_0\in C_0\cap C^\infty$ is bounded, and \[  \norm{v_0}` |
| S0039 | 74–77 | SENTENCE | yes | 2 | `cacc5084cfc13f48` | `All derivatives of $\nu_0$ belong to $L^1\cap L^\infty$, and every positive-order derivative of $V_0` |
| S0040 | 78–80 | SENTENCE | yes | 4 | `a31d63819b646f52` | `\begin{proof} For a bounded ball $B$, $\sup_y\int_B\|K(x-y)\|\dd<\infty$; Tonelli gives the almost-eve` |
| S0041 | 80–81 | SENTENCE | yes | 2 | `150008111484625a` | `The kernel's divergence, curl, and Fourier identities give the distributional assertions.` |
| S0042 | 81–83 | SENTENCE | yes | 3 | `030236d9a5c96521` | `These identities extend from compactly supported to arbitrary finite measures by truncation in total` |
| S0043 | 83–85 | SENTENCE | yes | 7 | `2d5ceb008eaf6f23` | `Equivalently, $m$ is locally integrable at frequency zero and integrable against Schwartz functions,` |
| S0044 | 85–90 | SENTENCE | yes | 2 | `ee856004b0517831` | `For radial $a$, circulation gives \[  (K*a)(x)=K(x)\int_{\|y\|<\|x\|}a(y)\,dy. \]` |
| S0045 | 90–92 | SENTENCE | yes | 3 | `4ad4e27eb236147e` | `Consequently $L_a=K-K*a$ vanishes outside $B_A$ and has only the integrable $\|x\|^{-1}$ singularity a` |
| S0046 | 92–93 | SENTENCE | yes | 2 | `e4bae4be0e08a610` | `Thus $L_a\in L^1$ and Young's inequality gives the $L^1$ estimate for $v_0$.` |
| S0047 | 93–97 | SENTENCE | yes | 3 | `e367d58fa18bf085` | `Evenness gives $\|1-\widehat a(\xi)\|\leq C_a\min(\|\xi\|^2,1)$; hence \[  (1+\|\xi\|^2)\|(1-\widehat a(\xi` |
| S0048 | 97–98 | SENTENCE | yes | 0 | `fe8277391bff61a0` | `Plancherel proves the $L^2$ estimate, using exactly the inhomogeneous hypothesis.` |
| S0049 | 98–100 | SENTENCE | yes | 5 | `1330a75eb2bb64e7` | `The multipliers $m\widehat a$ and $\xi^\alpha m\widehat a$ are integrable; for $\|\alpha\|\geq1$ the l` |
| S0050 | 100–101 | SENTENCE | yes | 2 | `494f3c2368f1d0d3` | `Fourier inversion and the Riemann--Lebesgue lemma give the assertions about $V_0$.` |
| S0051 | 101–102 | SENTENCE | yes | 3 | `9856c92edb4c5b83` | `The convolution identities and remaining bounds follow by finite-measure convolution.` |
| S0052 | 102–104 | SENTENCE | yes | 2 | `22475d6f68db41ab` | `In particular $K*\mu=V_0+v_0\in L^2_{\rm loc}$. \end{proof}` |
| S0053 | 105–106 | STRUCTURAL | no | 0 | `c49f039063aaf317` | `\paragraph{External input E1, used only here.}` |
| S0054 | 107–110 | STRUCTURAL | yes | 4 | `851b8c67ff1057a2` | `Crippa--Stefani, \emph{An elementary proof of existence and uniqueness for the Euler flow in localiz` |
| S0055 | 110–114 | SENTENCE | yes | 9 | `e1cd2eb9c776b66f` | `The specialization used here supplies a global Lagrangian vorticity solution for arbitrary signed $L` |
| S0056 | 114–116 | SENTENCE | yes | 3 | `e25e96bd755b5518` | `Definition 3.2 includes the weak initial-value vorticity equation and the Lagrangian pushforward rep` |
| S0057 | 116–116 | SENTENCE | yes | 3 | `8fa5ddc43eb196e9` | `It does not require compact support or finite global energy.` |
| S0058 | 116–118 | SENTENCE | yes | 3 | `60a7162515a33a1d` | `The kernel hypotheses hold because $\|K(z)\|=(2\pi\|z\|)^{-1}$, $\|K(z)-K(w)\|=\|z-w\|/(2\pi\|z\|\|w\|)$, and $\` |
| S0059 | 118–119 | SENTENCE | yes | 0 | `6828414a8aca1d20` | `The source is not being used as an unquoted smoothness theorem.` |
| S0060 | 119–129 | SENTENCE | yes | 8 | `2c5d7e4933cb5e85` | `\begin{lemma}[Bounded background and its trace]\label{lem:background} The datum $\nu_0$ in Lemma~\re` |
| S0061 | 129–132 | SENTENCE | yes | 0 | `ad004273159d89e6` | `Moreover $\norm{V(t)-V_0}2\leq t\norm V{L^\infty_{t,x}}\norm{\nu_0}2$. \end{lemma}` |
| S0062 | 133–134 | SENTENCE | yes | 3 | `0f7361a2c3a47969` | `\begin{proof} Apply E1, using its $L^1$ and $L^\infty$ bounds and canonical velocity.` |
| S0063 | 134–135 | SENTENCE | yes | 0 | `3b8380bb852c106c` | `No smoothness upgrade is needed in this construction.` |
| S0064 | 135–136 | SENTENCE | yes | 0 | `08845200a68e88b2` | `We first select an every-time representative.` |
| S0065 | 136–139 | SENTENCE | yes | 8 | `cb25371ab3cb9327` | `The log-Lipschitz modulus is Osgood, so the flow and its inverse are unique, continuous, and have bo` |
| S0066 | 139–139 | SENTENCE | yes | 2 | `76446e0c89e0b87d` | `Mollify the velocity only in space by a probability kernel.` |
| S0067 | 139–141 | SENTENCE | yes | 3 | `56187e3d6b898b06` | `The resulting smooth divergence-free flows preserve Lebesgue measure by the Jacobian equation.` |
| S0068 | 141–143 | SENTENCE | yes | 4 | `8b2a70b463c16f3c` | `Their uniform Osgood modulus and uniform convergence of the velocities give convergence of flows and` |
| S0069 | 143–145 | SENTENCE | yes | 5 | `fe0b08ddbaf78dc0` | `For a compact continuous test, bounded displacement confines its transported support to a fixed boun` |
| S0070 | 145–147 | SENTENCE | yes | 2 | `b8201e2ca07ed302` | `Define $\nu(t)=\nu_0\circ X_t^{-1}$ at every time.` |
| S0071 | 147–149 | SENTENCE | yes | 4 | `024bf2fcca675244` | `It agrees with the source solution almost everywhere in time and preserves the $L^1$, $L^2$, and $L^` |
| S0072 | 149–151 | SENTENCE | yes | 4 | `5d6e20e621b28c07` | `Approximating $\nu_0$ in $L^1$ or $L^2$ by compact smooth functions and using volume preservation an` |
| S0073 | 151–151 | SENTENCE | yes | 2 | `972bd0a433a3d1fd` | `Set $V(t)=K*\nu(t)$ at every time.` |
| S0074 | 151–153 | SENTENCE | yes | 3 | `375c4c440be00a7b` | `It agrees with the source velocity almost everywhere, so its equation is unchanged.` |
| S0075 | 153–156 | SENTENCE | yes | 3 | `45a1cb94b175fa06` | `For $f=\nu(t)-\nu(s)$ the near--far bound $\norm{K*f}\infty\leq r\norm f\infty+(2\pi r)^{-1}\norm f1` |
| S0076 | 156–157 | SENTENCE | yes | 3 | `419efd6364bd8c1c` | `Thus this representative has the canonical initial velocity and continuous positive-time local veloc` |
| S0077 | 157–163 | SENTENCE | yes | 2 | `584009aacedb5d2d` | `The Biot--Savart near--far split also bounds the velocity: \[  \norm V\infty\leq C\bigl(r\norm\nu\in` |
| S0078 | 163–164 | SENTENCE | yes | 4 | `b6c6b03742899497` | `Thus $V\nu$ belongs to both $L^1$ and $L^2$ uniformly on finite horizons.` |
| S0079 | 164–169 | SENTENCE | yes | 3 | `9b69392d1af7f0ff` | `For completeness, $K*\mu$ for any finite measure satisfies \[  \|\{\|K*\mu\|>\lambda\}\|\leq C\norm\mu\M` |
| S0080 | 169–172 | SENTENCE | yes | 3 | `9431ebef2c7f0c10` | `Indeed split $K$ at radius $r=\norm\mu\M/(\pi\lambda)$; the far part has supremum at most $\lambda/2` |
| S0081 | 172–172 | SENTENCE | yes | 0 | `1080ba32084d5669` | `Chebyshev proves the bound.` |
| S0082 | 172–173 | SENTENCE | yes | 2 | `e10943b457c1d3ec` | `Combining it with boundedness of $V$ and layer cake gives $\norm V3^3\leq C\norm\nu1^2\norm V\infty$` |
| S0083 | 173–178 | SENTENCE | yes | 3 | `7b6408b6d2a3f834` | `Integrate the vorticity equation: \[  \nu(t)-\nu_0=-\Div F_t,\qquad F_t=\int_0^t V(s)\nu(s)\,ds\in L` |
| S0084 | 178–180 | SENTENCE | yes | 3 | `a9261d4ec4f3f39b` | `The Fourier multiplier of $-K*\Div$ has operator norm at most one, yielding $V(t)-V_0=-K*\Div F_t$ a` |
| S0085 | 180–181 | SENTENCE | yes | 0 | `3b1128745b9f4a75` | `Likewise $\partial_tV,\nabla V\in L^\infty_tL^2$.` |
| S0086 | 181–182 | SENTENCE | yes | 0 | `0e9d748652dd3660` | `The same argument between any two times gives $\norm{V(t)-V(s)}2\leq C_T\|t-s\|$.` |
| S0087 | 182–184 | SENTENCE | yes | 2 | `87450bc672045d39` | `With $B_T=\sup_t\norm{V(t)}\infty$, interpolation gives $\norm{V(t)-V(s)}3^3\leq2B_T\norm{V(t)-V(s)}` |
| S0088 | 184–185 | SENTENCE | yes | 0 | `f2ae2154e508411b` | `Therefore $V\in C([0,T];L^3)$.` |
| S0089 | 185–187 | SENTENCE | yes | 3 | `e181a828aa3d91c1` | `The vector $\partial_tV+(V\cdot\nabla)V$ is an $L^2$ curl-free field by transport; it is a pressure ` |
| S0090 | 187–189 | SENTENCE | yes | 0 | `2f9b9ac709be293c` | `Thus the velocity Euler equation used below is indeed available without a global-energy assumption o` |
| S0091 | 190–191 | STRUCTURAL | no | 0 | `825e51babab6a80a` | `\section{An initial Euler--Reynolds subsolution}` |
| S0092 | 192–198 | SENTENCE | yes | 3 | `afaf254c6cdc1778` | `The convention for Euler--Reynolds is \begin{equation}\label{eq:ER}  \partial_tu+\Div(u\otimes u)+\n` |
| S0093 | 198–199 | SENTENCE | yes | 3 | `43657a2c072c77b7` | `Let $b=\mathcal F^{-1}(e^{-\|\xi\|^4})$ and $b_t(x)=t^{-2}b(x/t)$ for $t>0$.` |
| S0094 | 199–200 | SENTENCE | yes | 7 | `7b611533d3de7f2a` | `It is a real radial Schwartz kernel of integral one; it need not be positive.` |
| S0095 | 200–200 | SENTENCE | yes | 0 | `c8cac204e9fec77b` | `Write $C_b=\norm b1$.` |
| S0096 | 200–210 | SENTENCE | yes | 5 | `a1823f637494788f` | `\begin{proposition}[Initial Euler--Reynolds seed]\label{prop:seed} For the preceding decomposition a` |
| S0097 | 210–211 | SENTENCE | yes | 0 | `5fbbb341622f7bdc` | `This is a positive-time distributional solution of \eqref{eq:ER}.` |
| S0098 | 211–217 | SENTENCE | yes | 5 | `a82b481cc87cebe6` | `On $0<t\leq T$, \begin{align*}  \norm{u^{(0)}-V}2&\leq\norm{v_0}2,\\  \norm{\curl u^{(0)}}1&\leq\nor` |
| S0099 | 217–219 | SENTENCE | yes | 2 | `c98efeda7442192b` | `It has strong $L^2_{\rm loc}$ initial trace $u_0$ and canonical velocity $u^{(0)}(t)=K*(\nu(t)+b_t*\` |
| S0100 | 219–222 | SENTENCE | yes | 4 | `54a743cb68e34556` | `On compact positive-time intervals $R^{(0)}\in C_tL^1$, $u^{(0)}\in C_tL^3$, and the velocity is str` |
| S0101 | 223–225 | SENTENCE | yes | 2 | `a4366ae08da07693` | `\begin{proof} The multiplier of $b_t$ is $e^{-t^4\|\xi\|^4}$, so $\partial_tW=-4t^3\Delta^2W$.` |
| S0102 | 225–226 | SENTENCE | yes | 2 | `03d78f2efcf41883` | `Since $\Div W=0$, $\Div[\nabla\Delta W+(\nabla\Delta W)^T]=\Delta^2W$.` |
| S0103 | 226–227 | SENTENCE | yes | 0 | `a76802530b872406` | `Expanding $(V+W)\otimes(V+W)$ proves \eqref{eq:ER} with the stated signs.` |
| S0104 | 227–228 | SENTENCE | yes | 2 | `67cc80b8607efa30` | `Plancherel gives the $L^2$ bound and $W(t)\to v_0$ strongly in $L^2$.` |
| S0105 | 228–229 | SENTENCE | yes | 3 | `dce615e59c8ef1f5` | `Finite-measure convolution gives $\curl W=b_t*\sigma_0$ and the curl bound.` |
| S0106 | 229–230 | SENTENCE | yes | 0 | `fb6d49ef679e8193` | `Furthermore $\norm W1\leq C_b\norm{v_0}1$.` |
| S0107 | 230–235 | SENTENCE | yes | 3 | `5158ce46845be8ca` | `The identity $\Delta W=\nabla^\perp\curl W$ yields \[  \norm{\nabla\Delta W}1\leq C\norm{D^2b_t}1\no` |
| S0108 | 235–237 | SENTENCE | yes | 3 | `530e0d555f46d840` | `Thus the derivative stress costs $Ct\norm{\sigma_0}\M$, and the other terms are bounded as displayed` |
| S0109 | 237–237 | SENTENCE | yes | 0 | `032695f3dabc90eb` | `Lemma~\ref{lem:background} proves the trace.` |
| S0110 | 237–239 | SENTENCE | yes | 0 | `192cfeeeeed1a0ec` | `Fubini against compact tests, or the Fourier identity, gives the canonical convolution.` |
| S0111 | 239–241 | SENTENCE | yes | 2 | `f55d9e638f772c6b` | `On positive-time compact intervals, convolution bounds give $W\in C_t(L^1\cap L^2\cap L^\infty)$ and` |
| S0112 | 241–242 | SENTENCE | yes | 2 | `2f978d238634da3c` | `The derivative stress is continuous in $L^1$ by continuity of $D^2b_t$ in $L^1$.` |
| S0113 | 242–244 | SENTENCE | yes | 6 | `9053e801d015bdce` | `Products $W\otimes W$ are $L^1$-continuous by $C_tL^2$, while $V\otimes W$ and its transpose are $L^` |
| S0114 | 244–246 | SENTENCE | yes | 0 | `6a958d532efcdca4` | `This proves all asserted continuity without differentiating the old background. \end{proof}` |
| S0115 | 247–250 | SENTENCE | yes | 2 | `a3fe80ae3a89db62` | `\begin{remark}[Why a subcritical global increment norm is required]\label{rem:cross} Every repair be` |
| S0116 | 250–252 | SENTENCE | yes | 0 | `d7015d242698e11f` | `Indeed, $\norm{V\otimes w}1\leq\norm V3\norm w{3/2}$ closes the whole-plane cross-stress bound.` |
| S0117 | 252–254 | SENTENCE | yes | 8 | `20aac6a5f4e5c5df` | `Finite energy and finite curl variation do not suffice: a smooth radial swirl equal to $e_\theta/(r\` |
| S0118 | 254–256 | SENTENCE | yes | 3 | `003ba28b804c9048` | `Against a smooth unit-circulation background equal to $e_\theta/(2\pi r)$ at infinity, $\int\|V\otime` |
| S0119 | 256–258 | SENTENCE | yes | 0 | `1ca1c8af67b825ec` | `Multiplying $w$ by a small constant does not repair this divergence. \end{remark}` |
| S0120 | 259–260 | STRUCTURAL | no | 0 | `65b304eb320c2b66` | `\section{Endpoint repair: elementary building blocks}` |
| S0121 | 261–262 | STRUCTURAL | no | 0 | `4e0a2cca2b1b3a33` | `\subsection{An exact translating dipole}` |
| S0122 | 263–265 | SENTENCE | yes | 2 | `d62b1123fb3559c3` | `The Bessel functions used below may be defined by their convergent power series, whose termwise deri` |
| S0123 | 265–266 | SENTENCE | yes | 2 | `a91d1ef37ce5aa9d` | `There is a positive zero $\beta\in(3,4)$ of $J_1$.` |
| S0124 | 266–269 | SENTENCE | yes | 4 | `2be992cb7b091310` | `For completeness, the alternating series gives $J_1(3)\geq(3/2)(223/1024)>0$ by truncating after its` |
| S0125 | 269–270 | SENTENCE | yes | 0 | `fbb0c8a2c5fa4227` | `The omitted terms alternate with decreasing magnitudes.` |
| S0126 | 270–271 | SENTENCE | yes | 0 | `3512742e055d7967` | `The intermediate value theorem gives the asserted zero.` |
| S0127 | 271–272 | SENTENCE | yes | 2 | `923c9e404c9d72cc` | `If $J_0(\beta)=0$ also, the recurrence gives $J_1'(\beta)=0$.` |
| S0128 | 272–274 | SENTENCE | yes | 2 | `eb4704938bd42f8b` | `Uniqueness for the regular second-order Bessel ODE near $\beta>0$ would then make $J_1$ identically ` |
| S0129 | 274–275 | SENTENCE | yes | 0 | `ff5afbe548d1519a` | `Thus $J_0(\beta)\ne0$.` |
| S0130 | 275–285 | SENTENCE | yes | 13 | `8e00789ef6dd39c3` | `In polar coordinates set \[  \psi(\rho,\theta)=  \begin{cases}  -\rho\sin\theta+\dfrac{2J_1(\beta\rh` |
| S0131 | 285–287 | SENTENCE | yes | 4 | `81988413fd4171bb` | `With $q=\psi+x_2$, $D-e_1=\nabla^\perp q$ and $\curl D=-\beta^2q$ in $B_1$, while $\curl D=0$ outsid` |
| S0132 | 287–289 | SENTENCE | yes | 3 | `bdf4748033af15bf` | `The relations $J_1(\beta)=0$ and $J_1'(\beta)=J_0(\beta)$ give the matching values and first derivat` |
| S0133 | 289–291 | SENTENCE | yes | 3 | `2b06e35628742e8d` | `The Bessel equation also gives $J_1''(\beta)=-J_0(\beta)/\beta$, so the second radial derivatives ma` |
| S0134 | 291–293 | SENTENCE | yes | 3 | `01573858234981fe` | `Tangential differentiation of the matching traces gives the other second derivatives; hence the velo` |
| S0135 | 293–295 | SENTENCE | yes | 2 | `ea735f9b9ed07633` | `In particular $q=0$ on the circle and $(D-e_1)\cdot\nabla\curl D=0$ distributionally.` |
| S0136 | 295–299 | SENTENCE | yes | 2 | `9d5c35da7859fc59` | `The pressure \[  P=-\tfrac12\|D-e_1\|^2-\tfrac{\beta^2}{2}q^2\mathbf1_{B_1} \] gives $-\partial_1D+\Di` |
| S0137 | 299–301 | SENTENCE | yes | 2 | `ddb2095ec2c203eb` | `This follows from $(w\cdot\nabla)w=(\curl w)w^\perp+\nabla(\|w\|^2/2)$, and matching on the circle lea` |
| S0138 | 301–302 | SENTENCE | yes | 3 | `008f7caa13035d9a` | `Outside the unit disk, $D=\nabla(-x_1/\|x\|^2)$; $D$ is even under $x\mapsto-x$.` |
| S0139 | 302–304 | SENTENCE | yes | 4 | `299b1a57d95657c2` | `For a unit direction $\xi\in\mathbb S^1$, rotate the velocity and pressure profiles together, and wr` |
| S0140 | 304–305 | SENTENCE | yes | 0 | `f1e6fa8c6578a031` | `The direction is suppressed where no confusion arises.` |
| S0141 | 305–314 | SENTENCE | yes | 6 | `2d2cb24d2bcf82ea` | `Then \begin{equation}\label{eq:dipole}  -r^{-1}\partial_\xi D_r+\Div(D_r\otimes D_r)+\nabla P_r=0,  ` |
| S0142 | 314–316 | SENTENCE | yes | 5 | `e4e2fd412df3f425` | `The constants are finite by boundedness in the core and the exterior $\|x\|^{-2}$ decay; the curl is s` |
| S0143 | 316–318 | STRUCTURAL | no | 0 | `ae12764578699ca3` | `\subsection{A symmetric globally integrable anti-divergence}` |
| S0144 | 319–327 | SENTENCE | yes | 7 | `40c8ae483b57cc18` | `For a vector field $f$ supported in $B_R$, with \[  \int f=0,\qquad \int x_jf_i(x)\dd=0\quad\hbox{fo` |
| S0145 | 327–328 | SENTENCE | yes | 3 | `261cc6a2c0f8f5e6` | `It is symmetric and $\Div\mathcal Af=f$.` |
| S0146 | 328–328 | SENTENCE | yes | 0 | `8c96aab773e18f71` | `Its kernel has degree $-1$.` |
| S0147 | 328–329 | SENTENCE | yes | 0 | `f4f1f6605fa81e8d` | `On $B_{3R}$, integration of that kernel gives $CR\norm f1$.` |
| S0148 | 329–331 | SENTENCE | yes | 3 | `0ba596cb8f979a49` | `Outside $B_{3R}$, subtract its constant and linear Taylor terms using the two moment conditions; the` |
| S0149 | 331–334 | SENTENCE | yes | 0 | `b24210d4f775d109` | `Integration gives \begin{equation}\label{eq:anti}  \norm{\mathcal Af}1\leq CR\norm f1. \end{equation` |
| S0150 | 334–335 | SENTENCE | yes | 2 | `8afd10a2c2f8fd91` | `The output need not be compactly supported.` |
| S0151 | 335–336 | SENTENCE | yes | 0 | `4688701716058ba9` | `Cancellation of only the mean would leave a generally nonintegrable $\|x\|^{-2}$ far field.` |
| S0152 | 336–341 | SENTENCE | yes | 0 | `43870040b66f7638` | `Differentiation of the profile gives \[  \partial_rD_r=r^{-1}D_r-\Div(D_r\otimes x/r). \]` |
| S0153 | 341–343 | SENTENCE | yes | 3 | `58ef438922a2fcf3` | `The vector $f_r=\Div(D_r\otimes x/r)$ is supported in $B_r$, because the exterior dipole is homogene` |
| S0154 | 343–344 | SENTENCE | yes | 3 | `48edecbf3b93c94e` | `Evenness gives all first moments zero.` |
| S0155 | 344–346 | SENTENCE | yes | 0 | `5c8a5f4ac3504d4c` | `Its mean is zero by the boundary flux on any circle outside $B_r$, since the angular mean of the ext` |
| S0156 | 346–350 | SENTENCE | yes | 3 | `501e8b44765ba7ba` | `Therefore $F_r=-\mathcal Af_r$ satisfies \begin{equation}\label{eq:radial}  \partial_rD_r=r^{-1}D_r+` |
| S0157 | 350–352 | STRUCTURAL | no | 0 | `3796b9ca005dbcc4` | `\subsection{Variable radius and a compact source}` |
| S0158 | 353–353 | SENTENCE | yes | 5 | `573601cb59ecc725` | `On each visit take $r,\eta,X$ to be $C^1$ in time, with $r(t)>0$, $\eta(t)\geq0$, and $X'=\eta\xi/r$` |
| S0159 | 353–359 | SENTENCE | yes | 5 | `36afd5e6b65cb2e8` | `By \eqref{eq:dipole}--\eqref{eq:radial}, the packet $v(t,x)=\eta(t)D_{r(t)}(x-X(t))$ satisfies, afte` |
| S0160 | 359–366 | SENTENCE | yes | 6 | `539e47b67ae7ef16` | `Choose a radial cutoff $\chi$ equal to zero on $B_1$ and one outside $B_2$, let $\alpha=1/5$, and pu` |
| S0161 | 366–368 | SENTENCE | yes | 6 | `c4345a0757f71cf5` | `For small $r$, $Z_r$ is even and supported in $B_{2r^\alpha}$; direct radial integration gives $\nor` |
| S0162 | 368–370 | SENTENCE | yes | 3 | `a59dcc0b5a3a004f` | `Its integral is $2\pi r\xi$: on a large circle the respective boundary integrals for $D_r$ and $\nab` |
| S0163 | 370–371 | SENTENCE | yes | 3 | `7456a75e8577f052` | `Thus $S_r=Z_r/r$ has integral $2\pi\xi$ and all first moments zero.` |
| S0164 | 371–373 | SENTENCE | yes | 8 | `208c91b4fd2ef706` | `Fix a nonnegative radial smooth probability bump $U\in C_c^\infty(B_1)$ and define $U_H(x)=H^{-2}U(x` |
| S0165 | 373–375 | SENTENCE | yes | 2 | `e31ca0777166978a` | `If $2r^\alpha\leq H$, the difference $S_r-2\pi U_H\xi$ has its zeroth and first moments zero.` |
| S0166 | 375–378 | SENTENCE | yes | 0 | `87a67f2be8547e30` | `Equation~\eqref{eq:anti} gives \[  \norm{\mathcal A(S_r-2\pi U_H\xi)}1\leq CH(1+\|\log r\|). \]` |
| S0167 | 378–388 | SENTENCE | yes | 6 | `e69e70b58e6afb04` | `Equation~\eqref{eq:packet} therefore becomes \begin{equation}\label{eq:packet-source}  \partial_tv+\` |
| S0168 | 388–389 | SENTENCE | yes | 2 | `059089891a8e52a2` | `The endpoint estimate $\norm{\curl v}1=\|\eta\|C_\omega$ is independent of $r$.` |
| S0169 | 389–391 | STRUCTURAL | no | 0 | `8e20720a69514c3f` | `\section{Two-scale raster and local stress repair}\label{sec:repair-interface}` |
| S0170 | 392–393 | STRUCTURAL | no | 0 | `50fade3750cb853e` | `\subsection{Stress coefficients and a fixed cycle}` |
| S0171 | 394–395 | SENTENCE | yes | 2 | `27a4e301a0d4a216` | `For a prescribed symmetric stress piece $S$, use the directions $e_1,e_2,(e_1+e_2)/\sqrt2,(e_1-e_2)/` |
| S0172 | 395–397 | SENTENCE | yes | 5 | `116fc5546d67485f` | `For a fixed smooth compactly supported tensor $S$, choose a nonnegative compact smooth function $h$ ` |
| S0173 | 397–402 | SENTENCE | yes | 3 | `ac6fb5f605717255` | `For $\gamma>0$ put \[  A=\sqrt{S_{12}^2+\gamma^2h^2},\qquad  B=\sqrt{S_{11}^2+S_{22}^2+\gamma^2h^2}.` |
| S0174 | 402–404 | SENTENCE | yes | 3 | `451e7711458521dc` | `These functions are smooth: near the zero set of $h$, the entries of $S$ already vanish, so both squ` |
| S0175 | 404–405 | SENTENCE | yes | 2 | `c0d0239b5250d95e` | `They satisfy $A\geq\|S_{12}\|$ and $B\geq\max(S_{11},S_{22})$.` |
| S0176 | 405–411 | BOUNDARY-GROUP | yes | 6 | `b5c7addf04915e87` | `Define \[  a_1=B-S_{11},\quad a_2=B-S_{22},\quad  a_3=A-S_{12},\quad a_4=A+S_{12},\quad q=A+B \] The` |
| S0177 | 411–413 | SENTENCE | yes | 6 | `f7c681b798f352cc` | `All coefficients are smooth, compactly supported, and nonnegative, with $\sum_i\norm{a_i}1\leq C\nor` |
| S0178 | 413–414 | SENTENCE | yes | 0 | `05808f1d0ebf77e2` | `The final term can be made arbitrarily small before choosing fine scales.` |
| S0179 | 414–415 | SENTENCE | yes | 0 | `be3088a417aa0831` | `The discarded spatial tail remains a small residual.` |
| S0180 | 415–418 | SENTENCE | yes | 5 | `f527f823662524f4` | `On a compact time interval, continuity into $L^1$ makes this tail truncation uniform: the continuous` |
| S0181 | 418–420 | SENTENCE | yes | 2 | `1ca4139207e8b055` | `Fix a coefficient and its rectangle in coordinates $(s,y)$ adapted to $\xi$.` |
| S0182 | 420–421 | SENTENCE | yes | 2 | `6298ac3860cd054d` | `Write $a$ for the original compactly supported coefficient.` |
| S0183 | 421–423 | SENTENCE | yes | 4 | `d7c4d3d6d4d039db` | `On the scanning rectangle define $c=a+e$ with a strictly positive floor $e>0$, and use constant-$e$ ` |
| S0184 | 423–425 | SENTENCE | yes | 2 | `0df95c6ecad7fa00` | `Write $\varepsilon_{\rm floor}$ for the total added floor and buffer mass, including the fixed facto` |
| S0185 | 425–426 | SENTENCE | yes | 0 | `0fe97af8873f9bcc` | `This mass is chosen arbitrarily small.` |
| S0186 | 426–428 | SENTENCE | yes | 2 | `c212a7b96adcccf0` | `All rectangle, floor, and derivative constants are fixed before the fine parameter tends to zero.` |
| S0187 | 428–432 | SENTENCE | yes | 4 | `4abd38d7094f0098` | `We use two distinct scales \begin{equation}\label{eq:scales}  d=H^2\quad\hbox{(row spacing)},\qquad ` |
| S0188 | 432–433 | SENTENCE | yes | 0 | `2f71ca3e583a0b84` | `The auxiliary bump has width $H$, not $d$.` |
| S0189 | 433–434 | SENTENCE | yes | 2 | `7fd019bf46fd7168` | `One packet visits rows $y=kd$ sequentially, with no simultaneous packets.` |
| S0190 | 434–435 | SENTENCE | yes | 2 | `07d1b2d89e809fbe` | `On the interior of a row, $\eta$ is constant and $r(s)=r_0c(s,kd)$.` |
| S0191 | 435–440 | SENTENCE | yes | 2 | `5a6687a030173ac9` | `Thus \[  dt=(r_0/\eta)c(s,kd)\,ds,  \qquad\int\eta^2U_H(x-X(t))\,dt  =\eta r_0\int c(s,kd)U_H(x-s\xi` |
| S0192 | 440–443 | SENTENCE | yes | 3 | `56f3f95a63429b75` | `At entry use a fixed smooth temporal ramp $\zeta:[0,1]\to[0,1]$, equal to zero to all orders at zero` |
| S0193 | 443–444 | SENTENCE | yes | 0 | `7938436fba8fea77` | `At exit use the reversed ramp $\zeta(1-\cdot)$.` |
| S0194 | 444–445 | SENTENCE | yes | 2 | `d4704f0e484ac662` | `Write $I_\zeta=\int_0^1\zeta>0$.` |
| S0195 | 445–446 | SENTENCE | yes | 0 | `1405f4f8770fff53` | `Throughout either buffer $r=r_0e$ is constant.` |
| S0196 | 446–449 | SENTENCE | yes | 0 | `eec02b7ba2dba875` | `To traverse a buffer of length $L$, choose ramp duration $r_0eL/(\eta I_\zeta)$.` |
| S0197 | 449–451 | SENTENCE | yes | 0 | `555007d8c9128d0b` | `Let $B_i$ be the sum over rows of the interior line integrals of $c_i=a_i+e_i$, plus $2e_iL/I_\zeta$` |
| S0198 | 451–456 | SENTENCE | yes | 3 | `46a27d9265b0f4bf` | `Allocate $\tau_i=\tau/4$ to direction $i$, and set \begin{equation}\label{eq:normalization}  \eta_i^` |
| S0199 | 456–458 | SENTENCE | yes | 2 | `e12fc22a342ba9fd` | `The full scan takes exactly $(r_{0,i}/\eta_i)B_i=\tau_i$, and its coefficient weight is exactly $2\p` |
| S0200 | 458–459 | SENTENCE | yes | 0 | `7a55a655ac416a72` | `With sufficiently fine $d$, $dB_i\leq C\norm{a_i}1+C\varepsilon_{\rm floor}+o_H(1)$.` |
| S0201 | 459–463 | SENTENCE | yes | 2 | `e78bf2e5e89f3053` | `Writing $\varepsilon_{\rm reg}$ for the earlier regularization mass gives $\eta_i\leq C\sqrt\delta+ ` |
| S0202 | 463–466 | SENTENCE | yes | 3 | `e11c73fd68fbfd50` | `If a direction has zero mass it can be omitted; a positive floor otherwise makes \eqref{eq:normaliza` |
| S0203 | 466–469 | SENTENCE | yes | 3 | `ac3636d62c5b8fc2` | `On a ramp $\|(\eta r)'\|\leq C\eta_i^2$; on an interior row $\|\eta r'\|=\|(\eta r)'\|\leq\eta_i^2\norm{\p` |
| S0204 | 469–470 | SENTENCE | yes | 0 | `eb41c41aded3af74` | `Constants are fixed before $H\downarrow0$.` |
| S0205 | 470–472 | SENTENCE | yes | 5 | `0a69e59e4c8ac016` | `Accordingly $r_0\asymp H^8$, all radii are bounded above and below by fixed multiples of $H^8$, and ` |
| S0206 | 472–473 | SENTENCE | yes | 0 | `846aeda8fd5bb561` | `The intrinsic error \eqref{eq:E-bound} is $O(H\|\log H\|)+O(H^8)$.` |
| S0207 | 473–480 | SENTENCE | yes | 3 | `75b08abbb5a5e4ba` | `Integration by parts on a visit, using $\eta=0$ at its endpoints, gives \begin{equation}\label{eq:av` |
| S0208 | 480–481 | SENTENCE | yes | 0 | `d21f54e8a315d678` | `Indeed $\frac d{dt}(\eta rU_H(x-X))=(\eta r)'U_H-\eta^2\xi\cdot\nabla U_H$.` |
| S0209 | 481–482 | SENTENCE | yes | 0 | `beedeee7d544e1d8` | `Write the tensor in parentheses, summed over four directions, as $A_{\rm av}$.` |
| S0210 | 482–488 | SENTENCE | yes | 0 | `6c2cb656228138ae` | `The raster quadrature obeys \begin{equation}\label{eq:quad}  \left\\|d\sum_k\int a(s,kd)U_H(\,\cdot-s` |
| S0211 | 488–489 | SENTENCE | yes | 0 | `0b9f0401eb6e6f44` | `Here is the explicit Banach-valued rectangle-rule proof.` |
| S0212 | 489–491 | SENTENCE | yes | 0 | `b2d243af48c02850` | `Put $F(y)=\int a(s,y)U_H(\cdot-s\xi-y\xi^\perp)\,ds$, as an $L^1_x$-valued function.` |
| S0213 | 491–494 | SENTENCE | yes | 0 | `d4f1c463183eacf3` | `Differentiating it gives $\int\norm{F'(y)}1dy\leq\norm{\partial_\perp a}1+ \norm a1\norm{\partial_\p` |
| S0214 | 494–497 | SENTENCE | yes | 0 | `69288d3fceb1985d` | `On each row interval of length $d$, the fundamental theorem of calculus bounds the integrated discre` |
| S0215 | 497–498 | SENTENCE | yes | 0 | `b115861fdb3fee9b` | `Summing yields the first two terms in \eqref{eq:quad}.` |
| S0216 | 498–500 | SENTENCE | yes | 0 | `67b5a74c117a0422` | `The translation estimate $\norm{a*U_H-a}1\leq CH\norm{\nabla a}1$ gives the third.` |
| S0217 | 500–501 | SENTENCE | yes | 0 | `eae8f079a371dd3c` | `Estimate \eqref{eq:quad} applies to the original compact coefficient $a$.` |
| S0218 | 501–503 | SENTENCE | yes | 2 | `3a4d34ef48518c2d` | `The added floor and the ramp-weighted buffers contribute at most $C\varepsilon_{\rm floor}+o_H(1)$ s` |
| S0219 | 503–504 | SENTENCE | yes | 0 | `907e69031d85d54e` | `Since $d=H^2$, the quadrature error tends to zero.` |
| S0220 | 504–506 | STRUCTURAL | no | 0 | `e27cb5c8de69a506` | `\subsection{Temporal correction and the stress identity}` |
| S0221 | 507–511 | BOUNDARY-GROUP | yes | 0 | `a2f88bde9c771a68` | `On each cycle $[t_k,t_k+\tau]$ put \[  Q(t)=-\mathbb P\int_{t_k}^t  (\mathcal U(s)-\overline{\mathca` |
| S0222 | 511–513 | SENTENCE | yes | 0 | `139173d63852d180` | `The average here is taken over the entire four-direction cycle, not separately on each direction slo` |
| S0223 | 513–514 | SENTENCE | yes | 0 | `c4cc68641ddcb54c` | `This ensures that its tensor is the sum of all four directional averages throughout the cycle.` |
| S0224 | 514–516 | SENTENCE | yes | 2 | `c5f8bb290d88af8e` | `Here $\mathbb P=I-\nabla\Delta^{-1}\Div$ is used only on translates of the fixed bump $U_H\xi$ and t` |
| S0225 | 516–517 | SENTENCE | yes | 0 | `8042bf393c31caef` | `Its needed bounds have a direct fixed-profile proof.` |
| S0226 | 517–520 | SENTENCE | yes | 2 | `050e4d5bffbd2ab3` | `Let $G=(2\pi)^{-1}\log\|x\|$ and \[  Z_{H,\xi}=U_H\xi-(D^2G*U_H)\xi. \]` |
| S0227 | 520–521 | SENTENCE | yes | 2 | `d1f893e6344c0cd8` | `It has zero divergence and $\curl Z_{H,\xi}=\curl(U_H\xi)$.` |
| S0228 | 521–523 | SENTENCE | yes | 5 | `282d1525ad273d96` | `At $H=1$ it is smooth and bounded in the core: write the Hessian convolution as $\partial_iG*\partia` |
| S0229 | 523–525 | SENTENCE | yes | 4 | `8feac95adbf38ff5` | `Outside the bump support, radial averaging gives $G*U_1=G$, so $Z_{1,\xi}=-D^2G\xi=O(\|x\|^{-2})$.` |
| S0230 | 525–526 | SENTENCE | yes | 3 | `8634c0ecfff0a08d` | `Hence $Z_{1,\xi}\in L^p$ for every $p>1$.` |
| S0231 | 526–529 | SENTENCE | yes | 0 | `a08b8f6786a3c532` | `Scaling gives \[  \norm{Z_{H,\xi}}p\leq C_p H^{2/p-2}. \]` |
| S0232 | 529–530 | SENTENCE | yes | 0 | `6f92badf56da3343` | `Minkowski applies to its translates in the time primitive.` |
| S0233 | 530–531 | SENTENCE | yes | 0 | `350901051188c136` | `No general Calderón--Zygmund $L^p$ theorem is needed for this use of $\mathbb P$.` |
| S0234 | 531–535 | SENTENCE | yes | 3 | `31e7a14ec4c6a98d` | `For an explicit pressure sign, write $q_{H,\xi}=\xi\cdot\nabla(G*U_H)$ and let $\pi_{\mathcal U}(t)=` |
| S0235 | 535–536 | SENTENCE | yes | 0 | `5f57f11969c67238` | `Then $\mathcal U-\mathbb P\mathcal U=\nabla\pi_{\mathcal U}$.` |
| S0236 | 536–540 | SENTENCE | yes | 2 | `29b3ab5ed1487997` | `Taking $p_Q=-\pi_{\mathcal U}+\tau^{-1}\int_{\rm cycle}\pi_{\mathcal U}(s)\,ds$ gives the exact iden` |
| S0237 | 540–546 | SENTENCE | yes | 3 | `031f76919394837f` | `If $B$ bounds $\|(\eta r)'\|$, bump scaling gives \begin{equation}\label{eq:Q}  \norm Q2\leq C\tau H^{` |
| S0238 | 546–547 | SENTENCE | yes | 2 | `37d218242851d820` | `Here both $\mathcal U$ and its cycle average obey the needed norm bound.` |
| S0239 | 547–548 | SENTENCE | yes | 0 | `6ac9fa68b8e0ff61` | `The curl estimate follows directly from $\norm{\nabla U_H}1=O(H^{-1})$.` |
| S0240 | 548–549 | SENTENCE | yes | 0 | `e926048d3bbc75c9` | `No $L^1$ boundedness of $\mathbb P$ is invoked.` |
| S0241 | 549–550 | SENTENCE | yes | 0 | `cdc13386804aaa17` | `The corrector vanishes at both cycle endpoints.` |
| S0242 | 550–553 | SENTENCE | yes | 8 | `3bd744f42d5067c6` | `Its first time derivative may jump there, so the new velocity correction is continuous and, after th` |
| S0243 | 553–555 | SENTENCE | yes | 0 | `20a5127ac3dce3bf` | `Given an old distributional Euler--Reynolds seed $(u,p,R)$, set $\widetilde u=u+v+Q$.` |
| S0244 | 555–566 | SENTENCE | yes | 4 | `7aebc69f0c879406` | `Combining \eqref{eq:packet-source}, \eqref{eq:average}, and the equation for $Q$ gives, modulo a gra` |
| S0245 | 566–567 | SENTENCE | yes | 2 | `807a3ff72b654f94` | `The scalar $q$ is absorbed into pressure.` |
| S0246 | 567–569 | SENTENCE | yes | 3 | `4ffc44ccad9b7719` | `Thus $\widetilde R=R-S+E_{\rm total}$, where the averaging error is $S+A_{\rm av}-qI$ and all remain` |
| S0247 | 569–577 | SENTENCE | yes | 8 | `65b1b71a700eb29d` | `The displayed expression for $\widetilde R$ is symmetric, since each mixed product occurs with its t` |
| S0248 | 577–578 | SENTENCE | yes | 0 | `e20ecfcb1e8a9bf6` | `These terms tend to zero at fixed coarse seed as $H\downarrow0$.` |
| S0249 | 578–579 | SENTENCE | yes | 0 | `52d8c43837628093` | `The same estimates give an arbitrarily small $L^{3/2}$ increment.` |
| S0250 | 579–581 | SENTENCE | yes | 2 | `b191b227f30da3eb` | `A corrector on one direction slot alone would have the wrong instantaneous average stress and is not` |
| S0251 | 581–583 | STRUCTURAL | no | 0 | `be9332646d41db26` | `\subsection{Spatial smoothing, without remollifying the old seed}` |
| S0252 | 584–586 | SENTENCE | yes | 4 | `dc436b62dfe9ebd4` | `The raw profile can be made spatially smooth on each fixed cycle by convolving the \emph{new packet ` |
| S0253 | 586–587 | SENTENCE | yes | 3 | `ace42f4b48767b1c` | `Keep $\ell$ constant throughout that cycle and take it below its positive minimum radius.` |
| S0254 | 587–588 | SENTENCE | yes | 0 | `c7371fc0108a7ce5` | `Replace $v,Q,\mathcal U,E,A_{\rm av}$ by their convolutions consistently.` |
| S0255 | 588–593 | SENTENCE | yes | 2 | `ff5f3b1c7f2dd62b` | `The packet equation then gains the symmetric commutator \[  C_\ell=v_\ell\otimes v_\ell-(v\otimes v)` |
| S0256 | 593–596 | SENTENCE | yes | 4 | `d148ca2dbd9e8d1d` | `Its $L^1$ norm tends uniformly to zero on the fixed cycle: the map $t\mapsto v(t)$ is continuous int` |
| S0257 | 596–598 | SENTENCE | yes | 5 | `fd19b18f848f4e48` | `Norm bounds do not grow under probability convolution; evenness and the two moment cancellations are` |
| S0258 | 598–599 | SENTENCE | yes | 0 | `4a0e769ddf3a52cc` | `The constant smoothing scale eliminates any additional time derivative of the convolution kernel.` |
| S0259 | 599–600 | SENTENCE | yes | 2 | `722a067fcd3018ab` | `Zero endpoint values of $v$ and $Q$ are preserved.` |
| S0260 | 600–601 | SENTENCE | yes | 2 | `38f3d3653326d02b` | `The old seed is never remollified, so no new velocity jump is created at a pre-existing boundary.` |
| S0261 | 601–605 | SENTENCE | yes | 3 | `ca3b09bc8b066ec3` | `\begin{lemma}[Prescribed-piece local endpoint repair, LER]\label{ass:LER} Consider the following adm` |
| S0262 | 605–606 | SENTENCE | yes | 4 | `ba180ed6e3474173` | `Stresses are symmetric and locally bounded in $L^\infty_tL^1_x$.` |
| S0263 | 606–608 | SENTENCE | yes | 3 | `3f285f5e7a132a2e` | `Their restrictions to the open pieces of a locally finite positive-time partition admit continuous $` |
| S0264 | 608–609 | SENTENCE | yes | 0 | `e200214c0ca70065` | `The two one-sided extensions need not agree at a boundary.` |
| S0265 | 609–611 | SENTENCE | yes | 2 | `21c3e4070de39a8b` | `Actual stress values at those discrete times are chosen separately subject to the same norm bound; t` |
| S0266 | 611–612 | SENTENCE | yes | 0 | `135c9eeac33196cf` | `The Euler--Reynolds equation holds in distributions.` |
| S0267 | 612–613 | SENTENCE | yes | 0 | `a6a8bf02f477ed21` | `No derivative bound on the old velocity is required by the local construction.` |
| S0268 | 613–617 | SENTENCE | yes | 6 | `b488925bda163b91` | `Let $(u,R)$ be any current pair in this class, $J\Subset(0,\infty)$ an open interval, and $S$ a pres` |
| S0269 | 617–618 | SENTENCE | yes | 0 | `92b34938c9ec0c1d` | `Write $\delta=\sup_J\norm S1$.` |
| S0270 | 618–630 | SENTENCE | yes | 9 | `2e1063ba8e712642` | `For every $\varepsilon,\zeta,\kappa,r_*>0$ there are $w,E_{\rm total}$ compactly supported in time i` |
| S0271 | 630–633 | SENTENCE | yes | 6 | `5222a0b0bf728313` | `The constant $C$ is independent of the seed derivatives, support, patch location, and patch length; ` |
| S0272 | 633–635 | SENTENCE | yes | 3 | `490d5c084ceaef1c` | `The new correction is continuous into $L^2\cap L^3\cap L^{3/2}$, and only finitely many new time bou` |
| S0273 | 635–636 | SENTENCE | yes | 0 | `68794babdaf510f1` | `Old boundaries are included in the new partition.` |
| S0274 | 636–637 | SENTENCE | yes | 0 | `6a7798efafc2850d` | `Every principal radius can be required to be at most $r_*$.` |
| S0275 | 637–639 | SENTENCE | yes | 0 | `3e26ad725b91de90` | `All outputs paste within the admissible class. \end{lemma}` |
| S0276 | 640–641 | SENTENCE | yes | 3 | `7257658cb2304f1d` | `\begin{proof} If $\delta=0$, take $w=E_{\rm total}=0$.` |
| S0277 | 641–642 | SENTENCE | yes | 0 | `92f77ea8122a4ccb` | `Suppose henceforth that $\delta>0$.` |
| S0278 | 642–643 | SENTENCE | yes | 0 | `f42a54892bb17e4c` | `Choose $[a,b]\Subset J$ containing the temporal support of $S$ in its interior.` |
| S0279 | 643–644 | SENTENCE | yes | 0 | `68bcd7a777eb1814` | `Only finitely many inherited partition boundaries meet this interval.` |
| S0280 | 644–651 | SENTENCE | yes | 5 | `07e91f6aca0d46cd` | `On each closed one-sided continuity piece, uniform continuity into $L^1$ permits a finite coarse sub` |
| S0281 | 651–653 | SENTENCE | yes | 2 | `c986e99a1ac89267` | `In this display, $S$ on a closed $I_k$ means the one-sided continuous extension from its interior.` |
| S0282 | 653–654 | SENTENCE | yes | 0 | `fcbe2cb141cb23a2` | `No single actual boundary value is required to equal two different traces.` |
| S0283 | 654–657 | SENTENCE | yes | 3 | `fababb2acce09e71` | `First freeze $S$ at one time with error at most $\varepsilon_0/2$, then approximate that single $L^1` |
| S0284 | 657–658 | SENTENCE | yes | 0 | `ad755c09edd0801a` | `There are only finitely many coarse cells.` |
| S0285 | 658–660 | SENTENCE | yes | 3 | `84c49946288463b9` | `Thus their chosen supports, spatial derivatives, and decomposition parameters have finite maxima.` |
| S0286 | 660–661 | SENTENCE | yes | 0 | `31644fd737450a4a` | `No derivative of the actual prescribed $S$ is taken.` |
| S0287 | 661–664 | SENTENCE | yes | 0 | `dfd0818197200f19` | `On each $I_k$, decompose the constant tensor $-S_k$ modulo $q_kI$ as above.` |
| S0288 | 664–666 | SENTENCE | yes | 3 | `c292a83bee9e5877` | `Choose its regularization parameter and the positive floors so that all added coefficient mass is ar` |
| S0289 | 666–668 | SENTENCE | yes | 2 | `f8ec97653b1bea1a` | `The rectangular buffers lie outside the support of the original coefficient, where its value is zero` |
| S0290 | 668–670 | SENTENCE | yes | 2 | `26fb25a64b921a08` | `The constant-floor buffer errors are bounded by a fixed multiple of their total added mass.` |
| S0291 | 670–672 | SENTENCE | yes | 2 | `06321bdc43ad0452` | `In particular, shrinking those masses controls the averaging error and the additive amplitude slack ` |
| S0292 | 672–674 | SENTENCE | yes | 2 | `62f7854a44b7e27e` | `Fix the coarse tensor, rectangles, floors, and ramp functions.` |
| S0293 | 674–675 | SENTENCE | yes | 0 | `7cddae859256c898` | `Divide $I_k$ into $N_k$ equal complete four-direction cycles.` |
| S0294 | 675–676 | SENTENCE | yes | 3 | `61980b53f56db039` | `Put $\tau_k=\|I_k\|/N_k$, $H_k=\tau_k^{1/6}$, and $d_k=H_k^2$.` |
| S0295 | 676–678 | SENTENCE | yes | 2 | `2cfb3f2ca99f27e6` | `Consequently $\tau_k=H_k^6$ holds exactly, rather than only asymptotically, and every endpoint of $I` |
| S0296 | 678–679 | SENTENCE | yes | 0 | `5ea7d74a9e3c2ba1` | `Use the exact normalization \eqref{eq:normalization} on each cycle.` |
| S0297 | 679–681 | SENTENCE | yes | 4 | `89ba025a5d1d45ea` | `At fixed positive floors, the quantities $d_kB_i$ converge to positive finite limits as $N_k\to\inft` |
| S0298 | 681–683 | SENTENCE | yes | 6 | `0391be41671cc07d` | `The amplitudes therefore have positive lower and finite upper bounds independent of large $N_k$, wit` |
| S0299 | 683–688 | SENTENCE | yes | 0 | `9487ea3f5593086b` | `The leading upper bound is \[  \eta_i\leq C\sqrt{\delta+\varepsilon_0}    +C\sqrt{\hbox{added mass a` |
| S0300 | 688–690 | SENTENCE | yes | 2 | `c581e26e8885b110` | `The constant multiplying $\sqrt{\delta+\varepsilon_0}$ depends only on the fixed four directions and` |
| S0301 | 690–693 | SENTENCE | yes | 4 | `93ff8de784de0264` | `All radii on the fixed coarse cell are bounded above and below by positive constant multiples of $H_` |
| S0302 | 693–694 | SENTENCE | yes | 0 | `9c60b4d93d52659f` | `The constants may depend on its coefficients and floors.` |
| S0303 | 694–695 | SENTENCE | yes | 3 | `ae5f924f39614754` | `Thus $2r^{1/5}\leq H_k$ and $r\leq r_*$ hold for all sufficiently large $N_k$.` |
| S0304 | 695–698 | SENTENCE | yes | 6 | `8f9ee832519f5efd` | `The quantities $\|(\eta r)'\|$ and $\|\eta r'\|$ stay bounded independently of $N_k$, because their form` |
| S0305 | 698–700 | SENTENCE | yes | 0 | `a9c1cb80acac9bb2` | `Equation \eqref{eq:E-bound} makes the intrinsic stress $O(H_k\|\log H_k\|)+O(H_k^8)$.` |
| S0306 | 700–702 | SENTENCE | yes | 3 | `9bf2c69f4b1930b1` | `Equation \eqref{eq:Q} makes the corrector $O(H_k^5)$ in $L^2$ and curl $L^1$, and $O(H_k^{16/3})$ in` |
| S0307 | 702–703 | SENTENCE | yes | 0 | `38f018ea5ddb94e6` | `The principal $L^{3/2}$ norm is $O(H_k^{8/3})$ at fixed coarse parameters.` |
| S0308 | 703–704 | SENTENCE | yes | 0 | `5ee7458802c9d864` | `Equation \eqref{eq:quad} makes the quadrature error tend to zero.` |
| S0309 | 704–706 | SENTENCE | yes | 3 | `f6133f1dfda1e856` | `Every cross term with the actual old $u$ tends to zero by the displayed Hölder estimates and the fin` |
| S0310 | 706–709 | SENTENCE | yes | 2 | `4029e67192e7c068` | `There is no time-freezing derivative estimate here: the constructed tensor $S_k$ is constant on the ` |
| S0311 | 709–711 | SENTENCE | yes | 0 | `5d4d13aca6e94572` | `Finally choose a fixed spatial mollification scale on each complete cycle.` |
| S0312 | 711–712 | SENTENCE | yes | 3 | `972c429e2e061a00` | `The finite set of cycles has a positive minimum radius.` |
| S0313 | 712–714 | SENTENCE | yes | 3 | `6eb47b07948bd019` | `The commutator can therefore be made smaller than any remaining stress budget, while convolution dec` |
| S0314 | 714–715 | SENTENCE | yes | 0 | `2729057df2c27174` | `It changes the averaged tensor to its convolution.` |
| S0315 | 715–717 | SENTENCE | yes | 2 | `4de0b69277474017` | `The resulting additional averaging error also tends to zero in $L^1$ as the mollification scale tend` |
| S0316 | 717–718 | SENTENCE | yes | 0 | `c3c0f0ca0de5a008` | `No old field is mollified.` |
| S0317 | 718–721 | SENTENCE | yes | 0 | `ac4a34890d158df5` | `The exact stress identity on $I_k$ is $\widetilde R=R-S_k+E_k^{\rm loc}$.` |
| S0318 | 721–724 | SENTENCE | yes | 3 | `1c265511901a30b8` | `It follows by adding the old equation to the new packet and corrector identities, taking the average` |
| S0319 | 724–728 | SENTENCE | yes | 2 | `5742003b379e7b54` | `At times strictly inside a coarse cell, set \[  E_{\rm total}(t)=S(t)-S_k+E_k^{\rm loc}(t)\qquad(t\i` |
| S0320 | 728–729 | SENTENCE | yes | 0 | `cb805803061161a0` | `Then $\widetilde R=R-S+E_{\rm total}$ exactly.` |
| S0321 | 729–731 | SENTENCE | yes | 2 | `464afba5e3ba5f22` | `Choose $\varepsilon_0\leq\varepsilon/2$ and all local stress errors at most $\varepsilon/2$.` |
| S0322 | 731–732 | SENTENCE | yes | 0 | `3e7da5f85ba82ba4` | `This proves the requested stress bound.` |
| S0323 | 732–734 | SENTENCE | yes | 0 | `78f9aaf50772db1c` | `Choose $\varepsilon_0$ also so that $C\sqrt\varepsilon_0\leq\zeta/3$.` |
| S0324 | 734–736 | SENTENCE | yes | 0 | `29c8ac123bfede8b` | `Next choose added coefficient masses small enough for their amplitude cost to be at most $\zeta/3$.` |
| S0325 | 736–738 | SENTENCE | yes | 3 | `157ee70378ac5799` | `Finally choose the cycle counts large enough that the row-rule amplitude error and the $L^2$ and cur` |
| S0326 | 738–740 | SENTENCE | yes | 0 | `79989a882741ff26` | `Using $\sqrt{\delta+\varepsilon_0}\leq\sqrt\delta+\sqrt\varepsilon_0$ proves the independent leading` |
| S0327 | 740–742 | SENTENCE | yes | 2 | `449c2b411cef1dd7` | `The same cycle counts can make the two $L^{3/2}$ contributions sum to at most $\kappa$ and all radii` |
| S0328 | 742–744 | SENTENCE | yes | 2 | `d705e5a2426c1b5b` | `All these requirements have already been shown to improve as the counts increase at fixed coarse dat` |
| S0329 | 744–746 | SENTENCE | yes | 2 | `b1474e409df28a6a` | `Every principal packet and $Q$ vanishes at each completed cycle endpoint.` |
| S0330 | 746–747 | SENTENCE | yes | 0 | `a1513e9086c1ed4c` | `Extend $w$ by zero outside $[a,b]$.` |
| S0331 | 747–748 | SENTENCE | yes | 2 | `46091431238be700` | `Its continuous zero traces exclude temporal delta functions.` |
| S0332 | 748–749 | SENTENCE | yes | 2 | `8c1f00aa50d2c68f` | `Define $E_{\rm total}=0$ outside this interval; the prescribed $S$ is zero there.` |
| S0333 | 749–752 | SENTENCE | yes | 4 | `c9b06ca7b256f8d1` | `On the finite set of inherited, coarse-cell, and full-cycle boundary times, choose $E_{\rm total}(t)` |
| S0334 | 752–754 | SENTENCE | yes | 3 | `de73c2f1420514bf` | `These choices maintain the exact algebra and the pointwise error bound, and do not change the distri` |
| S0335 | 754–756 | SENTENCE | yes | 3 | `6ffcbdaa7954d29e` | `The error stress may jump at $a,b$ and at cycle boundaries, but spatial divergence creates no tempor` |
| S0336 | 756–757 | SENTENCE | yes | 0 | `e6a786e013365895` | `Both output supports are compact subsets of $J$.` |
| S0337 | 757–761 | SENTENCE | yes | 5 | `7ed0915fcbf90c4a` | `The principal packet is continuous in global $L^2$ and $L^{3/2}$ by positive-radius scaling and tran` |
| S0338 | 761–763 | SENTENCE | yes | 2 | `8de9311bc2febb77` | `Fixed spatial smoothing makes it continuous into $L^3$ by Young's inequality $\norm{\rho_\ell*v}3\le` |
| S0339 | 763–764 | SENTENCE | yes | 2 | `97545cc081334b9d` | `The projected-bump time integral makes $Q$ continuous into all three spaces.` |
| S0340 | 764–766 | SENTENCE | yes | 2 | `5b3645e979939dde` | `For each fixed construction these bounds are finite, without asserting a uniform $L^3$ bound through` |
| S0341 | 766–768 | SENTENCE | yes | 2 | `50c6434687df80f8` | `Every local intrinsic stress is continuous into $L^1$ on its closed cycle.` |
| S0342 | 768–770 | SENTENCE | yes | 2 | `7187e96267ba25c4` | `For the anti-divergence terms this follows from \eqref{eq:anti} on a common support ball and the $L^` |
| S0343 | 770–771 | SENTENCE | yes | 3 | `635aeacf91a82af2` | `Translations and positive-radius rescalings preserve the asserted continuity.` |
| S0344 | 771–772 | SENTENCE | yes | 0 | `697433f8de72ce37` | `At packet resets the prefactors in those intrinsic stresses tend to zero.` |
| S0345 | 772–773 | SENTENCE | yes | 3 | `745897a90d8d9a8f` | `The commutator and quadratic terms are continuous by their $L^2$ products.` |
| S0346 | 773–779 | SENTENCE | yes | 2 | `0361dba692c442ef` | `The old--new terms are continuous because \[  \norm{u(t)\otimes w(t)-u(s)\otimes w(s)}1  \leq\norm{u` |
| S0347 | 779–780 | SENTENCE | yes | 2 | `c61d0ccd0b98084e` | `Adding $S-S_k$ leaves the error piecewise continuous into $L^1$.` |
| S0348 | 780–781 | SENTENCE | yes | 2 | `f0113bed848a15e6` | `Thus the new stress and velocity remain in the stated admissible class.` |
| S0349 | 781–783 | SENTENCE | yes | 2 | `e00b0a0bf8e47145` | `Only finitely many coarse cells and cycles were used in $[a,b]$. \end{proof}` |
| S0350 | 784–785 | STRUCTURAL | no | 0 | `11db7c42d27cb5b3` | `\section{Global time iteration and exact-target closure}` |
| S0351 | 786–790 | SENTENCE | yes | 6 | `bcb1ecd8cacc875f` | `\begin{lemma}[Zero initial trace from anchor times]\label{lem:anchors} Suppose $(U,R)$ and $(\wideti` |
| S0352 | 790–792 | SENTENCE | yes | 4 | `dcffbe0258c2af10` | `Suppose $W=\widetilde U-U$ is uniformly bounded in global $L^2$ and $W(t_k)=0$ for a sequence $t_k\d` |
| S0353 | 792–794 | SENTENCE | yes | 0 | `36bac94f47a2cbdd` | `Then $W(t)\rightharpoonup0$ in global $L^2$ as $t\downarrow0$. \end{lemma}` |
| S0354 | 795–802 | SENTENCE | yes | 3 | `a1f55d97465722e4` | `\begin{proof} For a compact smooth divergence-free spatial test $\psi$, subtract the Euler--Reynolds` |
| S0355 | 802–803 | SENTENCE | yes | 3 | `e532e92dc0218ce1` | `The right side is uniformly bounded.` |
| S0356 | 803–805 | SENTENCE | yes | 3 | `0ab62c5c6cb1706e` | `The pairing is Lipschitz, including across piecewise-time boundaries by the distributional equation ` |
| S0357 | 805–806 | SENTENCE | yes | 3 | `9e43ae0272c3cd49` | `For any sequence $t_n\downarrow0$, the bounded sequence $W(t_n)$ has a weakly convergent $L^2$ subse` |
| S0358 | 806–808 | SENTENCE | yes | 4 | `d61377147b9bd39d` | `Its limit is divergence free and annihilates all such $\psi$; testing $\psi=\nabla^\perp\phi$ also m` |
| S0359 | 808–811 | SENTENCE | yes | 3 | `52d974b8767447cb` | `Fourier variables force this global $L^2$ vector field to vanish: away from frequency zero it is bot` |
| S0360 | 811–812 | SENTENCE | yes | 0 | `4c79f9c41eab5e85` | `All weak cluster points are zero, proving the claim. \end{proof}` |
| S0361 | 813–819 | SENTENCE | yes | 7 | `1cae356502980f4a` | `\begin{proposition}[Global iteration]\label{prop:iteration} The seed in Proposition~\ref{prop:seed} ` |
| S0362 | 820–826 | SENTENCE | yes | 4 | `83114791dc0edb1c` | `\begin{proof} Choose a nonnegative $\eta\in C_c^\infty((1/2,2))$ whose dyadic dilates cover $(0,\inf` |
| S0363 | 826–828 | SENTENCE | yes | 2 | `7b117f3bd3d99ded` | `This is a locally finite partition of unity with $\supp\chi_j\Subset I_j$.` |
| S0364 | 828–828 | SENTENCE | yes | 0 | `a8a77c23e617d2c2` | `Color patches by $j\bmod3$.` |
| S0365 | 828–830 | SENTENCE | yes | 3 | `6d8f6c04d032f04e` | `Within each color the intervals are disjoint and leave gaps; for a given $j$ of that color, $3\cdot2` |
| S0366 | 830–831 | SENTENCE | yes | 0 | `52d99f68c741c680` | `These gap times tend to zero as $j\to-\infty$.` |
| S0367 | 831–831 | SENTENCE | yes | 0 | `6a637f8fac8408dc` | `Use $N=3$ as an overlap bound.` |
| S0368 | 831–834 | SENTENCE | yes | 5 | `3655938b28588889` | `Choose a smooth nondecreasing majorant $\Theta\geq1$, finite on every finite horizon including zero,` |
| S0369 | 834–835 | SENTENCE | yes | 0 | `2cbd49e875d39ce1` | `It exists from Proposition~\ref{prop:seed}.` |
| S0370 | 835–836 | SENTENCE | yes | 2 | `774332f28a9bee85` | `Let $\delta_q=16^{-q}$ and inductively require $\norm{R^{(q)}(t)}1\leq\delta_q\Theta(t)$.` |
| S0371 | 836–838 | SENTENCE | yes | 0 | `1b819e53f76adaae` | `Freeze the prescribed pieces $S_{qj}=\chi_jR^{(q)}$ before any repair at stage $q$.` |
| S0372 | 838–838 | SENTENCE | yes | 3 | `348f534c43a493b8` | `Set $M_j=\sup_{I_j}\Theta$, $m_j=\inf_{I_j}\Theta\geq1$.` |
| S0373 | 838–844 | SENTENCE | yes | 4 | `41c2da9005e26907` | `For patch $j$ apply LER with \[  \varepsilon_{qj}=\delta_{q+1}m_j/N,\qquad  \zeta_{qj}=\sqrt{\delta_` |
| S0374 | 844–845 | SENTENCE | yes | 0 | `6d6af06218577b52` | `Process the three colors in order.` |
| S0375 | 845–846 | SENTENCE | yes | 2 | `80b6c11fab7e40cc` | `Within one color disjoint supports allow simultaneous pasting, with no cross term between different ` |
| S0376 | 846–848 | SENTENCE | yes | 2 | `2184b55900db97c0` | `Between colors use the current repaired pair as background, while still removing the originally froz` |
| S0377 | 848–849 | SENTENCE | yes | 0 | `284425d6685fac78` | `This prescribed-piece feature is why LER is stated with $S$ independently of the current $R$.` |
| S0378 | 849–851 | SENTENCE | yes | 2 | `064c999c54c8af1e` | `Each compact positive-time interval meets only finitely many patches, and LER introduces only finite` |
| S0379 | 851–852 | SENTENCE | yes | 2 | `9582647361b57925` | `Thus the finite-stage admissible class is retained.` |
| S0380 | 852–858 | SENTENCE | yes | 3 | `5735e2ae9d25013e` | `At the end of the stage, \[  u^{(q+1)}=u^{(q)}+w_q,\quad w_q=\sum_jw_{qj},\qquad  R^{(q+1)}=\sum_jE_` |
| S0381 | 858–860 | SENTENCE | yes | 2 | `5011958922faf098` | `There are at most $N$ active summands at any time, and each has $m_j\leq\Theta(t)$.` |
| S0382 | 860–861 | SENTENCE | yes | 0 | `ac6d06a1b4371b3c` | `Therefore $\norm{R^{(q+1)}(t)}1\leq\delta_{q+1}\Theta(t)$.` |
| S0383 | 861–867 | SENTENCE | yes | 0 | `eaabe07ef124051e` | `During a partially completed color stage the stress is \[  \left(1-\sum_{j\ \mathrm{processed}}\chi_` |
| S0384 | 867–873 | SENTENCE | yes | 4 | `4c04663d57e3fe5c` | `If $0<t\leq T$ and a patch is active, $I_j\subset(0,4T)$, so \begin{equation}\label{eq:increment-sta` |
| S0385 | 873–874 | SENTENCE | yes | 2 | `0ce1cdc46d365f82` | `These bounds are summable in $q$ and also bound intermediate color increments.` |
| S0386 | 874–877 | SENTENCE | yes | 2 | `820ce850b2a2d6af` | `The arbitrary $L^{3/2}$ budgets give summable subcritical increments; their more immediate role is m` |
| S0387 | 877–877 | SENTENCE | yes | 0 | `780cd35aaee06b3a` | `No uniform-in-stage $L^3$ norm is asserted.` |
| S0388 | 877–880 | SENTENCE | yes | 0 | `26cf4276ae205118` | `For each color the total correction vanishes at its gap times approaching zero.` |
| S0389 | 880–882 | SENTENCE | yes | 7 | `5ba60c53b66b6073` | `Both old and new stresses and local energies are uniformly bounded near zero, and the global $L^2$ c` |
| S0390 | 882–883 | SENTENCE | yes | 0 | `3886d10e10075c3a` | `Lemma~\ref{lem:anchors} shows it has weakly zero initial trace.` |
| S0391 | 883–883 | SENTENCE | yes | 0 | `a4c6746255467d6a` | `There are only three colors.` |
| S0392 | 883–885 | SENTENCE | yes | 0 | `b9a9115793abf20b` | `Induction therefore preserves exact initial trace at every stage without requiring small initial ene` |
| S0393 | 885–888 | SENTENCE | yes | 3 | `d481b8197cb57b7d` | `The correction series converges uniformly in global $L^2$ on $(0,T]$ for each finite $T$.` |
| S0394 | 888–889 | SENTENCE | yes | 4 | `1e29d39a54cb55c8` | `At positive times the finite stages are locally strongly $L^2$ continuous, so their locally uniform ` |
| S0395 | 889–891 | SENTENCE | yes | 5 | `251a19dc139ebd8f` | `At zero, split the series into finitely many terms and a uniformly small $L^2$ tail; each finite cor` |
| S0396 | 891–893 | SENTENCE | yes | 2 | `f8fe76cc9e408a1f` | `Together with the seed trace this gives $u\in C_w([0,\infty);L^2_{\rm loc})$ and $u(0)=u_0$.` |
| S0397 | 893–896 | SENTENCE | yes | 2 | `01573838ff8374c8` | `At each fixed $t>0$, the curl series converges absolutely in $L^1$ by \eqref{eq:increment-stage}, an` |
| S0398 | 896–901 | SENTENCE | yes | 2 | `e3a8c3162a15ddb4` | `Consequently \[  \sup_{0<t\leq T}\norm{\curl u(t)}1\leq  \sup_{0<t\leq T}\norm{\curl u^{(0)}(t)}1+  ` |
| S0399 | 901–902 | SENTENCE | yes | 0 | `7da2d5e90d360c20` | `Add the initial measure norm to obtain the bound including zero.` |
| S0400 | 902–903 | SENTENCE | yes | 0 | `777fbd098b7981f7` | `Divergence zero is preserved distributionally.` |
| S0401 | 903–907 | SENTENCE | yes | 2 | `3accb14ab0ecd464` | `Strong $L^2$ convergence on compact positive-time cylinders passes the quadratic term to the limit i` |
| S0402 | 907–908 | SENTENCE | yes | 0 | `0ff74f34a8b9b1d8` | `Thus Euler holds on $(0,\infty)$.` |
| S0403 | 908–909 | SENTENCE | yes | 0 | `818fa42bed19c8c9` | `For a test meeting zero, use a temporal cutoff rising on $(\varepsilon,2\varepsilon)$.` |
| S0404 | 909–910 | SENTENCE | yes | 0 | `22e65b4917a198f9` | `Uniform local energy makes the omitted convection integral tend to zero.` |
| S0405 | 910–912 | SENTENCE | yes | 2 | `5101923c130bb4e1` | `Weak local $L^2$ continuity identifies the cutoff-derivative term with $\int u_0\cdot\varphi(0)$; re` |
| S0406 | 912–914 | SENTENCE | yes | 0 | `29972b360d969ec6` | `This proves precisely the target's initial-value weak formulation. \end{proof}` |
| S0407 | 915–918 | SENTENCE | yes | 6 | `a17c414220695e3e` | `\begin{lemma}[Canonical normalization from a fixed background]\label{lem:canonical} Suppose $u=U+v$,` |
| S0408 | 918–919 | SENTENCE | yes | 0 | `0fac365cdde2a1b6` | `Then $u=K*\mu$. \end{lemma}` |
| S0409 | 920–922 | SENTENCE | yes | 5 | `d4abd4725f5c32ab` | `\begin{proof} The distribution $h=u-K*\mu$ has zero divergence and curl, so each component is harmon` |
| S0410 | 922–928 | SENTENCE | yes | 0 | `74eef9688c27edb2` | `Its mean-value estimate on $B_R(x)$ gives \[  \|h(x)\|\leq\frac1{\|B_R\|}\int_{B_R(x)}\|U\|  +\frac{C\norm` |
| S0411 | 928–930 | SENTENCE | yes | 0 | `184cb43ae677e933` | `The last term is at most $C\norm\mu\M/R$, because $\sup_y\int_{B_R(x)}\|K(z-y)\|\,dz\leq CR$.` |
| S0412 | 930–932 | SENTENCE | yes | 2 | `b8f4df0410c22b21` | `The first tends to zero since $U\in C_0$: separate a fixed large compact set from its uniformly smal` |
| S0413 | 932–933 | SENTENCE | yes | 2 | `5f66bc0cc45a4fd9` | `Letting $R\to\infty$ proves $h=0$. \end{proof}` |
| S0414 | 934–938 | SENTENCE | yes | 2 | `0c96a792169e2b6b` | `\begin{theorem}[Global existence]\label{thm:global} For every datum in the exact target stated at th` |
| S0415 | 939–942 | SENTENCE | yes | 4 | `c72d973572278aec` | `\begin{proof} Proposition~\ref{prop:iteration} gives the global velocity, the exact weak initial tra` |
| S0416 | 942–944 | SENTENCE | yes | 4 | `105fb39fbb3cbf60` | `At each time take $U=V_0$ and $v=(V(t)-V_0)+W(t)+\sum_qw_q(t)\in L^2$ in Lemma~\ref{lem:canonical}; ` |
| S0417 | 944–945 | SENTENCE | yes | 2 | `9b053da69233fff1` | `This proves the remaining canonical Biot--Savart identity at every time.` |
| S0418 | 945–947 | SENTENCE | yes | 2 | `74b69f6513baba72` | `No finite-horizon solutions have to be reconciled or restarted. \end{proof}` |
| S0419 | 948–949 | STRUCTURAL | no | 0 | `fef19ca8785dccb2` | `\end{document}` |
