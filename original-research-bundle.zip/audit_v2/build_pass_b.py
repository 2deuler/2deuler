import json, hashlib, collections
from pathlib import Path
base=Path('audit_v2'); src=(base/'proof.tex').read_bytes(); invbytes=(base/'audit_inventory.json').read_bytes(); inv=json.loads(invbytes); forms=json.loads((base/'audit_formulas.json').read_bytes())
rats={f'S{int(a):04d}':b for a,b in (s.split('|',1) for s in (base/'pass_b_rationales.txt').read_text().splitlines())}
source_hash=hashlib.sha256(src).hexdigest(); invhash=hashlib.sha256(invbytes).hexdigest()
assert source_hash=='1ffbeee20c4208e954396b55c3f4bc5289e478d76555579b09d5e7fbfae975bd'
assert invhash=='6f43080009e044109938412d2f40e6ba7374ec8777e8be2962c7c1489ea8e0eb'
scaffold=set(inv['scaffolding_only_child_ids'])
records=[]
for c in inv['containers']:
    status='VERIFIED' if c['mathematical'] else 'NOT MATHEMATICAL'
    rationale=rats.get(c['id'],'This is document formatting, an environment declaration, a title/heading, or an audit-status notice; it asserts no mathematical fact and all source bytes remain represented.')
    nested=[]
    for n in c['nested_checks']:
        ns='NOT MATHEMATICAL' if n['id'] in scaffold else 'VERIFIED'
        nr='This exact focus is only an empty/whitespace/environment-closing scaffold span; mathematical branch contents are checked in the other children and full parent.' if n['id'] in scaffold else 'Checked the focused assertion in its complete parent scope. '+rationale
        nested.append({'id':n['id'],'status':ns,'rationale':nr,'focus_sha256':n['sha256'],'focus':n['text']})
    records.append({'id':c['id'],'source_sha256':c['sha256'],'status':status,'rationale':rationale,'nested_checks':nested,'supplemental_checks':[],'line_start':c['line_start'],'line_end':c['line_end'],'formula_ids':[f['id'] for f in forms['formulas'] if f['container_id']==c['id']]})
assert len(records)==419 and sum(len(r['nested_checks']) for r in records)==855
assert set(rats)=={c['id'] for c in inv['containers'] if c['mathematical']}
proofmaps=[]
for result,proof in zip(inv['major_results'],inv['proof_environments']):
    proofmaps.append({'title':result['title'],'statement_ids':result['container_ids'],'proof_ids':proof['container_ids'],'status':'VERIFIED'})
theorem_details={
'S0040':('Tonelli','nonnegative measurable |K(x-y)| on dx times d|mu|; finite translated local kernel integral','finite local L1 convolution and a.e. definition'),
'S0046':('measure convolution L1 inequality','L_a in L1 and mu finite signed; use total variation','L1 norm <=||L_a||1||mu||M'),
'S0048':('Plancherel','inhomogeneous H^{-1} mu and the explicitly bounded weighted multiplier','v0 in L2 with stated norm'),
'S0050':('Fourier inversion and Riemann-Lebesgue','integrable derivative multipliers times bounded mu-hat; positive derivative multipliers also square integrable','V0 smooth C0; positive derivatives L2 and bounded'),
'S0054':('Crippa-Stefani Theorem 3.3, Assumptions 2.1/3.1, Definition 3.2','primary publisher source inspected; kernel estimates and divergence condition checked for plane; input nu0 in L1 and Linfinity','global Lagrangian bounded-vorticity solution with canonical velocity a.e. time and stated bounds'),
'S0062':('same primary theorem application','S0039 gives L1 and Linfinity nu0, S0058 verifies kernel hypotheses; whole plane has no boundary','background solution, with further regularity proved locally'),
'S0065':('Osgood flow uniqueness and stability','bounded time-measurable field; uniform modulus Cr(1-log r) with divergent reciprocal integral','unique invertible continuous flow and bounded displacement'),
'S0067':('Jacobian change-of-variables formula','smooth spatially mollified bounded divergence-free field, finite positive horizon','flow Jacobian determinant identically one'),
'S0069':('dominated convergence','compact test, uniformly bounded displacement, bounded transported integrand and compact support','volume preservation for the limiting flow'),
'S0081':('Chebyshev inequality','nonnegative absolute value of an L1 near convolution, lambda>0; zero-mass case treated directly','weak-L2 bound'),
'S0082':('layer cake','nonnegative |V|, bounded above by B and weak-L2 level estimate for lambda>0','global L3 bound'),
'S0104':('Plancherel and dominated convergence','v0 in L2; multiplier between zero and one and converging pointwise to one','L2 contraction and strong initial convergence'),
'S0110':('Fubini/distributional Fourier convolution','finite sigma0, Schwartz kernel, local kernel-integrability bound','canonical seed convolution identity'),
'S0126':('intermediate value theorem','continuous power series with opposite strict signs at 3 and 4','a root in (3,4)'),
'S0128':('uniqueness for linear ODE','regular continuous coefficients on compact subintervals of (0,infinity), zero function and derivative at beta>0','identical zero solution, contradicting the series'),
'S0214':('Banach-valued fundamental theorem of calculus','F absolutely continuous in L1_x and derivative integrable in y','integrated rectangle-rule error'),
'S0232':('Minkowski integral inequality','p>1, projected profile in Lp, bounded coefficients over finite interval','norm of time primitive bounded by integral of norms'),
'S0256':('uniform approximation of identity on compact sets','continuous L2 curve on a compact cycle; convolution contractions and convergence on each L2 function','uniform commutator convergence in L1'),
'S0309':('Holder inequality','old u uniformly L3 on compact patch, increments arbitrarily small in dual L^{3/2}; remaining terms in L2','vanishing global L1 cross stress'),
'S0338':('Young inequality','rho_ell in L^{6/5}, v in L2; 1+1/3=5/6+1/2','continuous L3 smoothed packet'),
'S0357':('weak sequential compactness in L2','uniform global L2 bound, Hilbert space; diagonal dense-set proof supplied','weakly convergent subsequence'),
'S0409':('Weyl lemma','h locally L1 distribution with componentwise Laplacian zero; mollification and interior harmonic estimates','smooth harmonic representative')}
assert set(theorem_details)=={c['id'] for c in inv['containers'] if c['external_theorem_invocation']}
out={'metadata':{'pass':'B','method':'fresh independent source-ordered re-derivation','source_filename':'proof.tex','source_sha256':source_hash,'inventory_sha256':invhash,'formula_inventory_sha256':hashlib.sha256((base/'audit_formulas.json').read_bytes()).hexdigest(),'source_lines':949,'source_bytes':len(src),'scope':'All 419 permanent containers, 855 shared children, 579 formula occurrences, 106 algebra-bearing containers, 22 inventoried theorem-application containers, 8 proof environments and major results.','independence':'Only the assigned prompt, target, current proof, frozen current inventory and factual notation/formula inventories were read. No prior revision, other pass report, worker conclusions, reconciliation/change/provenance files, checkpoints, routes or agent list were read. No other auditor was contacted; coordinator messages only reported this pass progress.','primary_source_url':'https://link.springer.com/article/10.1007/s00526-024-02750-4','primary_source_tool_refs':['turn109view0','turn110view0','turn110view1','turn111view0','turn111view1'],'counts':{'containers':419,'mathematical':388,'non_mathematical':31,'nested_checks':855,'nested_mathematical':852,'nested_scaffolding':3,'supplemental_checks':0,'formulas':579,'inline':520,'display':59,'algebra_bearing':106,'theorem_applications':22,'proofs':8,'major_results':8,'uncovered_containers':0,'uncovered_lines':0,'missing_pass_b_verdicts':0,'unchecked_formulas':0},'container_status_counts':dict(collections.Counter(r['status'] for r in records)),'verdict':'No substantive mathematical error or missing deduction identified by this independent re-derivation. This is PASS B only, not a completed four-pass reconciliation.','limitations':['No proof assistant was used.','SymPy was unavailable in both Python runtimes tried; no symbolic-software verification is claimed. Exact Fraction arithmetic was used for the two Bessel partial sums.','The four-pass certificate and dispute reconciliation are the coordinator responsibility and are not represented as performed here.']},'containers':records,'theorem_hypothesis_checks':[{'container_id':k,'theorem':v[0],'hypotheses_matched':v[1],'conclusion_checked':v[2],'status':'VERIFIED','rationale':rats[k]} for k,v in theorem_details.items()],'major_result_dependencies':proofmaps,'formula_checks':[{'id':f['id'],'container_id':f['container_id'],'source_sha256':f['sha256'],'status':'VERIFIED','rationale':'Independently checked with the full source container; see '+f['container_id']+' re-derivation.'} for f in forms['formulas']],'issues':[]}
(base/'pass_b.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print('Wrote pass_b.json:',len(records),'containers;',sum(len(r['nested_checks']) for r in records),'children;',len(out['formula_checks']),'formulas')
print(out['metadata']['container_status_counts'])
