# PASS B — fresh independent re-derivation

This pass found no substantive mathematical error or missing deduction in the current manuscript. It independently re-derived the construction, including the proposed general signed-measure existence conclusion, rather than taking that conclusion or the local repair lemma as an assumption. This is one audit pass; it is not a claim that the required four-pass reconciliation has been completed.

## Scope and independence

Examined `audit_v2/proof.tex`, all 949 source lines and 45,127 bytes, together with the supplied audit prompt, target problem, frozen inventory, factual notation inventory and formula inventory. No included TeX file or external bibliography file is required by this source. The mathematical macros, labels and references were resolved against the current source.

- Source SHA-256: `1ffbeee20c4208e954396b55c3f4bc5289e478d76555579b09d5e7fbfae975bd`.
- Frozen inventory SHA-256: `6f43080009e044109938412d2f40e6ba7374ec8777e8be2962c7c1489ea8e0eb`.
- The exact source partition, every parent digest, every shared child focus span and every formula digest were checked programmatically against the source bytes.
- The permanent identifiers and shared children were not changed. No source or inventory file was edited.
- No earlier revision, other pass verdict, prior worker output, change/reconciliation manifest, checkpoint, provenance or route was read. No agent-list call was made and no other auditor was contacted. Messages to the coordinator contained this pass's progress only. No substantive auditing was delegated.

The full source was read in consecutive order. Shared child focuses were then inspected in consecutive groups against their complete parents. There are 419 parent verdicts and 855 child verdicts in `pass_b.json`; the three preallocated whitespace/environment scaffold children of S0130 are explicitly nonmathematical. No new supplemental source claim was found to require another child identifier. The complete per-parent affirmative rationale is included in the ledger below, and each child record binds its exact focus and supporting re-derivation.

## Coverage

| Denominator | Checked by PASS B |
|---|---:|
| Source lines / represented lines | 949 / 949 |
| Permanent containers | 419 / 419 |
| Sentence / structural / boundary-group containers | 380 / 37 / 2 |
| Mathematical / nonmathematical containers | 388 / 31 |
| Compound containers | 253 |
| Shared nested checks | 855 / 855 |
| Mathematical / scaffold child checks | 852 / 3 |
| Formula occurrences | 579 / 579 |
| Inline / displayed formulas | 520 / 59 |
| Algebra-bearing containers | 106 / 106 |
| Inventoried theorem applications | 22 / 22 |
| Proof environments / major-result maps | 8 / 8 |
| Supplemental checks | 0 |
| Uncovered containers, lines, formulas, missing PASS B verdicts | 0 |
| VERIFIED / NOT MATHEMATICAL parent verdicts | 388 / 31 |
| Other parent verdicts | 0 |

These are PASS B counts, not claims about any other pass. Dispute identifiers and four-pass final statuses are not assigned by this independent pass.

## Independent derivations in source order

### Initial normalization, background and seed: S0026–S0114

With the stated curl and Fourier conventions, \(K=\nabla^\perp G\), \(\Delta G=\delta_0\), \(G=(2\pi)^{-1}\log|x|\), so its multiplier is \(-i\xi^\perp/|\xi|^2\). For each radius-R ball, uniformly over its center relative to the measure,
\[
\int_{B_R}|K(x-y)|\,dx\le CR.
\]
Integrating this against total variation proves the a.e. convolution and permits truncation of arbitrary finite measures. It does not require a moment or compact support.

For radial probability \(a\), circulation determines \(K*a=K\int_{B_{|x|}}a\), so \(L_a=K-K*a\) is compactly supported with an integrable inverse-radius singularity. Consequently \(\|L_a*\mu\|_1\le\|L_a\|_1\|\mu\|_{\mathcal M}\). Evenness yields \(1-\widehat a=O(|\xi|^2)\) near zero. Thus
\[
|(1-\widehat a)m|^2\le C(1+|\xi|^2)^{-1},
\]
which is precisely the inhomogeneous \(H^{-1}\)-to-\(L^2\) estimate; imposing zero total circulation is unnecessary. For the low-frequency background, \(m\widehat a\) is integrable, while positive-order derivative multipliers are both integrable and square integrable. Multiplying by the bounded \(\widehat\mu\) gives all stated \(C_0\), boundedness and derivative conclusions.

**Primary-source match.** I inspected the [Crippa–Stefani publisher article](https://link.springer.com/article/10.1007/s00526-024-02750-4), specifically Assumptions 2.1 and 3.1, Definition 3.2 and Theorem 3.3. The datum \(a*\mu\) is in \(L^1\cap L^\infty\). The exact kernel distance identity gives both size hypotheses; divergence is zero and the plane has no boundary. The result supplies the claimed global Lagrangian solution, canonical velocity a.e. in time, vorticity/velocity bounds and log-Lipschitz modulus. The weak initial equation and a.e.-time pushforward are in its definition. No sign, support or energy hypothesis is imported. Every-time representatives, norm preservation and additional regularity are proved in the manuscript, not attributed to a stronger external theorem.

For the representative construction, \(\int_0 dr/[r(1-\log r)]=\infty\) gives uniqueness and stability of the bounded flow and its backward flow. Spatial mollification preserves zero divergence; the Jacobian determinant solves \(J'=0\). The displacement bound confines transported compact tests to a fixed bounded set, permitting dominated convergence of the volume-preservation identity. Composition with the inverse flow then preserves \(L^1,L^2,L^\infty\). Approximation by compact smooth functions proves strong \(L^1\) and \(L^2\) continuity of the transported vorticity.

The near/far convolution estimate proves uniform velocity bounds and \(L^\infty\) continuity. For positive level thresholds, splitting at \(r=M/(\pi\lambda)\) gives weak \(L^2\); when \(M=0\) the estimate holds directly without choosing this radius. Layer cake, truncated at the velocity supremum, gives \(\|V\|_3^3\le CM^2\|V\|_\infty\). Integrating transport gives \(\nu(t)-\nu_0=-\operatorname{Div}\int_0^tV\nu\). The rank-one multiplier of \(-K*\operatorname{Div}\) has norm one, yielding the global \(L^2\) difference and its Lipschitz time bound. The acceleration is \(L^2\), and its curl vanishes by transport; smoothing justifies the product identity. Taking the negative potential gives the required pressure.

The seed multiplier is \(e^{-t^4|\xi|^4}\), so \(W_t=-4t^3\Delta^2W\). Row-wise divergence of the symmetrized derivative tensor gives \(\Delta^2W\), since \(\operatorname{Div}W=0\). This checks the negative derivative-stress sign. The derivative tensor costs
\[
t^3\|D^2b_t*\sigma_0\|_1\le Ct\|\sigma_0\|_{\mathcal M}.
\]
The mixed stress uses bounded \(V\) and \(L^1\) \(W\); its continuity uses the \(L^3\)-\(L^{3/2}\) pairing. The strong initial trace follows from Fourier dominated convergence of \(W\), together with the background difference estimate.

### Dipole, symmetric antidivergence and compact source: S0115–S0168

The radial-swirl counterexample was checked by integrating its tail: its kinetic integral is \(\int dr/(r\log^2r)\), its curl is \(-1/(r^2\log^2r)\), while the mixed-background integral is \(\int dr/(r\log r)\). This confirms why the construction needs small global \(L^{3/2}\) increments.

I expanded the Bessel series independently. Exact rational arithmetic gives the two manuscript partial sums \(669/2048\) and \(-2/45\); the omitted-term ratio is \((z/2)^2/[(k+1)(k+2)]\), decreasing and below one after each truncation. The sign change gives \(3<\beta<4\). If \(J_0(\beta)=0\), the recurrence would also set \(J_1'(\beta)=0\); uniqueness for the regular linear ODE then contradicts the nonzero series at zero.

For the profile, \(q=\psi+x_2\), \(D-e_1=\nabla^\perp q\), and \(\Delta q=-\beta^2q\) inside. At radius one the interior and exterior radial value, first derivative and second derivative are respectively \(-\sin\theta,\sin\theta,-2\sin\theta\). Tangential differentiation gives the remaining matching Hessian entries. At the origin, the Bessel expression is \(x_2\) times a convergent series in \(|x|^2\), so the polar formula extends smoothly. Since \(w^\perp=-\nabla q\) for \(w=\nabla^\perp q\),
\[
(w\cdot\nabla)w=\nabla\bigl(|w|^2/2+\beta^2q^2/2\bigr)
\]
inside, confirming both signs in the negative pressure. The zero trace of q and the matching velocity eliminate an interface distribution.

Independent exterior differentiation gives
\[
D(x)=\frac{(x_1^2-x_2^2,2x_1x_2)}{|x|^4}
=\nabla\left(-\frac{x_1}{|x|^2}\right).
\]
Its size and derivative are respectively \(O(|x|^{-2})\), \(O(|x|^{-3})\). Changing variables gives \(\|D_r\|_p=r^{2/p-1}\|D\|_p\), while gradient and curl \(L^1\) norms are scale invariant.

Taking divergence of the proposed symmetric antidivergence cancels its two gradient-divergence terms and leaves f. Its kernel is homogeneous -1. On a ball its integral is \(CR\); outside, subtracting the zeroth and first Taylor terms leaves \(CR^2|x|^{-3}\|f\|_1\), globally integrable with total \(CR\|f\|_1\). Only zero mean would leave a generally nonintegrable degree -2 tail, so both moment conditions are essential and were checked.

Direct scaling differentiation gives
\[
\partial_rD_r=-r^{-2}(D+y\cdot\nabla D),\qquad
\operatorname{Div}(D_r\otimes x/r)=r^{-2}(2D+y\cdot\nabla D).
\]
This verifies the radial identity. The second expression vanishes outside the core by degree -2 homogeneity, is even, and has zero mean by the zero angular average of the exterior dipole. Thus the antidivergence hypotheses really hold and \(\|F_r\|_1\le Cr\).

Differentiating \(\eta D_r(x-X)\) and using \(X'=\eta\xi/r\) cancels the translating nonlinear equation. The remaining coefficient of \(T_XD_r\) is \(\eta'+\eta r'/r=(\eta r)'/r\); both stress terms must retain their translations, as they do in the source.

The compact cutoff removes precisely the exterior gradient. Core, annulus and cutoff-transition integrals give \(Cr(1+|\log r|)\). Boundary integrals for \(D_r\) and \(\nabla\Pi_r\) equal \(\pi r\xi\) and \(-\pi r\xi\), respectively; their difference is **\(2\pi r\xi\)**. Division by r and subtraction of \(2\pi U_H\xi\) leave zero mean and, by evenness, zero first moments. Applying the symmetric antidivergence yields exactly the two intrinsic stress terms and their bounds.

### Raster, projection, exact stress equation and smoothing: S0171–S0260

Expanding the four rank-one tensors gives off-diagonal entry \((a_3-a_4)/2=-S_{12}\) and diagonal entries \(B-S_{ii}+A=q-S_{ii}\). Positivity and the universal total-mass estimate follow directly from the root formulas. Near h=0 the original tensor is already zero and the roots equal \(\gamma h\), so there is no nonsmooth square-root zero.

On a row, the speed law gives \(dt=(r_0/\eta)c\,ds\). A ramp's displacement is \(T\eta I_\zeta/(r_0e)\), so its exact duration is the one stated. Including both ramp times in B_i, the two equations to solve are
\[
(r_{0,i}/\eta_i)B_i=\tau_i,\qquad
2\pi\eta_i r_{0,i}/\tau=d.
\]
Solving them gives the manuscript normalization, with positive roots because retained directions have positive floors. At fixed floors, \(dB_i\) has a positive finite limit; hence \(\eta_i\) is bounded above and below, \(r\asymp\tau d\asymp H^8\), and \(r^{1/5}/H=O(H^{3/5})\to0\).

The interior derivative coefficient is \(\eta_i^2\partial_\xi\log c_i\). On a ramp it is \(\eta_i^2 I_\zeta\zeta'/L\), with constant radius. Both are bounded independently of the fine scale. Consequently the intrinsic error is \(O(H|\log H|)+O(H^8)\).

Integrating \(d(\eta rU_H(x-X))/dt\) over a zero-endpoint visit gives the **positive** averaged divergence in the manuscript. The full four-direction cycle must be used here. For the quadrature, write its row profile as an \(L^1_x\)-valued F(y). Then
\[
\int\|F'(y)\|_1dy\le\|\partial_\perp a\|_1+C H^{-1}\|a\|_1.
\]
The integrated fundamental theorem on each row interval gives d times this bound; adding \(\|a*U_H-a\|_1\le CH\|\nabla a\|_1\) yields the complete quadrature estimate. Rectangular floors and ramp buffers are estimated separately by their added mass; the derivative estimate is not misapplied to their edges.

For the projected bump, moving one derivative onto U proves core smoothness. Radial averaging gives \(G*U_1=G\) outside the bump, so the projected tail is \(-D^2G\xi\) of degree -2. Thus the profile is in every p>1 and scales with norm \(H^{2/p-2}\). Its curl is the curl of the original bump, avoiding any L1 projection theorem. The time primitive therefore satisfies the three displayed bounds.

An independent sign calculation gives
\[
Q'+\mathcal U=\overline{\mathcal U}
 +\nabla(\pi_{\mathcal U}-\overline{\pi_{\mathcal U}}).
\]
The stated \(p_Q=-\pi_{\mathcal U}+\overline{\pi_{\mathcal U}}\) is exactly the pressure that removes this gradient. Its zero endpoint primitive permits cycle pasting despite derivative jumps. Expansion of \((u+v+Q)\otimes(u+v+Q)\) produces exactly the seven displayed cross/Q terms; no \(v\otimes v\) term is omitted because it already belongs to the packet equation. Subtracting q from pressure corresponds to subtracting qI from stress.

Holder uses the actual old u in L3 and the new packet/corrector in L^{3/2}; it does not differentiate or time-freeze u. The asymptotic exponents are \(8/3\) for the packet, \(5\) for corrector L2 and curl L1, and \(16/3\) for corrector L^{3/2}. Every cross error vanishes at fixed coarse data.

Convolving the **new equation** adds the commutator \(v_\ell\otimes v_\ell-(v\otimes v)_\ell\) with the stated positive sign. Compactness of the finite-cycle L2 curve makes its L1 norm uniformly small. The average tensor is convolved too, and its additional L1 error tends to zero. The old seed is not convolved. The radius minimum is positive only after the finite cycles are fixed, exactly as required for this parameter choice.

### Local repair, gluing, initial anchors and global limit: S0261–S0418

The local prescribed stress is approximated on **one-sided** closed continuity cells; the actual isolated boundary values are not forced to match either side. Each frozen tensor can be approximated by a compact smooth symmetric tensor. With finitely many cells, parameters are chosen in this order: coarse error, regularization/floor mass, finite sufficiently large cycle counts, then fixed sufficiently small convolution scales. This simultaneously attains the stress, amplitude, subcritical and radius budgets. Constants depending on support or derivatives affect the required fine scales but do not multiply the universal leading \(\sqrt\delta\) increment bound.

At interiors, \(E_{\rm total}=S-S_k+E_k^{\rm loc}\) gives the exact desired algebra. At inherited, coarse and cycle boundaries the actual error is set to zero. These finite-time changes do not alter the spacetime distribution. Velocity traces vanish at paste endpoints, so their time derivatives have no jump deltas; stress jumps are harmless because only spatial divergence acts on them. Continuity of all stress terms follows from L1 continuity of zero-moment inputs under the bounded antidivergence on a common ball, L2 product estimates, and the old-new L3/L^{3/2} estimate. Fixed convolution transfers packet L2 continuity to L3 using \(\|\rho_\ell\|_{6/5}=C\ell^{-1/3}\).

The anchor lemma is substantive and was independently reconstructed. Compact divergence-free pairings have uniformly bounded derivatives by the local energy and stress bounds. Their continuous representatives are Lipschitz down to zero and their zero anchor sequence forces zero limit. Any weak L2 cluster point of the correction is divergence free and annihilates all such tests; using perpendicular gradients also gives zero curl. At nonzero frequency it must be both parallel and perpendicular to xi, and an L2 Fourier transform cannot be supported on the remaining singleton. Every cluster point is therefore zero.

For the global stage, same-color intervals are disjoint: their successive endpoints are \(2\cdot2^j\) and \(4\cdot2^j\), with gap time \(3\cdot2^j\). The supports of the prescribed pieces are compact inside their patches. The pieces are frozen **before** any color operation, and LER allows removing a prescribed piece independently of the current stress. This is the reason the exact cancellation \(R^{(q+1)}=\sum_jE_{qj}\) remains valid after the three colors.

The active-patch bound and \(m_j\le\Theta(t)\) give the stated stress contraction. If an active patch meets \((0,T]\), its whole interval lies in \((0,4T)\). Consequently its prescribed norm is at most \(\delta_q\Theta(4T)\), and summing at most N repair bounds yields the displayed global increment bound. Its square-root factor is \(4^{-q}\), with total sum 4/3. Intermediate color stages have the stated bounded stresses and local energies, so every anchor-lemma hypothesis is actually met.

Uniform convergence of the global L2 correction series gives a single positive-time velocity. Its weak zero-time trace follows by splitting off a uniformly small tail, not by claiming strong convergence at zero. At every positive time the curl series converges absolutely in L1 and is the distributional curl of the L2 velocity limit. Adding the given finite initial measure gives the uniform variation bound including zero. Local strong L2 convergence passes the quadratic Euler term in L1; stress contraction removes the residual. The cutoff derivative at zero has integral one, and weak local continuity supplies exactly the positive initial pairing. The omitted convection interval has size O(epsilon), and replacing the test by its zero-time value costs O(epsilon).

Finally, for the canonical normalization, div and curl of \(h=u-K*\mu\) vanish. A direct mollification/mean-value proof of the Weyl step supplies an entire harmonic representative. Averaging over radius R gives contributions from the C0 background tending to zero, the L2 remainder of order \(R^{-1}\), and the finite-measure Biot–Savart field of order \(R^{-1}\). Thus h=0. At each positive time the chosen background is the fixed V0 and the remaining terms are all in global L2; at zero the identity is prescribed. This proves the every-time normalization, with no restart or finite-horizon compatibility assumption.

## Theorem use and computation record

All 22 inventoried theorem-application parents have explicit hypothesis/conclusion records in `pass_b.json`. For elementary tools, the conditions were checked directly: nonnegative integrands for Tonelli, absolute integrability for Fubini, matching Holder/Young exponents, uniform dominating functions, compact images for uniform approximation of identity, regular ODE coefficients away from zero, and global L2 boundedness for weak compactness. The Osgood, weak compactness and harmonic-distribution steps were additionally reconstructed in the arguments above. The only specialized existence theorem invoked externally is the primary source matched above.

Exact computation used Python `fractions.Fraction` with no rounding for the Bessel partial sums:

| Input | Exact result | Role |
|---|---:|---|
| J1 series at z=3, k=0 through 3 | 669/2048 | Positive lower bound |
| J1 series at z=4, k=0 through 4 | -2/45 | Negative upper bound |

SymPy import was attempted in the shell Python and the primary-runtime Python; it was unavailable in both. No successful symbolic-software computation, numerical experiment, proof-assistant verification, or unperformed external check is claimed. The tensor, normalization, pressure and exponent calculations above were performed algebraically by hand.

## Findings, edge cases and dependency consequences

No definite mathematical error, unsupported specialized invocation, unresolved ambiguity or missing substantive deduction was identified in this pass. Positive length, radius, scale and level-threshold conventions were checked where inverse operations occur. The zero datum, zero prescribed stress, zero coefficient directions, positive floors tending small only before fixing fine scales, noncompact measures, nonzero circulation, potentially infinite global energy, negative entries of a signed stress, interface matching, scan resets, cycle/coarse/inherited boundaries, and the distinction between positive time and t=0 were all considered. No failed estimate was repaired by silently imposing a sign or compact-support condition on the initial measure.

The proof's dependency chain, with all entries VERIFIED in this pass, is:

| Major result | Statement IDs | Principal dependencies |
|---|---|---|
| Initial decomposition | S0034–S0039 | S0032–S0033, S0040–S0052 |
| Bounded background | S0060–S0061 | S0034–S0039, primary input S0054–S0058, S0062–S0090 |
| Initial seed | S0096–S0100 | Background, decomposition, S0101–S0114 |
| Prescribed-piece local repair | S0261–S0275 | S0122–S0260, S0276–S0349 |
| Zero trace from anchors | S0351–S0353 | S0354–S0360 |
| Global iteration | S0361 | Seed, local repair, anchors, S0362–S0406 |
| Canonical normalization | S0407–S0408 | Kernel identities and S0409–S0413 |
| Global existence | S0414 | S0361, S0407–S0408, S0415–S0418 |

In particular the local repair is proved here as a construction, not treated as an external endpoint theorem. The final existence statement depends on it critically. There is no earlier-error propagation to list because this pass found no earlier error. Any disagreement from another pass remains for the coordinator to reconcile from the unchanged source; this pass has not seen those verdicts.

## Full source-ordered PASS B container ledger

Each row's source anchor and digest are the exact frozen entries in `audit_inventory.json`; `pass_b.json` repeats the parent digest under `source_sha256`, every child focus, formula mapping and verdict. The following table contains all 419 parent rationales without omitting routine or formatting material.

| ID | Source lines | Status | Independent rationale |
|---|---:|---|---|
| S0001 | 1–1 | NOT MATHEMATICAL | This is document formatting, an environment declaration, a title/heading, or an audit-status notice; it asserts no mathematical fact and all source bytes remain represented. |
| S0002 | 2–2 | NOT MATHEMATICAL | This is document formatting, an environment declaration, a title/heading, or an audit-status notice; it asserts no mathematical fact and all source bytes remain represented. |
| S0003 | 3–3 | NOT MATHEMATICAL | This is document formatting, an environment declaration, a title/heading, or an audit-status notice; it asserts no mathematical fact and all source bytes remain represented. |
| S0004 | 4–4 | NOT MATHEMATICAL | This is document formatting, an environment declaration, a title/heading, or an audit-status notice; it asserts no mathematical fact and all source bytes remain represented. |
| S0005 | 5–5 | NOT MATHEMATICAL | This is document formatting, an environment declaration, a title/heading, or an audit-status notice; it asserts no mathematical fact and all source bytes remain represented. |
| S0006 | 6–6 | NOT MATHEMATICAL | This is document formatting, an environment declaration, a title/heading, or an audit-status notice; it asserts no mathematical fact and all source bytes remain represented. |
| S0007 | 7–7 | NOT MATHEMATICAL | This is document formatting, an environment declaration, a title/heading, or an audit-status notice; it asserts no mathematical fact and all source bytes remain represented. |
| S0008 | 8–8 | NOT MATHEMATICAL | This is document formatting, an environment declaration, a title/heading, or an audit-status notice; it asserts no mathematical fact and all source bytes remain represented. |
| S0009 | 9–9 | NOT MATHEMATICAL | This is document formatting, an environment declaration, a title/heading, or an audit-status notice; it asserts no mathematical fact and all source bytes remain represented. |
| S0010 | 10–10 | NOT MATHEMATICAL | This is document formatting, an environment declaration, a title/heading, or an audit-status notice; it asserts no mathematical fact and all source bytes remain represented. |
| S0011 | 11–11 | VERIFIED | Macro expands to the real-number symbol used for the plane; no conflicting expansion occurs. |
| S0012 | 12–12 | VERIFIED | Macro expands to the finite-measure space named in the target; the later norm consistently denotes total variation. |
| S0013 | 13–13 | VERIFIED | The operator name agrees with scalar planar curl partial_1 u_2-partial_2 u_1 throughout. |
| S0014 | 14–14 | VERIFIED | The operator name is later defined componentwise on matrices, consistently with row-wise divergence. |
| S0015 | 15–15 | VERIFIED | Support notation is a conventional operator macro and introduces no operation beyond support. |
| S0016 | 16–16 | VERIFIED | Two-argument norm macro retains both expression and subscript; single-token arguments 1,2,3 and infinity expand as intended. |
| S0017 | 17–17 | VERIFIED | The differential macro expands to dx, consistently with spatial integration; time integrals add dt separately. |
| S0018 | 18–18 | NOT MATHEMATICAL | This is document formatting, an environment declaration, a title/heading, or an audit-status notice; it asserts no mathematical fact and all source bytes remain represented. |
| S0019 | 19–19 | NOT MATHEMATICAL | This is document formatting, an environment declaration, a title/heading, or an audit-status notice; it asserts no mathematical fact and all source bytes remain represented. |
| S0020 | 20–20 | NOT MATHEMATICAL | This is document formatting, an environment declaration, a title/heading, or an audit-status notice; it asserts no mathematical fact and all source bytes remain represented. |
| S0021 | 21–21 | NOT MATHEMATICAL | This is document formatting, an environment declaration, a title/heading, or an audit-status notice; it asserts no mathematical fact and all source bytes remain represented. |
| S0022 | 22–22 | NOT MATHEMATICAL | This is document formatting, an environment declaration, a title/heading, or an audit-status notice; it asserts no mathematical fact and all source bytes remain represented. |
| S0023 | 23–24 | NOT MATHEMATICAL | This is document formatting, an environment declaration, a title/heading, or an audit-status notice; it asserts no mathematical fact and all source bytes remain represented. |
| S0024 | 24–26 | NOT MATHEMATICAL | This is document formatting, an environment declaration, a title/heading, or an audit-status notice; it asserts no mathematical fact and all source bytes remain represented. |
| S0025 | 26–28 | NOT MATHEMATICAL | This is document formatting, an environment declaration, a title/heading, or an audit-status notice; it asserts no mathematical fact and all source bytes remain represented. |
| S0026 | 29–29 | VERIFIED | The displayed vector is perpendicular to x, has size 1/(2 pi \|x\|), and has positive unit circulation. |
| S0027 | 29–31 | VERIFIED | These are the exact signed finite-measure and inhomogeneous H^{-1} hypotheses; the convolution is legitimized by the decomposition proved below, without requiring zero circulation. |
| S0028 | 31–41 | VERIFIED | Read as the requested target, these quantifiers and function spaces match the supplied problem, including every time and weak local L2 continuity; they are not assumed as a premise. |
| S0029 | 41–48 | VERIFIED | Integration by parts in time and row-wise divergence gives the displayed plus initial term; divergence-free compact tests remove pressure and agree with the target. |
| S0030 | 48–50 | VERIFIED | Inspection of the subsequent estimates uses finite measure and inhomogeneous H^{-1}, with a bounded background carrying nonzero circulation; no listed additional assumption is inserted. |
| S0031 | 50–52 | NOT MATHEMATICAL | This is document formatting, an environment declaration, a title/heading, or an audit-status notice; it asserts no mathematical fact and all source bytes remain represented. |
| S0032 | 53–56 | VERIFIED | The four conventions give curl(grad-perp psi)=Delta psi and Div(v tensor w)_i=partial_j(v_i w_j); the Fourier derivative multiplier is i xi_j. |
| S0033 | 56–57 | VERIFIED | K=grad-perp G and Delta G=delta with G=log\|x\|/(2 pi), so multiplying -\|xi\|^{-2} by i xi-perp gives exactly -i xi-perp/\|xi\|^2. |
| S0034 | 57–60 | VERIFIED | The lemma's hypotheses and M definition repeat the finite signed-measure and inhomogeneous H^{-1} assumptions; no positivity is used. |
| S0035 | 60–62 | VERIFIED | Tonelli gives local L1 and a.e. definition; the physical decomposition yields local L2, and differentiating K distributionally gives div zero and curl mu. |
| S0036 | 62–63 | VERIFIED | A nonnegative radial smooth probability function supported in an arbitrary sufficiently large ball exists by normalizing a radial bump; its first moments vanish. |
| S0037 | 63–67 | VERIFIED | Finite-measure convolution defines nu0, sigma0, V0 and v0 as distributions and locally integrable functions; subtraction is linear and each type agrees with later estimates. |
| S0038 | 67–74 | VERIFIED | Radial circulation makes K-K*a integrable and compactly supported; its high-pass multiplier is bounded from H^{-1} to L2. Fourier inversion makes V0 smooth and vanishing at infinity. Convolution with a probability gives M and 2M bounds. |
| S0039 | 74–77 | VERIFIED | For nu0 use D^alpha a in L1 and Linfinity against finite mu. For positive derivatives of V0 the multiplier xi^alpha m a-hat is both L1 and L2, multiplied by bounded mu-hat. |
| S0040 | 78–80 | VERIFIED | Splitting any translated ball into distance less than twice its radius and its complement bounds integral \|K\| by C radius. Tonelli applies to \|K(x-y)\| d\|mu\|(y) dx and proves finite local integrals. |
| S0041 | 80–81 | VERIFIED | Integration on circles gives div K=0 and curl K=delta; the Fourier multiplier in S0033 then carries both distributional identities through convolution. |
| S0042 | 81–83 | VERIFIED | The variation of mu restricted to \|x\|>R tends to zero; the uniform translated-ball estimate controls the convolution locally, permitting distributional passage of curl and divergence. |
| S0043 | 83–85 | VERIFIED | The multiplier is O(\|xi\|^{-1}) at zero, integrable in two dimensions, and has at most polynomial growth at infinity. The uniform Fourier error is bounded by the tail variation, so dominated testing against Schwartz functions applies. |
| S0044 | 85–90 | VERIFIED | Radial symmetry forces a tangential velocity; Stokes circulation around radius r is the mass of a inside that radius, yielding exactly K(x) times that mass. |
| S0045 | 90–92 | VERIFIED | Outside the support radius the enclosed mass is one; inside, K*a is bounded and K has integrable inverse-radius singularity. Thus the difference has the stated support and local behavior. |
| S0046 | 92–93 | VERIFIED | Integrating \|L_a(x-y)\| against d\|mu\|(y) gives \|\|L_a*mu\|\|1 <= \|\|L_a\|\|1 M, proving the needed measure version of Young directly. |
| S0047 | 93–97 | VERIFIED | Use a-hat=integral cos(x dot xi)a(x)dx and \|1-cos z\|<=z^2/2 near zero; elsewhere use 2. Multiplication by \|m\|=\|xi\|^{-1} gives the displayed uniformly bounded weighted square. |
| S0048 | 97–98 | VERIFIED | The Fourier expression for v0 and the preceding multiplier bound yield integral \|v0-hat\|^2 <= C integral \|mu-hat\|^2/(1+\|xi\|^2); this is exactly the stated inhomogeneous norm. |
| S0049 | 98–100 | VERIFIED | Near zero, xi^alpha m has magnitude O(\|xi\|^{\|alpha\|-1}); at infinity a-hat is Schwartz. L1 holds also for alpha=0; L2 holds for \|alpha\|>=1 and is not asserted for the zeroth multiplier. |
| S0050 | 100–101 | VERIFIED | The bounded mu-hat times each integrable derivative multiplier permits differentiation and Fourier inversion, yielding continuous derivatives vanishing at infinity; square-integrable positive derivative multipliers give L2 derivatives. |
| S0051 | 101–102 | VERIFIED | Fubini is justified by the bounded translated local kernel integral and finite measure mass. Probability convolution gives \|\|nu0\|\|1<=M, and the variation triangle inequality gives \|\|sigma0\|\|M<=2M. |
| S0052 | 102–104 | VERIFIED | The distributional decomposition has locally L2 right side, because V0 is bounded and v0 globally L2; it therefore identifies the a.e. convolution with that local L2 function. |
| S0053 | 105–106 | NOT MATHEMATICAL | This is document formatting, an environment declaration, a title/heading, or an audit-status notice; it asserts no mathematical fact and all source bytes remain represented. |
| S0054 | 107–110 | VERIFIED | The named article, theorem number, assumptions, definition, year, volume and article number were checked on the primary publisher page; the theorem matching is recorded in the report. |
| S0055 | 110–114 | VERIFIED | Primary Theorem 3.3 supplies a global Lagrangian weak solution for signed L1 and Linfinity data, canonical velocity and the stated bounds and log-Lipschitz modulus. In this divergence-free specialization the flow is measure preserving, so the L1 norm is in fact constant. |
| S0056 | 114–116 | VERIFIED | Primary Definition 3.2 contains the initial-value weak vorticity identity and the pushforward representation for almost every time; the manuscript correctly separates that from its every-time representative construction. |
| S0057 | 116–116 | VERIFIED | The primary hypotheses on the whole plane are L1 and Linfinity vorticity and kernel conditions; neither compact support nor global L2 velocity appears. |
| S0058 | 116–118 | VERIFIED | Inversion x->x/\|x\|^2 satisfies the exact distance identity by squaring both sides. Rotation preserves length. Distributional div K=0 verifies the divergence condition and the plane has no boundary condition. |
| S0059 | 118–119 | VERIFIED | The cited input is used for existence, bounds and Lagrangian representation only; the subsequent proof explicitly derives every additional regularity property it needs. |
| S0060 | 119–129 | VERIFIED | The norm statements follow from the measure-preserving transported representative, near/far velocity estimate, weak-L2 layer cake, and the bounded Fourier operator applied to the time integral of V nu. Pressure follows from the curl-free acceleration argument below. |
| S0061 | 129–132 | VERIFIED | The operator -K*Div has Fourier operator norm one; integrating \|\|V nu\|\|2 <= \|\|V\|\|infinity \|\|nu0\|\|2 over [0,t] proves the coefficient-one estimate. |
| S0062 | 133–134 | VERIFIED | nu0=a*mu belongs to L1 and Linfinity by S0039. The plane kernel satisfies both primary assumptions in S0058, so Theorem 3.3 is applicable with p=infinity and no support or energy restriction. |
| S0063 | 134–135 | VERIFIED | All subsequent requirements are obtained from bounded vorticity, norm-preserving transport, and Fourier estimates; no differentiable-background existence claim is used. |
| S0064 | 135–136 | VERIFIED | Choosing the canonical continuous representative is a permissible modification at a null set of times, with the actual construction specified in S0065-S0076. |
| S0065 | 136–139 | VERIFIED | The reciprocal integral of r(1-log r) diverges at zero. The Osgood differential inequality gives uniqueness and stability, applied also to the reversed-time field for the inverse flow. Bounded velocity gives displacement at most T times its bound. |
| S0066 | 139–139 | VERIFIED | Convolving with a smooth probability kernel preserves divergence zero and approximates the bounded uniformly log-Lipschitz field uniformly in space, essentially uniformly in time on a finite horizon. |
| S0067 | 139–141 | VERIFIED | The spatially smooth field has bounded spatial derivatives after mollification, so its flow is differentiable in initial position. The determinant solves J'=div V_l(X_l)J=0, J(0)=1, proving preservation of Lebesgue measure. |
| S0068 | 141–143 | VERIFIED | For the difference of two flows use displacement bound e(t)<=T\|\|V_l-V\|\|infinity+integral omega(e(s))ds; Osgood stability makes e tend uniformly to zero. The backward ODE gives the identical inverse-flow conclusion. |
| S0069 | 143–145 | VERIFIED | A compact test transported by a flow of displacement at most C_T remains within a fixed compact set; its integrand is bounded there. Dominated convergence transfers the mollified change-of-variables identity. |
| S0070 | 145–147 | VERIFIED | The unique homeomorphic flow has an inverse for every time; composing the measurable nu0 with it defines the representative without changing its a.e. spatial class. |
| S0071 | 147–149 | VERIFIED | The primary pushforward and measure preservation identify this composition with the original solution a.e. in time. Changing variables preserves each of its L1, L2 and Linfinity norms. |
| S0072 | 149–151 | VERIFIED | Approximate nu0 by compact smooth functions in L1 or L2. Composition is an isometry, and bounded displacement plus continuous inverse flow gives convergence for the smooth approximants by dominated convergence; the three-term approximation proves norm continuity. |
| S0073 | 151–151 | VERIFIED | The near/far kernel estimate makes K*nu defined and bounded for every time; this definition fixes the canonical normalization, including t=0. |
| S0074 | 151–153 | VERIFIED | Changing a time-dependent function on a time-null set leaves its spacetime distribution unchanged, so the source equation survives the representative choice. |
| S0075 | 153–156 | VERIFIED | The near kernel integrates to r and the far kernel is at most 1/(2 pi r). The difference has uniformly bounded Linfinity norm and L1 norm tending to zero; choosing r and then the time difference proves Linfinity continuity. |
| S0076 | 156–157 | VERIFIED | At zero the composition is nu0, giving V0; Linfinity continuity implies continuous pairings with compactly supported velocity tests and local L2 continuity. |
| S0077 | 157–163 | VERIFIED | Split the convolution into \|z\|<r, whose kernel integral equals r, and \|z\|>=r, whose supremum is 1/(2 pi r); applying this to \|nu\| yields the stated bound. |
| S0078 | 163–164 | VERIFIED | Bounded V multiplies nu in L1 and L2, both uniformly preserved on finite horizons; hence the products satisfy both stated integrability bounds. |
| S0079 | 164–169 | VERIFIED | For positive lambda and nonzero mass the near/far split and Chebyshev give measure <=C M^2/lambda^2. If M=0 the convolution is zero and the assertion holds directly. |
| S0080 | 169–172 | VERIFIED | At r=M/(pi lambda), the far supremum is M/(2 pi r)=lambda/2. The near convolution L1 norm is at most rM, giving the two estimates; the zero-mass case is handled directly before choosing r. |
| S0081 | 172–172 | VERIFIED | Since a level set of the sum at lambda lies in the near-part level set at lambda/2, Markov's inequality bounds it by 2\|\|near\|\|1/lambda <=C M^2/lambda^2. |
| S0082 | 172–173 | VERIFIED | Layer cake gives \|\|V\|\|3^3=3 integral_0^B lambda^2 measure{\|V\|>lambda}d lambda <= C\|\|nu\|\|1^2 B; the upper integration endpoint is the Linfinity bound. |
| S0083 | 173–178 | VERIFIED | The weak vorticity equation integrates to nu(t)-nu0=-Div F_t for all times by continuity; Bochner integrability follows from V bounded, nu in continuous L1 and L2, and finite horizon. |
| S0084 | 178–180 | VERIFIED | The Fourier matrix of -K*Div is a signed rank-one matrix xi-perp tensor xi/\|xi\|^2, of norm one. Applying it to F_t gives V(t)-V0 distributionally and in L2, with the claimed bound and continuity. |
| S0085 | 180–181 | VERIFIED | The same bounded multiplier applied instantaneously to V nu controls partial_t V in L2; multipliers i xi_j m control grad V in L2 using nu in L2. |
| S0086 | 181–182 | VERIFIED | Replacing [0,t] by [s,t] in the Bochner integral yields \|\|V(t)-V(s)\|\|2 <= \|\|V\|\|infinity \|\|nu0\|\|2 \|t-s\| on each finite horizon. |
| S0087 | 182–184 | VERIFIED | For f=V(t)-V(s), \|\|f\|\|infinity<=2B_T and integral \|f\|^3<=\|\|f\|\|infinity integral \|f\|^2, giving the exact stated inequality. |
| S0088 | 184–185 | VERIFIED | Each V(t) is in L3 by layer cake, and the preceding difference bound tends to zero with t-s; hence the map is continuous into global L3. |
| S0089 | 185–187 | VERIFIED | The two acceleration terms are L2 because V is bounded and grad V,partial_t V are L2. The identity curl((V dot grad)V)=Div(V nu) follows by smoothing and local Sobolev convergence; transport cancels this with partial_t nu. A curl-free distribution on the simply connected plane is a gradient. |
| S0090 | 187–189 | VERIFIED | Taking p_V to be the negative potential of the preceding acceleration gives the velocity Euler equation without ever requiring V itself to be in global L2. |
| S0091 | 190–191 | NOT MATHEMATICAL | This is document formatting, an environment declaration, a title/heading, or an audit-status notice; it asserts no mathematical fact and all source bytes remain represented. |
| S0092 | 192–198 | VERIFIED | This fixes the sign convention, row-wise divergence and symmetric stress; all later packet and cross-stress signs were checked against this equality. |
| S0093 | 198–199 | VERIFIED | Inverse Fourier transform of exp(-\|xi\|^4) is defined in the Schwartz class, and the dilation t^-2 b(x/t) has Fourier transform exp(-t^4\|xi\|^4) for positive t. |
| S0094 | 199–200 | VERIFIED | The frequency function is real, radial, even and Schwartz, so its inverse is real radial Schwartz. Integral b equals its Fourier transform at zero, namely one; none of the bounds use positivity. |
| S0095 | 200–200 | VERIFIED | C_b denotes the finite L1 norm of this Schwartz function, retaining the needed total-variation constant for a possibly signed kernel. |
| S0096 | 200–210 | VERIFIED | All four definitions are well typed: W is global L1 and L2 for t>0, V bounded, and the symmetric derivative tensor has finite L1 norm. Direct substitution gives the seed stress with the negative time-derivative coefficient. |
| S0097 | 210–211 | VERIFIED | partial_t W=-4t^3 Delta^2 W, and the divergence of the symmetrized gradient-Delta tensor is Delta^2 W; expansion of the square cancels all seed terms in the stated Euler-Reynolds equation. |
| S0098 | 211–217 | VERIFIED | Plancherel contraction gives the first estimate; measure convolution and norm-preserving nu give the second; quadratic and cross terms cost \|\|v0\|\|2^2 and 2 C_b\|\|V\|\|infinity\|\|v0\|\|1, while second-kernel-derivative scaling gives Ct\|\|sigma0\|\|M. |
| S0099 | 217–219 | VERIFIED | V(t)-V0 tends to zero globally in L2 and W(t) tends to v0 in L2, so their sum has strong local L2 initial trace. Fourier convolution gives curl W=b_t*sigma0 and W=K*(b_t*sigma0), with the canonical background added. |
| S0100 | 219–222 | VERIFIED | On any compact interval away from zero, kernel dilation and derivatives depend continuously in all required norms. Product estimates then give continuous L1 stress and L3 velocity, as well as strong local L2 velocity continuity. |
| S0101 | 223–225 | VERIFIED | Fourier dilation yields exp(-t^4\|xi\|^4); differentiating it gives -4t^3\|xi\|^4 exp(-t^4\|xi\|^4), the multiplier of the asserted fourth-order heat equation. |
| S0102 | 225–226 | VERIFIED | Convolution preserves Div W=0. Component expansion gives Div(grad Delta W)=Delta^2 W and Div((grad Delta W)^T)=grad Delta Div W=0. |
| S0103 | 226–227 | VERIFIED | Subtract the background equation from the proposed seed equation; the remaining three quadratic tensors occur once on each side and partial_t W equals the divergence of the displayed derivative stress. |
| S0104 | 227–228 | VERIFIED | The Fourier multiplier lies in [0,1] and tends pointwise to one. Plancherel gives contraction and dominated convergence against \|v0-hat\|^2 gives strong L2 convergence. |
| S0105 | 228–229 | VERIFIED | Spatial distributional derivatives commute with Schwartz convolution, giving curl W=b_t*sigma0. Integrating against variation bounds its L1 norm by C_b\|\|sigma0\|\|M. |
| S0106 | 229–230 | VERIFIED | Integrating the absolute convolution of b_t and v0 gives \|\|W\|\|1 <=\|\|b_t\|\|1\|\|v0\|\|1=C_b\|\|v0\|\|1. |
| S0107 | 230–235 | VERIFIED | For divergence-free W the vector identity Delta W=grad-perp curl W has the displayed positive sign. Differentiating twice the kernel and scaling D^2 b_t gives t^-2 in L1, proving both transitions. |
| S0108 | 235–237 | VERIFIED | Multiplying the previous derivative bound by 4t^3 leaves Ct. The other terms are controlled by the L2 product and bounded-background times L1-W estimates, with transpose contributing the factor two. |
| S0109 | 237–237 | VERIFIED | The background lemma gives V(t)-V0->0 in L2; combining with W(t)->v0 and V0+v0=u0 proves the seed trace. |
| S0110 | 237–239 | VERIFIED | K convolved with b_t*sigma0 has Fourier expression m exp(-t^4\|xi\|^4)(1-a-hat)mu-hat, identical to W. Distributional testing is justified by Schwartz decay and the finite-measure local kernel bound. |
| S0111 | 239–241 | VERIFIED | Away from zero, b_t varies continuously in L1 and Linfinity, and convolution with v0 in L1 and L2 gives the stated three norm continuities. Interpolation supplies L^{3/2} and L3 continuity. |
| S0112 | 241–242 | VERIFIED | The derivative stress is a scalar t^3 times a fixed second-derivative convolution against sigma0; its L1 continuity follows from L1 continuity of the dilated kernel derivatives. |
| S0113 | 242–244 | VERIFIED | For W squares use \|\|f tensor f-g tensor g\|\|1 <=(\|\|f\|\|2+\|\|g\|\|2)\|\|f-g\|\|2. For each mixed product use the L3 and L^{3/2} Holder inequality; the transpose has the identical norm. |
| S0114 | 244–246 | VERIFIED | S0111-S0113 prove all three claimed continuous norms using norm continuity, with no time derivative of V required. |
| S0115 | 247–250 | VERIFIED | This states a construction requirement fulfilled later. With V only globally L3, small L^{3/2} increments provide the Holder-dual control for global L1 stress. |
| S0116 | 250–252 | VERIFIED | Pointwise \|V tensor w\|=\|V\|\|w\|, and 1/3+2/3=1 gives the displayed global Holder bound. |
| S0117 | 252–254 | VERIFIED | For the tail swirl f(r)=1/(r log r), L2 reduces to integral dr/(r log^2 r)<infinity; curl=(rf)'/r=-1/(r^2 log^2 r), with finite L1 tail. The L^{3/2} integral is integral r^{-1/2}(log r)^{-3/2}dr and diverges. A smooth core extension adds only finite norms. |
| S0118 | 254–256 | VERIFIED | Multiplying the two tail magnitudes and the polar Jacobian leaves a positive constant times integral dr/(r log r), which diverges. A smooth radial unit-circulation vorticity produces the specified background outside its support. |
| S0119 | 256–258 | VERIFIED | Every nonzero scalar multiple multiplies the nonnegative divergent integral by its absolute value; taking that scalar small cannot make it finite. |
| S0120 | 259–260 | NOT MATHEMATICAL | This is document formatting, an environment declaration, a title/heading, or an audit-status notice; it asserts no mathematical fact and all source bytes remain represented. |
| S0121 | 261–262 | NOT MATHEMATICAL | This is document formatting, an environment declaration, a title/heading, or an audit-status notice; it asserts no mathematical fact and all source bytes remain represented. |
| S0122 | 263–265 | VERIFIED | For integer n, J_n(z)=sum_k (-1)^k(z/2)^{2k+n}/(k!(k+n)!) converges with all derivatives on compact sets. Coefficient substitution gives the Bessel equation and differentiating the n=1 series gives the stated recurrence. |
| S0123 | 265–266 | VERIFIED | The exact rational lower and upper partial-sum bounds in S0124 have opposite signs, and the power series is continuous, proving a zero in the open interval (3,4). |
| S0124 | 266–269 | VERIFIED | Exact rational summation independently gives J1's k=0..3 partial sum at 3 as 669/2048=(3/2)(223/1024), and its k=0..4 sum at 4 as -2/45. Alternating remainder signs produce the displayed inequalities and strict signs. |
| S0125 | 269–270 | VERIFIED | The absolute successive term ratio is (z/2)^2/((k+1)(k+2)); after each displayed truncation this is below one and decreases, proving the alternating-tail bounds. |
| S0126 | 270–271 | VERIFIED | Continuity on [3,4] follows from uniform series convergence there; opposite strict endpoint signs satisfy the intermediate value theorem and place the zero strictly inside. |
| S0127 | 271–272 | VERIFIED | At a zero of J1, the identity J1'=J0-J1/z gives J1'(beta)=J0(beta), so simultaneous vanishing of J0 forces zero derivative as claimed. |
| S0128 | 272–274 | VERIFIED | On every interval bounded away from zero the Bessel ODE has continuous coefficients and the zero Cauchy data have a unique solution, by the linear integral equation and Gronwall. Propagation along (0,infinity) contradicts the nonzero leading term z/2. |
| S0129 | 274–275 | VERIFIED | The contradiction rules out J0(beta)=0, so every denominator in the dipole formula is nonzero. |
| S0130 | 275–285 | VERIFIED | Both branches give -sin(theta) at radius one. Near the origin J1(beta rho)sin(theta) is x2 times a convergent series in \|x\|^2, so the polar expression extends smoothly there. The stream function and its perpendicular gradient are therefore well-defined with the stated branch domains. |
| S0131 | 285–287 | VERIFIED | grad-perp x2=-e1 gives D-e1=grad-perp q. The angular-mode Bessel ODE gives Delta q=-beta^2 q in the disk, while Delta(-sin(theta)/rho)=0 outside; curl D=Delta psi. |
| S0132 | 287–289 | VERIFIED | At rho=1 the Bessel term vanishes. The interior radial derivative is -sin(theta)+2 J1'(beta)sin(theta)/J0(beta)=sin(theta), equal to the exterior derivative; tangential traces also agree. |
| S0133 | 289–291 | VERIFIED | The ODE at J1(beta)=0 gives beta^2 J1''+beta J1'=0. Thus the interior second radial derivative is -2 sin(theta), equal to differentiating -sin(theta)/rho twice at one. |
| S0134 | 291–293 | VERIFIED | Differentiating the common value and common radial-derivative traces tangentially gives the remaining Hessian traces. Since the interface is away from the polar origin, Cartesian Hessians agree, making D continuously differentiable across it. |
| S0135 | 293–295 | VERIFIED | q has zero trace at rho=1 and curl D=-beta^2 q there, with zero exterior curl. Inside, grad-perp q dot grad q=0. Integration by parts across the circle has no jump of curl, proving the distributional transport assertion. |
| S0136 | 295–299 | VERIFIED | Set w=D-e1=grad-perp q. Then w-perp=-grad q and curl w=-beta^2 q, so (w dot grad)w=grad(\|w\|^2/2+beta^2 q^2/2) inside. Outside the beta term vanishes. The stated negative pressure cancels this acceleration exactly. |
| S0137 | 299–301 | VERIFIED | Component expansion gives (w dot grad)w-grad(\|w\|^2/2)=curl(w)(-w2,w1). The fields and relevant pressure traces match, and q vanishes at the interface, so distributional first derivatives add no boundary measure. |
| S0138 | 301–302 | VERIFIED | Differentiating -x1/\|x\|^2 gives ((x1^2-x2^2),2x1x2)/\|x\|^4, identical to grad-perp(-x2/\|x\|^2). The stream function is odd under inversion, so D is even in both regions. |
| S0139 | 302–304 | VERIFIED | Proper planar rotation sends e1 to any unit xi and preserves divergence and tensor equations. Scaling velocity by r^-1 and pressure by r^-2 makes every equation term scale as r^-3; translations later retain the rotated profiles consistently. |
| S0140 | 304–305 | VERIFIED | The suppressed direction refers to the fixed rotation just defined; each use occurs within a specified direction slot and introduces no change of profile. |
| S0141 | 305–314 | VERIFIED | The translating equation scales by r^-3, and divergence remains zero. Change of variables gives \|\|D_r\|\|p=r^{2/p-1}\|\|D\|\|p and \|\|grad D_r\|\|1=\|\|grad D\|\|1, hence all four displayed norm scalings and the curl scaling. |
| S0142 | 314–316 | VERIFIED | D and grad D are bounded in the core; outside, D=O(rho^-2) and grad D=O(rho^-3). These are integrable in each claimed norm, and the harmonic exterior has zero curl. |
| S0143 | 316–318 | NOT MATHEMATICAL | This is document formatting, an environment declaration, a title/heading, or an audit-status notice; it asserts no mathematical fact and all source bytes remain represented. |
| S0144 | 319–327 | VERIFIED | For integrable compactly supported f with the stated finite moments, convolution with derivatives of log\|x\| defines the operator locally. The formula is a symmetric two-by-two tensor and its moment conditions are exactly those used for its global L1 estimate. |
| S0145 | 327–328 | VERIFIED | Interchanging i and j preserves the expression. Taking partial_j and summing produces partial_i Delta^{-1}Div f+f_i-partial_i Delta^{-1}Div f=f_i. |
| S0146 | 328–328 | VERIFIED | Each kernel term is a first derivative of the two-dimensional logarithmic fundamental solution and is homogeneous of degree -1. |
| S0147 | 328–329 | VERIFIED | For y in B_R and x in B_3R, the difference x-y lies in B_4R; integral of \|x-y\|^-1 over that ball is C R. Fubini gives the local bound. |
| S0148 | 329–331 | VERIFIED | Taylor expansion of the degree -1 kernel at x has second derivative O(\|x\|^-3) when \|y\|<=R and \|x\|>3R. Zeroth and first moment cancellation removes the first two terms, leaving C R^2 \|x\|^-3\|\|f\|\|1. |
| S0149 | 331–334 | VERIFIED | Integrating the far bound gives C R^2 integral_3R^infinity rho^-2 d rho=C R; adding the local estimate proves the full L1 inequality. |
| S0150 | 334–335 | VERIFIED | The inverse-Laplacian derivative kernels have nonzero tails in general; the moment cancellation improves decay but does not make those tails vanish identically. |
| S0151 | 335–336 | VERIFIED | With only zeroth moments removed, the leading Taylor derivative has degree -2 and a nonzero first-moment coefficient in general. Its absolute radial integral is integral dr/r, which diverges. |
| S0152 | 336–341 | VERIFIED | Direct differentiation gives partial_r D_r=-r^-2(D+y dot grad D), y=x/r. Expanding Div(D_r tensor x/r)=r^-2(2D+y dot grad D) proves the stated identity, including the extra r^-1 D_r term. |
| S0153 | 341–343 | VERIFIED | Euler's homogeneous identity gives 2D_r+x dot grad D_r=0 outside B_r. Inside f_r scales as r^-2 times a bounded fixed profile, so its L1 norm is constant. C1 matching prevents an interface distribution. |
| S0154 | 343–344 | VERIFIED | D_r is even; differentiating its odd product with x gives even f_r. Each x_j f_{r,i} is therefore odd and compactly supported, with integral zero. |
| S0155 | 344–346 | VERIFIED | The total flux is integral D_r (x dot n)/r on a circle. The exterior dipole angular components are proportional to cos(2theta),sin(2theta), whose means vanish; hence the vector mean of f_r is zero. |
| S0156 | 346–350 | VERIFIED | The anti-divergence gives Div(-A f_r)=-f_r and \|\|A f_r\|\|1<=C r\|\|f_r\|\|1<=Cr. Substituting into S0152 proves both assertions. |
| S0157 | 350–352 | NOT MATHEMATICAL | This is document formatting, an environment declaration, a title/heading, or an audit-status notice; it asserts no mathematical fact and all source bytes remain represented. |
| S0158 | 353–353 | VERIFIED | On each visit the C1 functions with strictly positive radius make the scaling and translation differentiable; nonnegative amplitude and X'=eta xi/r match the translating-dipole speed. T_X consistently means f(x-X). |
| S0159 | 353–359 | VERIFIED | Differentiate eta T_X D_r: amplitude and radial terms combine as (eta r)'T_X D_r/r+Div(eta r'T_X F_r). The motion contributes -eta^2 partial_xi D_r/r, which cancels the nonlinear and pressure terms by S0141. |
| S0160 | 359–366 | VERIFIED | A smooth radial cutoff with the two stated constant regions exists. Phi is odd and homogeneous -1 away from zero, but the zero cutoff removes its singularity. Pi_r is smooth near zero and Z_r is a well-defined localized remainder. |
| S0161 | 366–368 | VERIFIED | For r<1, r<=r^{1/5}; outside 2r^{1/5}, grad Pi_r= r grad Phi=D_r. Both vector terms are even. The core costs Cr, the annulus integral of r/rho^2 costs Cr\|log r\|, and the cutoff derivative contributes Cr. |
| S0162 | 368–370 | VERIFIED | For xi=e1, boundary integration of grad-perp psi gives pi r e1, while the gradient of -r x1/\|x\|^2 gives -pi r e1 through its scalar boundary values. Their difference is 2pi r e1; rotation gives the stated xi vector. |
| S0163 | 370–371 | VERIFIED | Division by r yields mean 2pi xi. Since Z_r is even and compactly supported, each first moment of Z_r/r vanishes by oddness. |
| S0164 | 371–373 | VERIFIED | Normalize a nonnegative radial smooth bump of compact support inside B1. The H^-2 dilation has mass one, retains radial symmetry and smoothness, and its support lies in B_H. |
| S0165 | 373–375 | VERIFIED | The support hypothesis puts both terms in B_H. Their means are both 2pi xi, and both even profiles have zero first moments, proving all cancellations. |
| S0166 | 375–378 | VERIFIED | The compact source has L1 norm <=C(1+\|log r\|) and support radius H; applying S0149 with the established zeroth and first moments gives exactly CH(1+\|log r\|). |
| S0167 | 378–388 | VERIFIED | Replace D_r/r by S_r+grad(Pi_r/r), absorbing the gradient in pressure. Split S_r into 2pi U_H xi plus a zero-moment remainder, represented by Div A. Translate both stresses by X; triangle inequality and S0156,S0166 give the stated bound with the correct coefficients. |
| S0168 | 388–389 | VERIFIED | Curl differentiates the dilated velocity once, and two-dimensional integration cancels r^-2. Translation changes no norm; multiplication by eta gives \|eta\|C_omega. |
| S0169 | 389–391 | NOT MATHEMATICAL | This is document formatting, an environment declaration, a title/heading, or an audit-status notice; it asserts no mathematical fact and all source bytes remain represented. |
| S0170 | 392–393 | NOT MATHEMATICAL | This is document formatting, an environment declaration, a title/heading, or an audit-status notice; it asserts no mathematical fact and all source bytes remain represented. |
| S0171 | 394–395 | VERIFIED | The four listed vectors are unit vectors; their rank-one symmetric tensors span the symmetric two-by-two tensors modulo an isotropic scalar, as verified by the coefficient expansion. |
| S0172 | 395–397 | VERIFIED | Compact support of S admits a larger smooth compact cutoff equal to one on a neighborhood. Nonnegativity is obtainable by a standard radial cutoff enclosing the compact set. |
| S0173 | 397–402 | VERIFIED | For gamma>0 the two nonnegative square roots are defined pointwise. They are strictly away from zero on the support of S because h=1 there; the second is the Euclidean norm of three components. |
| S0174 | 402–404 | VERIFIED | A neighborhood of the zero set of h is disjoint from supp S. There the roots equal gamma h, since h>=0; elsewhere their radicands are positive. These local formulas prove smoothness even at the zero set. |
| S0175 | 404–405 | VERIFIED | Each square root dominates the absolute value of every individual entry it contains. In particular B dominates both diagonal entries themselves, whether positive or negative. |
| S0176 | 405–411 | VERIFIED | Expanding the diagonal directions gives diagonal contributions (a3+a4)/2=A and off-diagonal contribution (a3-a4)/2=-S12. Adding a1,a2 gives q-S11,q-S22, exactly -S+qI. |
| S0177 | 411–413 | VERIFIED | Smoothness and compact support follow from S,h, and positivity from the root inequalities. Pointwise sum a_i=2A+2B-S11-S22 <=C\|S\|+C gamma h; integrating proves the bound. |
| S0178 | 413–414 | VERIFIED | With h already fixed and integrable, choosing gamma sufficiently small makes C gamma\|\|h\|\|1 as small as prescribed, independently of subsequent fine parameters. |
| S0179 | 414–415 | VERIFIED | Replacing an L1 tensor by a compact truncation changes it by its L1 tail; this is retained as part of the residual and is not silently removed from the stress equation. |
| S0180 | 415–418 | VERIFIED | A compact subset of L1 has uniformly small tails: cover by finitely many L1 balls, truncate each center beyond one common radius, and use the triangle inequality. Continuous images of compact time intervals are compact. |
| S0181 | 418–420 | VERIFIED | Rotate orthonormal coordinates so x=s xi+y xi-perp; a bounded rectangle can contain the compact coefficient support with longitudinal buffers outside it. |
| S0182 | 420–421 | VERIFIED | The symbol a here denotes the fixed nonnegative compact coefficient from the tensor decomposition; the earlier mollifier a is no longer used in this local calculation. |
| S0183 | 421–423 | VERIFIED | Adding a fixed positive e bounds c away from zero and makes log c and the radius formulas well-defined; where the compact original coefficient vanishes the buffered radius is constant. |
| S0184 | 423–425 | VERIFIED | The declared floor budget includes interior area mass and longitudinal buffer mass with the fixed ramp factor 1/I_zeta, so it covers the actual later time weights. |
| S0185 | 425–426 | VERIFIED | The rectangle and buffer dimensions are finite; choosing their positive floors sufficiently small makes every included added mass small without eliminating positivity. |
| S0186 | 426–428 | VERIFIED | This parameter order ensures that coefficients, floors and all derivatives appearing in B or log c have finite constants independent of the later H limit. |
| S0187 | 428–432 | VERIFIED | The chosen independent exponents set row spacing to H^2 and cycle time comparable to H^6; their resulting compatibility is checked in the normalization and error exponents below. |
| S0188 | 432–433 | VERIFIED | U_H is the H dilation already defined; using H rather than d in its norms is consistent with every projection and quadrature estimate. |
| S0189 | 433–434 | VERIFIED | A finite rectangle has finitely many rows at each positive d. Zero amplitude at visit endpoints allows resetting the center and starting the next row without simultaneous packets or a velocity jump. |
| S0190 | 434–435 | VERIFIED | On a row the peak eta is fixed and c>0, so r=r0 c is a positive smooth radius depending on longitudinal location; it joins a constant radius where a vanishes in buffers. |
| S0191 | 435–440 | VERIFIED | The speed relation ds/dt=eta/(r0 c) gives dt=(r0/eta)c ds. Multiplying by eta^2 and substituting the row position gives the second displayed identity without an extra factor of c. |
| S0192 | 440–443 | VERIFIED | A normalized smooth step built from exp(-1/t) and exp(-1/(1-t)) has the required flat endpoint values and stays in [0,1]. Its use gives smooth joins to zero amplitude and the constant peak. |
| S0193 | 443–444 | VERIFIED | Reversing the entry step interchanges endpoint values and retains flatness, giving the stipulated exit ramp. |
| S0194 | 444–445 | VERIFIED | The continuous nonnegative ramp equals one at its terminal endpoint, so it is positive on a subinterval and its integral is strictly positive. |
| S0195 | 445–446 | VERIFIED | The original coefficient is zero on each buffer, so c=e and r=r0 e remains constant while the amplitude ramps. |
| S0196 | 446–449 | VERIFIED | The buffer displacement equals duration times eta I_zeta/(r0 e); solving for displacement L gives exactly the stated duration, with positive denominator. |
| S0197 | 449–451 | VERIFIED | Interior time is (r0/eta) times each line integral. Each of two buffers adds (r0/eta)eL/I_zeta, proving the expression for B_i. |
| S0198 | 451–456 | VERIFIED | The positive square root defines eta_i from B_i; r0_i then solves the coefficient-weight equation. Substitution into the scan-time equation with tau_i=tau/4 determines both normalizations consistently. |
| S0199 | 456–458 | VERIFIED | Substitution gives (r0_i/eta_i) B_i=tau d B_i/(2pi eta_i^2)=tau_i and 2pi eta_i r0_i/tau=d, verifying both equalities exactly. |
| S0200 | 458–459 | VERIFIED | The row Riemann sum d times the interior line integrals converges to coefficient area mass plus floor area mass; the finite number of buffer rows contributes its budget and a vanishing endpoint row-count error. |
| S0201 | 459–463 | VERIFIED | eta_i^2=(2/pi)dB_i, and the coefficient sum bound is C delta+C regularization mass. Taking square roots and using sqrt(x+y)<=sqrt x+sqrt y yields the stated upper estimate. |
| S0202 | 463–466 | VERIFIED | A genuinely unused zero coefficient may be omitted, leaving an idle slot. Every retained scan with a positive floor has B_i>0 and hence positive eta_i,r0_i, avoiding division by zero. |
| S0203 | 466–469 | VERIFIED | On a ramp eta(t)=eta_i zeta(t/T), r=r0 e, so \|(eta r)'\|<=eta_i^2 I_zeta\|\|zeta'\|\|infinity/L. On an interior row r'=r0 c_s ds/dt=eta_i c_s/c, giving both equalities and the logarithmic derivative bound. |
| S0204 | 469–470 | VERIFIED | Every constant in the derivative bounds involves only fixed coefficients, positive floors, buffer lengths and ramp shape; none varies with H. |
| S0205 | 470–472 | VERIFIED | Since eta_i is bounded above and below at fixed retained positive floor, r0=tau d/(2pi eta_i) is comparable to H^8. Multiplying by c with fixed positive lower and upper bounds preserves comparability; r^{1/5}/H=O(H^{3/5})->0. |
| S0206 | 472–473 | VERIFIED | The two time coefficients are uniformly bounded, so the intrinsic stress estimate is Cr+CH(1+\|log r\|). With r comparable to H^8 it is O(H^8)+O(H\|log H\|). |
| S0207 | 473–480 | VERIFIED | The time derivative of eta r U_H(x-X) integrates to zero on each visit because eta vanishes at both ends. The remaining spatial derivative term is eta^2 xi dot grad U_H, which after multiplication by xi is Div(eta^2 U_H xi tensor xi), giving the positive sign. |
| S0208 | 480–481 | VERIFIED | Chain rule gives derivative of the translated bump as -X' dot grad U_H. Substituting X'=eta xi/r cancels r and produces exactly the negative eta^2 directional derivative. |
| S0209 | 481–482 | VERIFIED | Summing the integrable symmetric tensors over the four direction slots defines A_av for the whole cycle, including their time weights and ramps. |
| S0210 | 482–488 | VERIFIED | The independent derivation uses the Banach-valued rectangle rule with derivative cost \|\|partial_perp a\|\|1+CH^-1\|\|a\|\|1, then approximation of a by a*U_H with error CH\|\|grad a\|\|1. This yields exactly the displayed three terms. |
| S0211 | 488–489 | VERIFIED | The ensuing argument is an explicit proof of the stated quadrature estimate; no additional external quadrature assumption is invoked. |
| S0212 | 489–491 | VERIFIED | For each y, compact smooth a and the probability bump give an L1_x function; F and its derivative are integrable in y by Fubini, permitting the Banach-valued fundamental theorem. |
| S0213 | 491–494 | VERIFIED | Differentiate both a(s,y) and the translation by y xi-perp. Integrating their L1_x norms and using \|\|U_H\|\|1=1 gives the two displayed terms with the triangle inequality. |
| S0214 | 494–497 | VERIFIED | For y in [kd,(k+1)d], \|\|F(y)-F(kd)\|\|1<=integral_kd^y \|\|F'(z)\|\|1 dz. Integrating y bounds this by d integral_kd^{(k+1)d}\|\|F'(z)\|\|1 dz. |
| S0215 | 497–498 | VERIFIED | Sum the disjoint interval estimates and substitute \|\|partial_perp U_H\|\|1=C/H, producing d\|\|partial_perp a\|\|1+C d H^-1\|\|a\|\|1. |
| S0216 | 498–500 | VERIFIED | Write a*U_H-a as an average of translation differences; \|\|a(.-z)-a\|\|1<=\|z\|\|\|grad a\|\|1 and the bump's first absolute moment is CH. |
| S0217 | 500–501 | VERIFIED | The original compact smooth coefficient satisfies all differentiability and integrability hypotheses of S0210; the nonsmooth rectangular floor is charged separately rather than inserted in that derivative estimate. |
| S0218 | 501–503 | VERIFIED | On buffers eta(t)^2<=eta_i^2 and their time lengths are known, so their averaged L1 weight is bounded by the budgeted constant floor mass. Interior floor rows converge to the finite rectangular area mass, with vanishing row-count error. |
| S0219 | 503–504 | VERIFIED | d H^-1=H, d=H^2 and the mollification error is O(H); all three quadrature terms vanish for the fixed smooth coefficient. |
| S0220 | 504–506 | NOT MATHEMATICAL | This is document formatting, an environment declaration, a title/heading, or an audit-status notice; it asserts no mathematical fact and all source bytes remain represented. |
| S0221 | 507–511 | VERIFIED | The integral is a well-defined Lp time primitive of projected translates for p>1. Subtracting the full-cycle time average makes its total integral zero; the minus sign is required for cancellation of the source. |
| S0222 | 511–513 | VERIFIED | The average is fixed on the full four-slot interval of length tau, so it does not change when the active direction changes. |
| S0223 | 513–514 | VERIFIED | Linearity of integration adds each of the four directional tensors; this constant total tensor, rather than the current single direction, enters the instantaneous corrected equation. |
| S0224 | 514–516 | VERIFIED | Using Delta G=delta gives the displayed Helmholtz projection on these smooth bump sources. The proof below constructs the needed images and estimates directly, so no undefined extension to arbitrary L1 fields is required. |
| S0225 | 516–517 | VERIFIED | The projected source is a dilation and translation of one explicit smooth profile; establishing its decay and curl controls all uses of the projection. |
| S0226 | 517–520 | VERIFIED | G is the plane's fundamental solution with Delta G=delta. Differentiating its convolution with the smooth bump gives grad Delta^{-1}Div(U_H xi), so Z_{H,xi} is exactly P(U_H xi). |
| S0227 | 520–521 | VERIFIED | Divergence of the Hessian convolution is grad U_H dot xi, canceling Div(U_H xi); its curl is zero since it is a gradient, leaving the displayed curl. |
| S0228 | 521–523 | VERIFIED | Move one derivative onto the compact smooth bump: partial_i G has locally integrable inverse-radius singularity. The convolution is bounded on compact sets and arbitrarily many derivatives can be moved onto U, giving smoothness. |
| S0229 | 523–525 | VERIFIED | For a radial unit-mass bump, the angular mean of log\|x-y\| equals log\|x\| outside its support. Thus the convolution equals G there, and the Hessian of G is O(\|x\|^-2). |
| S0230 | 525–526 | VERIFIED | The smooth core has finite measure and is bounded; the tail integral is integral_1^infinity rho^{1-2p}d rho, finite precisely for p>1. This includes all exponents used. |
| S0231 | 526–529 | VERIFIED | The Hessian convolution scales as H^-2 times its unit-scale profile because the constant log H disappears on taking two derivatives. Hence Z_H(x)=H^-2 Z_1(x/H), giving H^{2/p-2} in Lp. |
| S0232 | 529–530 | VERIFIED | The time coefficient is bounded on each finite cycle and translations preserve the Lp norm of Z_H. The integral triangle inequality therefore applies to this Bochner integral and to its averaged term. |
| S0233 | 530–531 | VERIFIED | S0226-S0232 supply the needed restricted operator estimate by explicit kernel decay and scaling; no general singular-integral theorem is used in this step. |
| S0234 | 531–535 | VERIFIED | The gradient of q_H is (D^2G*U_H)xi, so multiplying by the active scalar coefficient and translating constructs the irrotational part of the source. At zero amplitude reset the derivative prefactor vanishes, so the zero value is consistent. |
| S0235 | 535–536 | VERIFIED | P(U_H xi)=U_H xi-grad q_H by definition. Multiplication by 2pi(eta r)' and translation therefore gives U-PU=grad pi_U with exactly the stated sign. |
| S0236 | 536–540 | VERIFIED | Q'=-P U+P average(U); hence Q'+U=average(U)+grad(pi_U-average(pi_U)). Adding grad p_Q with the displayed negative/positive signs cancels the extra gradient. |
| S0237 | 540–546 | VERIFIED | Both projected source and its average have norm <=C B H^{2/p-2}. Integrating for at most tau gives C tau B H^-1 at p=2 and C tau B H^-2/3 at p=3/2. Curl commutes with the projection here and has norm <=C B/H, giving the final bound. |
| S0238 | 546–547 | VERIFIED | The instantaneous coefficient is bounded by B; averaging cannot increase a norm bound. The same is true for the projected profile norms and curl norms used to estimate Q. |
| S0239 | 547–548 | VERIFIED | Differentiating U_H=H^-2 U(x/H) multiplies its L1 norm by H^-1. Curl(U_H xi) is one directional derivative combination, so this controls its L1 norm directly. |
| S0240 | 548–549 | VERIFIED | Only p>1 bounds for the projected velocity and the direct curl identity enter; the proof never estimates the projection as an L1-to-L1 map. |
| S0241 | 549–550 | VERIFIED | At the first endpoint the primitive is zero; at the last, the integral of U minus its full-cycle average is exactly zero. Projection preserves these zeros. |
| S0242 | 550–553 | VERIFIED | The primitive is continuous through cycle endpoints even when its derivative has a jump. Within each visit the chosen smooth ramps and coefficients, after fixed spatial convolution of the profile, give smooth time dependence; a finite piecewise partition accounts for the joins. |
| S0243 | 553–555 | VERIFIED | Adding the packet and divergence-free projected corrector defines the new velocity as a locally L2 distribution, with the required continuity and global increment norms established in the local construction. |
| S0244 | 555–566 | VERIFIED | Expand (u+v+Q) tensor itself. Subtract the u and v equations and use Q'+U+grad p_Q=Div A_av; the remaining seven mixed/Q tensors are exactly those displayed. Subtracting qI from the stress is compensated by subtracting q from pressure. |
| S0245 | 566–567 | VERIFIED | Div(qI)=grad q. Thus replacing the stress by stress-qI and pressure by pressure-q preserves the Euler-Reynolds equation. |
| S0246 | 567–569 | VERIFIED | Add and subtract S in the displayed stress. The term S+A_av-qI is the quadrature error because the target directional tensor is -S+qI; all remaining terms belong to the stated total error. |
| S0247 | 569–577 | VERIFIED | R,E,A_av,qI are symmetric and each mixed tensor has its transpose. Holder with exponents 3 and 3/2 proves the old-new bounds; Cauchy-Schwarz proves the v-Q bound; the Frobenius norm of Q tensor Q is \|Q\|^2. The dipole scaling supplies eta r^{1/3}. |
| S0248 | 577–578 | VERIFIED | At fixed old seed, \|\|u\|\|3 is bounded on the patch; r^{1/3}=O(H^{8/3}), \|\|Q\|\|2=O(H^5) and \|\|Q\|\|3/2=O(H^{16/3}), so each displayed cross or square error tends to zero. |
| S0249 | 578–579 | VERIFIED | The triangle inequality gives \|\|v+Q\|\|3/2<=C eta r^{1/3}+C tau H^-2/3 B, and both powers of H are positive with fixed coarse data. |
| S0250 | 579–581 | VERIFIED | A direction-slot average would contain only that direction's rank-one tensor during its slot; a general prescribed symmetric S needs the sum of the four tensors at every time. The full-cycle definition avoids this mismatch. |
| S0251 | 581–583 | NOT MATHEMATICAL | This is document formatting, an environment declaration, a title/heading, or an audit-status notice; it asserts no mathematical fact and all source bytes remain represented. |
| S0252 | 584–586 | VERIFIED | Convolution of the new distributional equation with a fixed smooth compact even probability mollifier commutes with time and spatial derivatives and makes the new velocity spatially smooth; the old equation is kept intact. |
| S0253 | 586–587 | VERIFIED | Each fixed finite cycle has finitely many visits with positive continuous radii, so their minimum is positive. A constant ell smaller than this can be chosen, and time constancy removes kernel-derivative terms. |
| S0254 | 587–588 | VERIFIED | Convolving all five named new quantities preserves their linear equations and the averaged-source relation; the nonlinear packet product requires the separately displayed commutator. |
| S0255 | 588–593 | VERIFIED | Convolution gives partial_t v_l+Div((v tensor v)_l)+grad p_l=U_l+Div E_l. Replacing the left product by v_l tensor v_l adds Div(v_l tensor v_l-(v tensor v)_l) to the right, with the displayed positive sign and symmetry. |
| S0256 | 593–596 | VERIFIED | Translation and positive-radius scaling make v(t) a continuous L2 curve on a compact cycle, including zero resets. Approximation of identity is uniform on its compact image; quadratic L2-to-L1 continuity then makes both product-approximation errors uniformly small. |
| S0257 | 596–598 | VERIFIED | Probability convolution is a contraction in every stated velocity and curl norm. An even mollifier preserves evenness. Mean and first-moment convolution formulas preserve zero moments for the compact inputs because their mean is zero and the mollifier's mean is one. |
| S0258 | 598–599 | VERIFIED | With ell fixed on the cycle, partial_t(rho_ell*v)=rho_ell*partial_t v in distributions; there is no partial_t rho_ell term. |
| S0259 | 599–600 | VERIFIED | Convolution is linear and sends the zero function at each packet or cycle endpoint to zero, so both endpoint conditions remain exact. |
| S0260 | 600–601 | VERIFIED | The old velocity is unchanged, and the added correction has zero continuous traces at the cycle boundaries. Pasting therefore cannot introduce an old-boundary jump. |
| S0261 | 601–605 | VERIFIED | This defines the admissible velocity class. Local L2 continuity supports distributional time traces, and global L3 continuity on positive compact intervals provides the finite Holder-dual background bound needed by the repair. |
| S0262 | 605–606 | VERIFIED | Symmetry and local essential L1 stress bounds are part of the class; pointwise boundary representatives are also bounded as stipulated immediately afterward. |
| S0263 | 606–608 | VERIFIED | The inherited partition is locally finite away from zero, and on each closed one-sided piece the stress is a continuous L1 curve; this supplies the precise compactness needed for coarse freezing. |
| S0264 | 608–609 | VERIFIED | Different one-sided stress limits are compatible with a distributional equation involving spatial Div R and no partial_t R, so equality of those limits is not required. |
| S0265 | 609–611 | VERIFIED | Changing stress values at a discrete time set leaves its spacetime distribution unchanged. Maintaining the same norm bound keeps the pointwise stage estimates meaningful. |
| S0266 | 611–612 | VERIFIED | The stated Euler-Reynolds distributional identity is the equation assumption for the class; it uses the already fixed sign convention. |
| S0267 | 612–613 | VERIFIED | Every old-field occurrence in the exact added equation is a product of u with the new velocity. Holder estimates require only a finite global L3 norm on the patch, not spatial or time derivatives of u. |
| S0268 | 613–617 | VERIFIED | This fixes a current pair, a relatively compact open positive-time interval and a symmetric prescribed stress with compact time support and the inherited one-sided piecewise L1 continuity. These are exactly the inputs used in the freezing argument. |
| S0269 | 617–618 | VERIFIED | The pointwise supremum is finite: finitely many continuous one-sided L1 pieces meet the compact support, with the bounded representative values specified by the class convention. |
| S0270 | 618–630 | VERIFIED | The construction below meets each quantified budget: finite coarse approximation, small regularization/floor masses, large cycle counts, then small fixed mollification scales. Zero endpoints give compact time support and divergence-free increments; the exact expansion gives a symmetric error. The resulting estimates are C sqrt(delta)+zeta, epsilon, and kappa respectively. |
| S0271 | 630–633 | VERIFIED | eta_i is bounded by a universal multiple of sqrt coefficient L1 mass, and the dipole's L2 and curl constants are fixed. Support, derivative and time-patch constants affect only how small H and ell must be; they do not multiply the leading sqrt(delta) estimate. |
| S0272 | 633–635 | VERIFIED | Only finitely many inherited and new coarse cells and cycles occur on the compact patch. Positive-radius translation and fixed convolution give continuity in all three velocity spaces, including the zero endpoint traces. |
| S0273 | 635–636 | VERIFIED | Taking the union with finitely many coarse and cycle boundaries preserves each old boundary; no assumption that old stresses become continuous across it is made. |
| S0274 | 636–637 | VERIFIED | All principal radii are O(H^8) at fixed coarse data, so any strictly positive r_* can be met by increasing the finite cycle counts. |
| S0275 | 637–639 | VERIFIED | The continuous zero velocity endpoints and piecewise continuous L1 stresses established in S0329-S0349 permit pasting without time delta functions and preserve the admissible class. |
| S0276 | 640–641 | VERIFIED | delta=0 is a pointwise supremum of norms, so S=0 at every time as an L1 tensor. Taking both outputs zero leaves the pair unchanged and satisfies every positive budget. |
| S0277 | 641–642 | VERIFIED | The remaining construction assumes strictly positive delta; all square-root budgets and regularization choices are then legitimate, with the zero case already handled. |
| S0278 | 642–643 | VERIFIED | A compact subset of the open interval J has positive distance from both endpoints, so a closed interval [a,b] compactly contained in J can enclose the temporal support in its interior. |
| S0279 | 643–644 | VERIFIED | Local finiteness of the inherited positive-time partition means every compact [a,b] meets only finitely many boundaries, permitting finite one-sided subdivision. |
| S0280 | 644–651 | VERIFIED | Each closed one-sided stress curve is uniformly continuous. Freeze it with epsilon0/2 error, approximate the frozen tensor in L1 by a compact smooth symmetric tensor with epsilon0/2 error, and use the triangle inequality for both displayed bounds. |
| S0281 | 651–653 | VERIFIED | Reading a cell endpoint through its own one-sided extension is consistent with the declared stress class and with applying uniform continuity on the closed cell. |
| S0282 | 653–654 | VERIFIED | The equation ignores isolated actual values, and distinct one-sided extensions are used separately. The approximation does not require assigning two values to the same actual stress representative. |
| S0283 | 654–657 | VERIFIED | Density follows by truncation and smooth probability convolution of each entry, followed by symmetrization, which does not increase the approximation error for a symmetric target. The two epsilon0/2 errors add as stated. |
| S0284 | 657–658 | VERIFIED | Each of finitely many compact continuity pieces has a finite uniform-continuity subdivision, so the total number of coarse cells is finite. |
| S0285 | 658–660 | VERIFIED | Each selected tensor is smooth and compactly supported with fixed positive floors and finite rectangle dimensions; finitely many selections have finite maxima of every required constant. |
| S0286 | 660–661 | VERIFIED | Coarse freezing uses norm continuity and fixed smooth spatial approximations; the construction never differentiates the original time-dependent S. |
| S0287 | 661–664 | VERIFIED | Apply the earlier explicit coefficient formulas to S_k, obtaining -S_k+q_k I as the nonnegative sum; 'constant' means fixed in time on this coarse cell, with its spatial dependence retained. |
| S0288 | 664–666 | VERIFIED | Choose gamma to reduce gamma\|\|h\|\|1 and each positive floor to reduce its finite area/buffer mass. Finitely many coefficients allow doing this for all of them before H is chosen. |
| S0289 | 666–668 | VERIFIED | The scanning rectangle can extend strictly beyond the compact coefficient support in the longitudinal direction; within those extensions the original a is identically zero, and only the floor remains. |
| S0290 | 668–670 | VERIFIED | The averaged ramp contribution is bounded by peak eta squared times its exact duration. The resulting bound is a universal factor times the budgeted floor mass, including I_zeta and the two buffer lengths. |
| S0291 | 670–672 | VERIFIED | The bounds depend on total added mass and its square root, not separately on area. Even a large rectangle can use a sufficiently small positive floor; its derivative constants may change the later required scale but not this mass estimate. |
| S0292 | 672–674 | VERIFIED | All coarse tensors, supports, floors and ramps are fixed at this stage, so constants in the following N_k limit are finite and independent of N_k. |
| S0293 | 674–675 | VERIFIED | An interval of positive finite length splits into N_k equal subintervals for every positive integer N_k; each is assigned one complete four-direction scan. |
| S0294 | 675–676 | VERIFIED | These positive definitions give tau_k=cell length/N_k, H_k=tau_k^{1/6}, and row spacing d_k=H_k^2, tending to zero as N_k grows. |
| S0295 | 676–678 | VERIFIED | The sixth power of H_k equals tau_k exactly. Equal complete cycles fill the entire cell and therefore end exactly at its endpoints. |
| S0296 | 678–679 | VERIFIED | For each retained direction the fixed positive floor ensures B_i>0; applying S0198 supplies the exact slot duration and correct coefficient weight on every cycle. |
| S0297 | 679–681 | VERIFIED | The compact fixed scanning rectangle has a positive width and strictly positive floor; the row Riemann sums for interior integrals and buffer counts converge to finite positive area/buffer integrals. |
| S0298 | 681–683 | VERIFIED | eta_i^2=(2/pi)d_kB_i. The positive finite limit bounds this quantity above and away from zero for all sufficiently large N_k; taking square roots preserves these bounds. |
| S0299 | 683–688 | VERIFIED | The coefficient L1 bound is C(delta+epsilon0) plus regularization mass. Adding floor and row-rule errors, then applying sqrt(x+y)<=sqrt x+sqrt y, proves the displayed leading amplitude estimate. |
| S0300 | 688–690 | VERIFIED | The coefficient pointwise inequalities involve only four fixed unit directions and absolute matrix norms; the velocity and curl norms multiply fixed profile constants. No derivative or rectangle constant enters the leading term. |
| S0301 | 690–693 | VERIFIED | r0_i=H_k^8/(2pi eta_i) is comparable to H_k^8 by the amplitude bounds. Multiplying by the fixed c_i with positive floor and finite supremum bounds every radius above and below. |
| S0302 | 693–694 | VERIFIED | The lower and upper constants contain extrema of c_i and eta_i, which legitimately depend on fixed coefficient and floor choices; they are not claimed uniform over these choices. |
| S0303 | 694–695 | VERIFIED | r^{1/5}/H_k=O(H_k^{3/5}) tends to zero and r=O(H_k^8) tends to zero. Both requested inequalities therefore hold once N_k exceeds a finite threshold. |
| S0304 | 695–698 | VERIFIED | Inside a row the derivative coefficient is eta_i^2 partial_xi log c_i. On a ramp it is eta_i^2 times a fixed ramp/length factor, while eta r'=0 there. The uniform amplitude bounds and fixed positive floors control all of them independently of N_k. |
| S0305 | 698–700 | VERIFIED | Insert r comparable to H_k^8 and bounded derivative coefficients into \|\|E\|\|1<=C\|eta r'\|r+C\|(eta r)'\|H_k(1+\|log r\|); the displayed two asymptotic terms follow. |
| S0306 | 700–702 | VERIFIED | With tau_k=H_k^6, the L2 and curl exponents are 6-1=5, and the L^{3/2} exponent is 6-2/3=16/3. The coefficient B is uniformly bounded at fixed coarse data. |
| S0307 | 702–703 | VERIFIED | The packet norm is C eta_i r^{1/3}; bounded eta_i and r=O(H_k^8) yield the exponent 8/3. |
| S0308 | 703–704 | VERIFIED | The quadrature estimate has factors d_k=H_k^2, d_k/H_k=H_k and H_k, each tending to zero with all coefficient derivatives fixed. |
| S0309 | 704–706 | VERIFIED | Continuity of the old u into L3 gives a finite supremum on [a,b]. Multiply that bound by the vanishing L^{3/2} packet/corrector norms and use the vanishing L2-Q norm for the remaining cross products. |
| S0310 | 706–709 | VERIFIED | The construction acts on S_k fixed over its cell; no derivative of its time step is inserted into the velocity. The prescribed difference S-S_k is explicitly added to the error, already bounded by epsilon0. |
| S0311 | 709–711 | VERIFIED | After finitely many positive cycle counts have been selected, choose a positive constant spatial mollification scale on each cycle; no infinite minimum or simultaneous asymptotic choice is required. |
| S0312 | 711–712 | VERIFIED | There are finitely many cycles and finitely many visits per cycle. Every visit has a continuous strictly positive radius on its compact duration, so the finite union has a positive minimum. |
| S0313 | 712–714 | VERIFIED | Uniform approximation of identity on each compact L2 packet curve makes its commutator arbitrarily small. Probability convolution contracts L2, L^{3/2} and curl L1, preserving all velocity budgets. |
| S0314 | 714–715 | VERIFIED | Spatial convolution commutes with the finite time integral defining A_av and its divergence, so the new averaged tensor is exactly (A_av)_ell. |
| S0315 | 715–717 | VERIFIED | A_av is a finite time integral of translated L1 bumps with bounded coefficients, hence is L1. Approximation of identity then gives \|\|(A_av)_ell-A_av\|\|1->0; this is the additional averaging error when q_k is left unchanged. |
| S0316 | 717–718 | VERIFIED | Only the newly constructed packet equation and corrector are convolved; all u and R terms in the exact assembled equation are the actual current seed. |
| S0317 | 718–721 | VERIFIED | The exact expanded equation, including the mollification commutator, has stress R+A_av,ell-q_k I plus intrinsic and cross terms. Adding S_k inside the error rewrites it exactly as R-S_k+E_k^loc. |
| S0318 | 721–724 | VERIFIED | Adding the two new equations cancels U and replaces it by the complete-cycle average. Expanding the new square supplies all cross terms. Subtracting q_k from pressure matches subtraction of q_k I from stress because their gradients agree. |
| S0319 | 724–728 | VERIFIED | This definition is made on cell interiors, where S has the correct one-sided continuous branch. S-S_k is an L1 tensor bounded by epsilon0, and addition to E_k^loc preserves symmetry and piecewise continuity. |
| S0320 | 728–729 | VERIFIED | Substitute E_total=S-S_k+E_k^loc into R-S+E_total; S cancels and the result is exactly the stress R-S_k+E_k^loc. |
| S0321 | 729–731 | VERIFIED | The two independent error sources are bounded by epsilon0 and epsilon/2, so choosing epsilon0<=epsilon/2 makes their sum at most epsilon on every cell interior. |
| S0322 | 731–732 | VERIFIED | The interior bound follows by the triangle inequality, and boundary values are assigned zero error below; outside the patch error is zero, proving the pointwise supremum bound. |
| S0323 | 732–734 | VERIFIED | epsilon0 may be decreased while retaining the stress budget. Taking epsilon0 <= (zeta/(3C))^2 reserves at most one third of the amplitude slack for coarse approximation. |
| S0324 | 734–736 | VERIFIED | There are finitely many regularization and floor masses, and their square-root contributions can be made arbitrarily small before choosing fine scales; reserve another third of zeta for them. |
| S0325 | 736–738 | VERIFIED | The row-rule error tends to zero and both Q's L2 and curl-L1 norms are O(H_k^5). Increasing each finite cycle count beyond a threshold allocates the remaining third of zeta to their combined contributions. |
| S0326 | 738–740 | VERIFIED | Squaring nonnegative quantities shows sqrt(delta+epsilon0)<=sqrt(delta)+sqrt(epsilon0). Combining the three reserved slacks with the universal coefficient/profile estimate yields C sqrt(delta)+zeta. |
| S0327 | 740–742 | VERIFIED | Both L^{3/2} costs vanish as positive powers H_k^{8/3},H_k^{16/3}, and radii as H_k^8; finitely many thresholds can be met simultaneously by sufficiently large finite N_k. |
| S0328 | 742–744 | VERIFIED | After coarse data and floors are fixed, all error terms tend to zero and the radius constraint improves for all sufficiently large counts. Their finitely many thresholds have a common maximum, proving compatibility without interchanging parameter order. |
| S0329 | 744–746 | VERIFIED | Every last visit exits at zero amplitude; Q integrates its mean-zero cycle forcing to zero. Thus both summands vanish at each complete-cycle endpoint. |
| S0330 | 746–747 | VERIFIED | The interval [a,b] is compactly contained in J and both velocity endpoint values vanish. Extension by zero defines a time-compact correction with the intended support. |
| S0331 | 747–748 | VERIFIED | For a continuous piecewise differentiable Banach-valued curve, distributional time differentiation has only derivative densities and jump deltas; the jump coefficients here are zero at every paste. |
| S0332 | 748–749 | VERIFIED | The prescribed temporal support lies in the interior of [a,b], so S=0 outside; defining E_total=0 there restores the old equation and yields the desired support. |
| S0333 | 749–752 | VERIFIED | Only finitely many listed boundaries occur in the patch. At them E_total=0 and Rtilde=R-S define actual L1 values satisfying the exact desired algebra without requiring agreement with one-sided limits. |
| S0334 | 752–754 | VERIFIED | The algebra holds by definition and zero error obeys every positive epsilon bound. Changing values on a finite time set affects neither the distribution nor the continuous one-sided extensions from open cells. |
| S0335 | 754–756 | VERIFIED | Stress enters through derivatives in x, not t. A temporal jump of an L1 stress is locally time-integrable and causes no time delta in its spatial divergence, unlike a velocity jump. |
| S0336 | 756–757 | VERIFIED | Both corrections vanish outside [a,b], and [a,b] is a compact subset of J; possible nonzero error traces at a,b do not enlarge support beyond it. |
| S0337 | 757–761 | VERIFIED | For p=2 and 3/2, the fixed profile belongs to Lp; translations and dilations vary continuously for positive radii. At a reset eta->0 with radii bounded away from zero in this finite construction, giving zero norm limits despite center reset. |
| S0338 | 761–763 | VERIFIED | Young uses 1+1/3=1/2+1/(6/5). The mollifier L^{6/5} norm scales as ell^{-1/3}, so convolution is bounded L2->L3 at fixed ell and transfers L2 time continuity. |
| S0339 | 763–764 | VERIFIED | Q is a time primitive of bounded translated projected profiles in each of L2,L3,L^{3/2}; it is continuous in these norms and is zero at the cycle endpoints, so different cycle scales paste continuously. |
| S0340 | 764–766 | VERIFIED | There are finitely many fixed positive scales on any single patch and finitely many active patches at a positive finite stage. The potentially large L3 constants are finite there; no summability of those constants is needed for the final L2 limit. |
| S0341 | 766–768 | VERIFIED | Within each visit the source inputs, radius and coefficients vary continuously. At resets the derivative prefactors vanish, and zero concatenations make the intrinsic stress a continuous L1 curve on the closed cycle. |
| S0342 | 768–770 | VERIFIED | Differences of compact inputs retain zero zeroth and first moments and stay in a common finite ball. The operator estimate \|\|A(f-g)\|\|1<=C R\|\|f-g\|\|1 proves continuous dependence, including the translated/scaled inputs. |
| S0343 | 770–771 | VERIFIED | For any L1 profile, translations are strongly continuous; positive dilation is continuous after a change of variables and density by smooth compact functions. The finite radius interval stays away from zero, so these operations preserve the claimed continuity. |
| S0344 | 771–772 | VERIFIED | Entry and exit ramps are flat at their zero-amplitude ends, with constant buffer radius. Consequently eta r'=0 and (eta r)'=r eta'->0 there, making both intrinsic-stress terms vanish at a reset. |
| S0345 | 772–773 | VERIFIED | The maps (f,g)->f tensor g are continuous L2 times L2 into L1. This applies to v,Q and their convolved products, proving continuity of all new quadratic and commutator terms. |
| S0346 | 773–779 | VERIFIED | Add and subtract u(s) tensor w(t); use the triangle inequality and Holder with exponents 3 and 3/2 on the two differences. The continuous norms and boundedness on the compact patch make the right side tend to zero. |
| S0347 | 779–780 | VERIFIED | On each one-sided coarse piece S is L1-continuous and S_k is fixed; adding this difference to the previously continuous local error preserves piecewise L1 continuity. |
| S0348 | 780–781 | VERIFIED | The new velocity is old plus a continuous local L2/global L3 correction, and the stress is symmetric, locally bounded and has continuous one-sided L1 extensions. The exact distributional equation and boundary representative convention were checked, so all class conditions persist. |
| S0349 | 781–783 | VERIFIED | The inherited partition has finitely many boundaries on [a,b], each continuity piece has finitely many coarse cells, and each chosen N_k is finite. Their finite sum is the asserted new partition count. |
| S0350 | 784–785 | NOT MATHEMATICAL | This is document formatting, an environment declaration, a title/heading, or an audit-status notice; it asserts no mathematical fact and all source bytes remain represented. |
| S0351 | 786–790 | VERIFIED | These are explicit hypotheses of the anchor lemma: local continuous velocities, uniformly bounded local L2 squares and global L1 stresses suffice to bound every compact divergence-free pairing derivative; they are later checked for each color transition. |
| S0352 | 790–792 | VERIFIED | The difference W has a uniform global L2 bound and exact zero values along times tending to zero. These are independent assumptions, strong enough to give weak compactness and an anchor for the pairing limit. |
| S0353 | 792–794 | VERIFIED | The proof uses bounded distributional derivatives of compact divergence-free pairings, their zero anchor values, and weak L2 cluster points with both curl and divergence zero. The only such global L2 field is zero, proving weak convergence of the whole family. |
| S0354 | 795–802 | VERIFIED | Test the two Euler-Reynolds equations against a compact smooth divergence-free psi and integrate row-wise divergence by parts. Pressure vanishes; the convection term has the positive sign and stress the negative sign shown in the difference identity. |
| S0355 | 802–803 | VERIFIED | On supp psi the quadratic difference has integral bounded by the sum of the two local kinetic energies; the stress difference by the two global L1 bounds. Multiplication by \|\|grad psi\|\|infinity gives a uniform constant. |
| S0356 | 803–805 | VERIFIED | A distributional derivative in Linfinity implies a Lipschitz representative. Local L2 continuity identifies it with the given pairing at all times, so no boundary jump remains. Lipschitz continuity and its zero sequence force limit zero at t=0. |
| S0357 | 805–806 | VERIFIED | Every bounded sequence in the Hilbert space L2 has a weakly convergent subsequence: choose a countable dense set, diagonalize the bounded scalar pairings, and extend the limit by the uniform norm bound to an L2 element. |
| S0358 | 806–808 | VERIFIED | Distributional divergence passes through weak L2 convergence. Each compact divergence-free pairing tends to zero by S0356; in particular psi=grad-perp phi yields curl of the weak limit equal to zero. |
| S0359 | 808–811 | VERIFIED | Fourier transforming div z=0 and curl z=0 gives xi dot z-hat=0 and xi-perp dot z-hat=0. For xi nonzero these vectors span the plane; z-hat=0 almost everywhere off a singleton, and an L2 function is also zero on that singleton in its equivalence class. |
| S0360 | 811–812 | VERIFIED | If W failed to converge weakly to zero, a sequence would keep some pairing away from zero. Its weakly convergent subsequence has the zero cluster limit just proved, a contradiction. |
| S0361 | 813–819 | VERIFIED | The dyadic prescribed-piece iteration below gives geometric L2 and curl summability, decaying stresses and preserved anchor traces. Passing its local strong L2 limit gives Euler and every-time curl variation, with the exact zero-time trace established separately from positive-time convergence. |
| S0362 | 820–826 | VERIFIED | Choose eta positive on a closed subinterval [a,b] of (1/2,2) with b>2a, ensuring dyadic coverage. At each t only finitely many terms in the denominator are nonzero and at least one is positive; the normalized functions and intervals are well-defined. |
| S0363 | 826–828 | VERIFIED | The denominator is positive, smooth and locally a finite sum, so each chi is smooth nonnegative and the sum is one. Compact support of eta inside (1/2,2) gives compact support of chi_j inside I_j; dyadic scale bounds give local finiteness. |
| S0364 | 828–828 | VERIFIED | The residue classes modulo three form exactly three colors and assign every integer patch index uniquely. |
| S0365 | 828–830 | VERIFIED | I_j ends at 2^{j+1}=2*2^j and I_{j+3} begins at 2^{j+2}=4*2^j. Thus same-color intervals are separated, and 3*2^j lies strictly in their gap. |
| S0366 | 830–831 | VERIFIED | For each fixed residue class, 3*2^j tends to zero through positive values as j tends to negative infinity, supplying the required anchor sequence for that color. |
| S0367 | 831–831 | VERIFIED | A time lies in at most two of these open dyadic intervals except for endpoint conventions, so the stated bound N=3 is safely valid, including the supports used for pasting. |
| S0368 | 831–834 | VERIFIED | The seed stress bound is finite on every horizon, including near zero. A smooth nondecreasing function majorizing its running supremum and at least one can be constructed by smooth step interpolation above integer-horizon maxima. |
| S0369 | 834–835 | VERIFIED | The seed estimate bounds \|\|R0\|\|1 by a constant plus a finite-horizon bounded background factor and a linear t term; it therefore supplies the bounded running maxima required in S0368. |
| S0370 | 835–836 | VERIFIED | delta_q=16^{-q} starts at one and has square root 4^{-q}. The q=0 bound holds by Theta; the later error budget proves the same inequality at q+1. |
| S0371 | 836–838 | VERIFIED | Since the chi sum is one, the frozen pieces sum to R^{(q)} pointwise. Their supports are compactly inside the patches, and their inherited piecewise L1 continuity and symmetry follow by multiplication with a smooth scalar. |
| S0372 | 838–838 | VERIFIED | Each I_j has positive finite endpoints and Theta is continuous, nondecreasing and locally finite, so its supremum M_j is finite and its infimum m_j is at least one. |
| S0373 | 838–844 | VERIFIED | Every budget is strictly positive because delta_q>0 and m_j>=1. For J=I_j, S=chi_j Rq is symmetric, time compact and piecewise L1-continuous; the current pair stays admissible after prior colors. Hence every hypothesis of LER is matched, and r_*=1 is an allowed radius bound. |
| S0374 | 844–845 | VERIFIED | A finite ordering of the three residue classes is possible; each stage has exactly these three color operations, while spatial/time locality handles infinitely many disjoint patches within a color. |
| S0375 | 845–846 | VERIFIED | Within a color the time supports are disjoint. At a given time at most one correction in that color is nonzero, so products of distinct same-color corrections vanish; local finiteness justifies summing their distributional equations. |
| S0376 | 846–848 | VERIFIED | LER accepts a prescribed S independent of current R. Therefore earlier color modifications change only the old velocity and stress used in cross terms, while the remaining subtraction is the originally frozen S_{qj}. |
| S0377 | 848–849 | VERIFIED | This matches the proved prescribed-piece version of LER rather than assuming the stress to remove must equal the current stress, which would invalidate the partition-of-unity cancellation. |
| S0378 | 849–851 | VERIFIED | Compact positive-time intervals contain only finitely many dyadic patch scales. Each local construction adds finitely many boundaries; the finite union is again locally finite. |
| S0379 | 851–852 | VERIFIED | Each color preserves velocity continuity and the one-sided stress class locally by LER and disjoint pasting; finitely many colors preserve the full finite-stage admissible class. |
| S0380 | 852–858 | VERIFIED | Successive updates add each w_{qj} and subtract each frozen chi_j Rq once. Since the chi sum is one, the entire old stress cancels, leaving sum E_{qj}; all sums are locally finite in positive time. |
| S0381 | 858–860 | VERIFIED | The patch-overlap bound applies equally to compact correction supports inside the patches. For an active patch t lies in I_j, so its infimum m_j does not exceed Theta(t). |
| S0382 | 860–861 | VERIFIED | Triangle inequality gives sum_active epsilon_qj=delta_{q+1} sum_active m_j/N<=delta_{q+1}Theta(t), proving the pointwise inductive stress bound. |
| S0383 | 861–867 | VERIFIED | After a subset of frozen pieces is removed the uncanceled coefficient is 1-sum_processed chi_j, lying in [0,1]. Its stress norm is <=delta_q Theta, and the already added errors total <=delta_{q+1}Theta, giving the displayed bound. |
| S0384 | 867–873 | VERIFIED | If t in I_j and t<=T then 2^{j-1}<T, so 2^{j+1}<4T and the entire patch lies below 4T. The prescribed norm is <=delta_q M_j<=delta_q Theta(4T); sum at most N LER bounds and N zeta_qj=sqrt(delta_q) to obtain the exact estimate. |
| S0385 | 873–874 | VERIFIED | sqrt(delta_q)=4^{-q} has finite geometric sum. Partial color sums have at most the same active count and satisfy the same bound, so intermediate corrections are bounded near zero as well. |
| S0386 | 874–877 | VERIFIED | At every time at most N terms with budgets 2^{-q}/N are active, giving \|\|w_q\|\|3/2<=2^{-q}, a summable series. More directly these norms make each finite-stage old-new Holder product arbitrarily small during LER. |
| S0387 | 877–877 | VERIFIED | Only finite-stage L3 continuity and boundedness on each compact patch is required. The infinite-stage construction uses L2 convergence, so it does not silently claim uniform L3 control. |
| S0388 | 877–880 | VERIFIED | Every correction of a fixed color is supported inside that color's intervals; the times 3*2^j in the same-color gaps lie outside all those supports. Thus the sum vanishes exactly along its positive sequence approaching zero. |
| S0389 | 880–882 | VERIFIED | The old seed has uniformly bounded local energy near zero; finitely many stage/color increments with the global L2 bound preserve this. S0383 controls intermediate stresses, and S0384 controls the global difference, matching all quantitative anchor hypotheses. |
| S0390 | 882–883 | VERIFIED | For each color compare the pair immediately before and after that color. They satisfy the anchor lemma's equation, local continuity, near-zero energy/stress bounds, global L2 difference bound and exact zero gap sequence; its conclusion is weakly zero initial trace. |
| S0391 | 883–883 | VERIFIED | Modulo three yields exactly three color transitions, so the total stage trace is the sum of finitely many weakly zero correction traces. |
| S0392 | 883–885 | VERIFIED | The seed has the prescribed strong local trace. Inductively adding finitely many color corrections with weakly zero trace preserves that exact trace at every stage; no initial norm smallness enters the anchor proof. |
| S0393 | 885–888 | VERIFIED | The uniform-on-(0,T] bound in S0384 is a summable numerical sequence. Completeness of L2 and the uniform Cauchy criterion give the asserted globally L2 correction series and uniform finite-horizon bound. |
| S0394 | 888–889 | VERIFIED | On every positive-time compact interval the finite stages are locally strongly L2-continuous, and the correction series converges uniformly in that norm. The uniform limit of continuous Banach-valued maps is continuous. |
| S0395 | 889–891 | VERIFIED | For a fixed compact L2 test, the uniformly small global L2 tail gives a uniform small pairing by Cauchy-Schwarz. The finitely many leading corrections have weak zero trace, so taking time to zero and then the tail cutoff proves the limit. |
| S0396 | 891–893 | VERIFIED | The positive-time strong local continuity and the preceding weak zero-time correction trace, combined with the seed trace, give weak local L2 continuity on [0,infinity) and exactly u(0)=u0. |
| S0397 | 893–896 | VERIFIED | At any fixed positive time the sum of curl L1 norms is finite by S0384, so it converges in L1. Testing curl against a compact smooth function also passes the L2 velocity limit, identifying the L1 sum with its distributional curl. |
| S0398 | 896–901 | VERIFIED | The triangle inequality for the L1 series yields the first displayed bound uniformly over (0,T]. The seed curl bound is finite and sum_q sqrt(delta_q)=4/3, proving the second relation and finiteness. |
| S0399 | 901–902 | VERIFIED | At zero curl u0=mu0 has finite variation by the initial lemma. Taking the larger bound, or adding its norm as stated, extends the uniform estimate to the closed interval including zero. |
| S0400 | 902–903 | VERIFIED | Every finite stage is divergence-free. Pairing its local L2 limit with the gradient of a compact test passes to the limit, preserving zero divergence at positive times; the initial field already has zero divergence. |
| S0401 | 903–907 | VERIFIED | For local L2-convergent velocities with uniformly bounded local L2 norms, the quadratic difference is bounded in L1 by (\|\|u_q\|\|2+\|\|u\|\|2)\|\|u_q-u\|\|2. On finite positive cylinders this tends to zero, while the stress norm integrates to O(delta_q) by bounded Theta. |
| S0402 | 907–908 | VERIFIED | Passing the divergence-free compact spacetime test identity with support away from zero removes the stress and gives the Euler equation on the full open positive-time half-line. |
| S0403 | 908–909 | VERIFIED | A fixed smooth monotone step dilated by epsilon is zero before epsilon and one after 2epsilon; multiplying the test by it yields an admissible positive-time test and a derivative supported on that short interval. |
| S0404 | 909–910 | VERIFIED | The absolute convection integral over (0,2epsilon) is <=C epsilon times the uniform local energy and \|\|grad phi\|\|infinity; it vanishes. The omitted time-derivative integral also vanishes by uniform local L2 control. |
| S0405 | 910–912 | VERIFIED | The cutoff derivative is nonnegative, integrates to one and is supported at times tending to zero, so weak local continuity identifies its pairing with u0. Smoothness gives \|\|phi(t)-phi(0)\|\|2=O(epsilon) there, and the uniform local L2 bound controls the averaged replacement error by O(epsilon). |
| S0406 | 912–914 | VERIFIED | The cutoff limit yields integral u dot partial_t phi+(u tensor u):grad phi plus the positive initial pairing equal to zero, exactly the target identity for all specified divergence-free tests. |
| S0407 | 915–918 | VERIFIED | These are independent fixed-time hypotheses: a vanishing-at-infinity bounded background, an L2 remainder, divergence zero and finite-measure curl. They do not assume H^{-1} or global L2 for u. |
| S0408 | 918–919 | VERIFIED | Subtracting K*mu gives an entire harmonic vector field. The mean-value bound tends to zero using the C0 background, the L2 remainder and the uniform inverse-radius kernel average; this proves the exact canonical identity. |
| S0409 | 920–922 | VERIFIED | The finite-measure convolution is locally L1 by the earlier kernel estimate, so h is a distribution with div h=curl h=0. Componentwise Delta h=0. Mollification gives smooth harmonic approximants; their local L1 convergence and interior mean-value derivative bounds give a smooth harmonic representative of h, proving the Weyl step directly. |
| S0410 | 922–928 | VERIFIED | A harmonic vector obeys h(x)=average_B h, and Jensen/triangle gives \|h(x)\|<=average \|h\|. Split h=U+v-K*mu; Cauchy-Schwarz bounds average \|v\| by C\|\|v\|\|2/R, proving all three terms. |
| S0411 | 928–930 | VERIFIED | The supremum over centers of the inverse-distance integral on any radius-R ball is at most C R by the same near/far split as S0040. Integrate against d\|mu\| and divide by pi R^2 to get C\|\|mu\|\|M/R. |
| S0412 | 930–932 | VERIFIED | For any epsilon choose a compact set outside which \|U\|<=epsilon. Its integral divided by pi R^2 tends to zero, while the complementary average is <=epsilon; then let epsilon tend to zero. |
| S0413 | 932–933 | VERIFIED | All three nonnegative terms in S0410 tend to zero as R grows, so \|h(x)\|=0 for every fixed x. Thus h vanishes as a function and distribution. |
| S0414 | 934–938 | VERIFIED | The global iteration proves all time, weak formulation and measure bounds for every initial datum, and the final canonical lemma supplies the remaining every-time normalization. All input hypotheses are precisely those in the target. |
| S0415 | 939–942 | VERIFIED | The iteration conclusion includes weak local continuity, the exact initial-value formulation and every-positive-time L1 curl; adding mu0 covers zero. Its bounds are uniform on every finite horizon, as required. |
| S0416 | 942–944 | VERIFIED | S0038 gives V0 in C0; the background lemma gives V(t)-V0 in L2, the seed gives W(t) in L2 and the geometric series gives the correction in L2. Divergence and finite curl are already proved, so all fixed-time canonical-lemma hypotheses hold. At zero K*mu0 is the prescribed datum. |
| S0417 | 944–945 | VERIFIED | Applying that lemma separately at each positive time yields u(t)=K*curl u(t), without an a.e.-time exception; the initial equality holds directly by definition. |
| S0418 | 945–947 | VERIFIED | The dyadic partition and all stages are defined on the entire positive half-line; finite horizons occur only in bounds and convergence estimates. Therefore a single global limit has been constructed without choosing or reconciling separate finite-horizon solutions. |
| S0419 | 948–949 | NOT MATHEMATICAL | This is document formatting, an environment declaration, a title/heading, or an audit-status notice; it asserts no mathematical fact and all source bytes remain represented. |

## Final completeness certificate

- PASS — Every TeX file in this pass was inventoried: 1 root, no missing include dependency.
- PASS — Every source line belongs to a permanent container: 949/949; all 45,127 bytes exactly partitioned.
- PASS — Permanent identifiers remained unchanged: 419/419 matched source digests.
- PASS — Every compound mathematical container has one nonrecursive shared layer: 253 containers, 855 allocated children.
- FAIL — Every permanent container received a verdict from every required pass: this report certifies only PASS B, 419/419; other passes were intentionally not inspected.
- FAIL — Every final child and simple mathematical container was affirmatively checked by every pass: PASS B checked 855/855 shared children and all 388 mathematical parents; cross-pass completion is outside this report.
- PASS — Every inventoried formula was checked by PASS B: 579/579, comprising 520 inline and 59 display occurrences.
- PASS — Every algebra-bearing container was independently re-derived in PASS B: 106/106.
- PASS — Every inventoried theorem application received hypothesis matching in PASS B: 22/22, including inspection of the specialized primary source.
- PASS — Every proof was checked locally and globally in PASS B: 8/8, with 8 major-result dependency maps.
- PASS — Edge cases and attempted failure modes were investigated as described above.
- PASS — Definitions, macros, formula conventions and cross-references were checked across all 949 lines.
- PASS — Dependencies were traced; no earlier mathematical error was identified to propagate in this pass.
- FAIL — Every required escalation was reconciled through local dispute items: independent PASS B does not perform or claim four-pass reconciliation.
- PASS — Definite errors were independently confirmed where feasible: no definite error was identified, so the confirmation set is empty.
- FAIL — No source container, pass verdict or dispute item remains unchecked: PASS B has zero uncovered source containers and zero missing own verdicts, but makes no claim about uninspected other passes or coordinator disputes.
