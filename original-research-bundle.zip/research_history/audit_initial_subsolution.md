# Independent hostile audit: initial Euler–Reynolds seed

Auditor: primary_interfaces. Source packet: `route_initial_subsolution.md` (frozen candidate read in full), with external interface E1 and smoothness reconstruction in `route_initial_velocity_interfaces.md`. The dynamic-packet files remain frozen. This is an independent mathematical audit, not adoption of the coordinator's authority.

**Overall verdict: PASS for the initial Euler–Reynolds seed, including the exact inhomogeneous target data. INCONCLUSIVE for the subsequent perturbative construction.** Section C correctly labels unproved interfaces. An interpretation of C claiming that its required global cross-term integrability follows from only finite energy and finite curl variation would be **FAIL**; an explicit counterexample appears below.

## A. Finite-energy biharmonic seed — PASS

Use the matrix convention `(grad f)_{ij}=partial_j f_i` and `(div S)_i=sum_j partial_j S_{ij}`. Let `b` denote the Schwartz kernel with Fourier transform `exp(-|xi|^4)`, avoiding collision of its notation with the positive radial cutoff in B. It is real, radial, has integral one, and need not be positive. Its dilation `b_t=t^{-2}b(x/t)` has multiplier `exp(-t^4|xi|^4)`.

For `U=b_t*u0`, direct differentiation gives

    partial_t U = -4t^3 Delta^2 U,
    div[grad Delta U+(grad Delta U)^T] = Delta^2 U.

The second equality uses `div U=0`; thus the displayed candidate `R=U tensor U-4t^3[grad Delta U+(grad Delta U)^T]` has precisely the advertised sign and gives the Euler–Reynolds equation with pressure zero. There is no hidden pressure or inverse-divergence estimate here.

For any divergence-free two-dimensional distribution,

    Delta U = grad-perp curl U.

Consequently each entry of `grad Delta U` is a second derivative of `b_t*mu`, and

    ||grad Delta U||_1 <= C t^{-2} ||D^2 b||_1 ||mu||_M.

Multiplication by `4t^3` gives the claimed `CtM` contribution, not an inverse power of t. Plancherel gives `||U||_2<=||u0||_2` and strong L2 convergence at zero. Measure convolution gives `||curl U||_1<=||b||_1 M`. Products of L2 derivatives and the derivative-kernel estimates give the required smoothness and L1 stress derivatives away from t=0. No false L1 Riesz-transform assertion enters.

The seed is not asserted to be a solution, to obey an energy inequality, or to have a positive stress. If a later construction requires trace-free stress, replace `R` by `R-(tr R/2)Id` and `p` by `p-tr R/2`; the L1 bounds change only by a harmless matrix constant.

## B1. The stated Schwartz high-pass kernel — PASS

The candidate's Taylor-tail proof is valid, but radiality gives a shorter complete verification. Let `eta=F^{-1}chi`, where chi is the stated real radial compact cutoff. Then eta is real radial Schwartz and has mass one. For every radial integrable smooth function eta, the Biot–Savart formula is

    (K*eta)(x) = K(x) integral_{|y|<|x|} eta(y)dy,  x != 0.

This follows by angular averaging, or by rotational covariance, tangency, and the circulation identity. It applies to signed eta by linearity. Hence

    L(x)=K(x)-(K*eta)(x)
        =K(x) integral_{|y|>|x|} eta(y)dy.

For large r, the last integral is bounded by the absolute Schwartz tail `C_N r^{-N}`. Therefore L decays faster than every prescribed power after multiplication by `|K|~r^{-1}`. Near zero the enclosed mass is O(r²), so `K*eta=O(r)`; the remaining K singularity is locally integrable. Thus `L in L1` with a constant depending on eta. Fubini in distributions, or Fourier multiplication followed by local integrability, gives `v0=L*mu0`. Young's inequality yields

    ||v0||_1 <= ||L||_1 ||mu0||_M.

This proof does not assume eta has compact support and does not require any moment of mu0. The high-frequency L2 estimate, `||v0||_2<=sqrt(2)||mu0||_{H^-1}` for the packet's normalized cutoff, is already direct from Plancherel.

## B2. Compact radial physical-space replacement — PASS

The coordinator proposed this simplification during the audit; it is an independently verified replacement, not silently inserted into the frozen packet. Choose `a in C_c^infinity(R2)`, nonnegative, radial, integral one, with support in B_A. Define

    nu0=a*mu0, sigma0=mu0-nu0,
    U0=K*nu0, v0=K*sigma0=(K-K*a)*mu0.

For `|x|>A`, every component of `y -> K(x-y)` is harmonic on the averaging disk. Radial averaging and the harmonic mean-value property imply `K*a=K` there. Equivalently, use the radial formula in B1. Thus `L_a=K-K*a` vanishes outside B_A; near zero it has only K's integrable `1/r` singularity. In particular `L_a in L1`, and `||v0||_1<=||L_a||_1 M`.

For the L2 statement, evenness and the finite second moment give

    |1-a_hat(xi)| <= C min(|xi|²,1).

For `m(xi)=-i xi-perp/|xi|²`, this implies

    (1+|xi|²) |(1-a_hat(xi))m(xi)|² <= C_a.

Indeed the left side is O(|xi|²) at zero and bounded at infinity. Plancherel proves

    ||v0||_2 <= C_a ||mu0||_{H^-1}.

This uses precisely the inhomogeneous target norm, with neither a zero-circulation nor a moment assumption. Also `||nu0||_1<=M`, `||sigma0||_M<=2M`, and all derivatives of nu0 lie in L1 and Linfinity. The velocity U0 is smooth and bounded: `m a_hat` and every multiplier `xi^alpha m a_hat` are integrable, using integrability of `1/|xi|` in two dimensions near zero and Schwartz decay at infinity. For every positive-order derivative the same multiplier is L2. Thus the physical-space replacement retains the needed background properties.

## B3. External background and regularity — PASS, with input accurately delimited

Independently opened primary source: G. Crippa and G. Stefani, *An elementary proof of existence and uniqueness for the Euler flow in localized Yudovich spaces*, Calculus of Variations and PDE 63, 168 (2024), <https://link.springer.com/article/10.1007/s00526-024-02750-4>. Checked Assumptions 2.1 and 3.1, Definition 3.2, and Theorem 3.3. Retrieval references: `turn69view0`, `turn70view0`–`turn70view3`.

The needed specialization is global Lagrangian existence for arbitrary signed initial vorticity in L1 intersect Linfinity, with the canonical whole-plane Biot–Savart velocity and bounded vorticity/velocity on finite horizons. The theorem imposes neither compact support nor finite kinetic energy. Our K satisfies its size and two-point estimates; its divergence is zero and there is no boundary. This source supplies a vorticity solution, not an unquoted classical-smoothness theorem. The packet's subsequent regularity argument supplies that upgrade: bounded vorticity gives a global log-Lipschitz modulus, its unique flow and inverse are Hölder on finite horizons, smooth nu0 then gives Hölder transported vorticity, cancellation in grad K gives bounded Hölder velocity gradient, and bootstrapping yields smoothness. Constants may depend on the datum and horizon. There is no uniform-in-smoothing smoothness assertion.

For completeness, the initial velocity trace can be checked without all this bootstrapping. Bounded integrable vorticity gives `V in L-infinity_{t,x}` and `omega_V in L-infinity_t L2`. Integrating transport and applying the bounded Fourier multiplier `-K*div` yields

    V(t)-U0 = -K*div integral_0^t V(s)omega_V(s)ds,
    ||V(t)-U0||_2 <= t ||V||_{L-infinity_{t,x}} ||nu0||_2.

The velocity Fourier identities are justified for finite measures, as in the source packet. Hence `V(t)->U0` strongly in local L2 even when neither field is globally L2. The same multiplier gives `partial_t V in L-infinity_t L2`; also `grad V in L-infinity_t L2`. Thus `partial_t V+(V dot grad)V` is an L2 curl-free field. It is a pressure gradient distribution, so the background really satisfies the velocity Euler equation required for the expansion. No harmonic velocity drift is introduced.

## B4. V plus W, uniform stress, and exact target trace — PASS

Let `W=b_t*v0`, using either decomposition in B1 or B2. Then `curl W=b_t*sigma0`, `div W=0`, and `partial_t W=-4t^3 Delta²W`. Expanding `(V+W) tensor (V+W)` and subtracting the exact background equation gives exactly the candidate stress, with pressure pV. Every cross term is globally integrable because

    ||W||_1 <= ||b||_1 ||v0||_1,
    ||W||_2 <= ||v0||_2,
    ||V tensor W||_1 <= ||V||_infinity ||W||_1.

The derivative stress has L1 norm at most `Ct||sigma0||_M`, by the same curl identity as A. Consequently all the displayed uniform stress and curl bounds hold on `0<t<=T`. In the compact radial decomposition they can be written with `||nu0||_1<=M` and `||sigma0||_M<=2M`.

Strong L2 convergence `W(t)->v0` and the preceding V estimate prove `Ubar(t)->u0` in local L2. The curl has weak-* measure trace `nu0+sigma0=mu0`: V has the Lagrangian initial trace, while the uniformly L1-bounded approximate identity b_t converges weak-* on finite measures. Fourier multiplication or Fubini against compact tests proves

    W(t)=K*(b_t*sigma0),
    Ubar(t)=K*(omega_V(t)+b_t*sigma0).

Fubini is legitimate despite signed b: its absolute convolution with the locally integrable K is bounded at fixed t, uniformly under translation, and sigma0 has finite variation. Thus the asserted canonical normalization is exact. Extending the Euler–Reynolds identity from positive times to tests meeting t=0 follows by the strong local trace and uniform local kinetic-energy/global stress bounds. No support or circulation assumption has entered.

## C. Relative energy and cross norms — mixed scoped verdict

**PASS:** the seed has the uniform relative energy bound `||Ubar(t)-V(t)||_2<=||v0||_2`. This is algebraically W and Plancherel; it does not require conservation of a global energy for V.

**PASS:** V belongs to global L3, uniformly on finite horizons. Here is a self-contained estimate avoiding a black-box Lorentz convolution assertion. For any finite measure of mass M and velocity v=K*mu, split K at `r=M/(pi lambda)`. The far convolution has magnitude at most lambda/2; the near convolution has L1 norm at most rM. Chebyshev gives

    |{x: |v(x)|>lambda}| <= C M²/lambda².

If additionally `||v||_infinity<=B`, the layer-cake identity yields

    ||v||_3³ <= C M² B.

Apply this to the background vorticity. Consequently Hölder gives `||V tensor w||_1<=||V||_3 ||w||_{3/2}`. For the actual seed, `W in L1 intersect L2`, and interpolation yields

    ||W||_{3/2} <= ||W||_1^{1/3} ||W||_2^{2/3}.

**FAIL if inferred without an added perturbation estimate:** finite L2 norm and finite curl variation do not force a perturbation into L^{3/2}, nor force its product with V into L1. Choose a smooth radial swirl w that vanishes near zero and satisfies

    w(x)=e_theta/(r log r),   r>=e².

Its vorticity is smooth and integrable: outside that disk, `curl w=-1/(r²(log r)²)`, and the interpolation region contributes finite mass. The circulation function `2pi r w_theta` tends to zero at infinity, so the total vorticity mass is zero and w is its canonical Biot–Savart velocity. Direct integration gives

    w in L2, curl w in L1 intersect Linfinity,
    w not in L^{3/2}.

Take the smooth background generated by a compact radial unit-mass vorticity. Outside its support, `V=e_theta/(2pi r)`. Then

    integral_{r>=R} |V tensor w| dx
    = integral_R^infinity dr/(r log r) = infinity.

Multiplying w by any positive constant makes both its L2 norm and its curl variation arbitrarily small without repairing the divergent product. Thus a one-step or limiting scheme with only the L2-increment and curl-TV estimates listed in C1–C2 does not automatically close the global-L1-stress induction. It needs the extra L^{3/2} estimate in C3, or a sufficient substitute such as controlled L1 or compact support. This is an actual obstruction to an unspoken inference, not to the seed construction.

**INCONCLUSIVE:** existence of the endpoint repair, summation of its curl cost, global cross-term control along its iteration, and exact initial trace of its final solution. Those claims are explicitly deferred by the candidate. Nothing in this audit proves them, and the valid initial seed must not be reported as resolving the target.

## Audit boundary

The narrow seed result survives the hostile checks. The key new obligation sharpened by this audit is global integrability of every perturbation against the infinite-energy background; L2 and curl-TV alone are insufficient. This audit is one independent pass on this packet, not the four-pass certification required before a complete solution claim.
