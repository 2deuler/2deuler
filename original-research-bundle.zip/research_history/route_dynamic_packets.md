# Dynamic neutral packets: escape, rotation and a three-vortex reduction

Worker E follow-up, 2026-10-08. This artifact keeps `route_primary_interfaces.md` frozen. These are limited mathematical probes, not a proof of the authoritative existence problem. Point vortices themselves are not in H^{-1}(R²), so point-vortex conclusions are explicitly model-level until a uniform regularization/interface argument is supplied. All calculations below are direct derivations unless a source is named.

## 1. A quantitative escape lemma for finite-energy traveling profiles

**Statement.** Let U∈L²(R²;R²), c≠0, x₀∈R², and

u_ε(t,x)=ε^{-1}U((x−x₀−ct/ε)/ε).

For every ball B(a,R), every T>0, and ε>0,

∫₀ᵀ∫_{B(a,R)}|u_ε|² dxdt ≤ (2Rε/|c|)∥U∥²₂.

**Proof.** Substitute x=x₀+ct/ε+εz and use Tonelli:

∫₀ᵀ∫_{B(a,R)}|u_ε|² dxdt
=∫|U(z)|² |{t∈[0,T]:x₀+ct/ε+εz∈B(a,R)}| dz.

For fixed z the line travels at speed |c|/ε, and its intersection with the ball has length at most 2R. The time-set measure is at most 2Rε/|c|. This proves the claim.

**Euler interface.** If U(x−ct) is an exact traveling Euler solution, Euler scaling shows that u_ε is also exact. If curl U∈M, then ∥curl u_ε(t)∥_M=∥curl U∥_M and ∥u_ε(t)∥₂=∥U∥₂. Nevertheless u_ε→0 strongly in L²_loc in space-time. Thus this coherent neutral concentration mechanism creates no interior space-time stress defect.

**Primary example.** Li–Song–Zhou, *On the stability of Lamb–Chaplygin dipole for the 2D Euler equation*, arXiv:2605.01491v1, Section 1.1, formulas (1.5)–(1.8), explicitly gives an exact speed-one traveling profile with compactly supported bounded vorticity, odd in x₂, and finite kinetic energy. URL: https://arxiv.org/pdf/2605.01491v1 . Only that explicit-profile interface is used; none of its stability theorems is assumed. The profile is not asserted to be C∞ across its support boundary.

**Mismatch with fixed-datum approximation.** The scaled initial velocities here have nonvanishing global energy and vary with ε. This family alone is not a strongly convergent regularization of one fixed datum. It is a test of the local mechanism, not a counterexample or existence construction for the target.

## 2. Neutral point vortices: exact invariant calculations

Consider distinct points x_i(t) with fixed nonzero real strengths Γ_i, obeying

x_i'=Σ_{j≠i}Γ_j K(x_i−x_j),  K(z)=Jz/(2π|z|²),  J=[[0,−1],[1,0]].

Write

Γ=Σ_iΓ_i,
P=Σ_iΓ_i x_i,
I=Σ_iΓ_i|x_i|²,
L=Σ_{i<j}Γ_iΓ_j,
H=−(1/(2π))Σ_{i<j}Γ_iΓ_j log|x_i−x_j|.

Pairwise antisymmetry gives P'=0 and I'=0. Differentiating H and using x_i'=−Γ_i^{-1}J∇_{x_i}H gives H'=0. A separate pair calculation gives the virial identity

Σ_iΓ_i x_i×x_i'=L/(2π),

where v×w=v₁w₂−v₂w₁. Indeed the pair (i,j) contributes Γ_iΓ_j(x_i−x_j)×J(x_i−x_j)/(2π|x_i−x_j|²)=Γ_iΓ_j/(2π).

If Γ=0, then

L=−(1/2)Σ_iΓ_i²<0.

Consequences for neutral configurations:

1. **No stationary point configuration.** If every x_i'=0, the virial identity would give L=0, impossible.
2. **Rigid translation.** If x_i(t)=b_i+Vt, conservation of I gives P·V=0, and the virial identity gives P×V=L/(2π). Therefore P≠0 and

   V=[L/(2π|P|²)]JP.

   If all b_i lie in a disk of radius ε and M=Σ|Γ_i|, then |P|≤Mε and

   |V|≥ΣΓ_i²/(4πMε).

3. **Rigid rotation.** If x_i=c+R_{Ωt}b_i and Ω≠0, conservation of P forces ΣΓ_i b_i=0; in the neutral case this says P=0. The virial identity yields ΩI_c=L/(2π), with I_c=ΣΓ_i|b_i|². If the shape has diameter O(ε), translation invariance of I when Γ=P=0 gives |I_c|≤CMε², hence |Ω|≥c/ε² for fixed strengths.
4. **Fixed-shape total collapse is impossible.** If every mutual distance is ρ(t) times a fixed positive distance, then H(t)=H_shape−[L/(2π)]logρ(t). Since L≠0 and H is constant, ρ cannot vary, much less tend to zero. This does not rule out arbitrary multiscale partial collisions in systems with four or more vortices.

These consequences cover all N, but they do not classify all motions.

**Essential smooth/point distinction.** Smooth neutral radial Euler eddies can be stationary. The discrete virial L excludes self-interactions; a continuous vorticity’s analogous full pair sum has different cancellation. Therefore the point-vortex no-stationarity assertion must never be transferred to smooth Euler packets.

## 3. Two vortices: complete neutral dynamics

For Γ₊=γ, Γ₋=−γ, γ≠0, set d=x₊−x₋ and c=(x₊+x₋)/2. The equations give

d'=0,
c'=−γK(d).

Every collision-free neutral two-vortex system is a rigidly translating dipole. If |d|=εd₀, its speed is |γ|/(2πεd₀). It neither rotates rigidly nor collapses. This direct calculation agrees with Section 2 because P=γd and L=−γ².

## 4. A complete reduction for neutral triples on regular energy levels

After reversing every strength and time if needed, write the three strengths as a,b,−s with a,b>0 and s=a+b. Define

C=(a x₁+b x₂)/s,
d=C−x₃=P/s,
z=x₁−x₂,
α=a/s, β=b/s.

Then d is a fixed vector, and

x₁=C+βz,  x₂=C−αz,  x₃=C−d.

The reduced equations, obtained directly from the three vortex equations, are

z'=s[K(z)−K(d+βz)+K(d−αz)],
C'=−aK(d+βz)−bK(d−αz).

The reduced Hamiltonian is

h(z)=−(1/(2π))[ab log|z|−as log|d+βz|−bs log|d−αz|],

and direct differentiation gives

z'=−[s/(ab)]J∇h(z).

### 4.1 Zero impulse: every configuration is a collinear rigid rotation

If d=0, the reconstruction formulas force the three positions to be collinear. The reduced equation simplifies to

z'=ΩJz,
Ω=−s(a²+ab+b²)/(2πab|z|²).

Thus |z| is constant and Ω≠0 is constant. Moreover C' is a constant multiple of Jz, hence integration reconstructs a rigid rotation around one fixed center. In particular no collision occurs.

Example: strengths γ,γ,−2γ at positions re₁,−re₁,0 rotate with Ω=−3γ/(4πr²).

### 4.2 Nonzero impulse: relative configurations stay in a compact collision-free set

Suppose d≠0. The three excluded reduced positions are

z=0,
z=−d/β,
z=d/α.

They are distinct. The asymptotics are

h(z)→+∞ as z→0,
h(z)→−∞ as z→−d/β or z→d/α,
h(z)→+∞ as |z|→∞.

The final assertion follows because the coefficient of log|z| in h is (s²−ab)/(2π)>0. Therefore every finite energy level {h=h₀} lies in a bounded set separated from all three collision positions. Smooth ODE continuation then gives global relative motion, with all mutual distances bounded above and bounded away from zero. The reconstruction velocity C'(z) stays bounded, so absolute positions also continue for all finite times.

### 4.3 The only rigid translations are equilateral triples

Rigid translation is equivalent to z'=0. Identify R² with C and rotate coordinates if desired. Using K(w)=i/(2π conjugate(w)), the equation z'=0 reduces, after conjugation and multiplication of nonzero denominators, to

d²+(β−α)dz+(1−αβ)z²=0.

Hence

z/d=[(α−β)±i√3]/[2(1−αβ)].

Equivalently,

d/z=(α−β)/2 ∓ i√3/2.

Since x₃ lies at C−d, while the midpoint of x₁,x₂ is C+(β−α)z/2, this is exactly the condition that x₃ lies at one of the two equilateral vertices above/below the segment x₁x₂. Conversely, in an equilateral triple of side ℓ,

x_i'=J(Γx_i−P)/(2πℓ²)=−JP/(2πℓ²),

independent of i, proving sufficiency.

### 4.4 Exact escape-or-bounded dichotomy on regular levels

Assume h₀ is a regular value of h. A connected component of {h=h₀} is a compact smooth one-dimensional manifold without boundary, hence a circle. The vector field z'=−sJ∇h/(ab) is nonzero on it, so z(t) is periodic with some finite period τ.

Because C'=F(z(t)) is then periodic, define

V̄=(1/τ)∫₀^τF(z(t))dt.

Integration gives C(t)=V̄t+p(t), where p is bounded and τ-periodic. Each x_i(t)=V̄t+p_i(t), with bounded periodic p_i. The exact point-vortex scaling is

x_i^ε(t)=x₀+εx_i(t/ε²)=x₀+V̄t/ε+εp_i(t/ε²).

There are two rigorous alternatives:

- If V̄≠0, the entire packet stays within Cε of a line moving at speed |V̄|/ε. The times when any vortex lies in B(a,R) have total length at most 2(R+Cε)ε/|V̄|.
- If V̄=0, every vortex remains in B(x₀,Cε) for all time. Section 6 shows that the time-averaged internal angular nonlinearity vanishes against compact smooth test functions.

This is an actual model-level dichotomy on regular neutral-three-vortex energy levels. Critical levels containing separatrices are excluded. No assertion has been made that V̄ must be nonzero for every nonzero-impulse regular orbit.

## 5. Four vortices: checked examples and the limit of the classification

For four neutral nonzero strengths, the invariant conclusions of Section 2 still exclude a stationary point configuration and fixed-shape total collapse. They determine the velocity of any rigid translation and require P=0 for any rigid rotation. They do not exclude partial triple collisions or chaotic internal dynamics.

A concrete neutral rotating quadruple consists of three equal strengths γ at the vertices of an equilateral triangle on the circle of radius r and one strength −3γ at its center. The three outer vortices alone rotate with angular speed γ/(2πr²); the central vortex adds −3γ/(2πr²). Their sum is

Ω=−γ/(πr²).

The center remains fixed because the three outer induced velocities cancel there. This directly verifies an exact bounded neutral four-vortex microcluster.

A pair of dipoles can undergo close interactions; no complete four-vortex escape-or-isotropize assertion is proved here. Section 7 addresses a controlled-separation regime that applies to two dipoles when each pair sees a uniformly Lipschitz external field.

## 6. Weighted angular cancellation for a bounded neutral point packet

Define the signed quadratic-moment matrix

Q(t)=Σ_iΓ_i x_i(t)⊗x_i(t).

Pairwise differentiation gives the exact identity

Q'(t)=(1/(2π))Σ_{i<j}Γ_iΓ_j [Je_{ij}⊗e_{ij}+e_{ij}⊗Je_{ij}],

where e_{ij}=(x_i−x_j)/|x_i−x_j|. The right side is symmetric and trace free. In terms of

A(t)=Σ_{i<j}Γ_iΓ_j[e_{ij}⊗e_{ij}−I₂/2],

the identity is Q'=(JA−AJ)/(2π). On symmetric trace-free 2×2 matrices, the map A↦JA−AJ is invertible; in fact applying it twice gives −4A.

Suppose |x_i(t)|≤C for all t and the strengths are fixed. For the scaled bounded packet x_i^ε(t)=x₀+εx_i(t/ε²), translation of the coordinates to x₀ gives

Q_ε(t)=ε²Q(t/ε²),
Q_ε'(t)=Q'(t/ε²).

For χ∈C_c^1((0,T)), integration by parts yields

|∫χ(t)A(t/ε²)dt|≤C_Γ ε²∥χ'∥₁.

For a scalar test ψ(t,x), the internal point-vortex weak nonlinearity is

N_ε(ψ)=Σ_{i<j}Γ_iΓ_j K(x_i^ε−x_j^ε)·[∇ψ(t,x_i^ε)−∇ψ(t,x_j^ε)].

Taylor expansion around x₀ gives a leading contraction of D²ψ(t,x₀) with the angular matrix above and a remainder bounded by C M² ε∥D³ψ∥∞, where M=Σ|Γ_i|. The bound uses |x_i^ε−x_j^ε| to cancel the 1/|x_i^ε−x_j^ε| kernel singularity, so no positive minimum separation is needed for the estimate at a collision-free time. Integrating in time and using the moment identity gives

|∫₀ᵀN_ε(ψ)dt|
≤C ε²∥∂_tD²ψ(·,x₀)∥₁+C M²Tε∥D³ψ∥∞.

Thus bounded neutral point microclusters have vanishing weak nonlinear contribution. In the escaping alternative of Section 4.4, the same contribution is bounded pointwise by CM²∥D²ψ∥∞ and is supported in a time set of size O(ε); it again vanishes.

This quantity is the symmetrized point-vorticity interaction, not a finite-energy velocity stress: point velocities are not in L² near the vortices. A smoothing theorem controlling core effects is still required before treating it as an Euler approximation lemma.

## 7. Controlled-separation lemma: a dipole in a bounded Lipschitz external field

**Statement.** Fix γ≠0, d₀>0 and T>0. Let b(t,x) be measurable in t, spatially Lipschitz, with |b|≤B and Lip_x b≤L. Consider a neutral point dipole satisfying

x₊'=−γK(x₊−x₋)+b(t,x₊),
x₋'=−γK(x₊−x₋)+b(t,x₋),
|x₊(0)−x₋(0)|=εd₀.

Then for every fixed R>0 and all sufficiently small ε,

|{t∈[0,T]:(x₊(t)+x₋(t))/2∈B(a,R)}|≤C ε,

where C depends only on R,T,γ,d₀,B,L. The same conclusion holds with either vortex in the ball. No time derivative of b is assumed.

**Proof.** Let d=x₊−x₋, c=(x₊+x₋)/2, V=−γK(d), and b̄=(b(x₊)+b(x₋))/2. Then

d'=b(x₊)−b(x₋),
c'=V+b̄,
|d'|≤L|d|.

Gronwall, applied both forward and backward to the scalar distance, yields

εd₀e^{-LT}≤|d(t)|≤εd₀e^{LT}.

Set v₀=|γ|e^{-LT}/(2πd₀), v₁=|γ|e^{LT}/(2πd₀). Then

v₀/ε≤|V|≤v₁/ε,
|V'|≤Lv₁/ε,

because ∥DK(d)∥=1/(2π|d|²). If L>0, partition [0,T] into at most N=1+ceil(4TLv₁/v₀) intervals of length at most h=v₀/(4Lv₁); if L=0 use one interval. On an interval starting at t_k, put e_k=V(t_k)/|V(t_k)|. Then

V(t)·e_k≥3v₀/(4ε).

For ε≤v₀/(4B) (with no restriction when B=0),

c'(t)·e_k≥v₀/(2ε).

The projection c·e_k is strictly increasing, and while c lies in B(a,R) that projection lies in an interval of length 2R. Consequently the residence time in that interval is at most 4Rε/v₀. Sum over at most N intervals. If x₊ or x₋ is in the ball, the center is in the ball enlarged by εd₀e^{LT}/2; this changes only the constant. QED.

**Nonlinearity consequence.** The dipole’s self-interaction against ψ is bounded by Cγ²∥D²ψ∥∞ and vanishes unless the center lies within O(ε) of the compact spatial support of ∇ψ. Its time integral is therefore O(ε). The interaction with b is itself bounded by

|γ| |b(x₊)·∇ψ(x₊)−b(x₋)·∇ψ(x₋)|
≤|γ|(L∥∇ψ∥∞+B∥D²ψ∥∞)|d|=O(ε).

**Separated-vorticity interface.** If b=K*η and η has total variation at most M_ext and stays at distance at least d_*>0 from both vortices and the connecting segment, then in that region

|b|≤M_ext/(2πd_*),
Lip_x b≤C M_ext/d_*².

Thus bounded total variation plus a uniform separation hypothesis gives the desired escape estimate. Bounded total variation alone does not give these constants: close encounters are the first missing interface.

## 8. Fast rotation of a genuine finite-energy profile

Let U∈L²(R²), Ω≠0, and define

u_ε(t,x)=ε^{-1}R_{Ωt/ε²}U(R_{−Ωt/ε²}(x−a)/ε).

Suppose this is an exact uniformly rotating Euler family; the following stress computation only uses the formula and finite energy. Write S=∫U⊗U and E=tr S. For every compact smooth matrix test A(t,x), changing variables and using dominated convergence in the finite measure |U(z)|²dzdt gives

∫A:(u_ε⊗u_ε)dxdt
−∫A(t,a):R_{Ωt/ε²}S R_{Ωt/ε²}ᵀdt →0.

The trace-free part of the rotated 2×2 tensor oscillates with frequency 2Ω/ε². Integration by parts in t gives convergence of its pairing with A(t,a) to zero. Hence

u_ε⊗u_ε ⇀* (E/2)I₂ dt δ_a.

If ∫|z||U(z)|²dz<∞, the spatial replacement error is O(ε), and the angular averaging error is O(ε²/|Ω|) for fixed smooth A. Thus this coherent rotation mechanism produces only isotropic concentration. Existence of arbitrary signed rotating profiles is not assumed or proved here.

## 9. What the executed probes do and do not establish

**Established as written, pending independent audit:** escape for scaled finite-energy translating profiles; exact neutral point-vortex invariant constraints; full neutral-dipole dynamics; the neutral-triple reduction and regular-level escape-or-bounded dichotomy; weighted angular cancellation of bounded point microclusters; quantitative dipole escape under controlled external separation; isotropic stress averaging for finite-energy uniformly rotating profiles.

**Still missing for the target:** an arbitrary approximation cannot yet be decomposed into finitely many such packets with uniformly controlled interactions. The uniform external Lipschitz bound is precisely what general signed measure data do not supply. Four-vortex close encounters and arbitrary large clusters are not classified. Point-vortex atoms violate the initial H^{-1} hypothesis, and regularization must preserve the delicate stress conclusions uniformly. None of these missing interfaces is repaired by the calculations above.

**Decisive next probe:** quantify a close interaction of a size-ε dipole with a second neutral packet whose strength is comparable, tracking not merely center deflection but the integrated traceless interaction tensor. Bounded TV permits strong interactions at scale ε; therefore a statement that rapid turning always requires unbounded TV would need proof and is not accepted. Repeated encounters may transfer angular stress between packets, suggesting that an interaction-graph virial identity, rather than individual trajectory tracking, is the correct observable.

## 10. Executed four-vortex scattering probe: a right-angle turn with bounded TV

The previous proposed next probe admits the following exact symmetric calculation. Take γ>0, positions

x₁=(x,y),  x₂=(−x,y),  x₃=(−x,−y),  x₄=(x,−y),

and strengths (γ,−γ,γ,−γ), with x,y>0. Reflection and central symmetries preserve this configuration class. Direct substitution in the point-vortex ODE gives

x'=γx²/[4πy(x²+y²)],
y'=−γy²/[4πx(x²+y²)].

In particular x increases and y decreases. Differentiation shows exactly

d/dt (x^{-2}+y^{-2})=0.

Write the invariant as x^{-2}+y^{-2}=a^{-2}. Then x,y>a, and the trajectory has

x(t)→a, y(t)→∞ as t→−∞,
x(t)→∞, y(t)→a as t→+∞.

To justify the asymptotics, monotonicity and the invariant leave only those possible limits; finite positive limits of both coordinates would contradict x'>0. The vector field is bounded since x,y≥a, so reaching infinity takes infinite time. At t=0 choose x=y=√2a. For t≤0 the vortices form two incoming dipoles with horizontal separation asymptotic to 2a, traveling vertically toward each other. For t≥0 they form two outgoing dipoles with vertical separation asymptotic to 2a, traveling horizontally apart. The partners exchange and each outgoing dipole is turned by a right angle relative to an incoming dipole.

All four strengths are fixed, total circulation is zero, total variation is 4γ, and the minimum pair separation is at least 2a. Thus a rapid order-one directional change does **not** by itself require unbounded TV. Taking a=ε makes the interaction region O(ε) and its characteristic interaction time O(ε²).

This exact scattering does not defeat the escape mechanism. If t≥0, then x≥y, y≤√2a, and

x'≥γ/(8π√2a).

If t≤0, then y≥x, x≤√2a, and

−y'≥γ/(8π√2a).

Therefore the total time during which any of the four points lies in B(0,R) is at most

16π√2Ra/γ.

Indeed their radii are identical, and membership in that ball implies x≤R and y≤R. The incoming and outgoing halves each have at most the displayed inverse-speed crossing time. Consequently the bounded symmetrized point-vorticity nonlinearity contributes O(a) against any smooth test supported in that fixed ball. A finite right-angle scattering creates no persistent local nonlinear defect.

**Updated disposition.** One-close-encounter turning is now explicitly understood and does not require TV growth. The unresolved issue is an unbounded sequence of recurrent or cascading encounters in a fixed macroscopic region, or a many-packet limit. The four-vortex calculation gives no estimate excluding that scenario.
