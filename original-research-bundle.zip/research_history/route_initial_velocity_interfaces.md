# Initial velocity, low frequencies, and every-time closure

Worker: initial_velocity_interfaces. Status: self-contained claim packet for independent verification; no resolution of the main existence question is asserted.

## 1. Conventions and data normalization

Write \(x^\perp=(-x_2,x_1)\), \(K(x)=x^\perp/(2\pi|x|^2)\), and use
\[
\widehat f(\xi)=\int e^{-ix\cdot\xi}f(x)\,dx,
\qquad
\|f\|_{H^{-1}}^2=(2\pi)^{-2}\int\frac{|\widehat f(\xi)|^2}{1+|\xi|^2}\,d\xi.
\]
The data space is the inhomogeneous space stated in the target. Neither zero circulation nor finite global kinetic energy follows from its hypotheses.

### Lemma 1: canonical local velocity and quantitative estimate

For every finite signed measure \(\mu\), the integral
\[
u(x)=\int K(x-y)\,d\mu(y)
\]
is absolutely convergent for almost every \(x\), defines an \(L^1_{\rm loc}\) vector field, and satisfies \(\operatorname{div}u=0\), \(\operatorname{curl}u=\mu\) in distributions. If additionally \(\mu\in H^{-1}\), then \(u\in L^2_{\rm loc}\). With the above normalization, for every ball \(B_R(a)\),
\[
\|u\|_{L^2(B_R(a))}
\leq \frac{R}{\sqrt\pi}\|\mu\|_{\mathcal M}
       +\sqrt2\|\mu\|_{H^{-1}}.
\tag{1}
\]

**Proof.** For every fixed bounded ball \(B\),
\(\sup_y\int_B |K(x-y)|\,dx<\infty\): integrate the locally integrable singularity on a larger fixed ball when \(y\) is near \(B\), and use the bounded far-field kernel when \(y\) is far away. Tonelli gives local integrability and almost-everywhere absolute convergence. The distributional identities for \(K\) follow from divergence zero off the origin, tangency to circles, and circulation \(\int_{\partial B_r}K\cdot\tau\,ds=1\); integrating against compact tests and then against \(\mu\) gives the claimed divergence and curl.

The Fourier transform of \(K\) is the locally integrable multiplier
\[
\widehat K(\xi)=-i\frac{\xi^\perp}{|\xi|^2}=:m(\xi).
\]
One way to check the possible zero-frequency ambiguity is to use \(K=\nabla^\perp[(2\pi)^{-1}\log|x|]\), or to solve its divergence/curl identities away from \(\xi=0\) and use homogeneity: both \(\widehat K\) and \(m\) have degree \(-1\), whereas a distribution supported at the origin is a finite sum of derivatives of \(\delta_0\), whose homogeneous degrees are \(-2-k\). Thus no supported-at-zero term remains.

For a compactly supported measure, convolution and Fourier transform give \(\widehat{K*\mu}=m\widehat\mu\). For general finite \(\mu\), truncate to \(\mu_N=\mathbf1_{B_N}\mu\). Then \(\|\mu_N-\mu\|_{\mathcal M}\to0\), so the preceding local integrability estimate gives \(K*\mu_N\to K*\mu\) in \(L^1_{\rm loc}\). Also \(\widehat\mu_N\to\widehat\mu\) uniformly, and \(m\) is integrable against every Schwartz test, so \(m\widehat\mu_N\to m\widehat\mu\) in tempered distributions. For completeness, the physical convergence is also tempered: for every Schwartz \(\phi\), \(\sup_y\int |K(x-y)\phi(x)|\,dx<\infty\), by splitting \(|x-y|<1\) and its complement. Hence the Fourier identity holds for every finite measure.

Choose real radial \(\chi\in C_c^\infty\), \(0\leq\chi\leq1\), with \(\chi=1\) on \(B_1\) and support in \(B_2\). Set
\[
U=\mathcal F^{-1}(\chi m\widehat\mu),\qquad
v=\mathcal F^{-1}((1-\chi)m\widehat\mu).
\]
The low-frequency integrand lies in \(L^1\), and
\[
\|U\|_\infty\leq(2\pi)^{-2}\|\mu\|_{\mathcal M}
\int_{B_2}|\xi|^{-1}\,d\xi
=\pi^{-1}\|\mu\|_{\mathcal M}.
\tag{2}
\]
Because \(1-\chi=0\) on \(B_1\),
\[
\|v\|_2^2
=(2\pi)^{-2}\int\frac{|1-\chi|^2}{|\xi|^2}|\widehat\mu|^2\,d\xi
\leq 2\|\mu\|_{H^{-1}}^2.
\tag{3}
\]
Since \(u=U+v\) as distributions, (1) follows. This argument does not divide by total circulation and includes the zero measure. \(\square\)

### Lemma 2: no atoms

Every finite signed measure in \(H^{-1}(\mathbb R^2)\) is atomless.

**Proof.** Fix \(a\). Choose smooth \(0\leq\phi_\varepsilon\leq1\), equal to one on \(B_{\varepsilon^2}(a)\), supported in \(B_\varepsilon(a)\), with logarithmic interpolation between the two circles. Explicitly, with \(L=|\log\varepsilon|\) and a smooth cutoff \(\zeta=1\) on \(( -\infty,0]\), \(\zeta=0\) on \([1,\infty)\), use \(\zeta((\log|x-a|+2L)/L)\) off \(a\), extended constantly near \(a\). Then \(\|\phi_\varepsilon\|_2^2\leq\pi\varepsilon^2\) and \(\|\nabla\phi_\varepsilon\|_2^2\leq C/L\). Thus \(\langle\mu,\phi_\varepsilon\rangle\to0\) by \(H^{-1}\)-\(H^1\) duality. On the other hand, dominated convergence against the finite measure \(|\mu|\) gives \(\int\phi_\varepsilon\,d\mu\to\mu(\{a\})\). Hence \(\mu(\{a\})=0\). \(\square\)

## 2. Explicit obstruction to a compact circulation background

### Proposition 3: subtracting a compact circulation blob need not give finite energy

Define the nonnegative radial density
\[
f(x)=\frac{\mathbf1_{\{|x|\geq e\}}}
 {4\pi |x|^2(\log|x|)^{3/2}}.
\tag{4}
\]
Then \(f\in L^1\cap L^\infty\subset H^{-1}\), \(\int f=1\), but, for every compactly supported smooth radial \(\eta\) with \(\int\eta=1\),
\[
K*(f-\eta)\notin L^2(\mathbb R^2).
\tag{5}
\]
Consequently \(f-\eta\notin\dot H^{-1}\), although it is a zero-mass element of \(\mathcal M\cap H^{-1}\).

**Proof.** Polar integration gives
\[
\int_{|x|\geq r} f(x)\,dx
=\frac12\int_r^\infty\frac{ds}{s(\log s)^{3/2}}
=\frac1{\sqrt{\log r}},\qquad r\geq e.
\tag{6}
\]
Taking \(r=e\) proves mass one; boundedness and integrability imply \(L^2\), hence \(H^{-1}\). For a radial vorticity \(g\), its Biot–Savart velocity is
\[
K*g(x)=\frac{x^\perp}{2\pi|x|^2}\int_{|y|\leq|x|}g(y)\,dy.
\tag{7}
\]
Indeed, rotation invariance and tangency give a radial swirl, and its circulation is the enclosed mass; alternatively angular integration in the defining convolution gives (7). For \(r\) outside both \(B_e\) and the support of \(\eta\), the enclosed mass of \(f-\eta\) is \(-1/\sqrt{\log r}\). Therefore
\[
\int_{|x|\geq R}|K*(f-\eta)|^2\,dx
=\frac1{2\pi}\int_R^\infty\frac{dr}{r\log r}
=\infty.
\tag{8}
\]
The equivalence here with failure of the Fourier seminorm \((2\pi)^{-2}\int|\widehat{f-\eta}|^2/|\xi|^2\) follows directly from the Fourier identity in Lemma 1 and Plancherel, understood as an extended nonnegative integral. \(\square\)

The radial assumption on the compact correction is unnecessary for the failure: for any smooth compactly supported unit-mass \(\eta\), the circulation of \(K*(f-\eta)\) around every sufficiently large circle is \(-1/\sqrt{\log r}\). Cauchy–Schwarz on the circle gives
\(\int_{\partial B_r}|u|^2\,ds\geq[2\pi r\log r]^{-1}\), and integrating in \(r\) gives the same divergence. This supplies a second direct check of the obstruction.

**Scope warning.** This example is not a counterexample to the target. Its radial velocity is a stationary Euler solution: for swirl \(u=a(r)e_\theta\), set \(p'(r)=a(r)^2/r\), so \((u\cdot\nabla)u+\nabla p=0\). The example only disproves a proposed universal finite-energy reduction.

## 3. A low-frequency background that does work

### Lemma 4: bounded smooth background with finite-energy perturbation

For every \(\mu\in\mathcal M\cap H^{-1}\), use the \(U\) and \(v\) from Lemma 1. Then
\[
u=U+v,\qquad v\in L^2,
\]
and \(U\) is smooth, real, divergence free, bounded, and tends to zero at infinity. Moreover,
\[
\nabla U\in L^2\cap L^\infty,
\qquad \Delta U\in L^2,
\qquad (U\cdot\nabla)U\in L^2.
\tag{9}
\]
All displayed norms of \(U\) are bounded by constants depending only on \(\chi\) times \(\|\mu\|_{\mathcal M}\), except the quadratic bound \(\|(U\cdot\nabla)U\|_2\leq C_\chi\|\mu\|_{\mathcal M}^2\).

**Proof.** The Fourier multiplier for \(U\) is integrable at zero and compactly supported. Multiplying it by any positive-order monomial in \(\xi\) gives a bounded compactly supported function times \(\widehat\mu\); this belongs to both \(L^1\) and \(L^2\). Fourier inversion, differentiation under the integral, the Riemann–Lebesgue lemma, and Plancherel prove all smoothness, decay, \(L^\infty\), and \(L^2\) claims. The multiplier is perpendicular to \(\xi\), proving divergence zero. Realness follows from the conjugate symmetry of \(\widehat\mu\), since \(\chi\) is real and even. Finally use \(\|(U\cdot\nabla)U\|_2\leq\|U\|_\infty\|\nabla U\|_2\). The estimate for \(v\) is (3). \(\square\)

### Lemma 5: compatibility with ordinary mollification

Let \(\rho\in C_c^\infty\) be nonnegative with mass one and \(\rho_\varepsilon(x)=\varepsilon^{-2}\rho(x/\varepsilon)\). Set \(u_0^\varepsilon=K*(\rho_\varepsilon*\mu)=\rho_\varepsilon*u\). Then
\[
u_0^\varepsilon-U
=\rho_\varepsilon*v+(\rho_\varepsilon*U-U)
\longrightarrow v \quad\text{strongly in }L^2.
\tag{10}
\]
In particular, the relative initial kinetic energies are uniformly bounded.

**Proof.** The convolution identity follows either by Fubini using the local integrability estimates for \(K\), or by the Fourier identity. Approximation of the identity gives \(\rho_\varepsilon*v\to v\) in \(L^2\). Since \(\nabla U\in L^2\), the fundamental theorem of calculus and Minkowski give
\[
\|U(\cdot-h)-U\|_2\leq |h|\|\nabla U\|_2,
\]
even though \(U\) itself need not be in \(L^2\). Thus
\[
\|\rho_\varepsilon*U-U\|_2
\leq \varepsilon\!\left(\int |z|\rho(z)\,dz\right)\!\|\nabla U\|_2\to0.
\]
This proves (10). \(\square\)

### Lemma 6: relative energy estimate (conditional a priori statement)

Let \(U\) satisfy Lemma 4 and be fixed in time. Suppose \(u=U+v\) is a sufficiently regular Euler or Navier–Stokes solution for which the integrations below are justified, with viscosity \(0\leq\nu\leq1\), and \(v(0)\in L^2\). Then
\[
\frac12\frac d{dt}\|v\|_2^2+\nu\|\nabla v\|_2^2
=-\int v\cdot(v\cdot\nabla U)
 -\int v\cdot(U\cdot\nabla U)
 +\nu\int v\cdot\Delta U.
\tag{11}
\]
With \(a=\|\nabla U\|_\infty\) and
\(F=\|U\|_\infty\|\nabla U\|_2+\|\Delta U\|_2\),
\[
\|v(t)\|_2\leq e^{at}\bigl(\|v(0)\|_2+Ft\bigr).
\tag{12}
\]
For Euler the \(\Delta U\) contribution can be omitted. Formula (11) follows by subtracting the time-independent field \(U\), testing by \(v\), and canceling the transport terms using \(\operatorname{div}(U+v)=0\). Estimate the three remaining terms by \(a\|v\|_2^2+F\|v\|_2\); regularizing the square root at zero gives (12). Spatial cutoff justification is available when the solution and \(U\) are bounded and \(v\in L^2\), with the usual additional viscous gradient integrability in the Navier–Stokes case.

**Exact downstream use and limitation.** Together with Lemma 5, this supplies uniform local kinetic-energy bounds for any classical approximation family to which (11) applies. It handles noncompact initial tails without imposing a hidden homogeneous \(H^{-1}\) condition. It does not itself prove existence of such an approximation family, continuation, or convergence of its quadratic nonlinearity. Those are separate interfaces.

## 4. Closure of the prescribed Biot–Savart normalization

### Lemma 7: distributional closure under bounded total variation

Suppose \(\mu_n\in\mathcal M(\mathbb R^2)\), \(\sup_n\|\mu_n\|_{\mathcal M}\leq M\), \(u_n=K*\mu_n\), and \(u_n\to u\) in distributions. Suppose also \(\operatorname{curl}u_n=\mu_n\), as is automatic for these convolutions. Then \(\mu=\operatorname{curl}u\) is a finite signed measure with \(\|\mu\|_{\mathcal M}\leq M\),
\[
\mu_n\stackrel{*}{\rightharpoonup}\mu\quad\text{in }\mathcal M=C_0(\mathbb R^2)^*,
\qquad u=K*\mu.
\tag{13}
\]
In particular this applies when \(u_n\rightharpoonup u\) weakly in \(L^2_{\rm loc}\). Neither spatial tightness nor convergence of total circulation is required.

**Proof.** For \(\varphi\in C_c^\infty\), distributional convergence gives
\(\langle\mu_n,\varphi\rangle\to\langle\operatorname{curl}u,\varphi\rangle\), and
\(|\langle\mu_n,\varphi\rangle|\leq M\|\varphi\|_\infty\). Hence the limit extends uniquely to a bounded functional on \(C_0\), represented by a finite measure \(\mu\) with norm at most \(M\). Uniform approximation of \(C_0\) functions by compact smooth functions and the uniform variation bound then give weak-* convergence of the entire sequence.

For a compact smooth vector test \(\psi\), define
\[
G_\psi(y)=\int K(x-y)\cdot\psi(x)\,dx.
\]
This function is continuous: convolution of the locally integrable kernel with a compact smooth test is continuous, which can also be checked by splitting off a ball of radius \(\delta\), bounding its contribution by \(C\delta\|\psi\|_\infty\), and applying ordinary continuity on the complement. Moreover \(G_\psi(y)=O(|y|^{-1})\) as \(|y|\to\infty\), because \(\psi\) is compactly supported. Thus \(G_\psi\in C_0\). Fubini and weak-* convergence yield
\[
\langle u,\psi\rangle
=\lim_n\int G_\psi\,d\mu_n
=\int G_\psi\,d\mu
=\langle K*\mu,\psi\rangle.
\]
This proves (13). \(\square\)

### Lemma 8: every-time representative

Suppose \(u\in C_w([0,T];L^2_{\rm loc})\). Suppose that for almost every \(t\in[0,T]\), \(\omega(t)=\operatorname{curl}u(t)\in\mathcal M\), \(u(t)=K*\omega(t)\), and \(\|\omega(t)\|_{\mathcal M}\leq M\). Then, defining \(\omega(t)=\operatorname{curl}u(t)\) for every \(t\), all three conclusions hold for every time, and
\[
\omega\in C([0,T];\mathcal M\text{-weak-*}).
\tag{14}
\]

**Proof.** At any prescribed \(t\), choose \(t_n\to t\) in the full-measure set of good times; this can be done one-sided at the endpoints. Weak local \(L^2\) continuity implies \(u(t_n)\to u(t)\) in distributions. Lemma 7 gives the required measure, norm bound, and Biot–Savart equality at \(t\). For any sequence of times \(s_n\to s\), now all times have the uniform measure bound; distributional convergence of their curls plus \(C_0\)-density gives \(\omega(s_n)\to\omega(s)\) weak-*. This proves (14). \(\square\)

### Optional stronger subcritical closure

If \(\mu_n\stackrel{*}{\rightharpoonup}\mu\) in \(\mathcal M\) and their norms are bounded, then
\[
K*\mu_n\to K*\mu\quad\text{strongly in }L^p_{\rm loc},\qquad 1\leq p<2.
\tag{15}
\]
To verify this, choose a smooth truncation of \(K\) which vanishes on \(B_\delta\) and agrees with \(K\) outside \(B_{2\delta}\). The omitted kernel has \(L^p\) norm at most \(C_p\delta^{2/p-1}\), so convolution with any of the measures has local \(L^p\) norm bounded by the same expression times its variation. The retained kernel is bounded, continuous, and vanishes at infinity. For every fixed \(x\), weak-* convergence gives convergence of its convolution values; dominated convergence on a bounded spatial set gives \(L^p\) convergence. First let \(n\to\infty\), then \(\delta\downarrow0\). At \(p=2\) the small-kernel estimate fails because \(|K|^2\) is not integrable at zero. Thus (15) supplies no passage through the Euler quadratic nonlinearity.

## 5. Quantifiers and limitations checked

- Lemmas 1 and 4 use inhomogeneous \(H^{-1}\) only for the high-frequency finite-energy component; low frequencies use only total variation.
- No compact support, moment condition, sign condition, or zero circulation is used in the positive lemmas.
- The counterexample (4) only defeats a reduction; its datum itself admits a stationary solution.
- Lemmas 7–8 use the weak-* topology dual to \(C_0\), not the topology of testing against all bounded continuous functions. Mass may escape at infinity in this closure argument. For example, translates of a unit smooth vortex have weak-* limit zero while preserving mass one; their Biot–Savart velocities tend to zero locally.
- Lemma 8 closes the target's every-time requirements once the velocity continuity and almost-every-time conclusions have been proved elsewhere.
- No lemma here closes the signed quadratic compactness problem or proves the exact logical negation.
- Verification provenance: direct worker derivations; no independent audit yet. External theorem certificates are unnecessary for the elementary Fourier, cutoff, Fubini, Plancherel, Riesz representation, and density steps used here, but these steps remain available for reconstruction by a verifier.

## 6. Completed approximation interface, including noncircular energy propagation

This section upgrades the conditional statement in Lemma 6 for the actual Euler approximation family. Its only external existence input is recorded immediately below; propagation of the relative finite energy is derived explicitly rather than included among the input hypotheses.

### Checked external input E1

G. Crippa and G. Stefani, *An elementary proof of existence and uniqueness for the Euler flow in localized Yudovich spaces*, Calculus of Variations and PDE 63, 168 (2024), Theorem 3.3, Assumptions 2.1 and 3.1, Definition 3.2. Primary full text: <https://link.springer.com/article/10.1007/s00526-024-02750-4>.

The specialization used is: on the whole plane, every initial vorticity in \(L^1\cap L^\infty\) admits a global Lagrangian weak solution of the transport equation with the canonical Biot–Savart velocity, bounded vorticity and velocity on finite time intervals, and nonincreasing \(L^1\) norm. The assumptions concern the kernel size, its two-point difference, bounded divergence, and boundary tangency. Our kernel satisfies them: its size is \((2\pi|x-y|)^{-1}\), and
\[
|K(a)-K(b)|=\frac{|a-b|}{2\pi|a||b|}.
\]
Its divergence is zero, and the whole plane has no boundary. No sign, compact-support, or finite-energy hypothesis is present in this specialization. This source is used only to supply the global bounded-vorticity Lagrangian solution, not to assert unquoted smoothness or energy conclusions.

Retrieval provenance: primary article inspected on 2026-10-08; relevant web references `turn37view0`, `turn38view0`, `turn39view2`, `turn39view3`. A coordinator citing this source must open the source independently under the browsing citation rules.

### Proposition 9: canonical smooth Euler approximants and uniform relative energy

Let \(\mu\in\mathcal M\cap H^{-1}\), \(M=\|\mu\|_{\mathcal M}\), and let \(\rho_\varepsilon\) be the mollifiers of Lemma 5. There are global Euler solutions
\[
\omega_\varepsilon(0)=\rho_\varepsilon*\mu,
\qquad u_\varepsilon(t)=K*\omega_\varepsilon(t),
\]
smooth for each fixed \(\varepsilon>0\), with
\[
\|\omega_\varepsilon(t)\|_1
=\|\rho_\varepsilon*\mu\|_1\leq M,
\qquad
\|\omega_\varepsilon(t)\|_\infty
=\|\rho_\varepsilon*\mu\|_\infty.
\tag{16}
\]
Take the fixed, time-independent low-frequency field \(U=\chi(D)K*\mu\) from Lemma 4, and set \(w_\varepsilon=u_\varepsilon-U\). Then
\[
w_\varepsilon\in C([0,\infty);L^2),\qquad
\sup_{\varepsilon\in(0,1]}\sup_{0\leq t\leq T}\|w_\varepsilon(t)\|_2
\leq B(T)<\infty,
\tag{17}
\]
where one possible bound is
\[
B(T)=e^{aT}\left[
\sqrt2\|\mu\|_{H^{-1}}+
m_1(\rho)\|\nabla U\|_2+
T\|U\|_\infty\|\nabla U\|_2
\right],\qquad a=\|\nabla U\|_\infty.
\tag{18}
\]
The bound depends only on the datum, \(T\), and fixed cutoffs, not on the smoothing parameter.

**Proof, step 1: existence, transport, and smoothness.** Young's inequality gives \(\rho_\varepsilon*\mu\in L^1\cap L^\infty\), and all of its spatial derivatives lie in \(L^1\cap L^\infty\). Apply E1. For a bounded integrable vorticity, splitting the Biot–Savart integral at radius \(r\) gives
\[
\|u\|_\infty\leq C\bigl(r\|\omega\|_\infty+r^{-1}\|\omega\|_1\bigr),
\]
and hence the usual boundedness and log-Lipschitz estimate by splitting the kernel difference at scales \(|x-y|\) and one. The log-Lipschitz bound implies uniqueness of the ODE trajectories, in both time directions, by the integral inequality for \(d(1+|\log d|)\). Thus the flow is a homeomorphism.

The divergence-free flow preserves Lebesgue measure. This does not require assuming smoothness: mollify the velocity spatially, obtaining bounded smooth divergence-free fields with uniform log-Lipschitz modulus. Their flows converge locally uniformly to the unique original flow by the Osgood modulus argument; they preserve Lebesgue measure by the Jacobian equation. For every compact continuous test, uniform bounded displacement restricts the preimage of its support to a fixed ball, so dominated convergence passes volume preservation to the limit. The Lagrangian representation from E1 therefore becomes \(\omega(t)=\omega(0)\circ X(t)^{-1}\), proving (16) and all finite \(L^p\) conservation laws.

Here is also a direct regularity upgrade. On any prescribed finite time interval, the log-Lipschitz modulus gives a uniform Hölder modulus for the forward and inverse flow, with a positive exponent \(\beta_T\). Since the mollified initial vorticity is globally Lipschitz, its transported vorticity is uniformly \(C^{\beta_T}\). The cancellation in \(\nabla K\), combined with \(|\nabla K(z)|\leq C|z|^{-2}\), gives the finite bound
\[
\|\nabla u(t)\|_\infty
\leq C\left(\beta_T^{-1}[\omega(t)]_{C^{\beta_T}}
             +\|\omega(t)\|_\infty+\|\omega(t)\|_1\right).
\tag{19}
\]
Indeed, subtract \(\omega(t,x)\) in the singular integral for \(|z|<1\), use \(\int_0^1 r^{\beta_T-1}\,dr=1/\beta_T\), and bound the far part by \(\|\omega(t)\|_1\); the local distributional term is bounded by \(\|\omega(t)\|_\infty\). The same near/far decomposition gives the Hölder continuity of \(\nabla u\), so the flow becomes \(C^{1,\beta_T}\). Composition with the smooth initial vorticity now gives \(C^{1,\beta_T}\) vorticity. Repeating differentiation of the transport equation and this singular-integral estimate upgrades all finite orders on the same finite time interval. Initial derivatives are integrable as well as bounded; differentiating the volume-preserving composition formula preserves their integrability with finite constants at each order. Thus the approximant is spatially smooth and its time regularity follows from the equations. These regularity constants may depend on \(\varepsilon\) and \(T\); none enter (18).

**Step 2: derive \(L^2\) propagation before testing energy.** Fix \(\varepsilon\), temporarily suppress its subscript, and set
\[
F_t=\int_0^t u(s)\omega(s)\,ds.
\]
The conserved \(L^1\cap L^\infty\) bounds imply \(\omega\in L^\infty_tL^2\) and \(u\in L^\infty_{t,x}\); hence \(F_t\in L^1\cap L^2\), with continuous dependence on \(t\) in both spaces. Integrating the vorticity equation yields
\[
\omega(t)-\omega(0)=-\operatorname{div}F_t
\quad\text{in distributions}.
\tag{20}
\]
The velocity difference is consequently
\[
u(t)-u(0)=-K*\operatorname{div}F_t,
\qquad
\|u(t)-u(0)\|_2\leq\|F_t\|_2.
\tag{21}
\]
To check (21) without a low-frequency assumption, Fourier-transform (20). Since both vorticities and \(F_t\) are in \(L^1\), the transform equality is between continuous functions. Multiplying by \(-i\xi^\perp/|\xi|^2\) gives the velocity difference, and the resulting matrix multiplier is
\(-\xi^\perp\otimes\xi/|\xi|^2\), of operator norm one. Its value at \(\xi=0\) is immaterial. Plancherel proves (21). Thus \(w(t)\in L^2\) follows from its initial \(L^2\) membership in Lemma 5, independently of the energy calculation.

The same argument in time-distribution form gives
\[
\partial_tu=-K*\operatorname{div}(u\omega)\in L^\infty(0,T;L^2),
\qquad
\nabla u\in L^\infty(0,T;L^2),
\tag{22}
\]
where the second assertion uses the bounded Fourier multiplier \(i\xi\otimes\widehat K\) and \(\omega\in L^\infty_tL^2\). Consequently \(w\in W^{1,\infty}(0,T;L^2)\cap L^\infty(0,T;H^1)\) for each fixed \(\varepsilon\). The norms in (22) may depend on \(\varepsilon\); they only justify the subsequent calculation.

**Step 3: pressure and uniform energy.** The vector
\(A=\partial_tu+(u\cdot\nabla)u\) belongs to \(L^2\) by (22) and boundedness of \(u\). Its curl is zero, because
\[
(u\cdot\nabla)u=\nabla(|u|^2/2)+\omega u^\perp,
\qquad \operatorname{curl}(\omega u^\perp)=\operatorname{div}(u\omega),
\]
and the vorticity equation holds. In Fourier space every curl-free \(L^2\) field is orthogonal to every divergence-free \(L^2\) field. Thus \(\langle A,w\rangle=0\); this both gives the velocity weak Euler equation and justifies cancellation of the pressure term in the energy test without any assumption that the pressure decays at infinity. Since \(u\) is bounded and divergence free and \(w\in H^1\), a spatial cutoff followed by \(R\to\infty\) gives \(\int w\cdot(u\cdot\nabla w)=0\). Therefore
\[
\frac12\frac d{dt}\|w\|_2^2
=-\int w\cdot(w\cdot\nabla U)-\int w\cdot(U\cdot\nabla U).
\tag{23}
\]
Applying the scalar Gronwall argument from Lemma 6 and the initial bound in Lemma 5 proves (18), completing the noncircular derivation. \(\square\)

### Proposition 10: all target compactness interfaces except the quadratic limit

From every sequence \(\varepsilon_n\downarrow0\), one can extract a subsequence and a single global \(u=U+w\) such that
\[
w\in C_w([0,\infty);L^2(\mathbb R^2)),\qquad
u\in C_w([0,\infty);L^2_{\rm loc}),\qquad u(0)=K*\mu,
\tag{24}
\]
and, for every \(T\),
\[
w_{\varepsilon_n}\to w\quad\text{in }C([0,T];L^2\text{-weak}),
\qquad
u_{\varepsilon_n}\to u\quad\text{in }C([0,T];L^p(B_R)),\ 1\leq p<2.
\tag{25}
\]
Here the first convergence means uniform convergence in time after pairing with any fixed \(L^2\) test. At every time,
\[
\omega(t)=\operatorname{curl}u(t)\in\mathcal M,
\quad \|\omega(t)\|_{\mathcal M}\leq M,
\quad u(t)=K*\omega(t),
\quad\operatorname{div}u(t)=0.
\tag{26}
\]

**Proof.** Let \(P\) denote the whole-plane Leray projection. The exact projected relative equation is
\[
\partial_tw_\varepsilon
=-P\operatorname{div}(w_\varepsilon\otimes w_\varepsilon
 +w_\varepsilon\otimes U+U\otimes w_\varepsilon)
 -P((U\cdot\nabla)U).
\tag{27}
\]
For any fixed \(s>2\), Fourier estimates give
\[
\|P\operatorname{div}F\|_{H^{-s}}\leq C_s\|F\|_1,
\qquad
\|P\operatorname{div}G\|_{H^{-1}}\leq C\|G\|_2.
\tag{28}
\]
The first uses \(|\widehat F|\leq\|F\|_1\) and
\(\int |\xi|^2(1+|\xi|^2)^{-s}\,d\xi<\infty\) exactly when \(s>2\); the second uses boundedness of the Leray multiplier. Equations (17), (27), and (28) yield
\[
\sup_n\|\partial_tw_{\varepsilon_n}\|_{L^\infty(0,T;H^{-s})}
\leq C_{s,T}<\infty.
\tag{29}
\]

Choose a countable dense set in \(L^2\) consisting of Schwartz tests. Bounds (17) and (29), scalar Arzelà–Ascoli, and a diagonal extraction give uniformly-in-time convergence of every pairing on this dense set for every integer horizon. The uniform \(L^2\) bound extends the pairings and their uniform convergence to all \(L^2\) tests, giving one globally defined \(w\) with (24)–(25)'s weak assertion. Lemma 5 gives the initial trace.

For each time separately, apply Lemma 7 to \(u_{\varepsilon_n}(t)\rightharpoonup u(t)\) locally in \(L^2\) and the variation bound (16), obtaining (26). No new subsequence depending on time is needed: distributional convergence determines the only possible limiting curl. Divergence zero also passes distributionally.

For the strong assertion in (25), first use the optional subcritical closure (15) at a fixed time. Uniformity in time follows by contradiction: if it fails, choose times \(t_n\to t\) with a fixed positive discrepancy. Uniform weak convergence and weak continuity imply \(u_{\varepsilon_n}(t_n)\rightharpoonup u(t)\) locally in \(L^2\). Lemma 7 and (15) imply strong local \(L^p\) convergence to \(u(t)\), while the same argument applied to \(u(t_n)\) gives \(u(t_n)\to u(t)\) in local \(L^p\). This contradicts the discrepancy. \(\square\)

### Exact remaining equation and closure gap

After another diagonal subsequence, the tensors \(w_{\varepsilon_n}\otimes w_{\varepsilon_n}\,dx\,dt\) converge weak-* as finite matrix-valued measures on every finite time horizon to \(Q\). Set
\[
R=Q-w\otimes w\,dx\,dt.
\]
The tensor measure \(R\) is symmetric and positive semidefinite, by lower semicontinuity of the nonnegative quadratic form tested against any nonnegative compact weight. Its trace has finite total mass on each finite time horizon. The fixed-background cross terms converge distributionally by (25)'s weak assertion, and therefore
\[
\int_0^T\!\!\int\bigl(u\cdot\partial_t\varphi
 +(u\otimes u):\nabla\varphi\bigr)
+\int\nabla\varphi:dR
+\int u_0\cdot\varphi(0)=0
\tag{30}
\]
for every target test \(\varphi\). Thus the sole remaining condition needed by this particular approximation route is
\[
\int\nabla\varphi:dR=0
\quad\text{for every compact smooth divergence-free }\varphi.
\tag{31}
\]
Vanishing \(R\) would suffice, but is stronger than necessary: a pressure-only defect also satisfies (31). The initial-velocity, noncompact-tail, weak-continuity, every-time measure, uniform variation, and canonical Biot–Savart requirements have all been retained by this construction. Proposition 10 and (30) establish no assertion that (31) holds for general signed data.

**Verification status of the extension.** This is a worker proof packet with an inspected primary existence input and explicit derivations of the remaining interfaces. It has not yet received an independent hostile audit. In particular, the smoothness upgrade is not needed for the energy and compactness arguments: the bounded-vorticity Lagrangian solutions supplied by E1 already have the exact regularity in (22), which suffices for (23)–(30).

## 7. Direct final normalization from relative finite energy

### Lemma 11

Suppose \(u=U+v\), with \(U\in C_0(\mathbb R^2;\mathbb R^2)\), \(v\in L^2(\mathbb R^2;\mathbb R^2)\), \(\operatorname{div}u=0\), and \(\mu=\operatorname{curl}u\in\mathcal M(\mathbb R^2)\). Then \(u=K*\mu\). No global homogeneous \(H^{-1}\) hypothesis is needed, and no prior approximant normalization is required for this conclusion.

**Proof.** By Lemma 1's distributional identities, \(h=u-K*\mu\) has zero divergence and curl, so \(\Delta h=0\) distributionally. It is locally integrable; the harmonic regularity lemma makes it a smooth harmonic vector field. For fixed \(x\), its mean-value property and Cauchy–Schwarz give
\[
|h(x)|\leq\fint_{B_R(x)}|U|
+\frac{\|v\|_2}{\sqrt\pi R}
+\fint_{B_R(x)}|K*\mu|.
\]
The first term tends to zero because \(U\) tends to zero at infinity. Tonelli and the uniform translated-ball estimate
\(\sup_y\int_{B_R(x)}|K(z-y)|\,dz\leq CR\)
bound the last term by \(C\|\mu\|_{\mathcal M}/R\). Letting \(R\to\infty\) gives \(h(x)=0\) for every \(x\). \(\square\)

For a time-dependent solution, the argument applies independently at every time at which the relative \(L^2\) bound and finite-measure curl hold. Lemma 8 supplies every-time measure representatives when only almost-every-time bounds were initially available. The fixed low-frequency \(U\) in Lemma 4 lies in \(C_0\), so Lemma 11 matches that construction exactly.
