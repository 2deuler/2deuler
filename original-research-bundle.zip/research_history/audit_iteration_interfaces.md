# Independent audit: whole-plane iteration interfaces

Auditor: primary_interfaces. This packet examines the passage from a correctly proved local stress repair to the exact global target. It does not certify the local repair itself. Inputs inspected: `fullplane_endpoint_repair_probe.md`, `route_endpoint_convex_integration.md`, `route_initial_subsolution.md`, and the initial-velocity packet. The time-strip packet will be audited separately below once available.

**Current scoped verdict:** PASS for cross-stress closure when an explicit summable L^{3/2} increment estimate is added; PASS for block-only spatial smoothing and piecewise time regularity under the precise conditions below; PASS for global concatenation provided finite-time outputs retain their global-L2 perturbation representation. No unconditional existence conclusion follows until the one-step and time-strip hypotheses are proved.

## 1. The strengthened induction class and cross stresses

Fix a finite horizon and the canonical smooth Euler background V constructed in the audited seed. It obeys a uniform L3 bound and has bounded spatial derivatives on each closed positive-time interval. Write

    u_q=V+w_q.

Require on the complete horizon

    w_q in L-infinity_t(L2 intersect L^{3/2}),
    ||w_{q+1}-w_q||_{L-infinity_t L2} <= a_q,
    ||w_{q+1}-w_q||_{L-infinity_t L^{3/2}} <= b_q,
    sum_q a_q < infinity, sum_q b_q < infinity.

The seed W has both norms, since it is uniformly L1 intersect L2. The Lamb block has

    ||eta V_r||_{3/2}=C|eta|r^{1/3}.

The temporal correction has the proposed ordinary-p bound

    ||Q||_{3/2} <= C tau h^{-2/3} B.

Thus, if the local construction can choose radii and cell parameters arbitrarily small with fixed coarse coefficients, both terms can meet any prescribed positive b_q budget. Positive spatial convolution does not increase either norm. The asserted estimates must hold as time suprema, not merely as cell averages.

Under these hypotheses w_q converges uniformly in time strongly in both spaces to w. For all finite q and for the limit,

    ||V tensor w_q||_1 <= ||V||_3 ||w_q||_{3/2}.

In particular

    ||V tensor (w_q-w)||_{L-infinity_t L1}
      <= ||V||_{L-infinity_t L3} ||w_q-w||_{L-infinity_t L^{3/2}} ->0.

Also

    ||w_q tensor w_q-w tensor w||_1
      <= (||w_q||_2+||w||_2)||w_q-w||_2 ->0

uniformly in time. This proves global-L1 convergence of every relative quadratic tensor. No global L2 norm of V is used. It is stronger than the local convergence needed to pass the weak Euler tests.

There are two distinct regularity statements here. The induction controls L^{3/2} and L2 uniformly across q. It does **not** infer L3 from those two spaces. The local-repair cross estimate using the current full seed `u_q in L3` must instead use its actual finite-stage spatial smoothness and boundedness: a bounded finite-energy w_q lies in L3 by `||w_q||_3^3<=||w_q||_infinity||w_q||_2^2`. The bound may depend arbitrarily badly on q and on the chosen positive-time cell. The adaptive next frequency may depend on it. Forcing a uniform L3 bound across the iteration is unnecessary and is not proved.

The counterexample in `audit_initial_subsolution.md` shows why the explicit L^{3/2} condition cannot be dropped from a global-stress argument.

## 2. Spatial smoothing: a safe implementation and an unsafe shortcut

Suppose a principal correction v on a closed construction cell satisfies

    partial_t v+div(v tensor v)+grad p=U+div E,

and is continuous in L2, with piecewise smooth time dependence and zero velocity at both cell endpoints. Let kappa_delta be one fixed, nonnegative, smooth spatial mollifier on this entire cell. Then

    v_delta=kappa_delta*v,
    partial_t v_delta+div(v_delta tensor v_delta)+grad p_delta
      =U_delta+div[E_delta+v_delta tensor v_delta-(v tensor v)_delta].

This is an exact identity. The fixed mollifier commutes with time derivatives and translations. No derivative of its scale appears. If r varies, choose delta after all parameters in this cell, smaller than its strictly positive minimum radius. Differentiation in r is then performed with delta fixed. The self-stress commutator tends to zero in L1 uniformly on the cell: the image of a compact time interval under the continuous L2 map v is compact in L2, so convolution approximates the identity uniformly on this image, and the usual quadratic L2-to-L1 estimate applies. Equivalently one can use the nonnegative variance formula. Spatial derivatives of the smoothed blocks are finite, with no requirement that their constants be uniform across cells.

Convolve the entire source and its temporal correction consistently. Leray projection commutes with the fixed convolution, so `Q_delta=kappa_delta*Q`; its L2 and L^{3/2} bounds persist, and `curl Q_delta=kappa_delta*curl Q`. Endpoint values remain zero. Thus different smoothing scales in adjacent cells do not create velocity jumps: the corrections are zero on both sides of the joint. Matching all temporal derivatives is unnecessary.

**Unsafe shortcut:** convolving the entire old velocity with a different fixed scale on every time cell generally creates a jump at the joint. Such a jump produces a time delta in the Euler equation, and stress jumps do not cancel it. Making the scale vary continuously in time adds the forcing `ell'(t) partial_ell(kappa_ell*u)`. A generic whole-plane L1 symmetric anti-divergence estimate for this forcing has not been proved. It cannot be imported from the torus argument.

**Sufficient resolution for this project:** do not remollify the old coarse velocity. The audited initial seed is already spatially smooth for positive times. Smooth each newly introduced block as above. The resulting finite-stage velocities remain spatially smooth and continuous in time, with piecewise smooth temporal derivatives. The new finite-stage stresses also remain spatially smooth and piecewise time regular. Refine all inherited temporal joints when choosing the next construction cells. This closes the regularity class if the local repair indeed has the stated one-sided regularity. If a future local lemma requires globally C-infinity time regularity rather than this class, it needs an additional proof and cannot claim this resolution automatically.

## 3. Support, tails, and local finiteness

Spatial compactness of the full velocity is neither available nor needed. The full Lamb velocity has an integrable L^{3/2} tail and finite energy. Leray corrections also need not have compact support; their ordinary Lp bounds for p=2 and p=3/2 are sufficient. The compact support requirements in the anti-divergence formulas concern their source, with its specified canceled moments, not the final stress or velocity.

A uniform bound `sup_t||R(t)||_1<infinity` alone does not justify a single spatial truncation uniform in t. For example, smooth unit-mass bumps whose centers diverge at an endpoint have that bound and no uniform tail control. A sufficient hypothesis on each closed construction cell is strong L1 continuity of R, including one-sided endpoint limits. The image is then compact in L1, and for every epsilon there exists one radius A with

    sup_{t in cell} integral_{|x|>A}|R(t,x)|dx < epsilon.

Proof: take a finite L1 epsilon-net of the compact image, truncate its finitely many members, and use the triangle inequality. Piecewise continuity with finitely many pieces has the same property. The actual finite-cell formulas involve continuous translations and dilations of fixed L1 profiles with radii bounded below, finite trajectories, and smooth coefficients; these have that property after the source and anti-divergence estimates are verified.

At each finite iteration stage, the inherited time partition must be locally finite in `(0,T]`. A compact positive-time interval then meets finitely many old cells, allowing finite derivative and tail bounds before the next refinement. Accumulation at t=0 is allowed and handled by a separate trace argument. Accumulation at a positive time is not harmless merely because pointwise correction values vanish at their individual endpoints: continuity and local integration of the equation would then need additional estimates. A theorem using open patch endpoints with accumulation there must supply that local endpoint argument.

## 4. Canonical velocity and measure closure

Each finite-stage correction z is divergence free, globally L2, and has finite curl measure. It is automatically the canonical Biot–Savart velocity of its curl. To see this, use the Fourier identity for finite measures. Away from xi=0, divergence and curl determine

    z_hat(xi)=(-i xi-perp/|xi|²) (curl z)_hat(xi).

Both sides are locally integrable functions of xi, including at zero: the left belongs to L2, and the right is bounded by C/|xi| because curl z is a finite measure. Equality away from a point therefore gives equality as distributions everywhere. No delta or harmonic ambiguity survives. The canonical normalization is consequently preserved by adding a correction to V.

Uniform strong local L2 convergence and a uniform total variation bound imply the same statement for the limit by the initial-velocity packet's closure lemma: test K against a compact smooth velocity test to obtain a continuous function vanishing at infinity, then pass through weak-* convergence of the curls. The endpoint representative is supplied by weak local L2 continuity. Thus no spatial tightness or circulation convergence is required.

## 5. Finite-horizon outputs concatenate globally — PASS under the strengthened output

The needed finite-horizon theorem must return not only the target conditions but also

    u(t)=V(t)+w(t),  w in L-infinity([0,T];L2),

with an every-time representative retaining this bound, where `omega_V(t) in L1 intersect Linfinity`. A weakly continuous relative L2 representative suffices. The construction's uniform-L2 series supplies this property if its initial trace is correctly established.

For every terminal time,

    omega(T)=omega_V(T)+curl w(T) in H^-1(R2),
    ||omega(T)||_{H^-1} <= ||omega_V(T)||_2+||w(T)||_2.

The Fourier estimate for curl is `|xi|/(1+|xi|²)^{1/2}<=1`. Since `omega_V(T) in L1 intersect Linfinity`, its L2 norm is finite. Together with the already proved measure bound, the endpoint belongs to the exact class `M intersect H^-1`; no global kinetic energy for u is inferred.

This endpoint H^-1 statement does not follow from only `u in L2_loc` and `curl u in M`: the global perturbation representation is essential to this restart proof and must remain in the finite-time theorem.

Now apply a unit-horizon theorem first to mu0, next to its endpoint mu1, and inductively to each finite endpoint mu_n. Every new interval starts from `K*mu_n`, which is exactly the preceding terminal velocity. Piecewise weak local L2 continuity therefore yields global weak local L2 continuity. Integrating the weak equations interval by interval makes the boundary terms telescope, because the shared endpoint velocities agree. A general compact time test meets finitely many unit intervals. On every finite horizon, only finitely many interval-specific TV bounds are needed, so their maximum is finite. There is no need for a bound uniform as n tends to infinity, and arbitrary growth of these finite constants creates no obstruction to this countable construction.

The same argument works with any fixed positive interval length. It does not require prescribing the terminal velocity or matching temporal derivatives.

## 6. Time-strip audit location

The independent audit of `route_time_strip_iteration.md`, including its weak initial trace bridge, is recorded in section 9 below. Sections 7–8 first certify the regularity and time-support interfaces needed by the concrete implementation.

## 7. Concrete regularity class for the audited seed and finite stages

The following stronger class is available for the actual seed and is sufficient for the block implementation. At finite stage q, choose a time partition whose joint set is locally finite in `(0,infinity)`. On each closed component cell, interpreted with one-sided values at its ends, require:

- `u_q=V+w_q`, with V the fixed smooth Euler background and `w_q` continuous into global L2 and L^{3/2};
- the velocity is continuous in local L2 across all joints;
- spatial derivatives of w_q of all orders belong to L2 and L^{3/2}, are bounded in space, and have finite suprema on the cell; finite-order time derivatives have the same properties inside the cell and finite one-sided bounds;
- R_q and all finite spatial derivatives are continuous into global L1 on the closed cell, with the same piecewise time regularity;
- the Euler–Reynolds identity holds distributionally across the joints.

The background has V in L3 and Linfinity on finite horizons. All its positive-order spatial derivatives belong to L2 and Linfinity, and hence L3, on each positive-time compact interval. The smooth vorticity has derivatives in L1 intersect Linfinity. These assertions follow from the regularity argument in the seed audit and the kernel near/far estimates; differentiating its transport equation gives the corresponding finite-order time regularity. The background need not lie in global L2 or L^{3/2}.

For the initial seed, W=b_t*v0 has all these relative properties on every closed interval `[a,b]` with a>0, because v0 belongs to L1 intersect L2 and the smoothing kernels and all their derivatives are integrable there. The stress derivatives are in L1 by L2 times L2 for W-quadratic terms, bounded derivatives of V times L1 derivatives of W for cross terms, and the curl-kernel identity for the time stress. Thus no coarse remollification is needed at the first step.

On a fixed finite construction cell, the positive minimum of r, bounded trajectory, smooth amplitude and coefficients, and fixed positive spatial smoothing scale give all these properties for the principal block. For Q, boundedness of Leray projection in L2 and L^{3/2} applies after every spatial or piecewise time derivative. Bounded spatial derivatives follow, for example, from the elementary H2 Sobolev estimate applied to each derivative of Q. At cell endpoints the primitive is zero; its L2 and L^{3/2} norms tend to zero by their direct integral estimates, so Q is strongly continuous there in both global spaces.

For the anti-divergence stresses, the compact smooth sources retain their canceled moments under differentiation, translation, and the fixed convolution. On a fixed cell their supports stay in one bounded region. The local smoothness of their potentials and the explicitly integrable far-field expansion imply that every finite spatial derivative belongs to L1, with continuous dependence on the cell parameters. Interactions with the current velocity have L1 derivatives by the product rule using `D^k u_q in L3` and `D^k(v+Q) in L^{3/2}`. These claims require the source moment and anti-divergence identities in the local repair, which this audit does not independently certify.

Therefore, once that local algebra is correct, finite-stage smooth bounded blocks preserve the needed L3 norms on each compact time piece, with constants that may grow between stages. The strengthened uniform induction needed for the limit remains only L2, L^{3/2}, and curl variation; no uniform derivative estimate is asserted.

## 8. Exact time support versus zero endpoint values

The raster corrector generally has only zero **values** at cycle endpoints. Indeed

    Q(t)=-P integral_a^t (U(s)-bar U)ds

gives Q(a)=Q(b)=0 for a complete cycle `[a,b]`. If U is flatly zero at the ends but its cycle average is nonzero, then

    Q'(a+)=Q'(b-)=P bar U,

which generally is not zero. Extending Q by zero outside that cycle is continuous but usually not C1. The principal block's flat amplitude does not fix this corner. Thus a local theorem demanding correction smoothness across all cycle endpoints is not established by the displayed formula alone.

Compact time support is a separate property and **can** hold exactly. If a prescribed S has compact time support in an open patch J, choose a finite closed union of complete construction cells, containing its support, with all endpoints strictly inside J. Refine this union at every old temporal joint. Construct the full principal and Q correction on each complete cell, set it to zero elsewhere, and keep all cycle averages inside those cells. Zero endpoint values ensure continuous pasting, and the support of the resulting correction is a compact subset of J. No nonzero temporal primitive remains after the last cycle. Source and stress errors can likewise be set to zero outside this finite union; their jumps are permitted. This argument does not cover a schedule terminating midway through a cycle, nor a schedule with cells accumulating at the boundary of J without a collar.

A continuous velocity, piecewise smooth velocity derivatives, and piecewise integrable stress are enough for the distributional Euler–Reynolds identity. Integrate on the finitely many pieces meeting a compact positive-time test. The time boundary terms telescope because the velocity traces agree. There is no time derivative of the stress in the equation, so its jumps cause no delta. This is exactly why Q's derivative corner is acceptable. The same argument applies when the global set of joints is locally finite.

For the next stage, refine every inherited joint. In a compact patch there are only finitely many old joints and old cycles. Choose complete new cycles separately on each resulting subinterval, with new correction zero at each endpoint. There are again finitely many new joints in every positive-time compact set at every finite stage. A prescribed stress `chi_j R_q` can inherit jumps at old joints; the local repair must therefore allow piecewise smooth prescribed stresses, treated separately on these subintervals. Requiring it to be globally smooth without this extension would be a genuine mismatch.

## 9. Independent audit of the time-strip theorem

Inspected in full: `route_time_strip_iteration.md`, originally frozen by its author with SHA256 `78d2f6f81a9a9567c2a39ee13bda945985be9906cf8d250988d1ca27c214ca31`. The author subsequently made the explicitly noted continuity wording repair below. No one-step property is supplied by that packet.

**Lemma T — PASS.** Subtracting the two Euler–Reynolds equations bounds the derivative of every compact solenoidal test pairing by local kinetic energy plus the global stress norms. Each pairing has a limit at zero. The exact gap anchors force that limit to vanish. Uniform global L2 boundedness of the correction then gives weakly convergent subsequences for arbitrary sequences of times tending to zero. Every weak limit is divergence-free and annihilates compact solenoidal tests; testing with rotated gradients gives zero curl. Fourier division away from the origin and the L2 condition imply that limit is zero. This proves the full weak global L2 limit and preserves the exact weak initial trace. There is no hidden strong trace, energy inequality, or time-regular trajectory hypothesis. The proof still works for the piecewise regular class above because the distributional equation supplies the same Lipschitz representative of each pairing and velocity continuity supplies its anchor values.

**Theorem I — PASS as an abstract conditional implication from P.** The three-color dyadic cover has disjoint same-color intervals with exact gap times approaching zero. The frozen prescribed pieces sum to the old stress. Processing colors sequentially uses the current velocity for each exact repair, so overlap cross terms are included through P rather than discarded. The intermediate stress identity has coefficient `1-sum(processed chi_j)` in [0,1]. At a fixed time at most three patches are active; every active patch at t<=T lies below 4T. Thus the derivative-independent leading estimate yields the stated summable correction and curl bounds, and the error budgets yield the geometric stress reduction. Lemma T applies after each color. Summable global L2 tails preserve the trace in the final series. Strong local L2 convergence passes the quadratic terms; the vanishing L1 stress gives Euler; the temporal cutoff recovers the initial term. The L1 curl series at positive times is stronger than the target's measure conclusion. Canonical Biot–Savart closure is valid, either by the packet's weak-L2 harmonic argument or section 4 above.

One nonessential overclaim in the original proof was identified and reported: joint smoothness and a uniform global L2 bound alone do not imply strong global-L2 time continuity, since energy can travel from spatial infinity. Strong local-L2 continuity is automatic and is all the proof needs. The author confirmed the convergence paragraph was corrected to local L2; this removes the overclaim without changing the theorem. The concrete block construction in fact has stronger global-L2 continuity by the direct estimates in section 7.

**Concrete invocation of P — INCONCLUSIVE.** P as originally stated requests globally smooth time corrections compactly supported in the patch. The displayed raster primitive generally gives continuous piecewise smooth corrections, as section 8 proves. The abstract theorem remains valid with P replaced throughout by its piecewise version, provided the locally finite joint and one-sided norm conditions above are imposed. This is a repair of the interface, not a proof of the one-step estimates. Its other load-bearing assumptions remain prescribed-piece removal, exact completed-cycle compact time support, globally integrable stress errors, uniform leading cost, and small L^{3/2} increments if the concrete global cross-stress induction uses them.

The abstract limit passage itself does not need the L^{3/2} increment hypothesis: local strong L2 convergence suffices there. L^{3/2} is an additional sufficient implementation interface for proving P on the whole plane with the infinite-energy background.

## 10. Final scoped disposition

The seed, cross-norm interface, gap trace lemma, conditional colored iteration, and restart mechanism fit without a hidden sign, circulation, support, or homogeneous-H^-1 restriction. The time-class mismatch is resolved by continuous piecewise smooth velocities with inherited boundary refinement; it is not resolved by pretending Q has flat endpoint derivatives. The substantive unresolved statement remains the exact local prescribed-stress repair with all its stated estimates. This audit establishes no affirmative answer until that statement is independently certified.

## 11. Reduced regularity certificate: bounded-vorticity background suffices

The coordinator proposed removing higher smooth-Euler dependencies. **PASS**, provided prescribed stresses are approximated as described below. Section 7 gives a sufficient stronger class; it is not necessary for the local algebra or limit. In particular no spatial derivative of the old velocity is used by the displayed cross-stress estimate.

Take only the canonical Lagrangian L1-intersect-Linfinity background supplied by the independently checked E1. On a finite horizon its vorticity omega_b is uniformly L1 and Linfinity, and b is uniformly bounded. Thus omega_b is uniformly L2, and

    F(t)=integral_0^t b(s)omega_b(s)ds in C_t L2,
    ||F(t)-F(s)||_2 <= C_T |t-s|.

The vorticity equation and the canonical Fourier identity give

    b(t)-b(s)=-K*div integral_s^t b(r)omega_b(r)dr,
    ||b(t)-b(s)||_2 <= C_T |t-s|.

The matrix multiplier of `K*div` has norm at most one. This also selects a continuous local-L2 representative of b. Its uniform Linfinity bound extends to every time by that continuity. Since b belongs to global L3 by the weak-L2 estimate,

    ||b(t)-b(s)||_3³
      <= 2 sup_r||b(r)||_infinity ||b(t)-b(s)||_2²
      <= C_T |t-s|².

Hence b is strongly continuous in global L3, although b itself need not belong to global L2. The derivative bound `partial_t b in L-infinity_t L2` and the Fourier estimate `grad b in L-infinity_t L2` imply `partial_t b+(b dot grad)b in L2`; its curl vanishes by the vorticity equation. The same orthogonality argument as in the seed audit therefore gives the velocity Euler equation. Higher spatial smoothness is not needed.

For the seed, W is continuous in global L^{3/2} and L2 on every positive compact time interval. Therefore

    t -> b(t) tensor W(t)

is continuous in global L1 by Holder's inequality. The other seed stresses have the same continuity by their explicit smoothing formulas. One could also use local-L2 continuity, bounded b, and uniform L1 tails of W, but the C_t L3 estimate gives a direct proof.

At a finite construction stage, the current velocity need only satisfy

    u_q in L-infinity(cell;L3),
    u_q continuous in local L2,
    R_q piecewise continuous into global L1,

together with the global relative-energy and curl bounds. Actual finite sums of spatially smoothed blocks give the L3 property: the background is L3, W is smooth and finite energy away from zero, and each added block and corrector is bounded and finite energy on its own closed cell. There are only finitely many relevant blocks at finite stage on a positive-time compact set. No derivative of b, u_q, or R_q enters the leading cross estimates.

**Stress approximation must be explicit.** A rough current stress cannot simply be fed into a smooth coefficient decomposition. On each inherited time piece, its continuous global-L1 image is compact. Spatial truncation and convolution, together with time convolution of that stress alone, approximate a prescribed compact-time piece `chi_j R_q` uniformly in L1 by a symmetric smooth prescribed tensor S. Time convolution is taken inside a slightly larger patch and does not alter the velocity or its equation. Charge the actual tensor difference

    chi_j R_q-S

to the new residual stress. If its norm is at most epsilon, then the prescribed-piece norm is at most `sup||chi_j R_q||_1+epsilon`; choosing epsilon within the stage error budget preserves the square-root leading estimates, with at most a summable additional square-root cost. Symmetry is preserved by componentwise convolution and a scalar cutoff.

At a genuine stress jump, smooth-in-time approximation is not uniform across the jump. Refine at the inherited joint and approximate on each side using a one-sided extension, retaining a piecewise smooth prescribed tensor. The correction is zero at the joint, so the earlier continuous-pasting argument applies. If the one-step proof is formulated directly for coefficients frozen separately in these pieces, no time convolution is needed at all. In either formulation, smoothing the prescribed stress is harmless because only spatial divergence of the residual tensor enters Euler–Reynolds; it creates no time-convolution commutator in the velocity equation.

This reduced class is enough for the scheme provided the local repair has indeed been proved for an L3 old velocity and a smooth prescribed tensor: all old-velocity interactions are retained as explicit integrable stress. It removes any need to cite an unverified smoothness upgrade of E1. It does not weaken the unresolved demand for a complete exact local repair.

### Check of the author's piecewise amendment

After the first audit, the author appended section 7 of `route_time_strip_iteration.md`. I independently read that amendment. **PASS:** its modified property, locally finite inherited partitions, continuous velocity pasting, exact primitive support, finite-stage L3 control, and compact-image tail argument agree with sections 3, 7, and 8 here. Its retained smooth-spatial-dependence assumption is sufficient but unnecessary; the reduced class in section 11 drops it for the old background while smoothing only prescribed stress approximations and new blocks. No new one-step proof is present in the amendment.
