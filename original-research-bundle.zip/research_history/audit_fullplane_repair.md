# Hostile audit and assembled finite-step repair lemma

AUDITED SOURCES:

- `fullplane_endpoint_repair_probe.md`, SHA-256 `13face790f39e453a7665edd3f1e7d1067a15c2066f09a16a51784022a02583f`.
- `route_wholeplane_convex_integration.md`, SHA-256 `606fcdca7f6bcb877cb940766ade7c9e1df26be1c75404ddd15bb380935694b7`.

MODE: independent reconstruction by `/root/jordan_energy`, including coordination with the second packet's author. This is one research verification pass, not the four-pass final manuscript audit.

## 1. Verdict and literal scope corrections

No fatal algebraic, sign, moment, scaling, or uniform-curl obstruction was found in the finite-cycle construction.
The originally proposed statement is nevertheless **not literally proved as a smooth-to-smooth perturbation lemma**:

1. The printed time corrector satisfies \(\partial_tQ=P\overline U\) at a cycle endpoint, because the principal source is flat and zero there. Adjacent frozen cycles generally have different \(\overline U\). Thus the new velocity is continuous but its first time derivative can jump. A claim of global smoothness in time is false for that construction.
2. Local spacetime smoothness and a bare bound \(\sup_t\|R(t)\|_1<\infty\) do not imply uniform spatial tightness of the stress. Uniform truncation requires an additional hypothesis or proof.

Both defects are repaired below by a precise finite piecewise-time class. The resulting one-step lemma is proved here, conditional on that class. The infinite initial-time strip construction is not contained in this lemma.

## 2. Exact finite-step lemma

Let \(I=[a,b]\) be a compact interval with \(a<b\), carrying a finite partition \(a=t_0<\cdots<t_N=b\).
Suppose \((u,p,R)\) satisfies

\[
\partial_tu+\operatorname{div}(u\otimes u)+\nabla p
=\operatorname{div}R,\qquad \operatorname{div}u=0
\tag{ER}
\]

in distributions, and has the following properties:

- \(u\) is continuous in time with values in \(L^2_{\mathrm{loc}}\), and \(\sup_{t\in I}\|u(t)\|_3<\infty\).
- \(R\) is symmetric, \(\sup_{t\in I}\|R(t)\|_1\leq\delta\), and its restriction to each open partition interval admits a continuous \(L^1\)-valued extension to that interval's closure. The two traces at a partition point may differ.
- On each closed partition interval, \(u\) and \(R\) are smooth in space and have smooth time dependence up to one-sided endpoints locally in space. The pressure may be treated distributionally; only its gradient in (ER) is used.

Then, for every \(\varepsilon>0\), there is a finite refinement of the partition and a perturbation \(w\), continuous in \(L^2(\mathbb R^2)\), smooth in space and piecewise smooth in time, such that:

\[
\begin{gathered}
\operatorname{div}w=0,\qquad
w=0\quad\text{at every endpoint of the refined construction cycles},\\
\sup_{t\in I}\bigl(\|w(t)\|_2+
                  \|\operatorname{curl}w(t)\|_1\bigr)
\leq C\sqrt\delta+\varepsilon,
\end{gathered}
\tag{L1}
\]

and \(u_1=u+w\) solves (ER) with some pressure \(p_1\) and symmetric stress \(R_1\) satisfying

\[
\sup_{t\in I}\|R_1(t)\|_1\leq\varepsilon.
\tag{L2}
\]

The new stress has continuous \(L^1\)-valued one-sided extensions on every refined closed cycle, \(\sup_t\|u_1(t)\|_3<\infty\), and the same local spatial/time smoothness inside those cycles.
The constant \(C\) in (L1) depends only on the fixed dipole and the four fixed directions, not on support size, coefficient derivatives, or the seed's \(L^3\) norm.
Those quantities determine how small the construction parameters must be.

When \(\delta=0\), the zero perturbation already works.
Hence assume \(\delta>0\) in the construction below.

## 3. Building-block verification

### 3.1 Lamb profile, signs, and regularity

The two audited packets define the same velocity: their stream functions and their conventions for perpendicular gradient both differ by a minus sign.
Using the first packet's counterclockwise convention, the interior relative stream function is \(q=\psi+x_2\), with
\(V-e_1=\nabla^\perp q\) and \(\omega=-b^2q\).
Thus \((V-e_1)\cdot\nabla\omega=0\).
The exterior stream gives

\[
V(x)=\nabla(-x_1/|x|^2)
=\frac{(x_1^2-x_2^2,\,2x_1x_2)}{|x|^4}.
\]

Matching \(J_1(b)=0\) and \(J_1'(b)=J_0(b)\) gives continuous velocity and first spatial derivatives across the core boundary; the vorticity is continuous and vanishes there.
The piecewise formulas have enough regularity for the stated distributional identities and for \(\nabla V\in L^2\).
They do not by themselves give global \(C^\infty\) regularity.

The pressure identity can be checked without a curl-only argument:

\[
-\partial_1V+\operatorname{div}(V\otimes V)
=\nabla\left(\frac{|V|^2}{2}-V_1+
                \frac{b^2}{2}\mathbf1_{B_1}q^2\right).
\]

The core potential has no boundary delta because \(q=0\) at the boundary.
The corresponding pressure is the negative of the bracket.
Consequently the travel velocity is \(+e_1\), and after scaling it is \(+\xi/r\).

Scaling gives
\(\|V_r\|_2=C_2\), \(\|V_r\|_{3/2}=C_{3/2}r^{1/3}\),
\(\|\operatorname{curl}V_r\|_1=C_\omega\), and
\(\|\nabla V_r\|_2=C/r\).
The \(|x|^{-2}\) tail is in every \(L^p\) with \(p>1\), but not in \(L^1\); no later estimate uses a global \(L^1\) velocity norm.

### 3.2 Symmetric integrable antidivergence

For compactly supported \(f\) with zero mean and all first moments zero, define

\[
(\mathscr R f)_{ij}
=\partial_i\Delta^{-1}f_j+\partial_j\Delta^{-1}f_i
 -\delta_{ij}\operatorname{div}\Delta^{-1}f.
\]

Taking its divergence gives exactly \(f\); the two mixed derivative terms cancel.
It is symmetric and trace-free in dimension two.
Its kernel is of degree \(-1\).
Inside a ball of radius comparable to the support radius \(H\), Tonelli gives \(CH\|f\|_1\).
Outside, subtracting its constant and linear Taylor terms leaves
\(CH^2|x|^{-3}\|f\|_1\); integration gives another \(CH\|f\|_1\).
Therefore

\[
\|\mathscr Rf\|_1\leq CH\|f\|_1.
\tag{AD}
\]

The first-moment conditions are essential to this proof. They also imply the torque condition, so no hidden symmetry compatibility is missing.
Compact support of the tensor is neither claimed nor needed.

### 3.3 Radius derivative and moments

Direct differentiation yields

\[
h_r:=\partial_rV_r-V_r/r
=-\operatorname{div}(V_r\otimes x/r).
\]

The exterior degree \(-2\) homogeneity makes \(h_r\) vanish outside the core.
Its \(L^1\) norm is bounded independently of \(r\).
It is even under \(x\mapsto-x\), so every first moment vanishes.
Its mean is zero: integration of the divergence over a larger circle leaves a multiple of the exterior velocity's angular mean, which is zero.
Thus
\(\|\mathscr Rh_r\|_1\leq Cr\).
These are genuine integrable core functions; no boundary delta is omitted.

### 3.4 Compact source and its sign

Use the second packet's fixed auxiliary radius \(H\), with core \(r<H/4\).
Let \(\chi_H=0\) on \(B_{H/2}\), \(\chi_H=1\) outside \(B_H\), and \(\Phi_\xi=-\xi\cdot x/|x|^2\).
Then

\[
S_{r,H}=V_r/r-\nabla(\chi_H\Phi_\xi)
\]

is compactly supported and has

\[
\int S_{r,H}=\kappa\xi,\quad \kappa=2\pi,
\quad\int x_j(S_{r,H})_i=0,
\quad\|S_{r,H}\|_1\leq C(1+\log(H/r)).
\]

The mean's positive sign is checked by the two boundary integrals:
\(\int_{B_L}V_r/r=+\pi\xi\), whereas
\(\int_{B_L}\nabla(\chi_H\Phi_\xi)=-\pi\xi\).
Both statements hold for \(L>H\).
The first moments follow from even parity.
Subtracting \(\kappa\rho_H\xi\), where \(\rho_H\) is an even probability kernel, cancels both orders of moments.
Equation (AD) gives a symmetric \(L^1\) source-replacement stress of norm at most \(CH(1+\log(H/r))\).

For \(v=\eta V_r(\cdot-X)\), \(X'=\eta\xi/r\), and \(B=\eta r\), the exact non-gradient residual is
\(B'V_r/r+\eta r'h_r\).
It follows that

\[
\partial_tv+\operatorname{div}(v\otimes v)+\nabla p_v
=F+\operatorname{div}E,
\quad F=\kappa B'\rho_H(\cdot-X)\xi,
\]

with

\[
\|E\|_1\leq CH(1+\log(H/r))|B'|+Cr|\eta r'|.
\tag{E}
\]

Every pressure replacement is a spatial gradient. No time derivative of a discarded velocity is being omitted, because the velocity itself is never truncated.

### 3.5 Spatial smoothing with varying radius

Convolve the entire moving-packet identity at one fixed spatial scale \(\ell\) within the construction interval, with \(\ell\ll r_{\min}\).
The source becomes \(F*\rho_\ell\), so the auxiliary kernel becomes \(\widetilde\rho_H=\rho_H*\rho_\ell\).
This kernel still has mass one, even parity, compact support of radius \(O(H)\), and the same estimates
\(\|\widetilde\rho_H\|_2\leq C/H\),
\(\|\nabla\widetilde\rho_H\|_1\leq C/H\),
\(\|\widetilde\rho_H\|_{3/2}\leq CH^{-2/3}\).
Its first moment is \(O(H)\).

The additional symmetric stress is

\[
(v*\rho_\ell)\otimes(v*\rho_\ell)
 -(v\otimes v)*\rho_\ell,
\]

whose \(L^1\) norm is at most
\(C\eta^2\ell^2\|\nabla V_r\|_2^2
 \leq C\eta^2(\ell/r)^2\).
This follows by the variance identity and translation differences in \(H^1\).
It can be made uniformly as small as desired after all positive radii have been fixed.
The velocity \(L^2\), \(L^{3/2}\), and curl \(L^1\) bounds do not increase under this convolution.
Keeping \(\ell\) fixed when differentiating \(r(t)\) preserves the radius identity exactly.

## 4. Exact raster clock and four directions

The proof uses the second packet's two-scale raster, with row spacing \(d=H^2\).
The first packet's one-scale construction is also valid when its stated transverse partition of unity is imposed; an arbitrary one-scale radial kernel would not be valid.

For one frozen nonnegative smooth compact coefficient \(a_i\), choose a fixed finite rectangle with longitudinal buffers, a positive floor \(\beta_i\), and a spatial ramp \(g_i\) equal to one on the coefficient support.
At the endpoints choose \(g_i(s)\sim s\log^2(1/s)\), so \(\int g_i^{-1}<\infty\), \(\sup|g_ig_i'|<\infty\), and the induced temporal amplitude is flat.
Along row \(j\), let

\[
a_{ij}(s)=a_i(s,y_j)+\beta_i,\qquad
J_{ij}=\int a_{ij}/g_i\,ds,\qquad
A_i=d\sum_jJ_{ij}.
\]

To allocate exactly one quarter of a complete cycle of duration \(\tau\) to direction \(i\), use

\[
\eta_i^2=4A_i/\kappa,\qquad
r_{0i}=\frac{\tau d}{\kappa\eta_i}.
\tag{C}
\]

Set \(\eta=\eta_i g_i(s)\), \(r=r_{0i}a_{ij}(s)\), and
\(s'=\eta_i g_i/(r_{0i}a_{ij})\).
The total duration of that direction is

\[
\frac{r_{0i}}{\eta_i}\sum_jJ_{ij}
=\frac{\tau A_i}{\kappa\eta_i^2}=\frac\tau4.
\]

Only one principal packet is active at a time.
At row and direction resets the amplitude and all its temporal derivatives vanish, so resetting the center creates no temporal distribution.
The floor ensures a strictly positive minimum radius on every finite construction interval.

Since \(B X'=\eta^2\xi_i\), integration by parts, including both births and deaths, gives

\[
\overline F:=\frac1\tau\int_{\mathrm{cycle}}Fdt
=\operatorname{div}\mathcal A_H,
\quad
\mathcal A_H=\sum_{i=1}^4
 \left[d\sum_j\int a_{ij}(s)g_i(s)
 \widetilde\rho_H(\cdot-(s,y_j))ds\right]\xi_i\otimes\xi_i.
\tag{AVG}
\]

The coefficient \(d\) in this formula uses the full cycle \(\tau\), not its quarter; this is why the factor four is required in (C).

For a smooth coefficient, the Banach-valued rectangle rule and convolution approximation give the explicit bound

\[
\left\|d\sum_j\int a_i(s,y_j)
\widetilde\rho_H(\cdot-(s,y_j))ds-a_i\right\|_1
\leq C\left(d\|\partial_ya_i\|_1+
\frac dH\|a_i\|_1+H\|\nabla a_i\|_1\right).
\]

The extra floor contribution is at most \(C_{\mathrm{box},g}\beta_i\).
All terms tend to zero when the floor is chosen small first, then \(H\downarrow0\).
The factor \(g_i\) creates no loss on the actual coefficient because it equals one on its support.
It affects only the explicitly bounded floor mass.
Furthermore

\[
\eta_i^2\leq C\left(\|a_i\|_1+
d\|\partial_ya_i\|_1+C_{\mathrm{box},g}\beta_i\right).
\tag{AMP}
\]

No derivative or support-size constant enters the leading \(\|a_i\|_1\) coefficient.

## 5. Corrector sign, norms, and assembled residual

On each full cycle define

\[
Q(t)=-P\int_{t_k}^t(F(s)-\overline F)ds.
\]

Then \(Q\) is divergence free, zero at both endpoints, and
\(\partial_tQ=-PF+P\overline F\).
Since \(F-PF\) and \(P\overline F-\overline F\) are gradients, adding \(Q\) leaves the average stress \(\mathcal A_H\) with a **positive** sign.

Let \(D\) bound the sum of the four quantities
\(d\sum_j\int|(a_{ij}g_i)'|ds\).
For a fixed compact smooth coefficient family and fixed floors, \(D\) is bounded uniformly for small \(d\).
Direct change of variables yields
\(\int_{\mathrm{cycle}}|B'|dt\leq C\tau D\).
Boundedness of \(P\) on \(L^2\) and \(L^{3/2}\), together with \(\operatorname{curl}Pf=\operatorname{curl}f\), gives

\[
\|Q\|_{L^\infty_tL^2_x}+\|\operatorname{curl}Q\|_{L^\infty_tL^1_x}
\leq C\tau H^{-1}D,
\qquad
\|Q\|_{L^\infty_tL^{3/2}_x}\leq C\tau H^{-2/3}D.
\tag{Q}
\]

There is no use of an \(L^1\) bound for the Leray projection.
The curl is taken before estimating in \(L^1\).

Writing \(v\) for the single active smoothed principal packet and \(w=v+Q\), the exact stress added to the seed is

\[
\mathcal A_H+E
 +v\otimes Q+Q\otimes v+Q\otimes Q
 +u\otimes w+w\otimes u,
\tag{RES}
\]

where \(E\) includes the smoothing commutator.
Every tensor is symmetric, and every term lies in global \(L^1\).
The interaction estimates are

\[
\begin{aligned}
\|u\otimes v\|_1&\leq C\|u\|_3\eta_i r_{\max}^{1/3},\\
\|u\otimes Q\|_1&\leq\|u\|_3\|Q\|_{3/2},\\
\|v\otimes Q\|_1&\leq C\eta_i\|Q\|_2,
\qquad \|Q\otimes Q\|_1\leq\|Q\|_2^2.
\end{aligned}
\]

The principal curl cost is \(C_\omega\eta_i\), rather than a quantity growing with the inverse core radius.

## 6. Completion of the one-step proof

Work separately on each original closed time piece; there are finitely many.
Its continuous \(L^1\)-valued stress has compact image, hence uniformly small spatial tails.
Choose one spatial cutoff on the whole finite partition such that
\(\sup_t\|R-R^c\|_1\) is smaller than a prescribed small fraction of the final error budget.
The cutoff preserves symmetry.

Choose a compact bump \(b\geq0\) equal to one near the support of \(R^c\), and a small constant \(\gamma>0\).
Set

\[
A=\sqrt{(R^c_{12})^2+\gamma^2b^2},\qquad
B=\sqrt{(R^c_{11})^2+(R^c_{22})^2+\gamma^2b^2}.
\]

These are smooth: wherever the bump approaches its zero set, \(R^c\) already vanishes, and the square roots reduce to \(\gamma b\).
With the directions
\(e_1,e_2,(e_1+e_2)/\sqrt2,(e_1-e_2)/\sqrt2\), define

\[
a_1=B-R^c_{11},\quad a_2=B-R^c_{22},\quad
a_3=A-R^c_{12},\quad a_4=A+R^c_{12},\quad q=A+B.
\]

Then all coefficients are smooth, compactly supported, nonnegative, and

\[
-R^c+qI=\sum_{i=1}^4 a_i\xi_i\otimes\xi_i,
\qquad
\sum_i\|a_i\|_1\leq C\delta+C\gamma\|b\|_1.
\tag{DEC}
\]

Choose \(\gamma\) and all raster floors so that their total extra coefficient mass is as small as required for the additive \(\varepsilon\) in (L1), and their actual sampling error is a small fraction of (L2).
These choices precede the frequency choice.

Subdivide each original time piece into equal cycles of length \(\tau\), freezing \(R^c\) and its coefficients at the left endpoint of each cycle.
Choose the cycle number to tend to infinity and set \(H=\tau^{1/6}\), \(d=H^2\).
Then \(\tau=H^6\) holds exactly even when the interval length is not a prescribed power.
All frozen coefficient derivatives on the fixed spatial support are uniformly bounded because the original piece is compact in time and locally smooth up to its endpoints.
The fixed positive floors give a uniform positive lower bound for every \(\eta_i\), independent of sufficiently small \(H\), and a finite upper bound.
Thus

\[
r_{0i}=\frac{H^8}{\kappa\eta_i},\qquad
r_{\min},r_{\max}\asymp H^8
\]

with positive constants allowed to depend on the fixed floors and coefficients.
The instantaneous derivative formulas are

\[
B'=\eta_i^2\left(g_ig_i'+g_i^2\frac{a_{ij}'}{a_{ij}}\right),
\qquad
r|\eta r'|=\eta_i^2r_{0i}g_i^2|a_{ij}'|.
\]

Consequently the source-replacement stress is \(O(H(1+|\log H|))\), with fixed derivative-dependent constants, and the radius-derivative stress is \(O(H^8)\).
The corrector estimates are \(O(H^5)\) in \(L^2\) and curl \(L^1\), and \(O(H^{16/3})\) in \(L^{3/2}\).
The sampling error tends to zero, as do all interactions in section 5.
The freezing error
\(\|R^c(t)-R^c(t_k)\|_1\) tends to zero uniformly by its uniform \(L^1\) continuity.
Finally choose the fixed smoothing scale \(\ell\) small enough to make its commutator smaller than the remaining budget uniformly over all the finitely many cycles.

The seed stress plus the average principal stress can now be written exactly as

\[
R(t)+\mathcal A_H
=q(t_k)I+[R(t)-R^c(t)]
 +[R^c(t)-R^c(t_k)]
 +\left[\mathcal A_H-\sum_i a_i(t_k)\xi_i\otimes\xi_i\right].
\]

Absorb \(q(t_k)I\) into pressure by subtracting \(q(t_k)\) from the intermediate pressure.
Together with (RES), all remaining tensors define \(R_1\).
The preceding choices make their total uniform \(L^1\) norm at most \(\varepsilon\), proving (L2).

By (AMP), (DEC), and the fact that only one principal packet is active,

\[
\sup_t\bigl(\|v(t)\|_2+\|\operatorname{curl}v(t)\|_1\bigr)
\leq C\sqrt\delta+\varepsilon/2
\]

after taking the added floor masses and Riemann-sum errors sufficiently small.
Equation (Q) makes the remaining corrector cost at most \(\varepsilon/2\).
This proves (L1).

At every cycle boundary the principal amplitude is flat and zero and \(Q=0\).
Thus \(w\) is continuous in global \(L^2\), and patching the distributional identities produces no temporal delta.
Its derivative may jump, as permitted by the lemma.
The newly constructed stress may jump as well; its equation uses only spatial divergence, so these jumps create no time delta.

Every stress summand is continuous in \(L^1\) on a closed cycle:
the antidivergence acts boundedly on the common compact-support, zero-moment subspace; translations and positive-radius rescalings are continuous in the norms used; and the quadratic/cross terms obey the displayed Hölder bounds.
For a merely locally smooth seed with bounded \(L^3\) norm, continuity of \(u\otimes w\) follows by first truncating the uniformly tight \(L^{3/2}\)-valued correction family, then using local smoothness of \(u\).
Consequently each new closed-cycle stress image is compact in \(L^1\), providing the uniform tail property needed for a subsequent finite-stage repair.
The finite positive minimum radius and smooth finite-cycle source imply a finite \(L^3\) norm for every correction, uniformly on this fixed finite interval.
Hence the output belongs to the asserted piecewise class. \(\square\)

## 7. Claim-by-claim disposition of the original probe

| Probe interface | Verdict | Precise scope |
|---|---|---|
| Section 1 Lamb signs and speed | PASS | Both source conventions produce the same correctly oriented velocity; piecewise regularity requires the explicit smoothing step. |
| Section 2 symmetric antidivergence | PASS | All zeroth and first moments are required and are actually verified for each force used. |
| Section 3 radius derivative | PASS | Core support, even parity, zero mean, and \(Cr\) tensor bound all hold. |
| Section 4 compact source | PASS | Mean is \(+2\pi\xi\), first moments zero; replacing it alters pressure and an integrable symmetric stress. |
| Section 5 one-scale raster | PASS WITH ITS EXPLICIT PARTITION CONDITION | The stated transverse partition of unity repairs the comb obstruction. The assembled proof instead uses independently checked \(d=H^2\) averaging. |
| Section 5 clocks and buffers | PASS AFTER EXACT NORMALIZATION | The \(g^{-1}\) effective-mass clock above includes buffer time and gives exact quarter-cycle allocation. A plateau-only clock with added ramps would be wrong. |
| Section 6 corrector sign and norms | PASS | Negative Leray primitive cancels oscillating source and leaves positive averaged tensor. Curl is estimated before projection, avoiding an invalid endpoint bound. |
| Section 7 stress decomposition | PASS | The displayed four coefficients are nonnegative and give \(-R+qI\); compact smooth regularization is made explicit above. |
| Section 7 literal smooth-to-smooth conclusion | FAIL AS WRITTEN | The corrector is generally not differentiable across cycle boundaries. Repaired by the finite piecewise-time lemma, not by claiming flatness. |
| Section 7 tail truncation from bare uniform \(L^1\) | NOT JUSTIFIED AS WRITTEN | Repaired by one-sided \(C_tL^1_x\) stress on finitely many closed pieces, which the output formulas preserve. |
| Section 8 weak initial trace and infinite strips | NOT CERTIFIED BY THIS AUDIT | Weak vanishing of shrinking individual dipoles is valid, but a complete locally finite strip iteration and summable global estimates require a separate assembled argument. |
| Section 9 smooth Euler background | NOT CERTIFIED BY THIS AUDIT | The harmonic-kernel decomposition is elementary and consistent, but the global background theorem and derivative hypotheses still require a checked source. |
| Section 10 comparison with published construction | SCOPE STATEMENT ONLY | No published theorem was upgraded to imply this finite-step lemma. |

## 8. Remaining load-bearing obligations

1. Independently audit the complete finite-step lemma above, including its piecewise class and parameter order.
2. Construct the infinite collection of time strips with actual locally finite refinements, uniform increment bounds, and an exact weak initial trace.
3. Verify the seed and Euler background belong to the needed class on every compact positive-time interval and have uniform curl variation toward zero.
4. Prove every-time canonical Biot–Savart normalization and the global time diagonalization in the assembled limit.

This audit identifies no fatal finite-cycle mechanism error. It does **not** certify a proof of the original global existence problem, since the remaining obligations have not been assembled here.

## 9. Addendum: subsequently appended Section 9 of the localization packet

The source author appended elementary assembly interfaces after the initially frozen version. I read and checked the addition separately; the resulting source SHA-256 is `5e96d3bb889dcd307bcda5b30776b88aa5e25d973658c1c98e5e9972b1e9e26a`.

- **W30 decomposition: PASS.** The diagonal entries expand to \(\rho-R_{11}\) and \(\rho-R_{22}\), and the off-diagonal entry is \(-R_{12}\). The inequality \(\rho\geq16|R|\) guarantees positivity. Smoothness across the cutoff boundary follows because \(R\) already vanishes there. This is an alternative to (DEC), not an extra assumption.
- **W31 and low-frequency \(L^4\) background: PASS.** The compactly supported Fourier multiplier is in \(L^{4/3}\), because \(|\xi|^{-4/3}\) is integrable near zero in two dimensions. Inverse Hausdorff–Young gives the asserted \(L^4\) bound. Hölder with the correction's \(L^{4/3}\) norm is valid without finite background energy.
- **Finite-patch tail propagation: PASS.** The zero-moment antidivergences have uniform \(|x|^{-3}\) tails when centers and source bounds range over a fixed finite patch. Principal velocities and projected compact correctors have uniform \(|x|^{-2}\) tails. These tails vanish uniformly in the stated \(L^p\) norms; Hölder controls products with a merely bounded \(L^4\) background. The smoothing commutator also has uniformly integrable product tails. Therefore uniform tightness of the old stress propagates to the new stress.

The explicit tail argument can replace continuous \(L^1\)-valued stress as the mechanism for the next spatial truncation, provided old stress tightness is an actual input and time freezing is justified separately. It does not establish tightness from the bare uniform \(L^1\) norm.

## 10. Prescribed-piece corollary in the minimal piecewise class

The stronger smoothness assumptions in section 2 are unnecessary for the actual prescribed-piece interface.
The following version follows from the explicit packet construction and finite approximation, without differentiating or smoothing the old velocity or prescribed stress.

### Corollary \(P_{\mathrm{pw}}\)

Let \(J\Subset(0,\infty)\) be an open bounded interval.
Let \((u,p,R)\) be an Euler–Reynolds pair in distributions, with

\[
u\in C(J;L^2_{\mathrm{loc}})\cap C(J;L^3(\mathbb R^2)),
\]

and symmetric \(R\) piecewise continuous into global \(L^1\) on a locally finite positive-time partition, using one-sided extensions at its boundaries.
Let \(S\) be a symmetric prescribed stress with compact time support in \(J\), piecewise continuous into \(L^1\) on that partition or a locally finite refinement, and set
\(\delta=\sup_{t\in J}\|S(t)\|_1<\infty\).

For any four independent budgets

\[
\varepsilon>0\quad\text{(stress error)},\qquad
\zeta>0\quad\text{(increment slack)},\qquad
\beta>0\quad\text{(}\!L^{3/2}\text{ size)},\qquad
r_*>0\quad\text{(principal radius cap)},
\]

there exist a divergence-free correction \(w\) and a symmetric error \(E\), both compactly supported in time in \(J\), such that

\[
\begin{gathered}
(u+w,p_1,R-S+E)\quad\text{is an Euler–Reynolds triple},\\
\sup_t\|E(t)\|_1\leq\varepsilon,\\
\sup_t\bigl(\|w(t)\|_2+\|\operatorname{curl}w(t)\|_1\bigr)
\leq C\sqrt\delta+\zeta,\\
\sup_t\|w(t)\|_{3/2}\leq\beta.
\end{gathered}
\tag{Ppw}
\]

The correction is continuous into \(L^2\cap L^3\cap L^{3/2}\), and vanishes at every inherited boundary in its construction support and every completed full-cycle boundary.
The error is piecewise continuous into \(L^1\), with only finitely many new boundaries in \(J\).
All principal core radii can be chosen at most \(r_*\).
The universal leading constant \(C\) is independent of \(J\), support size, old-field derivatives, approximation modulus, and all four budgets.
Values of stresses at isolated boundaries can be selected from either bounded trace; their values do not affect the distributional equation.

**Proof.** If \(\delta=0\), take \(w=E=0\).
Otherwise choose a closed interval \([a,b]\Subset J\) containing the time support of \(S\) in its interior.
Only finitely many inherited boundaries meet this interval.
Split at those boundaries, and on each closed one-sided continuity piece use uniform \(L^1\) continuity to choose a finite further subdivision with the following property: for each resulting coarse cell \(I_k\), there is a fixed symmetric \(S_k\in C_c^\infty(\mathbb R^2;\mathbb R^{2\times2})\) satisfying

\[
\sup_{t\in I_k}\|S(t)-S_k\|_1\leq\alpha,
\qquad \|S_k\|_1\leq\delta+\alpha.
\tag{APP}
\]

To construct it, first freeze \(S\) at one time in the continuity piece with uniform error at most \(\alpha/2\), then approximate that single \(L^1\) tensor by a compact smooth symmetric tensor with error at most \(\alpha/2\).
There are finitely many cells, so all chosen supports and all spatial derivatives of these fixed approximants have finite maxima.
No derivative of \(S\) is taken.

On \(I_k\), use the block construction in sections 3–5 with the constant target \(S_k\): decompose \(-S_k+q_kI\), repeat complete four-direction cycles entirely inside \(I_k\), and use one time corrector over each full cycle.
Only the \(L^3\) bound of the actual current velocity \(u\) is needed for the cross terms.
Its finite supremum on \([a,b]\) follows from continuity and compactness.
Thus this construction gives an exact new stress

\[
R-S_k+E_k^{\mathrm{loc}}
\]

on the cell, with \(\sup_t\|E_k^{\mathrm{loc}}(t)\|_1\) arbitrarily small.
This conclusion uses the algebra (RES) with \(S_k\) in place of the stress to be canceled; it does not require the old full stress \(R\) itself to be compact or smooth.
In particular, the old equation is added to the new exact packet equation without applying any operation to \(u\) or \(R\).

Define the error relative to the prescribed piece by

\[
E(t)=S(t)-S_k+E_k^{\mathrm{loc}}(t),\qquad t\in I_k.
\tag{ERR}
\]

Then
\(R-S+E=R-S_k+E_k^{\mathrm{loc}}\) exactly.
Choose \(\alpha\leq\varepsilon/2\) and make every local error at most \(\varepsilon/2\), proving the stress bound in (Ppw).

The leading correction estimate on every coarse cell is
\(C\sqrt{\delta+\alpha}\) plus independently selectable small terms.
Choose \(\alpha\) also so small that \(C\sqrt\alpha\leq\zeta/3\), then choose decomposition regularization and floor masses to contribute at most \(\zeta/3\), and finally choose the cycle frequency to put the corrector contribution below \(\zeta/3\).
Using \(\sqrt{\delta+\alpha}\leq\sqrt\delta+\sqrt\alpha\) proves the desired independent increment budget.

At fixed floors and coefficients, \(H\downarrow0\), \(d=H^2\), \(\tau=H^6\) make both the principal \(L^{3/2}\) norm
\(C\eta_i r_{\max}^{1/3}\) and the corrector norm
\(C\tau H^{-2/3}D\) tend to zero.
They can therefore be made at most \(\beta\), simultaneously with all preceding error estimates.
The same choice makes \(r_{\max}\leq r_*\).
Neither requirement changes the leading amplitude estimate.
The final spatial smoothing only decreases these norms and can be chosen small enough for its separate stress error budget.

Each coarse cell is divided into an integer number of complete cycles, with \(H\) selected from its actual length as in section 6.
All corrections are zero at coarse-cell endpoints and at every full-cycle endpoint.
Set \(w=E=0\) outside \([a,b]\).
Because \(S=0\) there, the old equation is unchanged outside, and continuous zero pasting of \(w\) excludes temporal delta functions.
Possible jumps of \(E\) are harmless because the equation applies only spatial divergence to that tensor.
The supports of both outputs are closed subsets of \([a,b]\Subset J\).

For every fixed finite construction, the radii have a positive minimum.
The principal smoothed profiles consequently depend continuously on time in all three spaces \(L^2,L^3,L^{3/2}\), including zero endpoint limits.
The same is true of the time corrector: the Leray projection is bounded on all three spaces, and its defining primitive is zero at both full-cycle ends.
Thus the globally pasted \(w\) has the claimed strong continuity.
The local block errors are continuous into \(L^1\) on each closed cycle; the cross terms are continuous by

\[
\|u(t)\otimes w(t)-u(s)\otimes w(s)\|_1
\leq\|u(t)-u(s)\|_3\|w(t)\|_{3/2}
 +\|u(s)\|_3\|w(t)-w(s)\|_{3/2}.
\]

Together with (ERR), this proves the required piecewise \(L^1\) continuity of \(E\), hence of the new stress.
The new velocity retains \(C_tL^3\) and local \(C_tL^2\) by addition.
All refinements are finite on the chosen compact patch, completing the proof. \(\square\)

**Scope of this corollary.** It proves the prescribed-piece property needed by the amended piecewise iteration interface, with independent stress, norm-slack, \(L^{3/2}\), and core-radius budgets. It does not itself prove the infinite colored-strip iteration or its initial trace. The complete corollary remains a new load-bearing proof packet requiring independent audit.

## 11. Independent stress-normalization check

The source coefficient \(\kappa=2\pi\) is independently consistent with the exact dipole's integrated anisotropic stress:

\[
\int_{\mathbb R^2}(V_1^2-V_2^2)dx=2\pi,
\qquad\int_{\mathbb R^2}V_1V_2dx=0.
\]

The exterior doublet has equal diagonal energies and zero mixed integral by angular integration.
Inside the unit core, direct conversion of the stream function to Cartesian velocity gives

\[
V_1=A(r)+B(r)\cos2\theta,\qquad
V_2=B(r)\sin2\theta,\qquad
A(r)=1-\frac{J_0(br)}{J_0(b)}.
\]

Thus the angular integral of \(V_1^2-V_2^2\) is \(2\pi A(r)^2\).
The identities

\[
\int_0^1rJ_0(br)dr=J_1(b)/b=0,\qquad
\int_0^1rJ_0(br)^2dr
=\frac{J_0(b)^2+J_1(b)^2}{2}=\frac{J_0(b)^2}{2}
\]

give \(2\pi\int_0^1rA(r)^2dr=2\pi\).
The second Bessel integral follows by differentiating
\(r^2[J_0(br)^2+J_1(br)^2]/2\) and using the elementary Bessel recurrences.
Parity gives the mixed integral zero.
Hence the source averaging coefficient and the dipole's physical trace-free stress agree, providing a separate check against a lost sign or factor of two.
