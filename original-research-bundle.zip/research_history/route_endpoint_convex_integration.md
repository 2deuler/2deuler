# Endpoint convex-integration route: independent examination

Worker: `/root/signed_compactness`, new assignment. Primary source: Bruè–Colombo–Kumar, *Flexibility of Two-Dimensional Euler Flows with Integrable Vorticity*, arXiv:2408.07934v1, https://arxiv.org/html/2408.07934v1 . I inspected the perturbation construction, its estimates, the iteration statement, endpoint treatment, and anti-divergence appendix directly. This packet distinguishes source results, independently derived endpoint bounds, and an uncompleted adaptation. It does not assert a solution of the target.

## 1. Exact source mismatch

The source constructs solutions on the torus, with vorticity in a particular $L^p$ space for $p>1$. Its flexibility theorem approximates arbitrary prescribed initial and final velocities. It does not prescribe an arbitrary rough initial velocity exactly. The principal and temporal corrections vanish at designated time-cell endpoints, but the new velocity there equals the *mollified* preceding velocity. The fixed spacetime mollification changes the trace; source Proposition 3.1 controls that change by a small error, not by zero.

The endpoint route below changes the controlled norm from $\nabla u\in L^p$ to $\operatorname{curl}u\in\mathcal M$. This is substantial: gradients of potential correctors vanish under curl, and a curl estimate does not require an endpoint Calderón–Zygmund bound.

## 2. Scale-free principal curl estimate

Let $\bar V$ denote the fixed Lamb–Chaplygin velocity profile. Its curl is a bounded function supported in the unit disk; hence $C_*:=\|\operatorname{curl}\bar V\|_1<\infty$. Its scaled version is

\[
\bar V_r(x)=r^{-1}\bar V(x/r),\qquad
\operatorname{curl}\bar V_r(x)=r^{-2}(\operatorname{curl}\bar V)(x/r).
\]

Thus $\|\operatorname{curl}\bar V_r\|_1=C_*$ for every $r>0$. The source replaces $\bar V_r$ by $W_r=\bar V_r-\nabla\Pi_r$ and then corrects divergence by adding $V^c=-\nabla\Delta^{-1}\operatorname{div}V^p$. Neither operation changes curl. For a translated, rotated block with scalar time amplitude $\eta(t)$,

\[
V^p(x,t)=\eta(t) W_{r(t)}(x-X(t)),\qquad
\|\operatorname{curl}(V^p+V^c)(t)\|_1=C_*|\eta(t)|.
\]

Positive spatial mollification, used to make the profile smooth, can only decrease this $L^1$ norm. The source's amplitude satisfies $\eta^2\le C\delta$ when the old stress has $L^1$ size $\delta$. Since only one principal block is active at any time,

\[
\boxed{\ \|\operatorname{curl}v_{q+1}\|_{L^\infty_tL^1_x}\le C\sqrt\delta.\ }
\]

There is no dependence on core radius, frequency, coarse derivatives, or number of time cells. This derivation does not set $p=1$ in an $L^p$ estimate whose constant is singular at the endpoint.

## 3. Endpoint temporal-corrector estimate

Use a time cell $I=[b,b+\tau]$, and let $\bar U_I=\tau^{-1}\int_IU(s)\,ds$. The temporal corrector is

\[
Q(t)=-\mathbb P\int_b^t[U(s)-\bar U_I],ds,
\qquad Q(b)=Q(b+\tau)=0.
\]

Here $\mathbb P=I-\nabla\Delta^{-1}\operatorname{div}$ is the Leray projection, so $\operatorname{curl}\mathbb P f=\operatorname{curl}f$ distributionally. The auxiliary source is

\[
U(t,x)=A'(t)\widetilde U(x-X(t))\xi,
\qquad A(t)=\eta\zeta(t)r(X(t)).
\]

Its scalar profile has unit mass, support radius $C/\lambda$, and $\|D\widetilde U\|_1\le C\lambda$. Hence

\[
\|\operatorname{curl}Q(t)\|_1
\le2\tau\sup_I\|\operatorname{curl}U\|_1
\le C\tau\lambda\sup_I|A'|.
\]

Write $r(x)=r_0a(x)$, assume $a\ge\delta$, $\|a\|_1\le C\delta$, and $\eta^2\le C\delta$. The motion law is $X'=\eta\zeta\xi/r(X)$ and $|\zeta'|\le C\lambda/\tau$. Direct differentiation gives

\[
|A'|\le C\sqrt\delta,r_0\|a\|_\infty\frac\lambda\tau
+C\delta\frac{\|Da\|_\infty}{\inf a}.
\]

Under the traversal constraint $\lambda^2r_0\sqrt\delta\le c\tau$, this is at most $C\|a\|_{C^1}$. Therefore

\[
\boxed{\ \|\operatorname{curl}Q\|_{L^\infty_tL^1_x}
\le C\tau\lambda\|a\|_{C^1}.\ }
\]

For the velocity itself, use the ordinary $p=2$ Leray bound to obtain $\|Q\|_{L^\infty_tL^2_x}\le C\tau\lambda\|a\|_{C^1}$. Again no endpoint bound for $\mathbb P:L^1\to L^1$ is used.

## 4. Raw parameter obligations, independent of the source's fixed powers

Consider a fixed smooth coarse Euler–Reynolds triple on a compact positive-time interval of the torus. Let the old stress be bounded by $\delta$ in $L^\infty_tL^1_x$. After a sufficiently fine mollification, decompose it into the four source directions with coefficients $a_i$. Write

\[
B=\max_i\|a_i\|_{C^0},\quad A=\max_i\|a_i\|_{C^1},
\quad E=\|u_\ell\|_{L^\infty L^2},\quad D=\|u_\ell\|_{L^\infty L^3}.
\]

These quantities may be very large, but are finite on that interval. Let $\varepsilon>0$ be the next stress target and $s>0$ the allowed temporal-corrector curl cost. Constants depending on a fixed auxiliary exponent are allowed. The following sufficient requirements collect the actual mechanisms:

| Mechanism | Sufficient requirement, up to fixed constants |
|---|---|
| Principal support within auxiliary support | $r_0B\le c\lambda^{-5}$ |
| Many traversals during each time subcell | $\lambda^2r_0\sqrt\delta\le c\tau$ |
| Freezing coefficients in time | $\tau A\le\varepsilon$ |
| Temporal corrector | $\tau\lambda A\le s$ and $\tau\lambda A(E+\sqrt\delta+\tau\lambda A)\le\varepsilon$ |
| Linear interaction with the coarse velocity | $\sqrt\delta(r_0B)^{1/3}D\le\varepsilon$ |
| Intrinsic block stress | $\delta(r_0B)^{1/2}(1+A/\delta)\le\varepsilon$ |
| Time-average reconstruction error | $A/\lambda\le\varepsilon$ |
| Replacing the concentrated source by the auxiliary source | $C_p A\lambda^{-1}(r_0\delta)^{-\theta}\le\varepsilon$, $\theta=2-2/p>0$ |
| Coarse mollification error | Chosen below $\varepsilon$ and below the desired velocity increment by its own local smoothing scale |

The source-replacement estimate still uses a fixed $p>1$ symmetric anti-divergence estimate. It is not legitimate to replace that by an unproved $p=1$ operator estimate. This does not prevent the endpoint *curl* argument.

A concrete compatible hierarchy is

\[
\boxed{\quad \tau=\lambda^{-3},\qquad r_0=\lambda^{-6},
\qquad p=24/23,\qquad\theta=1/12.\quad}
\]

For fixed $\delta,A,B,D,E,\varepsilon,s$, every requirement is satisfied when $\lambda$ is sufficiently large. The source-replacement error is $C_p A\delta^{-1/12}\lambda^{-1/2}$; the temporal-corrector size is $CA\lambda^{-2}$; the other displayed errors also tend to zero. Thus making the core arbitrarily small *at fixed frequency* would be wrong, but making core radius and frequency satisfy this hierarchy is consistent.

This endpoint hierarchy decouples $\delta$ from $\lambda$. It no longer seeks the source's uniform $C_t^\alpha W^{1,p}_x$ bound. Consequently the coarse derivatives can determine how large the next frequency must be without increasing the principal curl cost.

## 5. Positive-time initial seed on the torus

For this subsection alone let $u_0\in L^2(\mathbb T^2)$ be divergence-free and mean zero, with $\operatorname{curl}u_0\in\mathcal M$. Define

\[
U(t)=e^{t^2\Delta}u_0,
\qquad
R(t)=U(t)\otimes U(t)+2t[DU(t)+DU(t)^T],\qquad p=0.
\]

The symmetric tensor satisfies

\[
\operatorname{div}R
=\operatorname{div}(U\otimes U)+2t\Delta U
=\operatorname{div}(U\otimes U)+\partial_tU.
\]

The seed is smooth for $t>0$, has the exact strong $L^2$ trace $u_0$, and obeys

\[
\|U(t)\|_2\le\|u_0\|_2,
\qquad\|\operatorname{curl}U(t)\|_1\le\|\operatorname{curl}u_0\|_{\mathcal M},
\qquad \sup_{0<t\le T}\|R(t)\|_1<\infty.
\]

The last claim follows from finite torus volume and $t\|De^{t^2\Delta}u_0\|_2\le C\|u_0\|_2$. This seed does not satisfy a uniform high-derivative bound at $t=0$, so source Proposition 3.1 cannot be invoked directly on a closed interval containing zero.

## 6. Proposed positive-time iteration, with exact weak trace

The following is a candidate adaptation needing a full iteration proof and independent audit. It is more concrete than invoking a density theorem.

### 6.1 Local positive mollification

Assume at stage $q$ that the velocity is locally continuous in $L^2$ on $(0,T]$, has the fixed weak trace $u_0$, and has uniform $L^2$ and curl-measure bounds. Cover positive time by overlapping dyadic intervals, and choose a nonnegative smooth partition $\chi_j(t)$ with $\sum_j\chi_j=1$. Pick a separate positive spacetime convolution kernel $\rho_j$ inside each enlarged interval, with support staying at positive times. Set

\[
u_\ell(t)=\sum_j\chi_j(t)(u_q*\rho_j)(t).
\]

Divergence, mean zero, the uniform $L^2$ bound, and the uniform curl-measure bound are preserved by convexity. The radii can be chosen separately to make $\|u_\ell-u_q\|_{L^\infty L^2}$ as small as desired. The extra forcing from differentiating the time partition is

\[
f(t)=\sum_j\chi'_j(t)[(u_q*\rho_j)(t)-u_q(t)],
\]

because $\sum_j\chi'_j=0$. It has zero spatial mean. Its symmetric anti-divergence is small in $L^1$ on the torus whenever $f$ is small in $L^2$. The local convolution radii can make this error arbitrarily small despite large $\chi'_j$. The quadratic convolution/partition error is likewise small in $L^1$ by local $L^2$ closeness. This provides a route to smooth positive-time coarse triples without increasing the curl bound.

The weak initial trace survives: averaging only times comparable to $t$ and spatial radii tending to zero preserves each smooth-test pairing, while the uniform $L^2$ bound upgrades this to weak $L^2$ convergence.

### 6.2 Adaptive time cells

On each dyadic slab $J_j=[2^{-j-1},2^{-j}]$, all coarse derivatives are bounded. Choose a dyadic integer $\lambda_j=2^{m_j}$ so large that the requirements in section 4 hold throughout the slab. Require $3m_j\ge j+1$, so $\tau_j=\lambda_j^{-3}$ divides the slab length exactly. Use the source's four-direction cell construction separately in each cell, with $r_{0,j}=\lambda_j^{-6}$. At all cell boundaries, the principal correction and $Q$ vanish. Hence the resulting velocity is continuous in $L^2$ at the boundaries. Its time derivatives may jump; this is acceptable for a piecewise smooth Euler–Reynolds identity and can be removed by the next local mollification.

The correction has uniformly bounded curl cost $C\sqrt{\delta_q}+s_q$ on every slab, independent of $j$. Increase $\lambda_j$ further to ensure, as $j\to\infty$,

\[
\|v_{q+1}\|_{L^\infty(J_j;L^{3/2})}\longrightarrow0,
\qquad
\|Q_{q+1}\|_{L^\infty(J_j;L^2)}\longrightarrow0.
\]

The first condition follows from $\|v\|_{3/2}\le C\sqrt\delta(r_0B)^{1/3}$. Therefore the perturbation tends weakly to zero in $L^2$ as $t\downarrow0$, even though its $L^2$ norm need not vanish. The weak initial trace remains exact.

### 6.3 Summation mechanism

Choose stress targets with $\sum_q\sqrt{\delta_q}<\infty$ and corrector/mollification budgets with summable costs. If the full local perturbation lemma described above is established, its outputs satisfy

\[
\|u_{q+1}-u_q\|_{L^\infty L^2}\le C\sqrt{\delta_q}+s_q,
\qquad
\|\operatorname{curl}u_{q+1}\|_{L^\infty\mathcal M}
\le\|\operatorname{curl}u_q\|_{L^\infty\mathcal M}
+C\sqrt{\delta_q}+s_q.
\]

Uniform strong $L^2$ convergence of the iteration would pass the quadratic Euler term and retain the exact weak initial trace. Weak-star compactness of curl and the uniform bounds give the measure property at every time. A temporal cutoff then extends the bulk weak identity to the initial endpoint. This route deliberately uses only the weak trace required by the target; insisting on strong trace would destroy the particular freedom used near $t=0$.

## 7. What is established and what is still missing

The scale-free principal curl bound, the direct curl bound for the temporal corrector, compatibility of the raw parameter hierarchy, and the torus positive-time seed are independently derived above. They are candidate load-bearing facts pending independent audit.

The positive-time iteration is not supplied by the source as a theorem. Its full proof must check the assembled Euler–Reynolds identity on nonuniform time cells, the local mollification commutators, all constants uniformly across slabs, exact mean cancellation, and convergence on the complete time interval. Mean cancellation has a simple mechanism: the principal block's mean is $A(t)\xi$; the corrector's mean is $-A(t)\xi$ because the cell-average source has mean zero.

Most importantly, the authoritative problem is on $\mathbb R^2$. The torus trajectory sweeps and its anti-divergence estimates cannot be treated as a proof on the plane. On the plane, the global symmetric order-zero anti-divergence can have a nonintegrable $|x|^{-2}$ tail. A construction using localized symmetric stresses or a separately proved whole-plane perturbation theorem is required. The original data can also have infinite total kinetic energy, which lies beyond the finite-energy seed considered in this assignment.

Parent separately supplied a promising finite-energy whole-plane seed using a biharmonic heat multiplier; that construction is not independently audited in this file. It addresses the seed obstruction, not the torus-to-plane perturbation obstruction.

## 8. Specific whole-plane follow-up suggested by the mechanism

A possible replacement for periodic torus sweeps is a finite grid of long straight traversals of a large box, with the dipole switched off before moving to the next line. The time-average calculation only needs integration by parts and the trajectory speed law; periodicity supplies a convenient uniform sampling identity, which could instead be replaced by a quadrature estimate. Since only one block is active at a time, the principal curl bound remains independent of the number of lines. This has not been carried out.

Compactly supported *symmetric* anti-divergence requires zero total force and zero torque. For the intrinsic constant-speed dipole residual, the torque reduces to the transverse mean of the dipole, which vanishes by symmetry. For source replacement, a centered radial auxiliary profile would match both mass and first moments of the concentrated source. These observations suggest checking localized symmetric anti-divergence rather than using a global Calderón–Zygmund operator whose $L^1$ tail is uncontrolled. Full moment computations and quantitative localized operator estimates remain obligations.

## 9. A concrete compact symmetric anti-divergence lemma

**Statement.** Fix $1<p<\infty$. If $f\in C_c^\infty(B_R(a);\mathbb R^2)$ satisfies

\[
\int f=0,
\qquad \int(x_1f_2-x_2f_1)\,dx=0,
\]

then there exists $S\in C_c^\infty(B_R(a);\mathrm{Sym}_2)$ with

\[
\operatorname{div}S=f,\qquad \|S\|_p\le C_pR\|f\|_p.
\]

The construction is linear in $f$ for a fixed ball. Constants are invariant under translation and dilation.

**External interface.** On a ball, the Bogovskii operator $\mathcal B$ maps compact smooth zero-mean scalars to compact smooth vector fields, with $\operatorname{div}\mathcal Bg=g$, $\|\mathcal Bg\|_p\le C_pR\|g\|_p$ and $\|D\mathcal Bg\|_p\le C_p\|g\|_p$. This precise support/regularity interface is furnished by Costabel–McIntosh, arXiv:0808.2614v2, Corollaries 3.3–3.4, Remark 3.5 and the homotopy identities; these portions of the primary source were inspected. The norm $W^{1,p}$ statement follows by taking integer regularity one in their $F^s_{p,2}$ formulation, for $1<p<\infty$. Scaling gives the displayed radius factors.

**Proof of the symmetric construction.** Apply $\mathcal B$ row by row to obtain a compact matrix $A$ with $\operatorname{div}A=f$ and $\|A\|_p\le C_pR\|f\|_p$. Let

\[
J=\begin{pmatrix}0&-1\\1&0\end{pmatrix},\qquad
\operatorname{skew}A=a_0J,
\qquad a_0=(A_{21}-A_{12})/2.
\]

Integration by parts yields

\[
\int(x_1f_2-x_2f_1)
=\int(A_{12}-A_{21})=-2\int a_0.
\]

Thus $a_0$ has zero integral. Put $b=\mathcal B a_0$ and define

\[
B_{ij}=\sum_k[J_{ik}\partial_kb_j+J_{jk}\partial_kb_i].
\]

Then $B$ is symmetric and compactly supported, and direct differentiation gives

\[
\sum_j\partial_jB_{ij}
=\sum_kJ_{ik}\partial_k(\operatorname{div}b)
+\sum_{j,k}J_{jk}\partial_j\partial_kb_i
=(J\nabla a_0)_i.
\]

The last double sum vanishes because $J$ is antisymmetric and second derivatives commute. Hence

\[
S=\operatorname{sym}A+B
\quad\Longrightarrow\quad
\operatorname{div}S
=\operatorname{div}A-\operatorname{div}(a_0J)+J\nabla a_0=f.
\]

Finally, $\|B\|_p\le C\|Db\|_p\le C_p\|a_0\|_p\le C_p\|A\|_p$, proving the norm bound. Smoothness and support follow twice from the Bogovskii interface. This proves the lemma conditional only on the explicitly checked external operator theorem, pending an independent audit.

### Application to the dipole moments

For the fixed direction $e_1$, the truncated dipole $W_r$ is centrally even, hence $\int x_j(W_r)_k=0$; its mean is a constant multiple of $re_1$. The intrinsic residual

\[
f_1=-r^{-1}\partial_1W_r+\operatorname{div}(W_r\otimes W_r)+\nabla P_1
\]

has zero mean and torque: symmetric quadratic stresses and gradients contribute zero torque, while the transport term contributes $r^{-1}\int(W_r)_2=0$. It is supported in the cutoff annulus. The radial-scale residual

\[
f_2=\partial_rW_r-r^{-1}W_r-\nabla P_2
=-\operatorname{div}(\bar V_r\otimes x/r)
\]

is supported in the core, has zero mean because $\partial_r\int W_r-r^{-1}\int W_r=0$, and has zero torque because the first moments of $W_r$ vanish. Rotations and translations preserve the two compatibility conditions. Therefore the plane intrinsic errors can be given compact symmetric stress representatives, rather than global representatives with problematic tails.

For source replacement, $S=W_r/r$ and a centered, centrally even auxiliary profile times $\xi$ have matching mass and vanishing relative first moments. Their difference consequently has zero mean and torque. If its support radius is $h\sim\lambda^{-1}$, the lemma and Hölder's inequality give

\[
\|\mathcal S f\|_1\le C_p h^{1+\theta}\|f\|_p,
\qquad\theta=2-2/p,
\]

which is suitable for the source-replacement estimate. This repairs a specific plane operator obstruction. A whole-plane averaging construction and the full iteration remain uncompleted.
