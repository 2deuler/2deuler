# Initial subsolution for an endpoint curl construction

STATUS: Root derivation, frozen candidate packet for independent audit. This is not an Euler existence proof.

## A. Finite-energy initial data

Let u0 belong to L2(R2;R2), div u0=0, and mu=curl u0 be a finite signed measure. Write E=||u0||2 and M=||mu||M. Fourier transform uses exp(-i x.xi). Define rho by rho-hat(xi)=exp(-|xi|^4), and rho_t(x)=t^{-2}rho(x/t), t>0. This is the biharmonic heat kernel at semigroup time t^4, not a positive kernel. It is a real radial Schwartz function of integral one; C_rho=||rho||1 is finite.

Set

    U(t)=rho_t*u0,
    R(t)=U(t) tensor U(t)-4t^3 [grad Delta U(t)+(grad Delta U(t))^T],
    p(t)=0.

Then (U,p,R) solves the Euler–Reynolds system

    partial_t U + div(U tensor U)+grad p=div R, div U=0

on (0,infinity) times R2. It has the following bounds for 0<t<=T:

    ||U(t)||2 <= E,
    ||curl U(t)||1 <= C_rho M,
    ||R(t)||1 <= E^2 + C t M <= E^2+C T M.

Moreover U(t)->u0 strongly in L2 as t decreases to zero, and U,R are smooth for positive times with finite spatial norms of every derivative required on compact time intervals bounded away from zero.

Proof: The Fourier multiplier has modulus at most one and tends pointwise to one, so Plancherel and dominated convergence give the energy bound and strong initial trace. Vorticity is rho_t*mu, giving the L1 estimate by finite-measure convolution. Since partial_t U=-4t^3 Delta^2 U, and div[grad Delta U+(grad Delta U)^T]=Delta^2 U for div U=0, the displayed system follows exactly. For a divergence-free field, Delta U=grad-perp curl U with grad-perp=(-partial_2,partial_1). Thus grad Delta U is a matrix of second derivatives of rho_t*mu, and

    ||grad Delta U||1 <= ||D^2 rho_t||1 M = t^{-2} ||D^2 rho||1 M.

Multiplication by 4t^3 yields the claimed CtM bound. This proof uses no L1 boundedness of a Riesz transform. The kernel is signed, so its total variation constant is C_rho rather than one. No positivity property is claimed.

## B. Candidate extension to the exact inhomogeneous target class

Let mu0 be the target datum and u0=K*mu0. Choose real radial chi in C_c^infinity, chi=1 near zero, and 0<=chi<=1. Let eta=F^{-1}chi. Set

    v0=(Id-chi(D))u0,
    U0=chi(D)u0,
    nu0=eta*mu0,
    sigma0=mu0-nu0.

The existing initial-velocity packet proves v0 in L2, U0 bounded smooth, nu0 in L1 intersect Linfinity, and sigma0 a finite signed measure. The additional claim needed here is v0 in L1 with ||v0||1<=C_chi ||mu0||M.

Proof of this additional claim: Define L=K-eta*K. Near the origin K is locally integrable and eta*K is bounded, so L is locally integrable. For large |x|, split the convolution into |y|<=|x|/2 and its complement. Since integral eta=1, integral y eta(y)dy=0, and every higher moment of eta is zero (chi is constant near zero), Taylor expansion of K(x-y) through any fixed order yields an arbitrarily rapidly decaying remainder on the first region. On the complementary region, the Schwartz decay of eta controls the local K singularity near y=x, and the remaining region is controlled by |K(x-y)|<=C or by its decay; the omitted moment tails are also arbitrarily small. Therefore L(x)=O_N(|x|^{-N}) for any fixed N away from the origin. In particular L is in L1, and v0=L*mu0 belongs to L1 by Young's inequality. This tail argument should be independently checked without assuming eta is compactly supported.

Let V(t) be the global smooth bounded-vorticity Euler solution with initial vorticity nu0 and velocity U0. The standard L1/Linfinity vorticity construction applies: ||curl V(t)||1<=||nu0||1 and ||V(t)||infinity is bounded on each finite time interval (indeed the conserved L1/Linfinity norms give a global bound). Its pressure pV is retained. Define

    W(t)=rho_t*v0,
    Ubar(t)=V(t)+W(t),
    Rbar(t)=W tensor W+V tensor W+W tensor V
            -4t^3 [grad Delta W+(grad Delta W)^T],
    pbar=pV.

Then the same direct expansion gives the Euler–Reynolds system for (Ubar,pbar,Rbar), and

    ||curl Ubar(t)||1 <= ||nu0||1+C_rho||sigma0||M,
    ||Ubar(t)-V(t)||2 <= ||v0||2,
    ||Rbar(t)||1 <= ||v0||2^2
                    +2 C_rho ||V(t)||infinity ||v0||1
                    +C t||sigma0||M.

All quantities are uniformly finite on 0<t<=T. The initial trace is u0 strongly in local L2, provided the standard V(t)->U0 local continuity is verified from the smooth bounded-vorticity construction. The vorticity of Ubar is globally L1 for positive time and has the exact weak measure trace mu0. Its velocity is the prescribed Biot–Savart convolution at each time, since both V and W are canonical convolutions and the latter identity follows by Fubini/Fourier multiplication.

This supplies a candidate uniform-stress initial subsolution for every datum in the exact problem, including nonzero circulation and noncompact tails. It does not supply a perturbation lemma on R2, convergence of an iteration, or exact initial trace of the final perturbed solution.

## C. Perturbation interfaces remaining

1. A one-step Euler–Reynolds repair on R2 with curl-L1 cost C sqrt(delta)+small, independent of coefficient derivative size after frequency choices.
2. Stress reduction in global L1 and small L2 velocity increment relative to V.
3. For non-finite-energy V, use V in L3 (bounded plus weak L2 from finite vorticity) and perturbations in L^{3/2}, rather than multiplying two globally L2 fields when one is not globally L2.
4. A locally finite time construction on (0,T] which keeps correction weakly zero at time zero and does not lose the uniform curl bound through infinitely many overlapping strips.
5. Four independent source-ordered audits of any assembled complete proof.

Verification provenance: direct Fourier/kernel/algebra calculation by root; not yet independently verified. The external smooth Euler existence interface is provided in route_initial_velocity_interfaces.md and must be checked there before use.
