# External background existence certificate

Verifier: primary_interfaces. Status: **PASS for the stated background interface.** The primary theorem and its defining assumptions were reopened and read directly for this certificate. No other worker's conclusion is used as a premise. The one substantive external existence input is identified below; all supplementary norm, representative, and velocity-equation assertions are derived here.

## 1. Certified statement

Let

    K(x)=(-x2,x1)/(2pi |x|²),
    nu0 in L1(R2) intersect Linfinity(R2), real-valued,
    b0=K*nu0.

No sign, support, circulation, moment, or finite-kinetic-energy hypothesis is imposed. Put `M=||nu0||_1`, `N=||nu0||_infinity`, and `Eomega=||nu0||_2<=sqrt(MN)`. There is a global canonical bounded-vorticity solution `(nu,b)` with an every-time representative such that:

1. `nu(t) in L1 intersect Linfinity` and `b(t)=K*nu(t)` for every t>=0; `div b=0`, `curl b=nu`.
2. For every p in `[1,infinity]`, `||nu(t)||_p=||nu0||_p`; circulation is preserved. For finite p, `nu in C([0,infinity);Lp)`.
3. `b(0)=b0`; `b` solves the velocity Euler equation against compact smooth divergence-free tests, including the exact initial term. It belongs to `C([0,infinity);L2_loc)` and `C([0,infinity);L3)`.
4. If M=N=0 the solution is zero. Otherwise one may take `B=sqrt(2MN/pi)` in

       sup_t ||b(t)||_infinity <= B,
       sup_t ||b(t)||_3³ <= (6/pi) M² B.

5. For every s,t>=0,

       b(t)-b(s) in L2(R2),
       ||b(t)-b(s)||_2 <= B Eomega |t-s|,
       ||b(t)-b(s)||_3³ <= 2B³ Eomega² |t-s|².

   Thus `b-b0 in W^{1,infinity}_loc([0,infinity);L2)` even when b0 and b(t) separately have infinite global kinetic energy. Also `grad b in L-infinity_t L2` and `||grad b(t)||_2=||nu(t)||_2` with the Frobenius matrix norm.

Only bounds, the canonical normalization, the velocity equation, and the continuity/L2-difference statements are needed by the candidate construction. Exact norm preservation and strong finite-p vorticity continuity are included with a direct derivation, not silently attributed to a stronger external theorem.

## 2. Exact external input and hypothesis match

**Primary source:** Gianluca Crippa and Giorgio Stefani, *An elementary proof of existence and uniqueness for the Euler flow in localized Yudovich spaces*, Calculus of Variations and Partial Differential Equations **63**, article 168 (2024), published 5 July 2024.

URL and DOI: <https://link.springer.com/article/10.1007/s00526-024-02750-4>.

**Exact locations checked:** Assumption 2.1, equations (2.1)–(2.2); Assumption 3.1, equations (3.1)–(3.2); Definition 3.2; Theorem 3.3, equations (3.4)–(3.7). Theorem 3.3 supplies a global Lagrangian weak vorticity solution for initial data in L1 intersect Linfinity, under those kernel assumptions, with finite-horizon vorticity and velocity bounds and a log-Lipschitz velocity modulus. Definition 3.2 includes the canonical velocity and weak initial-value vorticity equation. The Lagrangian representation is a pushforward for almost every time. The theorem has no sign, compact-support, moment, circulation, or velocity-energy restriction.

Retrieval provenance: primary text directly reopened during this certificate; web references `turn74view0`, `turn75view0`. This paragraph records the entire substantive external existence input. The upgrades below are separate deductions.

The specialization is exact:

| Source hypothesis | Verification here |
|---|---|
| Admissible domain | The whole plane is explicitly included; it has no boundary condition. |
| Kernel size | `|K(x-y)|=1/(2pi|x-y|)`. |
| Two-point difference | `|K(a)-K(b)|=|a-b|/(2pi|a||b|)` for nonzero a,b. This follows by squaring the inversion identity `|a/|a|²-b/|b|²|=|a-b|/(|a||b|)`. |
| Bounded divergence | `div(K*f)=0`; therefore the required bound holds with any positive constant. |
| Boundary tangency | Vacuous on R2. |
| Initial space | Exactly real `nu0 in L1 intersect Linfinity`; no positivity symbol occurs in the theorem. |

The printed generic L-infinity estimate contains `exp(C3 T M)`, with C3 a divergence-bound constant. This certificate does **not** pretend that the printed hypothesis “C3>0” is literally “C3=0.” Finite-horizon bounds suffice to begin; exact preservation below follows from the divergence-free flow. The proof's divergence-free specialization also has zero Jacobian growth, but that shortcut is not needed.

The source is a vorticity existence theorem. No smooth Euler existence result, energy conservation theorem, or homogeneous Sobolev assumption is imported. Although `L1 intersect Linfinity` automatically implies L2 and hence inhomogeneous H^-1, no Sobolev hypothesis is used to obtain this background.

## 3. Every-time transport representative and preservation

Fix a finite horizon T. The source supplies bounded velocity and a uniform spatial log-Lipschitz modulus for almost every time. A null-set change in time is irrelevant to its equation and flow. The modulus `r(1+|log r|)` is Osgood: the integral of its reciprocal diverges at zero. If two trajectories share an initial point, their distance satisfies the associated integral inequality; integrating the reciprocal modulus gives uniqueness. The same argument backwards in time gives uniqueness of the inverse flow. Boundedness prevents escape to infinity in finite time. Thus the source's flow X is a homeomorphism at every time, with continuous inverse and bounded displacement on the chosen horizon.

Here is a direct volume-preservation proof that does not assume classical smoothness of b. Smooth b only in space with a positive compact mollifier, writing `b_epsilon=kappa_epsilon*b`. These velocities remain divergence free and uniformly bounded, have uniformly the same Osgood modulus, and converge uniformly in space, essentially uniformly in time, to b. Their spatially Lipschitz flows preserve Lebesgue measure by the Jacobian equation. The Osgood stability inequality gives uniform convergence of their flows and inverse flows on compact time-space sets to X and X^{-1}. For a compact continuous test g, bounded displacement confines the support of `g(X_epsilon(t,x))` to one fixed bounded region. Dominated convergence in

    integral g(X_epsilon(t,x))dx = integral g(y)dy

therefore proves that X preserves Lebesgue measure. The reverse flow gives the same conclusion for its inverse.

Define for every time

    nu(t,x)=nu0(X(t)^{-1}(x)).

This agrees with the source's pushforward almost everywhere in time. It immediately preserves every Lp norm, including p=1 and p=infinity, and the signed integral. No restriction on the sign of nu0 is used. Pairing with a compact continuous test and using bounded displacement and dominated convergence gives weak measure continuity at every time.

For finite p, approximate nu0 in Lp by a compact smooth function g. Composition with the measure-preserving inverse flow leaves the approximation error unchanged. The compactly supported approximation composed with that flow is strongly continuous in Lp, by continuity of the inverse flow and bounded displacement. Letting the approximation error tend to zero proves `nu in C_t Lp`, including t=0.

Now define `b(t)=K*nu(t)` at every time. This agrees with the original source velocity for almost every time, so does not change its equation or flow. Its values are continuous in space by splitting the locally integrable kernel and using nu in L1 intersect Linfinity. Moreover, for any signed f in L1 intersect Linfinity,

    ||K*f||_infinity <= r||f||_infinity + ||f||_1/(2pi r).

Applying this to `f=nu(t)-nu(s)`, whose infinity norm is at most 2N and whose L1 norm tends to zero, shows continuity of b in global Linfinity. This also proves that the newly specified representative has the exact canonical initial velocity b0. The distributional vorticity identity extends to all time endpoints by the strong L1 continuity.

All arguments on [0,T] are compatible with the already global source solution. Since T was arbitrary, this selects one global every-time representative; it does not concatenate unrelated finite-time solutions.

## 4. Quantitative velocity bounds without energy assumptions

For any time, split the defining integral at radius r. The near kernel has L1 norm r, while the far kernel has supremum `1/(2pi r)`. Thus

    ||b(t)||_infinity <= Nr + M/(2pi r).

Choosing `r=sqrt(M/(2pi N))` gives the displayed B; if either M or N is zero, nu0 and the solution are zero.

A direct weak-L2 estimate uses only finite variation. For lambda>0 put `r=M/(pi lambda)`. The far convolution is at most lambda/2. The near convolution has L1 norm at most rM, and therefore Chebyshev gives

    |{x: |b(t,x)|>lambda}| <= 2M²/(pi lambda²).

The layer-cake identity, together with `|b|<=B`, yields

    ||b(t)||_3³
      =3 integral_0^B lambda² |{|b|>lambda}| dlambda
      <=(6/pi)M²B.

These statements permit nonzero circulation and noncompact tails. In particular they do not imply b(t) belongs to global L2, and the later proof never assumes it.

## 5. Fourier identity and noncircular global L2 differences

Use `f_hat(xi)=integral exp(-ix dot xi) f(x)dx`. The canonical kernel has Fourier multiplier

    m(xi)=-i xi-perp/|xi|².

One verification uses `K=grad-perp[(2pi)^{-1}log|x|]`, or its distributional divergence/curl identities and homogeneity. The multiplier is locally integrable at xi=0. A possible distribution supported at zero is excluded by homogeneity, since m has degree -1 whereas delta derivatives in dimension two have degrees -2,-3,... .

For any finite signed measure mu,

    (K*mu)_hat = m mu_hat

as tempered distributions. To justify this beyond compact support, first truncate mu, use convolution for the compactly supported measures, and pass to the limit. Their Fourier transforms converge uniformly; `m` is integrable against Schwartz tests. On the physical side, pairing K with a Schwartz test is uniformly bounded under translations, so the total-variation convergence also passes in tempered distributions. This checks the canonical multiplier without a low-frequency energy assumption.

The exact transport equation gives, for arbitrary 0<=s<t,

    nu(t)-nu(s)=-div F_st,
    F_st=integral_s^t b(r)nu(r)dr.

Here F_st belongs to both L1 and L2, because b is bounded and nu is in L1 intersect L2. In particular

    ||F_st||_2 <= B Eomega (t-s).

Since the two vorticities and F_st belong to L1, their Fourier identity is an equality of continuous functions. Multiplying it by m gives

    (b(t)-b(s))_hat(xi)
      = -[xi-perp tensor xi/|xi|²] (F_st)_hat(xi), xi!=0.

The bracketed matrix has operator norm one. The right side is consequently an L2 function; its value at zero is irrelevant. The left side is already the canonical distributional velocity difference. Equality in tempered distributions and Plancherel therefore prove

    b(t)-b(s) in L2,
    ||b(t)-b(s)||_2 <= ||F_st||_2 <= B Eomega (t-s).

This argument first **establishes** finite energy of the difference. It neither tests an unknown finite-energy field nor assumes that b(t) or b(s) individually belongs to L2. It is not circular.

The same argument in time-distribution form gives

    partial_t b = -K*div(b nu) in L-infinity_t L2.

Also `i xi tensor m(xi)` has Frobenius norm one away from zero, giving `grad b in L-infinity_t L2` and `||grad b||_2=||nu||_2`. Finally, boundedness of b yields

    ||b(t)-b(s)||_3³
      <= ||b(t)-b(s)||_infinity ||b(t)-b(s)||_2²
      <= 2B³ Eomega² |t-s|².

Thus the background has the exact global-L3 continuity required by the cross-stress argument, and strong local-L2 continuity, without higher smoothness.

## 6. Velocity Euler equation and its initial term

Set

    A=partial_t b+(b dot grad)b.

The preceding derivative estimates show `A in L-infinity_loc(t;L2_x)`, because b is bounded and grad b is L2. The Sobolev product identity

    (b dot grad)b = grad(|b|²/2)+nu b-perp

holds distributionally; it can be checked first for spatial mollifications and passed using local H1 convergence. Taking curl gives

    curl A=partial_t nu+div(b nu)=0.

For almost every time, a curl-free L2 field is orthogonal to every compact smooth divergence-free field. Indeed its Fourier transform is parallel to xi away from xi=0, while the transform of a divergence-free test is perpendicular to xi; a single frequency point has zero Lebesgue measure. Thus A contributes only pressure and vanishes against every target solenoidal test. Integrating in time gives the velocity Euler equation on positive times.

Strong local-L2 continuity at zero permits integration to the initial endpoint, or a temporal cutoff tending to one away from zero. The result is exactly

    integral_0^T integral [b dot partial_t phi
                            +(b tensor b):grad phi] dxdt
      + integral b0 dot phi(0) dx = 0

for every compact smooth divergence-free phi supported before T. All integrals are local in space and finite. If an explicit pressure distribution is desired, the curl-free field A is a distributional gradient on the simply connected plane; choosing the negative potential gives `partial_t b+div(b tensor b)+grad p_b=0`. Its integrability is not used in the candidate.

## 7. Application to the target datum

For any target `mu in M(R2) intersect H^-1(R2)`, choose a nonnegative compact smooth radial probability a and put `nu0=a*mu`. Then

    ||nu0||_1 <= ||mu||_M,
    ||nu0||_infinity <= ||a||_infinity ||mu||_M.

Thus this certificate applies directly. Signed mu, noncompact support, nonzero circulation, and slow tails cause no mismatch. In fact this background step only needs mu to be finite; the target H^-1 hypothesis is used separately to put the high-pass remainder in L2.

The background supplied here is sufficient for the audited initial seed: W is continuous in L^{3/2} and L2 on positive-time compacts, so `b tensor W` and `W tensor b` are continuous in global L1 by Holder. Subsequent local repairs can treat b as part of an old L3 velocity and smooth only prescribed stress approximations and new blocks. No classical smooth-Euler theorem or derivative bootstrap is required by this interface.

**Certificate boundary:** this is an independently checked background existence and regularity interface. It does not prove the endpoint stress-repair lemma or the main signed-measure existence theorem.
