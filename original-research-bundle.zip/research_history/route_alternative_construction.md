# Alternative constructions: live research worker C

Status: partial lemmas and route interfaces; not an affirmative proof or a counterexample to the target.

The target is the exact full-plane, every-initial-datum statement in `checkpoint.md`. In particular it does **not** impose an energy inequality or transport/renormalization of the vorticity. This makes controlled annihilation a legitimate approximation mechanism to test, provided its residual tends to zero. Compact support, zero circulation, periodicity, and density vorticity are only entry-probe restrictions below, not replacements for the target.

## 1. Primary-source theorem interfaces

### 1.1 Integrable-vorticity convex integration

Source: E. Bruè, M. Colombo, A. Kumar, *Flexibility of Two-Dimensional Euler Flows with Integrable Vorticity*, arXiv:2408.07934; primary author PDF:
https://cvgmt.sns.it/media/doc/paper/6757/Nonuniqueness_of_Euler_Solutions%20@13@.pdf

Checked theorem content: Theorem 1.1 on the torus gives a solution continuous in velocity L2 and vorticity Lp, for some p>1, whose two endpoints approximate prescribed divergence-free, mean-zero L2 fields to any requested accuracy. Theorem 1.2 fixes initial data in a selected dense subset. Theorem 1.3 gives nontrivial compact-time solutions. Proposition 3.1 permits iterative Lp-gradient increments, but its bound depends on an initial frequency parameter chosen to dominate derivatives of the seed. The construction's initial mollification and endpoint error do not give the exact arbitrary initial trace required here.

Named mathematical question answered: do integrable-vorticity convex integration results already provide the exact initial trace and full-plane class? No: endpoint approximation, selected data, and periodic domain are three distinct missing interfaces. Approximation of initial data alone cannot be passed to a solution without a further compactness/repair result.

### 1.2 Vortex-sheet initial data without a distinguished sign

Source: F. Mengual, L. Székelyhidi Jr., *Dissipative Euler Flows for Vortex Sheet Initial Data without Distinguished Sign*, arXiv:2005.08333, https://arxiv.org/pdf/2005.08333 .

Theorem 1.1 supplies admissible velocity weak solutions for a smooth simple closed vortex sheet with sufficiently regular sheet strength. This is a geometrically restricted class of initial measures. Its velocity solution theorem does not supply the required bounded-measure curl for positive times. It therefore cannot serve as a target theorem even for its restricted initial class without an additional vorticity statement.

## 2. Exact nearest-pair deletion estimate

This is a self-contained finite-dimensional calculation. It uses no existence theorem for Euler.

Let x_1,...,x_N be distinct points in R2. Their strengths are Gamma_i in {+m,-m}, with m>0, and let M=N m. Assume total circulation is zero when interpreting the physical global L2 energy below. Define the point Hamiltonian

    H(X) = -(1/(2 pi)) sum_{i<j} Gamma_i Gamma_j log |x_i-x_j|.

Let eta be a nonnegative, smooth, radial probability density supported in the unit disk. Put

    c_eta = integral integral eta(z) eta(w) log|z-w| dz dw,
    F_h(X) = H(X) + (1/(4 pi)) sum_i Gamma_i^2 [log(1/h)-c_eta].

Here h>0 is a fixed core size; c_eta is finite. The correction is an actual summed self-energy, not one self-energy assigned to the total mass.

Suppose a point a of strength +m and a point b of strength -m realize the globally smallest opposite-sign separation d=|a-b|. Delete these two points, leaving X'. Direct subtraction gives

    2 pi [F_h(X)-F_h(X')]
      = m^2 [log(d/h)-c_eta]
        + m sum_{k notin {a,b}} Gamma_k log(|b-x_k|/|a-x_k|).

For Gamma_k=+m, nearest-opposite minimality gives |b-x_k|>=d, while the triangle inequality gives |a-x_k|<=|b-x_k|+d<=2|b-x_k|. Therefore the kth summand is >=-m log 2. For Gamma_k=-m the roles reverse, and the same bound follows. Consequently

    F_h(X)-F_h(X')
      >= (1/(2 pi)) {m^2[log(d/h)-c_eta]-m(M-2m)log 2}.

In particular deletion does not increase F_h whenever

    log(d/h) >= c_eta + (M/m-2) log 2.                     (D)

This is stronger than estimating the deleted dipole by the triangle inequality in velocity L2. It uses its interaction with the other vortices, and the nearest-opposite condition is load-bearing. Deleting an arbitrary close pair does not give the uniform log 2 bound.

### 2.1 Physical energy interpretation

Let omega_h=sum_i Gamma_i eta_h(.-x_i) and u_h=K*omega_h. Assume all opposite-sign distances exceed 2h and sum_i Gamma_i=0. Then

    (1/2) ||u_h||_2^2 <= F_h(X).                         (E)

Proof. The logarithmic potential formula gives

    (1/2)||u_h||_2^2
      = -(1/(4 pi)) sum_{i,j} Gamma_i Gamma_j
           integral integral eta(z)eta(w)
                    log|x_i-x_j+h(z-w)| dz dw.

The diagonal terms are exactly the self-energy in F_h. For i!=j with |x_i-x_j|>2h, radial averaging and harmonicity of log away from zero give exactly log|x_i-x_j|. This includes every opposite-sign pair. For a same-sign pair, radial averaging of the subharmonic function log|.| gives an average at least log|x_i-x_j|, so multiplication by the negative coefficient gives an energy contribution at most the point Hamiltonian contribution. Summing proves (E). The zero-circulation assumption makes u_h globally L2 and legitimizes this global energy formula without a reference tail; removing that restriction needs separate bookkeeping.

### 2.2 Correct particle-number bookkeeping

If deletions occur when d=delta and the initial number is N, it suffices to choose

    h = delta exp[-C_eta-N log 2]

with C_eta large enough that h<delta/4 and (D) holds. The initial summed core correction is

    N m^2/(4 pi) [log(1/delta)+N log 2+C_eta-c_eta]
      = M^2/(4 pi) log 2
        + M^2/(4 pi N) [log(1/delta)+C_eta-c_eta].

Thus log(1/delta)=O(N) leaves a uniformly bounded correction. There is no factor N left in the leading M^2 term. For example delta=N^{-2} has this property. This creates a fixed order-M^2 energy reservoir; it does not yield strong initial energy convergence. The target requires only weak local L2 continuity, so strong energy convergence is not itself mandatory, but weak continuity still needs proof.

The points, with their finite h regularized velocity, are not claimed to be exact Euler velocity solutions. The point-vortex ODE and subsequent mollification must still be shown to have a vanishing Euler residual.

## 3. Weak vorticity residual of deletions

Let the surviving particles follow the classical point ODE between deletion times,

    dot x_i = sum_{j!=i} Gamma_j K(x_i-x_j).

For smooth compactly supported phi define

    H_phi(x,y) = (1/2) K(x-y).(grad phi(x)-grad phi(y)), x!=y,
    H_phi(x,x) = 0.

Pairing i,j gives the exact identity between deletions

    d/dt sum_i Gamma_i phi(x_i)
       = sum_{i,j} Gamma_i Gamma_j H_phi(x_i,x_j).

The bound |H_phi|<=||D2 phi||_infinity/(4 pi) is immediate from the stated K. A deletion of equal strengths at distance at most delta changes the scalar pairing by at most m delta ||grad phi||_infinity. At most N/2 pairs can be deleted. Hence the entire deletion residual on any finite time interval is bounded by

    (M delta/2) ||grad_x phi||_infinity.                 (R)

This applies equally to a time-dependent test function; evaluate it at each deletion time. Formula (R) does not prove convergence of the quadratic term, but shows that annihilation itself can have a vanishing weak-vorticity residual while removing order-one total variation.

## 4. Global finite-particle trajectory: checked mechanism, details still to audit

For fixed N,m,delta and a configuration with opposite-sign separation >delta, stop at the first opposite separation delta, delete a nearest opposite pair, and repeat immediately if another pair is at the threshold. There are finitely many deletions. On an interval with opposite separation >=delta, opposite-sign terms in the unsigned quadratic moment

    I=sum_i m |x_i|^2

have derivative bounded by C M^(3/2) sqrt(I)/delta, while same-sign pair contributions cancel by z.K(z)=0. Thus sqrt(I) grows at most linearly on each finite interval. Deletions only lower I. No particle can escape to spatial infinity in a finite time for fixed N,m,delta.

The point Hamiltonian is constant between deletions. With positions bounded and opposite separations bounded below, a same-sign collision would force its positive logarithmic contribution to infinity, while all potentially negative terms remain bounded below. Therefore a same-sign collision is excluded. This establishes the natural global continuation mechanism for the finite ODE. A formal packet should spell out simultaneous stopping events and the standard local ODE continuation theorem, but no new PDE issue occurs at this finite-dimensional stage.

## 5. What this does not solve: intermediate-scale neutral concentration

The energy/deletion mechanism controls the core scale h much more strongly than the threshold delta. It does not control concentrations on scales r much larger than delta.

Kinematic falsification test. Fix a smooth nonnegative radial probability density rho supported in a disk of radius c<1/10, and form

    omega_delta(x) = a delta^(-2)
       [rho((x-2 delta e1)/delta)-rho((x+2 delta e1)/delta)].

Its positive and negative supports remain separated by more than delta. Therefore a rule deleting only opposite pairs at distances <=delta has no reason to delete this configuration. Its total variation equals 2a, its unsigned vorticity converges to 2a delta_0, and its signed vorticity converges distributionally to zero. If V=K*[rho(.-2e1)-rho(.+2e1)], then

    u_delta(x)=a delta^(-1) V(x/delta),
    ||u_delta||_2=a||V||_2.

Thus bounded energy, bounded total variation, and opposite-sign separation delta are compatible with unsigned atomic concentration. The zero total circulation gives V in L2; smoothness removes the local singularity. This configuration is a kinematic test, not an Euler solution or a counterexample to the requested existence statement.

The still-meaningful dynamical question is weaker than unsigned nonconcentration: does the **signed angular diagonal defect** of the annihilating point system vanish after integration in time? A translating dipole suggests rapid escape from compact sets; same-sign fast rotations suggest isotropization. Neither heuristic proves the claim for interacting neutral clusters. External interactions, exchange of particles between clusters, and trapped multipole configurations must be tested.

## 6. Exact remaining construction lemma

For a sequence of these annihilating point configurations with m_n->0, delta_n->0, and uniform mollified velocity L2 and vorticity-M bounds, it would suffice to prove, for every compact spacetime test phi,

    lim_{r->0} limsup_{n->infinity}
      | integral_0^T sum_{i!=j: |x_i-x_j|<r}
             Gamma_i Gamma_j H_phi(t,x_i,x_j) dt | = 0,    (A)

or a version after subtracting the corresponding near-diagonal contribution of the limiting atomless measure. Formula (A), appropriate tail control, and the small deletion residual would allow passage through the symmetrized vorticity equation. Further full-plane Biot–Savart, velocity/vorticity equivalence, every-time traces, and general nonzero-circulation/noncompact data checks remain mandatory.

No assertion that (A) follows from (D), (E), or (R) is made. The neutral-cloud test shows why a purely kinematic proof is unavailable from those bounds.

## 7. Convex-integration route: concrete missing interface

A possible proof mechanism distinct from passive compactness is a stress-repair construction on strips approaching t=0. A seed such as u_seed(t)=exp(epsilon(t)^2 Delta)u_0 preserves the M bound on its curl and has the required local L2 trace. Formally it solves Euler–Reynolds with

    R_seed = 2 epsilon epsilon' sym(Du_seed)+u_seed tensor u_seed

under the convention sym(Du)=(Du+Du^T)/2 and pressure zero. Indeed div(2 epsilon epsilon' sym Du)=epsilon epsilon' Delta u, so this displayed coefficient needs correction by a factor two: the correct symmetric stress is

    R_seed = 4 epsilon epsilon' sym(Du_seed)+u_seed tensor u_seed.

Equivalently use 2 epsilon epsilon'(Du_seed+Du_seed^T). The explicit correction is recorded to prevent reusing the wrong coefficient. Smoothness away from t=0 is easy; global L1 control of this stress for noncompact/nonzero-circulation data is not automatic.

What is needed is a localized Euler–Reynolds repair estimate whose curl-M cost is controlled uniformly as the seed's derivatives diverge near t=0, while preserving the weak initial trace and bounded local velocity energy. The published integrable-vorticity iteration inspected above does not directly supply this derivative-independent bound. Requiring a uniform Lp-vorticity bound for fixed p>1 all the way to t=0 would exclude singular initial measures by weak closure, so the endpoint M bound is essential.

## 8. Route disposition and next tests

1. Freeze and independently audit the nearest-pair deletion estimate and its summed self-energy bookkeeping.
2. Test signed diagonal defect (A) on neutral translating and rotating point-vortex configurations, then on interacting zero-circulation clusters.
3. Check the existence of initial equal-particle approximations with bounded F_h and the exact initial weak local L2 trace. For smooth compact zero-circulation densities, random empirical approximation with delta=N^{-2} suggests such configurations: log interactions have finite second moments, while the probability of any separation below delta is O(N^2 delta^2). This is a proof plan, not yet a certified initial-data lemma.
4. A purely generalized-flow/Young-measure construction is insufficient until its covariance stress is shown invisible against divergence-free tests. Barycentric velocity alone solves an Euler–Reynolds equation, and the curl-M constraint does not remove that stress automatically.

Worker C has not proved the exact target or its exact negation.
