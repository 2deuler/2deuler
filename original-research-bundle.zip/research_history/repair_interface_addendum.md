# Precise interface for the full-plane repair candidate

Author: alternative_construction. This is an addendum to the frozen
`fullplane_endpoint_repair_probe.md`, not an independent audit of that
construction and not an unconditional existence theorem.

## Induction class

On every compact positive-time interval there is a finite partition such
that the velocity is continuous across the partition in global L2 relative
to a fixed smooth Euler background. On each closed one-sided branch it is
continuous into L3, spatially smooth, and has finite spatial derivative
bounds. The symmetric stress is continuous into global L1 on each branch;
it may jump at partition times. All equations are distributional. Refining
an inherited partition does not change any field.

Only the finite supremum of the current velocity's L3 norm is used to
estimate nonlinear cross stresses. Its L3 continuity ensures that these
cross stresses remain continuous into L1. No bound for this modulus, and
no derivative bound for the current velocity, enters the leading increment
cost. Finite-stage L3 norms need not remain uniformly bounded during the
iteration.

## Candidate prescribed-piece lemma

Let J be a positive-time open interval, let (u,R) be in the class above,
and let S be a symmetric prescribed stress with compact time support in J,
piecewise continuous into L1 on the inherited partition. Put

    delta = sup_t ||S(t)||_1.

Given any positive error budget e, increment slack z, L^{3/2} budget b,
and radius cap r_*, the construction is intended to produce a divergence-
free w and symmetric E, both compactly supported in time in J, with

    (u+w, R-S+E) an Euler--Reynolds pair,
    sup_t ||E(t)||_1 <= e,
    sup_t (||w(t)||_2 + ||curl w(t)||_1) <= C sqrt(delta)+z,
    sup_t ||w(t)||_{3/2} <= b.

Here C depends only on the fixed dipole profile, four directions, and
fixed ramp functions. It does not depend on the support size, patch length,
seed derivatives, or distance of J from time zero. All principal packet
radii may be required to be at most r_*. If delta=0, take w=E=0.

The velocity increment is continuous and vanishes at every inherited and
new cycle boundary. The new stress is only piecewise continuous into L1.
Values of a stress at isolated time boundaries may be chosen to respect
the displayed bound; those choices do not change the distributional
equation. No globally smooth temporal output is asserted.

## Compact time support without a flat-stress claim

Choose [a,b] compactly contained in J around the time support of S. Split
this interval at the finitely many inherited boundaries, and perform the
repair on those disjoint closed cells. Each complete raster cycle has
both its principal packet and its time corrector equal to zero at its
endpoints. Extend the resulting w by zero outside [a,b]. Continuity of w
excludes a time delta function. The error stress can also be set to zero
outside [a,b]; its possible jumps are harmless because the equation has
div_x E, not partial_t E. Thus the support is compact in J even though
temporal derivatives need not match at a and b.

## Universal leading cost and two scales

First approximate S uniformly in time in L1 by smooth spatially compact
tensors on each inherited branch. Its discarded tail and approximation
error are charged to e. Decompose the negative approximating tensor
modulo an isotropic scalar into four nonnegative coefficients. Their total
L1 mass is at most C delta plus an arbitrarily small floor mass.

Use an even radial auxiliary density of radius H and row spacing d=H^2.
For the ith direction let B_i be the sum of interior row integrals plus
the exact ramp contributions, and allocate tau_i=tau/4. Set

    eta_i^2 = tau d B_i/(2 pi tau_i),
    r_{0,i} = tau d/(2 pi eta_i).

Then the scan duration is exactly tau_i and its averaged coefficient has
exact weight d. Choose floors and buffers with total L1 mass as small as
needed for z, and then choose d sufficiently small that

    d B_i <= C delta + small.

This gives eta_i <= C sqrt(delta)+small independently of the rectangle.
The coefficient derivatives and floor minima affect only how small H
must be. With tau of order H^6, radii are of order H^8, source replacement
cost is O(H log(1/H)), and the corrector bounds tend to zero. The principal
L^{3/2} norm is C eta_i r^{1/3}, and the corrector L^{3/2} norm is at most
C tau H^{-2/3} sup |(eta r)'|. Hence b and r_* are independent selectable
budgets.

## Fixed mollifier bookkeeping

Choose one positive even spatial mollifier with a sufficiently small scale
on each complete cycle, fixed while r and eta vary. Convolve only the new
packet equation and the new time corrector. The new nonlinear stress is
augmented by

    (v*kappa) tensor (v*kappa) - (v tensor v)*kappa.

Its L1 norm tends uniformly to zero because the cycle radii range over a
compact subset of (0,infinity), translations do not change the norm, and
the amplitudes are bounded. Convolution preserves the mean and first-
moment cancellations, does not increase the required velocity or curl
norms, and preserves the exact zero endpoint values. The old velocity and
old stress are not convolved. There is consequently no unestimated
commutator involving the old background.

## Verification status

The listed interface and parameter normalizations have been checked by
their author against the formulas in the frozen packet. They still require
an independent proof audit as part of the complete candidate. In particular
this addendum does not replace the full raster quadrature, exact packet
identity, anti-divergence, or infinite-iteration proofs.
