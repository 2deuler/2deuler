# Candidate manuscript dependency and provenance manifest

Assembly time: 2026-10-08. Manuscript assembled by signed_compactness for the parent coordinator.

The manuscript is a complete proposed affirmative argument submitted for independent verification. Its theorem statements are claims of that argument, not an audit certificate or a permitted project stopping conclusion. Four complete independent source-ordered audits are still the coordinator's required gate. Scoped source-packet audits do not replace those passes.

## Artifact

- TeX: `candidate_proof.tex`.
- Compiled PDF for read-only layout review: `/tmp/candidate_proof.pdf` (13 pages).
- Build summary: `/tmp/candidate_build.log`.
- Detailed TeX log: `/tmp/candidate_proof.log`.
- The final two compilation passes completed without overfull, underfull, or undefined-reference warnings.

## Mathematical dependency order

| Manuscript component | Required predecessors and construction provenance |
|---|---|
| Canonical data decomposition | Finite-measure kernel convolution, Fourier multiplier, radial averaging, Plancherel; initial-velocity packet and seed audit |
| Bounded canonical Euler background | External input E1 below, followed by explicit flow representative and velocity multiplier argument; independent background certificate |
| Initial Euler–Reynolds seed | Decomposition and background; biharmonic kernel, divergence/curl identity and direct tensor expansion |
| Translating dipole | Explicit Bessel-series profile, Bessel ODE uniqueness, pressure formula, rescaling |
| Integrable symmetric anti-divergence | Explicit Newtonian-potential operator and zero zeroth/first moments |
| Radius derivative and compact source | Dipole parity, exterior homogeneity, source mean 2πξ, anti-divergence estimate |
| Two-scale averaging | Width H, row spacing d=H², exact full-cycle clock, explicit temporal ramps, Banach-valued rectangle rule |
| Temporal correction | Explicit radial projected bump; full four-direction cycle average; no general CZ endpoint theorem |
| Prescribed-piece local repair | Fixed coarse S_k approximations, repeated complete cycles, independent stress/L²-curl/L3/2/radius budgets, fixed spatial smoothing, all-time stress boundary representatives |
| Global iteration | Three-color dyadic patch cover, frozen prescribed pieces, bounded overlap, anchor-time trace lemma, summable corrections |
| Final normalization | Fixed C0 background plus global L² remainder, finite curl, harmonic mean-value argument |

## External existence input

E1 is G. Crippa and G. Stefani, *An elementary proof of existence and uniqueness for the Euler flow in localized Yudovich spaces*, Calculus of Variations and PDE 63, article 168 (2024), Theorem 3.3 with Assumptions 2.1 and 3.1 and Definition 3.2.

Primary source: https://link.springer.com/article/10.1007/s00526-024-02750-4

The manuscript uses global whole-plane Lagrangian bounded-vorticity existence with its canonical velocity and log-Lipschitz modulus. Every-time representatives, conserved bounds, global L² velocity differences, L³ continuity, and the velocity weak formulation are derived in the manuscript. The external theorem is not silently strengthened to a classical smoothness theorem.

Bruè–Colombo–Kumar arXiv:2408.07934v1 motivated earlier exploration of the dipole mechanism. No theorem from that source is used as a load-bearing input in this assembled manuscript.

## Hashes of the assembled sources

These hashes record the exact files read or used for this assembly. A later change to a development packet does not silently amend the TeX manuscript. Changes to the manuscript must be made explicitly and receive a new freeze hash before audits.

| File | SHA-256 |
|---|---|
| `candidate_proof.tex` | `b6741b471ba2f128b147f5a5c05fea0afe639c2c3a535b99a5afaf03ea6d4a43` |
| `route_initial_velocity_interfaces.md` | `3ff59038c75dc2d53f4bd1383392e77f60bf7f7e584bc8e90a02b1dda1f73298` |
| `route_initial_subsolution.md` | `90040f0e4896e64f545de9699eb4061e3b83c981e8a39dbf1b05b96c1ef2d737` |
| `audit_initial_subsolution.md` | `bd3369e0911d42bbbd3c05a2d965cb39e16355313de6bccb5d57e8bf33c51f3c` |
| `external_background_certificate.md` | `79e4f046d67dc3c44d9ba97236a50c888fc8a55e2979ac8f038c14a8215b3f6e` |
| `fullplane_endpoint_repair_probe.md` | `13face790f39e453a7665edd3f1e7d1067a15c2066f09a16a51784022a02583f` |
| `repair_interface_addendum.md` | `9f03aae48604d427eec4576deb96f19f19b828adc7d3d968a81b3377d1ba7fb4` |
| `audit_fullplane_repair.md` | `b6fdb1c3ca8256a8eb8c9aff76ede8a0f9790a0fd2c5af1696fe820810277c34` |
| `projected_bump_certificate.md` | `bcb92845292c37cebb227f30d2c363e00ea47fd75b194b12e5799d1eb3449afe` |
| `route_time_strip_iteration.md` | `877136e52a42434f1d0b4e59e67fe8c12594227d760ebca6ca3d9a5814d3187b` |
| `audit_iteration_interfaces.md` | `a44b64d429ef7f74c5191f089d59942bd1886628ddd26300e96100cc80f0e180` |

## Known audit focus

No missing lemma is intentionally left as an assumption in the assembled manuscript. The critical new claim is the prescribed-piece local repair, especially the exact clock including ramps, finite-direction full-cycle average, all global L¹ cross terms, smoothing bookkeeping, and preservation of the piecewise class. The coarse freezing step avoids time-derivative assumptions on the prescribed stress. The manuscript explicitly assigns stress/error representatives at isolated construction boundaries while velocity remains continuous.

The manuscript uses the r^(1/5) compact-source cutoff from the original repair packet, with 2r^(1/5)≤H. The two-scale hierarchy r≈H^8 proves this constraint. The independently audited fixed-H alternative is not silently mixed into its formulas.

The final initial trace uses gap-time anchors and the exact Euler–Reynolds identities, not an assumption of strong continuity at zero or nearby endpoint matching. The whole-plane background need not have finite kinetic energy; arbitrarily small L3/2 increments close its global cross stresses.
