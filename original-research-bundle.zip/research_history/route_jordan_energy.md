# Route D: Jordan decomposition and signed H^{-1} data

STATUS: exact counterexample packet; worker proof completed; independent verification requested.

This is a counterexample to an auxiliary implication, not a counterexample to the Euler existence target.

## 1. Exact claim

There is a compactly supported, atomless, purely singular finite signed Radon measure
\(\mu\) on \(\mathbb R^2\) such that

\[
\mu\in H^{-1}(\mathbb R^2),\qquad \mu(\mathbb R^2)=0,
\qquad \|\mu\|_{\mathcal M}=2,
\]

but neither Jordan part \(\mu^+\), \(\mu^-\), nor the total variation measure \(|\mu|\), belongs to \(H^{-1}_{\mathrm{loc}}\) in any neighborhood of the origin.

In fact \(\mu=\operatorname{div}F\) for a compactly supported vector field \(F\in L^2\) with \(\|F\|_2=1/\sqrt3\), and \(K*\mu\in L^2(\mathbb R^2)\).

Consequently, the hypothesis \(\mu\in\mathcal M\cap H^{-1}\) in the exact Euler target does not permit a reduction to two nonnegative \(H^{-1}\) data by Jordan decomposition.

## 2. Construction and complete proof

For integers \(n\geq1\), set

\[
a_n=2^{-n},\qquad r_n=2^{-16^n},\qquad c_n=(2^{-n},0),
\]

and let \(Q_n\) be the open square of side \(r_n\), centered at \(c_n\), with sides parallel to the coordinate axes.
Its left and right vertical edges are denoted by \(L_n\) and \(R_n\), respectively.
Endpoints of these edges make no difference to their length measures.

Since \(16^n\geq n+3\), we have \(r_n\leq 2^{-n-3}\).
For \(m>n\),

\[
|c_n-c_m|\geq2^{-n-1},\qquad
r_n+r_m\leq2^{-n-3}+2^{-n-4}<2^{-n-1}.
\]

Thus the closed balls \(\overline B(c_n,r_n)\), and hence the closed squares and all their edges, are pairwise disjoint.
All these balls lie inside \(B(0,1)\).
Their only possible accumulation point outside the balls is the origin.

Define

\[
F(x)=\sum_{n=1}^{\infty}\frac{a_n}{r_n}\mathbf1_{Q_n}(x)e_1,
\qquad
\mu_n=\frac{a_n}{r_n}
  \bigl(\mathcal H^1\!\restriction L_n
        -\mathcal H^1\!\restriction R_n\bigr),
\qquad \mu=\sum_{n=1}^{\infty}\mu_n.
\]

The first series converges in \(L^2\), because the supports are disjoint and

\[
\|F\|_2^2
=\sum_{n=1}^{\infty}\frac{a_n^2}{r_n^2}|Q_n|
=\sum_{n=1}^{\infty}a_n^2
=\sum_{n=1}^{\infty}4^{-n}=\frac13.
\]

The second series converges absolutely in total variation, because

\[
\|\mu_n\|_{\mathcal M}=2a_n,
\qquad \sum_{n=1}^{\infty}2a_n=2.
\]

The disjoint positive and negative edge supports identify the Jordan parts:

\[
\mu^+=\sum_{n=1}^{\infty}\frac{a_n}{r_n}
  \mathcal H^1\!\restriction L_n,
\qquad
\mu^-=\sum_{n=1}^{\infty}\frac{a_n}{r_n}
  \mathcal H^1\!\restriction R_n.
\]

Both Jordan parts have mass \(1\).
The signed measure has total mass zero.
Each edge length measure is atomless; countable summation preserves this property, including at the origin, because no summand charges the origin.
All of \(\mu\) is supported on a countable union of line segments and the origin, a Lebesgue-null set.
Its support is closed and bounded after adjoining the sole accumulation point, so it is compact.

For every \(\varphi\in C_c^\infty(\mathbb R^2)\), the one-dimensional fundamental theorem of calculus gives

\[
-\int_{\mathbb R^2}\frac{a_n}{r_n}\mathbf1_{Q_n}e_1
                 \cdot\nabla\varphi\,dx
=\frac{a_n}{r_n}\int_{-r_n/2}^{r_n/2}
 [\varphi(2^{-n}-r_n/2,y)-\varphi(2^{-n}+r_n/2,y)]\,dy
=\int\varphi\,d\mu_n.
\]

Taking partial sums and using \(L^2\) convergence on the left and total variation convergence on the right proves
\(\mu=\operatorname{div}F\) distributionally.
Therefore

\[
|\langle\mu,\varphi\rangle|
\leq\|F\|_2\|\nabla\varphi\|_2
\leq\frac1{\sqrt3}\|\varphi\|_{H^1},
\]

which proves the inhomogeneous \(H^{-1}\) assertion, with the convention
\(\|\varphi\|_{H^1}^2=\|\varphi\|_2^2+\|\nabla\varphi\|_2^2\).
The first inequality also proves a homogeneous \(\dot H^{-1}\) bound.

## 3. Positive-measure capacity test

Let \(U\) be any open neighborhood of the origin.
Choose \(R>0\) so small that \(\overline B(0,2R)\subset U\).
For all sufficiently large \(n\), \(|c_n|<R/2\) and \(r_n<R\), so \(\overline B(c_n,R)\subset U\).
Write \(b_n=\log(R/r_n)\), and define the nonnegative, compactly supported Lipschitz function

\[
\psi_n(x)=
\begin{cases}
b_n,&|x-c_n|\leq r_n,\\
\log\bigl(R/|x-c_n|\bigr),&r_n<|x-c_n|<R,\\
0,&|x-c_n|\geq R.
\end{cases}
\]

Direct polar-coordinate integration gives

\[
\|\nabla\psi_n\|_2^2=2\pi b_n,
\qquad
\|\psi_n\|_2^2
\leq2\pi\int_0^R\log^2(R/s)s\,ds
=\frac{\pi R^2}{2}.
\]

Thus

\[
\|\psi_n\|_{H^1(U)}^2\leq2\pi b_n+\frac{\pi R^2}{2}.
\]

Every left and right edge of \(Q_n\) lies in \(B(c_n,r_n)\), since its distance from the center is at most \(r_n/\sqrt2\).
For \(\nu=\mu^+\) or \(\nu=\mu^-\), positivity therefore yields

\[
\int\psi_n\,d\nu\geq a_nb_n.
\]

If \(\nu\in H^{-1}(U)\), duality would imply

\[
a_nb_n\leq
\|\nu\|_{H^{-1}(U)}
  \left(2\pi b_n+\frac{\pi R^2}{2}\right)^{1/2}.
\]

This duality inequality is valid for \(\psi_n\), even though it is initially defined as a Lipschitz function: mollify \(\psi_n\) with sufficiently small radii so that supports remain in \(U\).
The mollified functions converge both uniformly and in \(H^1\), so their measure integrals and their \(H^{-1}\) pairings have the indicated common limit.

But

\[
b_n=\log R+(\log2)16^n,
\qquad
a_n\sqrt{b_n}\sim\sqrt{\log2}\,2^n\longrightarrow\infty.
\]

The duality inequality is impossible for a fixed finite \(H^{-1}(U)\) norm.
Thus both Jordan parts fail \(H^{-1}(U)\).
The same proof applies to \(|\mu|\), with \(2a_n\) in place of \(a_n\).
Since \(U\) was arbitrary, all three failures occur locally at the origin.

## 4. The signed velocity has finite energy

For the Biot--Savart kernel in the target and a compactly supported measure of zero total mass, the Fourier multiplier calculation has no far-field circulation obstruction.
Using a unitary Fourier transform, \(\widehat\mu=i\xi\cdot\widehat F\), and

\[
\widehat{K*\mu}(\xi)
=-\frac{i\xi^\perp}{|\xi|^2}\widehat\mu(\xi)
=\frac{\xi^\perp(\xi\cdot\widehat F(\xi))}{|\xi|^2},
\qquad \xi\neq0.
\]

The multiplier has operator norm at most one on vectors, so Plancherel yields

\[
\|K*\mu\|_2\leq\|F\|_2=1/\sqrt3.
\]

The value of the multiplier at \(\xi=0\) is immaterial to its \(L^2\) class.
There is no added harmonic velocity: the distribution is the convolution with the fixed kernel \(K\).
One can obtain the same conclusion by applying this multiplier to the partial sums and then passing in distributions.
Indeed the partial-sum measures converge in total variation with uniformly compact support, which implies convergence of their convolutions with the locally integrable kernel \(K\) in distributions.

## 5. No alternative positive H^{-1} decomposition

The obstruction is not specific to choosing the minimal Jordan decomposition.
If \(0\leq\sigma\leq\lambda\) are finite measures on an open set and \(\lambda\in H^{-1}\), then \(\sigma\in H^{-1}\).
For a smooth compactly supported test \(\varphi\),

\[
\left|\int\varphi\,d\sigma\right|
\leq\int|\varphi|\,d\sigma
\leq\int|\varphi|\,d\lambda
\leq\|\lambda\|_{H^{-1}}\,\||\varphi|\|_{H^1}
=\|\lambda\|_{H^{-1}}\,\|\varphi\|_{H^1}.
\]

For the last duality step, the smooth compactly supported approximations
\(\sqrt{\varphi^2+\varepsilon^2}-\varepsilon\) converge uniformly and in \(H^1\) to \(|\varphi|\); their gradient magnitude is bounded by \(|\nabla\varphi|\), and their supports stay in the support of \(\varphi\).

If \(\mu=\lambda_1-\lambda_2\) with \(\lambda_1,\lambda_2\geq0\), then \(\mu^+\leq\lambda_1\) and \(\mu^-\leq\lambda_2\) by the defining minimality of the Jordan decomposition.
Therefore the constructed \(\mu\) admits no decomposition as a difference of two nonnegative \(H^{-1}\) measures, even locally around the origin.

## 6. Exact downstream uses and limits

1. **Rejected auxiliary implication.** \(\mu\in\mathcal M\cap H^{-1}\Rightarrow|\mu|\in H^{-1}\) is false, even for compactly supported atomless signed vortex sheets whose velocity is globally in \(L^2\).
2. **Rejected splitting route.** One cannot apply a positive-measure \(H^{-1}\) theorem separately to the two signs of every admissible initial datum; some data have neither sign part in \(H^{-1}\).
3. **Energy cancellation.** The actual signed energy can be finite while each separate sign has infinite local energy. Any estimate using positivity to control the total variation's logarithmic concentration requires an additional hypothesis.
4. **No Euler nonexistence conclusion.** The construction proves nothing about absence of an Euler solution. It only falsifies the proposed initial-data reduction.
5. **No forced initial energy defect.** For ordinary compactly supported mollifiers \(\rho_\varepsilon\), \(u_\varepsilon=(K*\mu)*\rho_\varepsilon\to K*\mu\) strongly in \(L^2\). Thus infinite Jordan-part energy does not itself create an initial energy concentration defect for mollified signed velocities.
6. **Exact target inclusion.** This \(\mu\) satisfies the target's initial-data hypotheses without invoking nonzero circulation, atoms, noncompact support, or an ambiguous Sobolev convention.

## 7. Verification packet and dependency ledger

- **Scope:** one fixed explicitly specified signed measure on \(\mathbb R^2\); no parameter-dependent datum is substituted for the target.
- **Predecessor facts:** distributional integration by parts for a rectangle; completeness of \(L^2\) and total variation norm; elementary Jordan decomposition; polar-coordinate integration; density by mollification; Fourier transform and Plancherel for the optional velocity claim.
- **External theorems:** no research-paper theorem is used in the construction or the capacity contradiction.
- **Convention checks:** \(\mu=\operatorname{div}F\) has positive left-edge and negative right-edge signs; \(\operatorname{curl}(K*\mu)=\mu\) uses the target's \(K(x)=x^\perp/(2\pi|x|^2)\); \(H^{-1}\) is inhomogeneous; the stronger homogeneous bound is additional.
- **Edge cases:** every \(r_n>0\); all sets and masses are countable; accumulation creates no atom; test supports remain strictly inside any prescribed neighborhood; no assertion relies on a total-variation mass bound controlling \(H^{-1}\).
- **Independent verification status:** not yet independently audited. Parent should freeze this packet and request a verifier before accepting it as a load-bearing fact.

## 8. Literature check performed but not used as a theorem certificate

A targeted search for nonnegative-measure \(H^{-1}\) criteria returned Grzegorz Jamróz, *Nonnegative measures belonging to \(H^{-1}(\mathbb R^2)\)*, arXiv:1412.5855, https://arxiv.org/abs/1412.5855 .
The primary-source abstract concerns nonnegative measures, matching the sign-sensitive interface examined here.
No claim from that paper is needed or imported into the proof above.

## 9. Exact neutral Gaussian blob energy

This second packet computes the energy scale of neutral opposite blobs.
It is logically independent of the Jordan-part counterexample.

Use the normalized Gaussian

\[
\rho_h(x)=\frac1{2\pi h^2}\exp\left(-\frac{|x|^2}{2h^2}\right),
\qquad
\omega_{a,d,h}(x)=a\left[\rho_h(x-\tfrac d2e_1)
                         -\rho_h(x+\tfrac d2e_1)\right],
\]

where \(a\in\mathbb R\), \(d\geq0\), and \(h>0\).
Define the entire exponential integral on nonnegative arguments by

\[
\operatorname{Ein}(z)=\int_0^z\frac{1-e^{-s}}s\,ds,
\qquad\operatorname{Ein}(0)=0.
\]

Then the **squared velocity norm**, rather than half this quantity, is exactly

\[
\boxed{
\|K*\omega_{a,d,h}\|_2^2
=\frac{a^2}{2\pi}\operatorname{Ein}
     \left(\frac{d^2}{4h^2}\right).}
\]

For a nonunitary Fourier transform \(\widehat f(\xi)=\int e^{-ix\cdot\xi}f(x)\,dx\), Plancherel and the Biot--Savart multiplier give

\[
\|K*\omega_{a,d,h}\|_2^2
=\frac{a^2}{(2\pi)^2}\int_{\mathbb R^2}
   \frac{2e^{-h^2|\xi|^2}(1-\cos(d\xi_1))}{|\xi|^2}\,d\xi.
\]

Insert \(|\xi|^{-2}=\int_0^\infty e^{-t|\xi|^2}\,dt\).
Tonelli applies because the integrand is nonnegative.
The elementary two-dimensional Gaussian transform then gives

\[
\begin{aligned}
\|K*\omega_{a,d,h}\|_2^2
&=\frac{a^2}{2\pi}\int_0^\infty
\frac{1-\exp(-d^2/[4(h^2+t)])}{h^2+t}\,dt\\
&=\frac{a^2}{2\pi}\int_0^{d^2/(4h^2)}\frac{1-e^{-s}}s\,ds.
\end{aligned}
\]

The substitution is valid for \(d>0\); the case \(d=0\) follows directly since the vorticity vanishes.

Writing \(z=d^2/(4h^2)\), Taylor's formula gives the fully quantitative bounds

\[
0\leq z-\operatorname{Ein}(z)\leq\frac{z^2}4,
\qquad
0\leq\operatorname{Ein}(z)-z+\frac{z^2}4\leq\frac{z^3}{18}
\quad(z\geq0).
\]

Indeed \(s-s^2/2\leq1-e^{-s}\leq s\), while
\(0\leq(1-e^{-s})-s+s^2/2\leq s^3/6\), and integration after division by \(s\) yields the claims.
Therefore, as \(d/h\to0\),

\[
\|K*\omega_{a,d,h}\|_2^2
=\frac{a^2d^2}{8\pi h^2}
 -\frac{a^2d^4}{128\pi h^4}+R,
\qquad
0\leq R\leq\frac{a^2d^6}{2304\pi h^6}.
\]

For the opposite regime, define the absolute constant

\[
\gamma_*=
\int_0^1\frac{1-e^{-s}}s\,ds-
\int_1^\infty\frac{e^{-s}}s\,ds.
\]

This constant is the usual Euler constant, although that identification is unnecessary here.
For \(z\geq1\), splitting the defining integral at one proves

\[
\operatorname{Ein}(z)=\log z+\gamma_*+
\int_z^\infty\frac{e^{-s}}s\,ds,
\qquad
0\leq\int_z^\infty\frac{e^{-s}}s\,ds\leq\frac{e^{-z}}z.
\]

Consequently, for \(d\geq2h\),

\[
\|K*\omega_{a,d,h}\|_2^2
=\frac{a^2}{\pi}\log\frac dh
 +\frac{a^2}{2\pi}(\gamma_*-\log4)+R_\infty,
\qquad
0\leq R_\infty\leq\frac{a^2}{2\pi}\frac{e^{-z}}z.
\]

The formula exhibits two distinct neutralization scales: well-separated opposite cores retain logarithmic energy, while two cores closer than their smoothing length have quadratic dipole energy.
It does not establish propagation of either bound by Euler dynamics.

## 10. Closest-opposite-pair deletion can increase regularized energy

Fix the unambiguous energy convention

\[
\mathcal E(\omega)=\|K*\omega\|_2^2.
\]

The Hamiltonian \(\frac12\mathcal E\) has exactly the same monotonicity conclusions.
The following are counterexamples to the claim that deleting the closest opposite-sign pair always lowers this regularized physical energy.

### 10.1 Four equal Gaussian vortices

Take \(a>0\), \(h=1/2\), and place circulations \((-a,+a,-a,+a)\) at positions \((-2,0,1,3)e_1\), respectively.
The uniquely closest opposite pair is \((0,1)e_1\), with distance one.
All other opposite-pair distances are two or five.
Let

\[
\omega_A=a(\rho_h(\cdot)-\rho_h(\cdot-e_1)),\qquad
\omega_B=a(\rho_h(\cdot-3e_1)-\rho_h(\cdot+2e_1)).
\]

Deleting the closest pair changes \(\omega_A+\omega_B\) to \(\omega_B\).
For a neutral finite collection of equal-width Gaussian blobs with circulations \(\Gamma_i\) at positions \(x_i\), the preceding Fourier calculation and \(\sum_i\Gamma_i=0\) give

\[
\mathcal E\left(\sum_i\Gamma_i\rho_h(\cdot-x_i)\right)
=-\frac1{2\pi}\sum_{i<j}\Gamma_i\Gamma_j
\operatorname{Ein}\left(\frac{|x_i-x_j|^2}{4h^2}\right).
\]

To justify the expansion, subtract one from each cosine term using neutrality; every individual integral of \(e^{-h^2|\xi|^2}(1-\cos(\xi\cdot z))/|\xi|^2\) is finite, and the finite sum may then be integrated term by term.
Substitution of the four positions gives

\[
\mathcal E(\omega_A+\omega_B)-\mathcal E(\omega_B)
=\frac{a^2}{2\pi}
 \left[\operatorname{Ein}(1)
       -2\bigl(\operatorname{Ein}(9)-\operatorname{Ein}(4)\bigr)\right].
\]

Now \(\operatorname{Ein}(1)<1\), and

\[
\operatorname{Ein}(9)-\operatorname{Ein}(4)
\geq(1-e^{-4})\log\frac94
>\frac{15}{16}\cdot\frac23=\frac58.
\]

Here \(e^4>16\), and \(\log(3/2)>1/3\) follows by integrating \(1/s>2/3\) on \([1,3/2)\).
It follows that

\[
\boxed{
\mathcal E(\omega_A+\omega_B)-\mathcal E(\omega_B)
< -\frac{a^2}{8\pi}.}
\]

Thus deletion increases the squared velocity norm by more than \(a^2/(8\pi)\), despite removing the uniquely closest opposite pair and preserving zero total circulation.
For Gaussian cores, the point-circulation total variation decreases by \(2a\); no monotonicity assertion about the already-overlapping continuous Gaussian densities' \(L^1\) norm is needed.

### 10.2 Compactly supported, nonoverlapping cores with actual TV decrease

The same failure is not an artifact of Gaussian tails or overlapping opposite cores.
Let

\[
\sigma_h=\frac1{\pi h^2}\mathbf1_{B(0,h)},\qquad h=\frac13,
\]

and place circulations \((-2a,+a,-a,+2a)\) at the same four positions \((-2,0,1,3)e_1\).
All disks are disjoint since their center distances are at least one and \(2h=2/3\).
The uniquely closest opposite pair is again the unit-strength pair at zero and one.
Write

\[
\widetilde\omega_A=a(\sigma_h(\cdot)-\sigma_h(\cdot-e_1)),\qquad
\widetilde\omega_B=2a(\sigma_h(\cdot-3e_1)-\sigma_h(\cdot+2e_1)).
\]

For a uniform disk, its logarithmic potential is

\[
P_h(x)=\int\log|x-y|\,\sigma_h(y)\,dy
=\begin{cases}
\log h-\frac12+\dfrac{|x|^2}{2h^2},&|x|\leq h,\\
\log|x|,&|x|\geq h.
\end{cases}
\]

This follows either from radial integration or from
\(\Delta P_h=2\pi\sigma_h\), continuity of value and radial derivative at \(r=h\), and \(P_h(r)-\log r\to0\) at infinity.
Its average against the disk itself is

\[
\iint\log|x-y|\,\sigma_h(x)\sigma_h(y)\,dx\,dy
=\log h-\frac14,
\]

because the disk average of \(|x|^2\) equals \(h^2/2\).
For two disks whose centers have separation \(d>2h\), their mutual logarithmic interaction equals \(\log d\): the first disk produces \(\log|x-c|\) throughout the second disk, and the mean-value property for that harmonic function gives its center value.

For a compactly supported bounded vorticity \(\omega\) of zero total mass, integration by parts for its stream function gives

\[
\mathcal E(\omega)
=-\frac1{2\pi}\iint\log|x-y|\,\omega(x)\omega(y)\,dx\,dy.
\]

All integrals here are finite: the logarithm is locally integrable against bounded compactly supported densities, and zero total mass makes the stream function \(O(1/|x|)\) and its gradient \(O(1/|x|^2)\) at infinity, so the boundary term vanishes.
The disk formulas and the four cross-interaction distances now yield

\[
\begin{aligned}
\mathcal E(\widetilde\omega_A+\widetilde\omega_B)
 -\mathcal E(\widetilde\omega_B)
&=\frac{a^2}{\pi}
\left(\log3+\frac14-4\log\frac32\right)\\
&=\frac{a^2}{\pi}\left(\frac14-\log\frac{27}{16}\right)
< -\frac{17a^2}{108\pi}<0.
\end{aligned}
\]

The numerical-free strict bound uses
\(\log(27/16)>(27/16-1)/(27/16)=11/27\).
At the same time, disjointness of opposite-sign cores gives the actual total variation decrease

\[
\|\widetilde\omega_A+\widetilde\omega_B\|_1=6a,
\qquad\|\widetilde\omega_B\|_1=4a.
\]

If an algorithm requires equal-strength particles, each circulation \(2a\) can be represented as two particles of circulation \(a\) at that same center.
Alternatively, separate those same-sign centers by sufficiently small distinct displacements: the strict energy gap persists by continuity, the nearest opposite pair remains unique, and opposite-sign core supports remain disjoint.
The only smoothness limitation in this explicit compact-core calculation is the disk boundary; small smooth radial approximations preserve the strict inequality, the separation, and the total-variation conclusion.

### 10.3 Consequence for an annihilation proof route

An annihilation scheme may lower the circulation-count or actual-vorticity total variation while increasing its natural regularized kinetic Hamiltonian.
The invalid step would be to discard the cross energy with the retained vortices.
This counterexample does not rule out schemes that compensate energy, use a different selection rule, or prove another compactness invariant.
Those alternatives need their own precise estimates.

## 11. Independent reconstruction audit of initial-velocity packet

**VERIFICATION_MODE_AND_PROVENANCE:** Worker D independently read and reconstructed every stated lemma in `route_initial_velocity_interfaces.md`; audited version SHA-256 `3e31eba256e7da13d72aa77acd157a9931c36b81f708b1d06c71e6bdae3f9b50`.
This is one independent reconstruction pass, not the four-pass forensic whole-manuscript certificate required for a complete project resolution.

**CRITICAL_ERRORS:** none found.

**GAPS:** none in the numbered claims under their stated scope. Lemma 6 remains explicitly conditional on sufficient solution regularity and justified integrations; this audit does not convert it into an approximation-existence theorem.

| Claim | Independent check | Verdict |
|---|---|---|
| Lemma 1: convolution and local energy | Tonelli with the uniform translated local kernel integral gives local \(L^1\); circulation and tangency give curl/divergence. Fourier homogeneity excludes a zero-supported multiplier correction. Truncating finite measures proves the Fourier identity in tempered distributions. Independently integrated \(\int_{B_2}|\xi|^{-1}=4\pi\), yielding the stated \(1/\pi\) low-frequency bound, and verified the high-frequency comparison \(|\xi|^{-2}\leq2(1+|\xi|^2)^{-1}\) on \(|\xi|\geq1\). | PASS |
| Lemma 2: absence of atoms | The smooth logarithmic cutoff has Dirichlet energy \((2\pi/L)\int_0^1|\zeta'|^2\), while its \(L^2\) norm vanishes. Signed measure dominated convergence isolates the atom without any assumption on Jordan-part energy. | PASS |
| Proposition 3: tail obstruction | Independently integrated the mass tail to \(1/\sqrt{\log r}\), checked total mass one and \(L^2\) inclusion, and computed the radial velocity energy \((2\pi)^{-1}\int dr/(r\log r)=\infty\). The circle Cauchy--Schwarz argument also validates nonradial compact corrections. | PASS |
| Stationary-solution scope remark | For the bounded radial density, the swirl is continuous and has the stated centripetal derivative; \(p'=a(r)^2/r\) cancels it distributionally. Thus the example is not an Euler nonexistence certificate. | PASS |
| Lemma 4: low-frequency background | Each positive-order Fourier derivative multiplier is bounded with compact support; therefore it lies in both \(L^1\) and \(L^2\). Fourier inversion and Plancherel give every stated bound. Zero-order multiplier is \(L^1\), giving boundedness and decay but no falsely asserted global \(L^2\) norm. | PASS |
| Lemma 5: mollified initial perturbation | Translation differences are in \(L^2\) with bound \(|h|\|\nabla U\|_2\), even if \(U\notin L^2\), by the integral formula for the difference. Minkowski and the finite mollifier first moment give the exact \(O(\varepsilon)\) estimate. | PASS |
| Lemma 6: conditional energy calculation | Expanded the equation for \(v=u-U\), canceled transport using \(\operatorname{div}(U+v)=0\), checked the positive sign of \(\nu\int v\cdot\Delta U\), and derived \(y'\leq ay+F\) after regularization at \(y=0\). The printed bound \(e^{at}(y(0)+Ft)\) follows for \(a\geq0\). | PASS, conditional as stated |
| Lemma 7: canonical Biot--Savart closure | Distributional curl convergence and uniform total variation extend uniquely from compact smooth tests to \(C_0\); the convolved vector test is continuous, bounded, and decays at infinity, so all-sequence weak-* convergence passes through the convolution. No mass-tightness requirement has been hidden. | PASS |
| Lemma 8: every-time closure | For each \(T>0\), a full-measure good-time set is dense including one-sided endpoint approximation. Weak local \(L^2\) continuity plus Lemma 7 closes the conclusions at each fixed time; the uniform variation bound then upgrades distributional time continuity to \(C_0\)-weak-* continuity. | PASS |
| Optional strong subcritical closure | Recomputed \(\|K\mathbf1_{B_{2\delta}}\|_p=O(\delta^{2/p-1})\) for \(1\leq p<2\); finite-measure convolution is bounded in \(L^p\) by this norm times TV. The retained kernel is \(C_0\), and pointwise convergence plus dominated convergence on bounded sets finishes. No endpoint \(p=2\) consequence follows. | PASS |

**REFERENCE_AND_PREDECESSOR_CHECKS:** All numbered positive conclusions reduce to the elementary tools stated in that packet; the verification did not import a research-paper theorem. The optional \(\dot H^{-1}\) statement in Proposition 3 is checked through its explicit Fourier definition and the multiplier identity, not through an unstated homogeneous-space quotient convention.

**EDGE_CASE_CHECKS:** Zero datum, nonzero circulation, noncompact measure support, signed atoms, mass escaping to infinity, mollifiers without symmetry, and the \(a=0\) Gronwall case all fit the claims. Lemma 8 is used for positive time horizons \(T>0\), as required by the target; a zero-length time interval would make its almost-everywhere premise vacuous and is not an intended scope.

**VERDICT:** PASS for the exact packet, preserving the conditional scope of Lemma 6.

**REPAIR_INSTRUCTIONS:** No mathematical repair required. If this is copied into a final manuscript, explicitly write \(T>0\) in Lemma 8 and retain the sentence that approximation existence and nonlinear convergence are separate obligations.
