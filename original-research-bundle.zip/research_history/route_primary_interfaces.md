# Worker E: primary theorem interfaces and concentration-curve route

Written 2026-10-08 during the active six-hour project. This is a worker artifact, not a terminal project report. Scope: exact theorem mismatches and a self-contained conditional cancellation lemma. No complete resolution of the target is claimed. Governing research procedure and audit procedure were read completely. External theorem statements below were checked against primary-source text except where expressly labelled unavailable. The conditional lemma below still requires independent audit.

## 1. Primary-source interface ledger

### E1. Delort: sign-definite compactly supported data

Primary author source: J.-M. Delort, *Existence de nappes de tourbillon pour l’équation d’Euler sur le plan*, Séminaire EDP, 1990–1991, exposé II; Theorem 1, printed p. II-2; extension on pp. II-9–II-10.

URL: https://www.numdam.org/item/SEDP_1990-1991____A2_0.pdf

Theorem interface: a compactly supported nonnegative Radon measure in inhomogeneous H^{-1}(R²), with its Biot–Savart velocity, generates a global distributional Euler solution, with nonnegative measure vorticity at every time and mass bounded by the initial mass. Subtracting a smooth radial circulation carrier yields a velocity locally bounded in time in global L². The negative-sign case follows by time reversal and velocity sign change. The stated extension allows a sign-definite compactly supported singular measure plus a more regular perturbation; the author’s footnote allows L¹∩H^{-1} perturbations.

Mismatch: arbitrary signed singular Jordan parts are not covered; compact support is additionally assumed in this source. This source does not justify summing independent one-sign solutions. The PDF text extraction loses some function-space symbols, so it is not used here as a certificate of the exact time-continuity topology.

### E2. Reflection symmetry: genuine signed existence, but a geometric invariant is essential

Primary author preprint: M. C. Lopes Filho, H. J. Nussenzveig Lopes and Z. Xin, *Existence of vortex sheets with reflection symmetry in two space dimensions*, IMECC report 43/1999; subsequently Arch. Ration. Mech. Anal. 158 (2001), 235–257, DOI 10.1007/s002050100145.

URL: https://www.ime.unicamp.br/sites/default/files/pesquisa/relatorios/rp-1999-43.pdf

Definition 1: NMS means odd with respect to x₁=0 and nonnegative in x₁>0. Theorem 1 (preprint p.14), with Section 3 hypotheses, gives finite-energy weak Euler solutions for compactly supported NMS measures in H^{-1}. Theorem 3 gives convergence of a vanishing-viscosity subsequence for the same class. Theorem 4 adds an odd compactly supported L¹∩H^{-1} perturbation. Theorem 2 characterizes reflection via the stronger boundary-coupled half-plane formulation.

Mismatch: symmetry, one-sided sign, and compact support are indispensable hypotheses of the retrieved statements. Their special additional estimate controls tangential velocity on the fixed symmetry axis; Lemmas 2–3 turn this into time-averaged nonconcentration of absolute vorticity. Merely solving a one-sign half-plane problem with weak tangency and reflecting does not supply the needed boundary-coupled condition. Thus this is a mechanism, not a cover of arbitrary signed data.

### E3. Sparse compactness: signed H^{-1} does not automatically control absolute-value sparse norms

Primary source read: Ó. Domínguez and M. Milman, *A sharp stability criterion for Euler equations via sparseness*, arXiv:2310.19659v1 (47 pages). Bibliographic page lists publication in Analysis & PDE 19 (2026), 659–720; the publisher PDF could not be retrieved, so numbering below is explicitly the preprint numbering.

URL: https://arxiv.org/pdf/2310.19659v1

Theorem 3 gives SR^{p,q} norm equivalence with the negative Sobolev norm for nonnegative functions, 1≤p<q<∞; for general signed functions it states only the embedding SR^{p,q}→H^{-n(1/p−1/q)}_q. Theorem 4’s sparse-index compactness equivalence explicitly assumes a positive function/measure cone. Theorem 5 yields strong convergence of approximate Euler families if their vorticities have a uniform bound in a space compactly embedded through a decay space S_Ψ.

Mismatch: our datum is signed; sparse norms involve absolute values. An H^{-1} bound on signed vorticity does not yield the positive-cone input. Moreover a datum-level bound must be propagated uniformly along an approximate evolution. Theorem 2’s broad prose must not be imported blindly: its converse proof explicitly uses a set in BM_c^+ and a positive-cone argument. No claim about correcting the paper is made; this records an unusable target interface.

### E4. Exact steady concentration examples and what they actually obstruct

Primary source: Ó. Domínguez and D. Spector, *A sparse resolution of the DiPerna–Majda gap problem for 2D Euler equations*, arXiv:2409.02344v1, Theorems 1.3 and 1.4, Section 3.5.

URL: https://arxiv.org/pdf/2409.02344v1

Theorem 1.3 constructs a nonnegative probability measure with logarithmic Morrey exponent 1 outside H^{-1}_{loc}. This is not an admissible target datum. Theorem 1.4 constructs exact steady mixed-sign vortex-sheet solutions, uniformly bounded in L² and logarithmic Morrey exponent 1, converging weakly to zero but not strongly in L². Energy concentrates on a zero-Hausdorff-dimensional Cantor set. Section 3.5 builds them from disjoint compactly supported radial eddies with zero circulation.

Mismatch: initial data vary with the sequence; the limit zero is an Euler solution. The construction refutes automatic strong compactness of the stated bounded class, not existence for any fixed target datum and not universal weak concentration cancellation. The paper’s “reduced defect measure” defined by a limsup on sets is expressly not generally a countably additive measure; it must not be confused with a subsequential weak-* stress measure.

### E5. Schochet: source limitation and a replacement direct argument

S. Schochet, *The weak vorticity formulation of the 2-D Euler equations and concentration-cancellation*, Comm. PDE 20 (1995), 1077–1104, DOI 10.1080/03605309508821124.

Primary publisher abstract: https://www.tandfonline.com/doi/abs/10.1080/03605309508821124

The abstract describes cancellation when approximate vorticities concentrate along a Hölder-1/2 curve. The full original article could not be retrieved (publisher 403), so its exact theorem number and full approximation hypotheses remain unchecked. No assembled proof should invoke that theorem from this abstract alone. Section 3 below supplies a directly proved velocity/stress statement with explicit hypotheses, so this source limitation need not halt the mathematical route.

### E6. A related primary result with a different defect notion

F. Poupaud, *Diagonal defect measures, adhesion dynamics and Euler equation*, Methods Appl. Anal. 9 (2002), 533–562, Proposition 4.3.

URL: https://archive.intlpress.com/site/pub/files/_fulltext/journals/maa/2002/0009/0004/MAA-2002-0009-0004-a004.pdf

Proposition 4.3 concerns generalized solutions (ω,ν) in the paper’s positive diagonal-defect class. Its defect ν does not charge a Hölder curve of exponent γ>1/2, nor sets outside the atomic support of ω. Theorem 4.3 permits positive atomic initial vorticities by introducing this generalized defect.

Mismatch: positivity and generalized solution class differ from the target; atoms are allowed precisely by relaxing ordinary Euler’s vorticity product. This theorem is not a substitute for signed M∩H^{-1} existence, and its ν is not automatically the velocity Reynolds stress below.

## 2. Direct calculation: why compact radial eddies have isotropic stress defects

This calculation is independent of any quoted theorem. Let

v_{n,j}(x)=V_{n,j}(|x-a_{n,j}|)e_θ(x-a_{n,j})

be L² radial tangential fields with pairwise disjoint supporting disks B(a_{n,j},r_{n,j}) for each n. Assume max_j r_{n,j}=r_n→0 and Σ_j∥v_{n,j}∥²₂≤C. Set v_n=Σ_jv_{n,j} and E_{n,j}=∥v_{n,j}∥²₂. Polar integration gives exactly

∫v_{n,j}⊗v_{n,j} dx = (E_{n,j}/2)I,

because ∫₀^{2π}e_θ⊗e_θ dθ=πI. For every smooth compactly supported matrix field A,

|∫A:(v_n⊗v_n)dx − (1/2)Σ_j E_{n,j} tr A(a_{n,j})|
≤ C∥∇A∥∞ r_n Σ_jE_{n,j} →0.

Here disjoint supports remove cross terms. If λ_n=Σ_jE_{n,j}δ_{a_{n,j}} converges weak-* locally to λ, then v_n⊗v_n ⇀* (λ/2)I. Such a stress contributes zero against divergence-free test gradients, even when λ is nonzero and concentrated on a complicated set. This explains the cancellation in the radial-building-block construction without requiring energy to converge strongly.

It does not prove that arbitrary dynamically formed small scales become radial. It identifies the weaker relevant requirement: eliminate the traceless stress, not all energy concentration.

## 3. Verification packet: cancellation on countably many Hölder-1/2 graphs

### Exact statement

Let I⊂R be open. Suppose u∈L²_loc(I×R²;R²), div_x u=0, and R is a locally finite symmetric matrix-valued Radon measure on I×R². Suppose

∫_{I×R²}[u·∂_tφ+(u⊗u):∇φ] dxdt + ∫_{I×R²}∇φ:dR =0

for every divergence-free φ∈C_c^∞(I×R²;R²). Let a:I→R² be locally Hölder continuous with exponent 1/2 and Γ_a={(t,a(t)):t∈I}. Then R restricted to Γ_a is isotropic:

R|_{Γ_a} = (1/2)tr(R|_{Γ_a}) I.

Consequently, if R is carried by a countable union of such graphs, then R=(tr R/2)I and u satisfies the ordinary Euler weak formulation on I.

No sign assumption, total-variation bound on curl u, global kinetic energy, time differentiability of a, or time absolute continuity of R is needed in this conditional statement.

### Complete proof

Fix χ∈C_c^∞(I) and a real 2×2 matrix P with tr P=0. Work on a compact time interval J⊂I containing supp χ in its interior. Extend a outside J to a globally Hölder-1/2 function without changing it near supp χ (constant continuation beyond endpoints suffices). Let ρ be a smooth nonnegative compactly supported time mollifier of integral one, and set a_ε=ρ_{ε²}*a. Standard direct convolution estimates give

sup_{supp χ}|a_ε−a|≤C_a ε,
sup_{supp χ}|a_ε'|≤C_a ε^{-1}.

For completeness, the first follows by integrating |a(t−s)−a(t)|≤C|s|^{1/2}; the second follows from ∫ρ'_{ε²}=0 and the same Hölder estimate. Constants depend on ρ and the local Hölder seminorm, not ε.

Write J₀=[[0,−1],[1,0]]. The matrix H=−J₀P is symmetric because tr P=0. Choose a smooth cutoff η equal to one on a ball B(0,C_a+1), and let q(z)=(1/2)zᵀHz. Define

Φ(z)=J₀∇[η(z)q(z)].

Then Φ is smooth and compactly supported, div Φ=0, and Φ(z)=Pz, ∇Φ(z)=P throughout B(0,C_a+1). Define the admissible test

φ_ε(t,x)=ε χ(t)Φ((x−a_ε(t))/ε).

Let E_ε denote its space-time support, enlarged if necessary to contain the supports of its derivatives. This lies in a fixed compact set and in a tube {|x−a(t)|≤Cε}. Hence 1_{E_ε}→0 almost everywhere for Lebesgue space-time measure, since Γ_a has zero three-dimensional Lebesgue measure. In particular,

∥u1_{E_ε}∥_{L²}→0,
∫_{E_ε}|u|² dxdt→0.

We have ∇_xφ_ε=χ(t)∇Φ((x−a_ε)/ε), uniformly bounded. Also

∂_tφ_ε=εχ'Φ((x−a_ε)/ε)−χ(t)[a_ε'(t)·∇]Φ((x−a_ε)/ε).

In two spatial dimensions, changing x=a_ε+εz shows that the L²_{t,x} norm of the first term is O(ε²), while the second is bounded by Cε∥a_ε'∥_{L²(supp χ)}≤C. Therefore

|∫u·∂_tφ_ε|≤∥u1_{E_ε}∥₂∥∂_tφ_ε∥₂→0,
|∫(u⊗u):∇φ_ε|≤C∫_{E_ε}|u|²→0.

At x=a(t), the bound |a−a_ε|/ε≤C_a gives ∇φ_ε(t,a(t))=χ(t)P exactly. At every point (t,x) with x≠a(t), ∇φ_ε(t,x)=0 for all sufficiently small ε. Uniform boundedness and local finiteness of |R| allow dominated convergence against the total variation of R, yielding

lim_{ε→0}∫∇φ_ε:dR = ∫_{Γ_a}χ(t)P:dR.

The weak identity thus gives ∫_{Γ_a}χ(t)P:dR=0. Since χ is arbitrary and projection (t,a(t))↦t identifies the graph with I, P:R|_{Γ_a}=0 as a signed measure for every trace-free P. The annihilator of trace-free matrices is span{I}; therefore R|_{Γ_a}=(tr R|_{Γ_a}/2)I.

For countably many graphs Γ_k, form the disjoint Borel pieces B₁=Γ₁ and B_k=Γ_k\∪_{j<k}Γ_j. Each R|_{B_k} is the restriction of an isotropic measure and is isotropic. Countable additivity, locally interpreted using total variation, gives isotropy of R on their union. If R is carried by that union, isotropy holds everywhere. Finally ∇φ:I=div φ=0, so the stress drops from the weak formulation. QED.

### Dependency and edge-case ledger

- Uses only local L² integrability of u, the Euler–Reynolds identity, elementary mollification, a compact stream-function cutoff, finite-dimensional linear algebra, and dominated convergence for Radon measures.
- The exponent 1/2 is included: the time derivative test remains uniformly bounded in L²; one does not need it to converge strongly to zero because u vanishes in L² on the shrinking tube.
- Curves may intersect. The proof first addresses restriction to one entire graph and then uses disjoint Borel pieces.
- No R=0 conclusion follows; scalar isotropic concentration may remain.
- The lemma concerns interior times. To recover the target’s prescribed initial trace, that trace must already be supplied by the approximation/compactness construction.
- The lemma has not yet received an independent hostile audit. It is a complete candidate packet, not an accepted project theorem.

## 4. Route record and decisive next probes

ROUTE_NAME: Dynamic isotropy by geometric concentration control.

DIRECTION: Proof.

PRECISE_INTERMEDIATE_TARGET: For some approximation sequence from each fixed target datum, obtain an Euler–Reynolds limit whose entire non-isotropic defect is carried by countably many locally Hölder-1/2 trajectories. The preceding lemma would eliminate it without requiring strong L² convergence.

EARLIEST_UNRESOLVED_OBLIGATION: Signed-M and local energy bounds alone do not yet provide any such trajectory cover. Countably many possible concentration points at each fixed time is not enough: their movement and temporal measurability/regularity matter.

NEXT_EXECUTABLE_PROBE: Suppose |ω^n(t)|⇀*m_t. Investigate whether atoms of m_t carrying a nonzero quadratic defect can be tracked with displacement |a(t)−a(s)|≲|t−s|^{1/2}. Try to derive it by localized first moments, recording the obstruction from the mixed-sign transport term ∫u^n|ω^n|. If that pairing has no uniform bound, investigate cancellations in the stress-supported portion rather than the full absolute vorticity.

DECISIVE FALSIFICATION TEST: An approximate Euler family with fixed-datum consistency and a genuine anisotropic stress supported on an irregular moving concentration set would falsify automatic graph control. Static function-space concentrating examples alone do not test the evolution claim.

PARK CRITERION: If the only candidate estimate reduces to a bound on ∫|u^n||ω^n| that is already false under energy and measure norms, do not relabel it as a new route. Reopen only with a transport-specific cancellation or a different observable controlling defect trajectories.

ALTERNATIVE PROBE: The radial computation suggests an angular second-moment equation: target the traceless tensor directly, not the magnitude of the energy defect. Derive a localized virial identity around a candidate concentration center and determine whether the time derivative of a small-scale angular impulse becomes negligible. The graph lemma is one rigorous case where this negligibility can be verified.

## 5. Executed virial probe and the surviving obstruction

Let ω be a smooth Euler vorticity, compactly supported uniformly on the finite time interval considered, with zero circulation, and u=K*ω. Then u∈L²(R²). For a scalar spatial test ψ,

d/dt ∫ψω = −∫(u⊗u):∇(∇^⊥ψ).

This sign follows from ∫ψ curl u=−∫u·∇^⊥ψ and the velocity equation. Quadratic ψ are justified by multiplying by spatial cutoffs of radius R and passing R→∞: the second derivatives of the cutoff quadratic remain bounded, while the annular velocity energy vanishes. Consequently,

d/dt ∫x₁²ω = −2∫u₁u₂,
d/dt ∫x₂²ω = +2∫u₁u₂,
d/dt ∫x₁x₂ω = ∫(u₁²−u₂²).

In particular ∫|x|²ω is constant. With Q(t)=∫(x₁+ix₂)²ω,

Q'(t)=2i∫(u₁+iu₂)².

An independent check uses the symmetrized vorticity kernel: writing z=x−y,

d/dt ∫x₁²ω = −(1/(2π))∬z₁z₂|z|^{-2}ω(x)ω(y)dxdy,
d/dt ∫x₁x₂ω = (1/(4π))∬(z₁²−z₂²)|z|^{-2}ω(x)ω(y)dxdy.

Now suppose a family of such exact solutions has ∥ω^n(t)∥_M≤M and vorticity support in B(a_n(t),ε_n), with ε_n→0 and a_n uniformly bounded. Its signed impulse P_n=∫xω^n is constant, and |P_n|≤Mε_n because its circulation vanishes. Therefore each signed quadratic moment is bounded by C Mε_n+C Mε_n², uniformly in t. Testing the displayed moment identities against a fixed smooth function of time shows that the global spatial integrals of both traceless stress components tend to zero in time distributions.

This confirms cancellation of the globally integrated anisotropy for a shrinking neutral cluster, even without a prescribed path regularity. It does not yet yield local stress cancellation against A(t,x): evaluating A at a_n(t) introduces a variable temporal weight, and differentiating that weight requires control of cluster movement. Multiple clusters also introduce interaction and flux terms. Thus the virial probe identifies the same exact missing bridge as Section 3 rather than proving the target.
