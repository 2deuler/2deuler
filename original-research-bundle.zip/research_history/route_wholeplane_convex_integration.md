# Whole-plane localization of moving-dipole convex integration

Worker: initial_velocity_interfaces. Status: new local repair packet; independent audit required. This is not a completed iteration or a proof of the main target.

## 1. Source interface and the genuine localization issues

Primary source inspected: Bruè–Colombo–Kumar, arXiv:2408.07934v1, <https://arxiv.org/html/2408.07934v1>, Sections 2.4–2.5, 4.5–4.9, Appendix A. The periodic construction uses rational straight orbits to sample area, periodic Helmholtz projection, and periodic symmetric antidivergence. Its positive coefficient floor is integrable because the domain is bounded. Appendix A distinguishes compact nonsymmetric antidivergence from symmetric antidivergence on the torus. The following work derives whole-plane substitutes directly; the estimates below are not asserted as statements from that paper.

Three naive transfers fail:

1. Periodic extension to the whole plane has infinite total vorticity variation unless the vorticity vanishes.
2. A single straight Euclidean trajectory, unlike a rational torus trajectory, does not sample a two-dimensional box.
3. A whole-plane order-minus-one antidivergence of a mean-zero compact force usually has a \(|x|^{-2}\) tail; this need not be in \(L^1\). First moments must be checked, or a different operator used.

Also, an auxiliary radial kernel with radius equal to the raster row spacing can leave a fixed transverse comb modulation. The packet uses row spacing \(d\ll H\), where \(H\) is the auxiliary kernel radius.

**Convention warning.** With \(\Psi=\operatorname{Im}(-1/z)\) and \(\nabla^\perp=(-\partial_2,\partial_1)\), one has \(\nabla^\perp\Psi=-\nabla\operatorname{Re}(-1/z)\). Thus the literal sign convention in the source's (2.1)–(2.2) should not be copied unchecked. We fix a correctly oriented dipole below.

## 2. A whole-plane endpoint antidivergence lemma

### Lemma W1

Let \(f\in L^1(\mathbb R^2;\mathbb R^2)\) be supported in \(B_H(c)\) and satisfy
\[
\int f=0,\qquad \int (x_j-c_j)f_i(x)\,dx=0\quad(i,j=1,2).
\tag{W1}
\]
Define
\[
\mathscr R f=D\Delta^{-1}f+(D\Delta^{-1}f)^T
             -I\operatorname{div}\Delta^{-1}f.
\]
Then \(\mathscr R f\) is symmetric, \(\operatorname{div}\mathscr R f=f\), and
\[
\|\mathscr R f\|_{L^1(\mathbb R^2)}\leq C H\|f\|_1.
\tag{W2}
\]
It need not be compactly supported. This is compatible with the requested solution class, which requires finite global curl variation, not compact velocity or stress support.

**Proof.** Every component of the convolution kernel \(L\) for \(\mathscr R\) is a fixed linear combination of derivatives of \((2\pi)^{-1}\log|x|\); hence \(|L(x)|\leq C|x|^{-1}\) and \(|D^2L(x)|\leq C|x|^{-3}\). For \(|x-c|\leq2H\), Tonelli gives
\[
\int_{B_{2H}(c)}|L*f|\leq
\int|f(y)|\int_{B_{2H}(c)}\frac C{|x-y|}\,dx,dy
\leq CH\|f\|_1.
\]
For \(|x-c|>2H\), subtract the constant and linear Taylor terms using (W1):
\[
|L*f(x)|\leq C|x-c|^{-3}\int|y-c|^2|f(y)|\,dy
\leq CH^2|x-c|^{-3}\|f\|_1.
\]
Integration gives another \(CH\|f\|_1\). Symmetry is explicit, and differentiating the formula distributionally gives \(\operatorname{div}\mathscr R f=f\). \(\square\)

For reference, compact **symmetric** antidivergence has an additional torque condition: if \(\operatorname{div}A=f\) with compact symmetric \(A\), then \(\int x^\perp\cdot f=0\). Given a compact rowwise Bogovskii inverse \(A_0\) of a zero-mean force with zero torque, one can symmetrize it: solve \(\operatorname{div}\psi=(A_0)_{21}-(A_0)_{12}\) compactly, and add the matrix whose rows are \(\nabla^\perp\psi_i\). Its row divergence is zero and its antisymmetric part cancels that of \(A_0\). This gives \(L^p\) estimates for \(1<p<\infty\). Lemma W1 is preferable here because it proves the actual \(L^1\) estimate directly.

## 3. Correctly oriented whole-plane dipole and force replacement

Take the unit Lamb dipole \(D\) traveling in direction \(e_1\) with speed one. It can be defined without convention ambiguity as follows. Let \(b\) be the first positive zero of \(J_1\), and define
\[
\psi(\rho,\theta)=
\begin{cases}
\rho\sin\theta-\dfrac{2J_1(b\rho)}{bJ_0(b)}\sin\theta,&\rho\leq1,\\
\dfrac{\sin\theta}{\rho},&\rho\geq1.
\end{cases}
\qquad D=(\partial_2\psi,-\partial_1\psi).
\tag{W3}
\]
Thus, outside \(B_1\), \(D=\nabla\Phi\) with \(\Phi=-x_1/|x|^2\). The Bessel equation and \(J_1(b)=0\) give matching derivatives and
\(\operatorname{curl}D=b^2(\psi-x_2)\) inside, zero outside. Since \(D-e_1=(\partial_2,-\partial_1)(\psi-x_2)\), the vorticity is constant along the relative streamlines. More explicitly,
\[
-\partial_1D+(D\cdot\nabla)D+\nabla P=0,
\quad
P=D_1-\frac12|D|^2-\frac{b^2}{2}\mathbf1_{B_1}(\psi-x_2)^2.
\tag{W4}
\]
The last potential has no boundary jump because \(\psi-x_2=0\) on \(\partial B_1\). These formulas also give the parity: \(D_1\) is even in both variables, and \(D_2\) is odd in both variables.

Set \(D_r(x)=r^{-1}D(x/r)\). Rotation gives the corresponding formulas for any unit direction \(\xi\). Then
\[
\|D_r\|_2=C_D,\quad
\|D_r\|_p=C_{D,p}r^{2/p-1}\ (1<p<\infty),\quad
\|\operatorname{curl}D_r\|_1=C_\omega,
\tag{W5}
\]
and the curl is supported in \(B_r\). In particular, full dipole velocity tails are permitted and cause no total-variation problem.

Define
\[
h_r=\partial_rD_r-D_r/r.
\]
Homogeneity outside \(B_r\) gives \(\operatorname{supp}h_r\subset B_r\), \(\|h_r\|_1\leq C\), and
\[
h_r=-\operatorname{div}(D_r\otimes x/r),\quad
\int h_r=0,\quad \int x_j(h_r)_i=0.
\tag{W6}
\]
For the mean, integrate the divergence on \(B_R\), \(R>r\), and use the zero angular average of the exterior doublet velocity. The first moments vanish by the stated parity. Hence
\[
\|\mathscr R h_r\|_1\leq Cr.
\tag{W7}
\]

Fix \(H>4r\), and let \(\chi_H\) be radial, zero on \(B_{H/2}\), one outside \(B_H\). Define
\[
S_{r,H}=D_r/r-\nabla(\chi_H\Phi).
\tag{W8}
\]
This is supported in \(B_H\), since \(D_r/r=\nabla\Phi\) outside the core. Direct angular integration, or the boundary integral of the potential, gives
\[
\int S_{r,H}=\kappa\xi,\quad \kappa=2\pi,
\qquad \int x_j(S_{r,H})_i=0,
\qquad
\|S_{r,H}\|_1\leq C[1+\log(H/r)].
\tag{W9}
\]
For example, in direction \(e_1\), the integral of \(D\) over its unit core is \(\pi e_1\), whereas the outer boundary integral of \(\nabla(\chi_H\Phi)\) is \(-\pi e_1\); their difference is \(2\pi e_1\). The first moments follow from parity, and the logarithm follows by integrating \(|x|^{-2}\) from \(r\) to \(H\).

Let \(\rho_H\) be an even smooth nonnegative unit-mass kernel supported in \(B_H\). Then
\(f=S_{r,H}-\kappa\rho_H\xi\) satisfies (W1), and
\[
\|\mathscr R(S_{r,H}-\kappa\rho_H\xi)\|_1
\leq CH[1+\log(H/r)].
\tag{W10}
\]

### Lemma W2: one moving core, with a genuine whole-plane \(L^1\) stress

Let \(r(t)>0\), \(\eta(t)\geq0\), \(c'(t)=\eta(t)\xi/r(t)\), and put
\[
V(t,x)=\eta(t)D_{r(t)}(x-c(t)),\qquad B(t)=\eta(t)r(t).
\]
Whenever \(r(t)<H/4\), there are a pressure and a symmetric integrable tensor \(E\) such that
\[
\partial_tV+\operatorname{div}(V\otimes V)+\nabla p
=\kappa B'(t)\rho_H(x-c(t))\xi+\operatorname{div}E,
\tag{W11}
\]
with
\[
\|E(t)\|_1
\leq CH[1+\log(H/r(t))]|B'(t)|
     +C|\eta(t)r'(t)|r(t).
\tag{W12}
\]
Also \(\operatorname{div}V=0\) and \(\|\operatorname{curl}V(t)\|_1=C_\omega\eta(t)\).

**Proof.** Differentiate and use (W4): the non-gradient residual is
\(B'D_r/r+\eta r'h_r\). Replace \(D_r/r\) by (W8), absorb the gradient into pressure, replace \(S\) by \(\kappa\rho_H\xi\), and apply (W10), (W7). \(\square\)

The dipole is initially only piecewise smooth across the core boundary. If a smooth building block is required, convolve the entire identity in space at scale \(\ell\ll\inf r(t)\). The added symmetric commutator stress is bounded by
\(C\eta^2\ell^2\|\nabla D_r\|_2^2\leq C\eta^2(\ell/r)^2\).
Curl variation does not increase. All zero and first moments survive convolution with an even unit-mass kernel. Thus smoothing is an arbitrarily small additional error for a fixed stage; its derivative costs must still be included in the full iteration bookkeeping.

## 4. Exact finite raster clock, including births and deaths

Fix a rectangle in coordinates \((s,y)\) parallel and perpendicular to \(\xi\). Let \(a_0\geq0\) be smooth and compactly supported in its interior. Enlarge the rectangle by fixed longitudinal buffers, and take finitely many equally spaced rows \(y_j\), spacing \(d\), covering the transverse projection of the support. Include enough extra rows that the \(H\)-neighborhood of that projection is covered. Along row \(j\), set
\[
a_j(s)=a_0(s,y_j)+\epsilon,
\tag{W13}
\]
where \(\epsilon>0\) is a floor. Every row has the same fixed endpoints and buffers, and \(a_j=\epsilon\) on the buffers.

Choose a profile \(g\), independent of the row, with \(0<g\leq1\) on the open line segment, \(g=1\) wherever \(a_0\) can be nonzero, and vanishing at its endpoints. Require
\[
\int g^{-1}\,ds<\infty,\quad
\sup|gg'|<\infty,\quad \int|g'|<\infty.
\tag{W14}
\]
One can moreover ensure a smooth flat temporal switch by taking, near a left endpoint,
\(g(s)=(s/b)\log^2(b/s)\) on a sufficiently short interval, then joining smoothly to one; use the reflected construction at the right endpoint. There \(a=\epsilon\), and the ODE below has \(s(t)\) proportional, up to a fixed coordinate normalization, to \(\exp(-C/t)\). Thus both the field amplitude and its derivatives vanish to all orders at the switch. The profile need not be smooth as a function of \(s\) at the endpoint; the resulting time profile is smooth.

Define
\[
J_j=\int\frac{a_j(s)}{g(s)}\,ds,
\qquad A_{d,\epsilon}=d\sum_jJ_j,
\qquad \eta_0^2=A_{d,\epsilon}/\kappa,
\qquad r_0=\frac{\tau d}{\kappa\eta_0}.
\tag{W15}
\]
The zero target coefficient can simply be skipped, avoiding a zero-amplitude normalization. Otherwise all quantities in (W15) are positive. On each row, in succession, set
\[
\eta(t)=\eta_0g(s(t)),\quad r(t)=r_0a_j(s(t)),\quad
s'(t)=\frac{\eta_0g(s(t))}{r_0a_j(s(t))}.
\tag{W16}
\]
The duration of row \(j\) is \((r_0/\eta_0)J_j\). Summing and using (W15) gives total duration exactly \(\tau\). Between rows, the center resets while the amplitude is zero and flat; the resulting velocity and source are smooth across the reset. At most one principal dipole is active at any time.

The buffer travel time cannot simply be added to a plateau-only normalization: \(\eta_0^2=d\sum\int a_j\) would already use all of \(\tau\) for plateau motion. The factor \(g^{-1}\) in (W15) repairs this exactly.

For the auxiliary source
\[
F(t,x)=\kappa B'(t)\rho_H(x-c(t))\xi,
\]
integration by parts on each row, using \(B=0\) at both endpoints, yields
\[
\frac1\tau\int_0^\tau F\,dt
=\operatorname{div}(A_{H,d,\epsilon}(x)\xi\otimes\xi),
\quad
A_{H,d,\epsilon}
=d\sum_j\int a_j(s)g(s)\rho_H(x-(s,y_j))\,ds.
\tag{W17}
\]
Indeed, \(B c'=\eta^2\xi\), so the tensor before changing variables is \((\kappa/\tau)\int\eta^2\rho_H\,dt\); (W16) and \(\kappa\eta_0r_0/\tau=d\) give (W17). This includes turn-on and turn-off terms, rather than discarding them.

## 5. Quantitative area sampling; why two spatial scales suffice

### Lemma W3

For \(a_0\in W^{1,1}(\mathbb R^2)\) smooth enough to evaluate on the rows,
\[
\left\|d\sum_j\int a_0(s,y_j)\rho_H(x-(s,y_j))\,ds-a_0\right\|_1
\leq C\left[
d\|\partial_y a_0\|_1+
\frac dH\|a_0\|_1+
H\|\nabla a_0\|_1\right].
\tag{W18}
\]
Rows may be summed over all integers since the summand vanishes outside finitely many rows.

**Proof.** Regard
\(F(y)=\int a_0(s,y)\rho_H(\cdot-(s,y))\,ds\)
as an \(L^1_x\)-valued function. The elementary one-dimensional rectangle-rule error is bounded by \(d\int\|F'(y)\|_1dy\). Differentiating gives the first two terms, since \(\|\partial_y\rho_H\|_1\leq C/H\). The resulting continuum integral is \(a_0*\rho_H\); its difference from \(a_0\) is bounded by \(CH\|\nabla a_0\|_1\). \(\square\)

Since \(g=1\) on the support of \(a_0\), the floor contribution in (W17) has \(L^1\) norm at most \(C_{\rm box}\epsilon\). Consequently the right-hand side of (W18), plus \(C_{\rm box}\epsilon\), bounds \(\|A_{H,d,\epsilon}-a_0\|_1\). Taking \(d=H^2\) makes all quadrature terms vanish. The leading amplitude obeys
\[
\eta_0^2\leq C\left(\|a_0\|_1+d\|\partial_y a_0\|_1+C_{\rm box}\epsilon\right),
\tag{W19}
\]
because \(a_0/g=a_0\) and the floor integral of \(g^{-1}\) is finite.

## 6. Time corrector and total curl variation

Let \(\overline F=\tau^{-1}\int_0^\tau F\,dt\), let \(P\) be the whole-plane Leray projection, and set
\[
Q(t)=-P\int_0^t(F(s)-\overline F)\,ds.
\tag{W20}
\]
Then \(Q(0)=Q(\tau)=0\), \(\operatorname{div}Q=0\), and its curl is compactly supported in the swept finite box enlarged by \(H\), since curl annihilates the gradient part of \(P\).

Define the finite coefficient variation
\[
D_{a,d,\epsilon}=d\sum_j\int |(a_jg)'(s)|\,ds.
\tag{W21}
\]
It stays bounded as \(d\downarrow0\) for a fixed smooth coefficient, box, and floor, and its leading term involves the longitudinal derivative of \(a_0\). From (W15),
\[
\int_0^\tau |B'(t)|\,dt
=\eta_0r_0\sum_j\int|(a_jg)'|\,ds
=\frac\tau\kappa D_{a,d,\epsilon}.
\tag{W22}
\]
The triangle inequality in (W20), boundedness of \(P\) on \(L^2\), and \(\|\rho_H\|_2+\|\nabla\rho_H\|_1\leq C/H\) imply
\[
\sup_t\left(\|Q(t)\|_2+\|\operatorname{curl}Q(t)\|_1\right)
\leq C\frac\tau H D_{a,d,\epsilon}.
\tag{W23}
\]
For \(1<p<\infty\), the analogous estimate is
\(\|Q\|_{L^\infty_tL^p_x}\leq C_p\tau H^{2/p-2}D_{a,d,\epsilon}\).
In particular,
\[
\sup_t\|\operatorname{curl}(V+Q)(t)\|_1
\leq C_\omega\eta_0+C\tau H^{-1}D_{a,d,\epsilon}.
\tag{W24}
\]
The leading term is independent of core size and row frequency.

The endpoint vanishing in (W20) is pointwise in time, not vanishing on a neighborhood. Extending \(Q\) by zero is continuous and produces no temporal delta in its derivative, but may produce a derivative jump. A global scheme demanding smooth gluing must account for this separately; one must not claim that the corrector is flat at cycle boundaries merely because the principal amplitude is flat.

## 7. Instantaneous error estimates and a consistent parameter probe

On a row,
\[
B'=\eta_0^2\left(gg'+g^2\frac{a_j'}{a_j}\right),\qquad
|\eta r'|r=\eta_0^2r_0g^2|a_j'|.
\tag{W25}
\]
Thus, with \(r_{\min}=r_0\epsilon\), \(r_{\max}=r_0(\|a_0\|_\infty+\epsilon)\), Lemma W2 yields
\[
\|E\|_{L^\infty_tL^1_x}
\leq C\eta_0^2H[1+\log(H/r_{\min})]
\left(\|gg'\|_\infty+\|\partial_s a_0\|_\infty/\epsilon\right)
+C\eta_0^2r_0\|\partial_s a_0\|_\infty.
\tag{W26}
\]
Adding \(Q\) changes the stress by the symmetric products \(V\otimes Q+Q\otimes V+Q\otimes Q\), whose \(L^1\) norm is at most \(2C_D\eta_0\|Q\|_2+\|Q\|_2^2\). The projected source cancellation is exact up to a pressure, so
\[
\partial_t(V+Q)+\operatorname{div}((V+Q)\otimes(V+Q))+\nabla p
=\operatorname{div}(A_{H,d,\epsilon}\xi\otimes\xi+E_{\rm total}).
\tag{W27}
\]
Against a fixed smooth finite-energy background \(u_*\), the additional interaction stress is bounded by
\[
2\|u_*\|_4\|V\|_{4/3}+2\|u_*\|_2\|Q\|_2
\leq C\|u_*\|_4\eta_0r_{\max}^{1/2}
+2\|u_*\|_2\|Q\|_2.
\tag{W28}
\]
This avoids an invalid whole-plane \(L^1\) bound on the full dipole velocity, which has a logarithmically divergent absolute integral.

For a fixed coefficient and a fixed positive floor, the explicit choice
\[
d=H^2,\qquad \tau=H^6,\qquad r_0=\frac{H^8}{\kappa\eta_0}
\tag{W29}
\]
makes \(r_{\max}\ll H\), (W26), (W23), (W28), and the quadrature error tend to zero as \(H\downarrow0\). The floor error is independently made small first by choosing \(\epsilon\) small. All derivative-dependent constants are finite for each frozen stage and can be absorbed by choosing \(H\) sufficiently small. The leading curl cost (W24), (W19) is \(C\|a_0\|_1^{1/2}\), up to arbitrarily small errors.

## 8. What this packet does and does not certify

The proved local statements remove two concrete whole-plane obstacles: integrable symmetric stress replacement of a compact source, and finite raster averaging without infinite vorticity variation. They provide exact finite-cycle identities and an endpoint curl estimate with no frequency factor in its leading term.

To turn them into a full perturbation proposition, the following still need a single assembled proof:

- A finite-direction decomposition of a general stress, with cycle allocation and all coefficient constants tracked.
- Time-dependent coefficients, their freezing errors, and smooth or sufficiently regular gluing of the correctors across cycles.
- Preservation of an exact prescribed trace through the time-strip iteration; pointwise cycle-end vanishing alone does not settle this.
- A simultaneous parameter choice across all time strips, with bounded temporal overlap and stagewise summability of the leading curl costs.
- Noncompact stress tails created by \(\mathscr R\) and velocity cross products. They are \(L^1\), but a later stage must truncate their stress to a large finite box with uniformly small tail before applying the raster lemma. Uniform-in-time tail control must be proved for the constructed stage; it does not follow from a bare \(L^\infty_tL^1_x\) bound.

One possible tail mechanism is that each fixed stage contains finitely many smooth time pieces and has continuous \(L^1\)-valued stress on each closed piece; their compact images are uniformly tight. This would justify choosing a sufficiently large next box. It must be checked for the actual assembled stress formulas.

Verification provenance: direct worker derivation; source inspected for construction interfaces; no independent verdict yet. No claim is made that the remaining iteration obligations have been completed.

## 9. Further elementary interfaces for assembly

### Fixed-direction decomposition without rational slopes

Let \(R\) be a compactly supported smooth symmetric tensor. Choose \(\chi\in C_c^\infty\), \(0\leq\chi\leq1\), equal to one on a neighborhood of \(\operatorname{supp}R\), and set
\(\rho=16\chi\sqrt{|R|^2+\epsilon^2}\).
This is smooth and compactly supported, \(\rho\geq16|R|\), and
\(\int\rho\leq16\|R\|_1+16\epsilon\|\chi\|_1\).
For directions
\(e_1,e_2,e_+=(1,1)/\sqrt2,e_-=(1,-1)/\sqrt2\), set
\[
a_1=\rho/2-R_{11}+R_{12},\quad
a_2=\rho/2-R_{22}+R_{12},\quad
a_+=\rho/2-2R_{12},\quad a_-=\rho/2.
\]
All coefficients are nonnegative, smooth and compactly supported, and direct expansion gives
\[
\rho I-R=\sum_i a_i e_i\otimes e_i,
\qquad
-\operatorname{div}R
=\operatorname{div}\sum_i a_i e_i\otimes e_i-\nabla\rho.
\tag{W30}
\]
Their summed integrals are bounded by \(C\|R\|_1+C\epsilon\|\chi\|_1\). The four raster families may be placed in disjoint time subintervals; their amplitude normalization must include the reciprocal fraction of the cycle allocated to each direction. For equal quarter-cycles this multiplies the amplitude by two, a fixed universal factor. This algebra does not rely on torus orbits.

### Backgrounds with infinite absolute kinetic energy

The cross-stress estimate can use only a finite \(L^4\) norm of the background:
\[
\|u_*\otimes(V+Q)\|_1
\leq\|u_*\|_4\bigl(C\eta_0r_{\max}^{1/2}+\|Q\|_{4/3}\bigr).
\tag{W31}
\]
For the fixed low-frequency background \(U=\chi(D)K*\mu\) from the initial-velocity packet, \(\chi(\xi)(-i\xi^\perp/|\xi|^2)\widehat\mu(\xi)\) lies in \(L^{4/3}_\xi\), with norm at most \(C\|\mu\|_{\mathcal M}\): the singularity \(|\xi|^{-4/3}\) is integrable in two dimensions. Hausdorff–Young therefore gives \(U\in L^4\). Thus a smooth relative-energy seed can also be used in (W31), provided its relative part has finite \(L^4\) norm on the patch. Nonzero circulation is not an obstruction to this estimate.

### Propagation of uniform stress tails on a finite patch

Assume the old stress is uniformly tight in \(L^1\) over a finite time patch and the old velocity is uniformly bounded in \(L^4\) there. The finite raster construction has bounded centers, radii bounded above and away from zero at that fixed stage, and bounded amplitudes. Lemma W1's Taylor proof gives uniform \(|x|^{-3}\) tails for the force-replacement stresses. The full dipoles and the projected compact correctors have uniform \(|x|^{-2}\) velocity tails; for the latter, apply the far-field expansion to \(PZ=Z-\nabla\Delta^{-1}\operatorname{div}Z\), where \(Z\) is the compact time integral in (W20). Hence these velocities have uniformly vanishing \(L^{4/3}\) tails. Hölder and (W31) imply uniform \(L^1\) tightness of their products with the old velocity. The products among corrections are treated by their uniform \(L^2\) tails. All finite sums and compact averaged-stress terms retain uniform tightness. Thus the new stress is uniformly tight, allowing its next correction to be restricted to a sufficiently large finite box with arbitrarily small leftover \(L^1\) norm.

This argument is local to a fixed finite time patch. Uniform constants over an infinite family of patches approaching time zero still belong to the full iteration audit; one may choose spatial boxes and frequencies separately on those patches, but must keep the leading norm costs uniform.
