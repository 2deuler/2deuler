# Signed-vorticity compactness route

Worker: `/root/signed_compactness`. This is a research packet, not a proof of the target or its negation. The governing procedure and audit procedure were read completely. No external theorem is needed for the calculations below; the smooth Euler approximants and their uniform local energy bounds are explicit conditional hypotheses.

## A. Exact conditional bridge

Fix (T>0). Let $(\omega_n,u_n)$ be smooth Euler solutions on $[0,T]\times\mathbb R^2$ with $u_n=K*\omega_n$, satisfying

\[
\sup_{n,t}\|\omega_n(t)\|_{\mathcal M}\le M,
\qquad
\sup_{n,t}\|u_n(t)\|_{L^2(B_R)}\le E_R<\infty
\quad(R<\infty),
\]

and $\omega_n(0)\rightharpoonup^*\omega_0$ as finite measures. Smoothness can be replaced by an approximate weak identity with a residual tending to zero and an equicontinuity estimate, but that extension is not used here.

For a scalar test function $\psi\in C_c^\infty([0,T)\times\mathbb R^2)$, set off the diagonal

\[
H_\psi(t,x,y)=\frac1{4\pi}
\frac{(\nabla\psi(t,x)-\nabla\psi(t,y))\cdot(x-y)^\perp}{|x-y|^2}.
\]

It is symmetric in $(x,y)$ and bounded by $(4\pi)^{-1}\|D^2\psi\|_\infty$. Put any value, for example zero, on the diagonal. Fix a radial cutoff $\chi\in C_c^\infty(\mathbb R^2)$ with $0\le\chi\le1$, $\chi=1$ on $B_1$ and $\chi=0$ off $B_2$. The sufficient condition is

\[
\tag{SD}
\lim_{\delta\downarrow0}\limsup_{n\to\infty}
\left|\int_0^T\iint
\chi\!\left(\frac{x-y}{\delta}\right)
H_\psi(t,x,y)\,d\omega_n(t,x)d\omega_n(t,y)\,dt\right|=0
\]

for every such $\psi$. This is a *signed* cancellation condition; no absolute values are imposed inside the integral.

**Conditional conclusion.** A subsequence converges to a solution on $[0,T]$ satisfying every property of the target restricted to that interval, with $\sup_t\|\omega(t)\|_{\mathcal M}\le M$. If the hypotheses and (SD) hold on all finite intervals for one approximation sequence, a diagonal subsequence gives one global solution.

### Proof of the compactness and every-time assertions

The same conditional conclusion holds for smooth Navier–Stokes approximants with viscosities $\nu_n\downarrow0$, under the identical bounds and (SD). The modifications are recorded after the proof.

For a time-independent scalar $\zeta\in C_c^\infty(\mathbb R^2)$, smooth transport and antisymmetry of $K$ give

\[
\frac d{dt}\int\zeta\,d\omega_n
=\int \nabla\zeta\cdot u_n\,d\omega_n
=\iint H_\zeta(x,y)\,d\omega_n(x)d\omega_n(y).
\]

Thus these pairings are uniformly Lipschitz, with constant at most $M^2\|D^2\zeta\|_\infty/(4\pi)$. Arzelà–Ascoli for a countable dense family of compact smooth tests, followed by uniform approximation and the bound $M$, gives a subsequence and a curve $\omega:[0,T]\to\mathcal M$ such that

\[
\omega_n(t)\rightharpoonup^*\omega(t)
\quad\text{uniformly in (t) against each }f\in C_0(\mathbb R^2),
\qquad \|\omega(t)\|_{\mathcal M}\le M.
\]

Here weak-star means the duality with $C_0$; no uniform tightness is asserted or needed. The limit is weak-star continuous, and $\omega(0)=\omega_0$.

For a compact smooth vector field $f$, the function

\[
F_f(y)=\int K(x-y)\cdot f(x)\,dx
\]

is continuous and tends to zero as $|y|\to\infty$. Local continuity follows from translation continuity of the locally integrable kernel; the tail is bounded by $C_f/|y|$. Consequently $\langle u_n(t),f\rangle=\langle\omega_n(t),F_f\rangle$ converges uniformly in $t$. The bounds $E_R$ identify the distributional limit $u(t)=K*\omega(t)$ as an $L^2(B_R)$ function for every $t$, with norm at most $E_R$. Density of smooth tests in $L^2(B_R)$ and the uniform bound then imply $u\in C_w([0,T];L^2(B_R))$. Distributionally $\operatorname{div}u=0$ and $\operatorname{curl}u=\omega$. This proves the Biot–Savart and measure assertions at every time, rather than only almost everywhere.

### Atomlessness of the limit, including signed measures

Fix $t$ and a point $a$. As $\omega(t)=\operatorname{curl}u(t)$ and $u(t)\in L^2_{\rm loc}$, the measure $\omega(t)$ belongs to $H^{-1}_{\rm loc}$. Choose smooth logarithmic cutoffs $\eta_k$ supported in a fixed ball about $a$ with $0\le\eta_k\le1$, $\eta_k(a)=1$, $\eta_k(x)\to0$ for every $x\ne a$, and $\|\eta_k\|_{H^1}\to0$. For example, before smoothing, let the cutoff be one on $|x-a|\le e^{-k^2}$, zero on $|x-a|\ge e^{-k}$, and affine in $\log|x-a|$ between these radii; its Dirichlet integral is $2\pi/(k^2-k)$. Then

\[
\int\eta_k\,d\omega(t)\longrightarrow0
\quad\text{by }H^{-1}_{\rm loc}\text{ continuity},
\qquad
\int\eta_k\,d\omega(t)\longrightarrow\omega(t)(\{a\})
\quad\text{by dominated convergence against }|\omega(t)|.
\]

Hence $\omega(t)(\{a\})=0$, and also $|\omega(t)|(\{a\})=0$. No claim that the Jordan parts belong to $H^{-1}$ is used.

### Passage to the quadratic form

For fixed $\delta>0$ the off-diagonal kernel $(1-\chi((x-y)/\delta))H_\psi$ is bounded and continuous. It vanishes when both variables lie outside the spatial support of $\nabla\psi$. If one variable is in that support and the other has size at least $R$, its absolute value is at most $C_\psi/R$ for large $R$. The resulting tail contribution is at most $C_\psi M^2/R$, uniformly in $n,t$. After truncating the variables to a compact set, uniform weak-star convergence and approximation of continuous functions of $(x,y)$ by finite sums of product functions show convergence of the double integrals, uniformly in $t$ (or pointwise followed by dominated convergence if the kernel depends on time). Thus the off-diagonal time integrals converge.

For the limit measure, atomlessness gives

\[
\iint_{|x-y|\le2\delta}d|\omega(t)|(x)d|\omega(t)|(y)\longrightarrow0
\quad (\delta\downarrow0)
\]

at every $t$: these sets decrease to the diagonal, whose product measure is $\int|\omega(t)|(\{x\})\,d|\omega(t)|(x)=0$. The bound $M^2$ permits dominated convergence in time. Combining this fact, off-diagonal convergence, and (SD) passes the smooth vorticity identity to

\[
\int_0^T\!\int\partial_t\psi\,d\omega\,dt
+\int_0^T\!\iint H_\psi\,d\omega\,d\omega\,dt
+\int\psi(0)\,d\omega_0=0.
\]

For each fixed nonatomic $\mu\in\mathcal M$ with $K*\mu\in L^2_{\rm loc}$, spatial mollification proves

\[
\tag{I}
\int (K*\mu)\otimes(K*\mu):\nabla(\nabla^\perp\psi)\,dx
=-\iint H_\psi(x,y)\,d\mu(x)d\mu(y).
\]

Indeed the mollified velocity converges strongly in local $L^2$, and the mollified measures have uniform diagonal control because

\[
\sup_x|\rho_\varepsilon*\mu|(B_r(x))
\le \sup_x|\mu|(B_{r+\varepsilon}(x))\longrightarrow0
\quad\text{as }r+\varepsilon\downarrow0.
\]

The final uniform convergence follows for every finite nonatomic measure: otherwise a sequence of shrinking balls with mass bounded below either has centers escaping to infinity, contradicting finite total mass, or has a convergent subsequence, yielding an atom. The same off-diagonal/tail argument just used applies to the mollified double integrals. Identity (I) is elementary for smooth functions, by $(u\cdot\nabla)u=\nabla(|u|^2/2)+\omega u^\perp$ and integration by parts. Its minus sign agrees with $\int u\cdot\nabla^\perp\psi=-\int\psi\,d\omega$.

Every compactly supported divergence-free smooth vector field on $\mathbb R^2$ is $\nabla^\perp\psi$ for a compactly supported smooth scalar $\psi$ after fixing the constant on the unbounded exterior component. Applying (I) converts the limiting identity to the exact velocity weak formulation. The time endpoint follows from the already proved weak continuity and initial measure identity.

For Navier–Stokes, the scalar derivative has the additional term $\nu_n\langle\omega_n,\Delta\zeta\rangle$, bounded by $\nu_nM\|\Delta\zeta\|_\infty$. This preserves equicontinuity because $(\nu_n)$ is bounded. Its time-integrated contribution tends to zero, so all subsequent compactness and limiting steps are unchanged. This extension uses the vorticity residual directly and requires no estimate of $\nu_n\nabla u_n$.

### Necessity within this compactness setup

For any convergent subsequence satisfying the compactness conclusions above, if its limit satisfies Euler, then its full smooth quadratic integrals converge to the limit quadratic integral by the weak formulations and convergence of the linear terms. Subtracting the already convergent off-diagonal terms and then letting $\delta\downarrow0$ gives (SD). Thus (SD) is not merely an arbitrary sufficient regularity requirement: it is the exact remaining nonlinear defect for this subsequence and these tests.

## B. A stronger, unsigned criterion and its missing propagation

The easily checked sufficient condition

\[
\tag{NC}
\lim_{r\downarrow0}\limsup_n\int_0^T
\sup_{x\in\mathbb R^2}|\omega_n(t)|(B_r(x))\,dt=0
\]

implies (SD), because the absolute value of its integral is bounded by

\[
\frac{M}{4\pi}\|D^2\psi\|_\infty
\int_0^T\sup_x|\omega_n(t)|(B_{2\delta}(x))\,dt.
\]

For mollifications of the fixed initial datum, (NC) holds at $t=0$, since the initial datum is nonatomic. This proves no propagation in time. The flow map of a smooth approximant is area preserving, but that controls Lebesgue volume rather than the mass of a singular measure on sets that may be compressed in one direction and elongated in another. Invoking area preservation to propagate (NC) for arbitrary measure data would be an invalid deduction.

## C. Exact counterexample to a spatial compactness shortcut

Let $f\in C_c^\infty(\mathbb R)$ be nonzero and nonconstant, set $\Psi(x)=f(x_1)f(2x_2)$, and put $v=\nabla^\perp\Psi$ and $\zeta=\operatorname{curl}v=\Delta\Psi$. For $\varepsilon\downarrow0$ define

\[
v_\varepsilon(x)=\varepsilon^{-1}v(x/\varepsilon),
\qquad
\zeta_\varepsilon(x)=\varepsilon^{-2}\zeta(x/\varepsilon).
\]

All of these are smooth and compactly supported. They satisfy $\operatorname{div}v_\varepsilon=0$ and $v_\varepsilon=K*\zeta_\varepsilon$ (both sides are divergence-free, have the same curl, decay at infinity, and their difference is harmonic). Moreover,

\[
\|v_\varepsilon\|_2=\|v\|_2,
\quad \|\zeta_\varepsilon\|_{\mathcal M}=\|\zeta\|_1,
\quad \|\zeta_\varepsilon\|_{H^{-1}}\le\|v\|_2,
\quad \int\zeta_\varepsilon=0.
\]

The measure sequence converges weak-star to zero, and the velocities converge weakly to zero in $L^2$, while

\[
v_\varepsilon\otimes v_\varepsilon\rightharpoonup^* A\delta_0,
\qquad A=\int v\otimes v\,dx
=C\begin{pmatrix}2&0\\0&1/2\end{pmatrix},
\quad C=\Bigl(\int f^2\Bigr)\Bigl(\int(f')^2\Bigr)>0.
\]

The zero off-diagonal entry is $-\int ff'\int f(2s)2f'(2s)\,ds=0$. The diagonal entries follow by the substitution $z=2x_2$. Choose a compact divergence-free test vector field equal to $(x_1,-x_2)$ near zero, for example $\varphi=\nabla^\perp[-x_1x_2\eta(x)]$ with $\eta=1$ near zero. Then

\[
\int v_\varepsilon\otimes v_\varepsilon:\nabla\varphi\,dx
\longrightarrow \frac32C\ne0.
\]

This disproves the claim that a uniform signed $H^{-1}$ bound and total variation bound make the Euler quadratic form weakly continuous. It also disproves the claim that atomlessness of the signed limit excludes concentration of the approximating total variations. In fact $|\zeta_\varepsilon|\rightharpoonup^*\|\zeta\|_1\delta_0$.

**Scope limitation.** These are spatial fields, not a sequence of Euler solutions on a fixed time interval with one strongly approximated initial datum. They falsify an a priori spatial lemma, not the target. Euler dynamics might enforce cancellation of the anisotropic part after integration in time; that is precisely (SD).

## D. Primary-source leads inspected, not invoked as theorem certificates

1. S. Schochet, *The weak vorticity formulation of the 2-D Euler equations and concentration-cancellation*, CPDE 20 (1995), 1077–1104, DOI 10.1080/03605309508821124. The publisher abstract says concentration along a Hölder-$1/2$ trajectory suffices for cancellation. The full statement has not yet been obtained, so this is a lead rather than a load-bearing theorem.
2. C. Cheverry and O. Guès, *Counter-examples to Concentration-cancellation*, ARMA 189 (2008), 363–424, DOI 10.1007/s00205-008-0132-6. The inspected publisher abstract establishes failure of local weak-$L^2$ closure through large-amplitude oscillatory solutions. It does **not** state a uniform measure bound on vorticity; it therefore cannot be used to defeat the target compactness class without checking the paper.
3. Ó. Domínguez and D. Spector, *A sparse resolution of the DiPerna–Majda gap problem for 2D Euler equations*, arXiv:2409.02344. Abstract retrieved; full source not yet inspected. Its maximal-vorticity rate criterion is stronger than the bare signed measure assumption. No claimed theorem application in this packet depends on it.

## E. Current route state

- Proved in this packet, pending independent audit: the exact conditional bridge, the unsigned sufficient condition, and the spatial anisotropic-concentration counterexample.
- Earliest unresolved obligation: establish (SD) for at least one global smooth/viscous approximation of every datum in the target class, together with the local energy bounds required above.
- More focused dynamic question: can every anisotropic concentration defect be shown to have zero pairing with compact divergence-free test gradients by exploiting vorticity transport and the finite total variation, even when the positive and negative parts concentrate together?
- Decisive false-lemma test for any proposed purely spatial estimate: apply it to the explicit fields in section C.
- Next executable work: derive local virial identities for shrinking neutral clusters, distinguish isotropic pressure defects from genuine Euler defects, and check precisely which spacetime regularity of concentration paths makes the signed diagonal integral vanish.

## F. Temporal pathology reconstructed directly

Use the anisotropic compact profile $(v,\zeta)$ of section C, put $\varepsilon_n=1/n$, and set on $[0,2\pi]$

\[
a_n(t)=(\sin(nt),0),\qquad
\widetilde\omega_n(t,x)=n^2\zeta(n(x-a_n(t))),\qquad
\widetilde u_n(t,x)=n v(n(x-a_n(t))).
\]

The total variation and $L^2$ velocity norms remain constant. The $H^{-1}$ vorticity norm stays bounded by the velocity norm. Since $\int\zeta=0$, differentiation against a fixed test $\phi\in W^{2,\infty}$ gives

\[
\begin{aligned}
\left|\frac d{dt}\langle\widetilde\omega_n,\phi\rangle\right|
&=\left|a_n'(t)\cdot\int\zeta(z)
   [\nabla\phi(a_n(t)+z/n)-\nabla\phi(a_n(t))],dz\right|\\
&\le \|D^2\phi\|_\infty\int |z|\,|\zeta(z)|\,dz.
\end{aligned}
\]

Thus this sequence has exactly a uniform weak temporal Lipschitz estimate at order two, besides the measure and energy bounds. In fact $\widetilde\omega_n\to0$ uniformly in time against smooth spatial tests, since $\int\zeta=0$. The absolute measures instead approximate $m\delta_{a_n(t)}$, where $m=\|\zeta\|_1$. Their tensor products converge as spacetime measures to

\[
\Gamma_t=m^2\int_{-1}^1\delta_{(s,0)}\otimes\delta_{(s,0)}
\frac{ds}{\pi\sqrt{1-s^2}},
\]

independently of $t$. To prove this, integrate a continuous compact test $F(t,x,y)$. Uniform continuity replaces $x,y$ by $a_n(t)$ with error tending to zero. The oscillatory averaging identity

\[
\int_0^{2\pi}F(t,\sin(nt)e_1,\sin(nt)e_1)\,dt
\longrightarrow
\int_0^{2\pi}\frac1{2\pi}\int_0^{2\pi}
F(t,\sin\theta e_1,\sin\theta e_1)\,d\theta\,dt
\]

follows first for functions constant on a finite time partition, by periodic averaging, and then for all continuous $F$ by uniform approximation. Changing variables in the inner average gives the displayed arcsine measure. This $\Gamma_t$ is diffuse along the spatial diagonal and is not a product measure: its marginal is the non-atomic arcsine law, while the product of that law with itself assigns zero measure to the diagonal.

No subsequence of $|\widetilde\omega_n(t)|$ converges weak-star for almost every $t$. Indeed such convergence, tested against a fixed compact test equal to $x_1$ on the common support, would force a subsequence of $\sin(nt)$ to converge almost everywhere. Boundedness would then imply strong $L^2(0,2\pi)$ convergence. Every subsequence has weak $L^2$ limit zero by orthogonality, whereas every term has squared norm $\pi$, a contradiction.

The stresses converge to the anisotropic matrix $A$ from section C times the same arcsine measure in space and Lebesgue measure in time. A test field equal to $(x_1,-x_2)$ near the entire segment detects its nonzero anisotropic pairing. Thus the sequence is *not* an approximate Euler sequence with vanishing residual. This is an explicit falsification of any attempt to deduce absolute-vorticity temporal compactness or Euler-defect cancellation solely from the usual three a priori spaces.

## G. The quadratic diagonal measure is the correct absolute object

After restricting to a bounded spatial set and extracting, let

\[
dt\,|\omega_n(t)|\otimes|\omega_n(t)|\rightharpoonup^*\Gamma
\]

as measures of $(t,x,y)$. Uniform total variation makes this extraction possible. If $\Gamma$ gives no mass to $\{x=y\}$ in the region relevant to a test, then (SD) follows from the boundedness of $H_\psi$ and the upper semicontinuity bound for closed diagonal tubes. Conversely, the temporal example above shows why a diffuse weak limit of $dt|\omega_n(t)|$ alone does not imply $\Gamma(\{x=y\})=0$.

For a *fixed-time* subsequence with $|\omega_n(t)|\rightharpoonup^*\Omega_t$, the unsigned product limit is $\Omega_t\otimes\Omega_t$, whose diagonal is the countable measure

\[
\sum_{a\in\operatorname{Atoms}(\Omega_t)}
\Omega_t(\{a\})^2\,\delta_{(a,a)}.
\]

This statement concerns the nonlinear Euler defect, not the full scalar kinetic-energy defect. The latter may diffuse even for steady Euler sequences.

Near the diagonal, Taylor's formula refines the residual to an angular second moment:

\[
H_\psi(t,x,y)
=\frac1{4\pi}D^2\psi(t,x):
\frac{(x-y)^\perp\otimes(x-y)+(x-y)\otimes(x-y)^\perp}
     {2|x-y|^2}
+O_\psi(|x-y|).
\]

The error in its integral over $|x-y|\le2\delta$ is at most $C_\psi\delta TM^2$. The angular matrix is symmetric and trace-free. Consequently the unresolved signed diagonal term is an angular quadrupole of cancelling vorticity, rather than the total mass of the diagonal. The scalar signed product can cancel while this angular moment survives, as the anisotropic profile in section C proves.

## H. Checked interface with De Rosa–Park (2026)

Primary source inspected: L. De Rosa and J. Park, *Dissipation Concentration in Two-Dimensional Fluids*, Communications in Mathematical Physics 407, article 137 (2026), DOI 10.1007/s00220-026-05662-w, sections 3 and 7 at the publisher's full-text HTML.

Proposition 7.2 constructs smooth compactly supported divergence-free fields with vorticity $L^1$ norm one and diffuse scalar energy defect. Remark 7.4 permits radial profiles, making the fields stationary Euler solutions and preserving weak Euler closure despite energy noncompactness. Remark 3.7 identifies temporal oscillation as an obstacle to factorizing the absolute-vorticity product. These results confirm the distinctions above; they do not prove (SD) for general evolving data. Section F independently reconstructs the temporal pathology without relying on the cited example.

## I. Conditional cancellation along one Hölder-$1/2$ path

This provides a fully specified dynamic interface, proved here independently of the unavailable full Schochet paper. Keep the smooth Euler or vanishing-viscosity Navier–Stokes hypotheses of section A, and extract the compactness subsequence there. Extract also the positive product measure limit $\Gamma$ from section G. Suppose there is a path $a:[0,T]\to\mathbb R^2$ with

\[
|a(t)-a(s)|\le L|t-s|^{1/2}
\]

such that the restriction of $\Gamma$ to the diagonal $\{x=y\}$ is supported on $\{(t,a(t),a(t)):0\le t\le T\}$. Then the limit is a target solution on this time interval. The diagonal measure need not vanish, and the approximating total variations need not be nonconcentrating.

**Proof.** Extend $a$ constantly outside the interval and mollify it in time at scale $h\downarrow0$. For $r=\sqrt h$, the resulting smooth path satisfies

\[
\|a_h-a\|_\infty\le C Lr,
\qquad \|a_h'\|_\infty\le CL/r.
\]

Fix a constant $c>2CL+2$, and a smooth spatial cutoff $\eta$ equal to one on $B_2$ and zero off $B_3$. For an arbitrary compact smooth scalar test $\psi$, define its affine Taylor polynomial about $a_h(t)$ by

\[
\ell_h(t,x)=\psi(t,a_h(t))+
\nabla\psi(t,a_h(t))\cdot(x-a_h(t)),
\]

and set

\[
g_h(t,x)=\eta\left(\frac{x-a_h(t)}{cr}\right)
       [\psi(t,x)-\ell_h(t,x)],
\qquad \psi_h=\psi-g_h.
\]

Then $\psi_h=\ell_h$ on a neighborhood containing $B_r(a(t))$ for every $t$. Therefore $H_{\psi_h}$ is identically zero when both spatial arguments are sufficiently near the concentration point at that time. Its remaining diagonal discontinuities occur on a set of $\Gamma$-measure zero. More explicitly, split by a diagonal cutoff: on a small tube around the path, the near-diagonal kernel is zero; on the complement its integral is controlled by the mass that $\Gamma$ gives to diagonal tubes off the path, which tends to zero. The off-diagonal convergence from section A thus proves the limiting vorticity identity for every fixed $\psi_h$. The viscous term, if present, tends to zero for fixed $h$.

Taylor's formula and the path bounds give constants independent of $h$ such that

\[
|g_h|\le C_\psi r^2,
\qquad |\nabla g_h|\le C_\psi r,
\qquad |D^2g_h|+|\partial_tg_h|\le C_{\psi,L},
\]

and all these functions vanish outside $|x-a(t)|\le C_Lr$. For the temporal derivative, differentiating the Taylor remainder gives a term bounded by $C r|a_h'|\le C_L$; differentiating the cutoff contributes the same bound. This is the endpoint where the Hölder exponent enters.

Because the limiting $\omega(t)$ is nonatomic at every time,

\[
|\omega(t)|(B_{C_Lr}(a(t)))\longrightarrow0
\quad\text{for every }t.
\]

The bound by $M$ permits dominated convergence in time. Hence the linear temporal error $\int\partial_tg_h\,d\omega\,dt$ tends to zero. The initial error is bounded by $C_\psi r^2M$. Finally, $H_{g_h}$ is uniformly bounded and is zero whenever both points lie outside the shrinking tube, so

\[
\left|\int_0^T\iint H_{g_h}\,d\omega\,d\omega\,dt\right|
\le C_{\psi,L}M\int_0^T
|\omega(t)|(B_{C_Lr}(a(t)))\,dt\longrightarrow0.
\]

Thus the limiting identity for $\psi_h$ passes to the one for $\psi$. Section A converts it to the required velocity identity. This proves the conditional assertion.

**Scope of this progress.** A priori weak temporal Lipschitz continuity of the *signed* vorticity has not been shown to produce such a concentration path; section F proves that the available kinematic bounds alone cannot do so. For a path with only Hölder exponent $\alpha<1/2$, the same construction at spatial scale $r=h^\alpha$ gives $|\partial_tg_h|=O(h^{2\alpha-1})$. Atomlessness without a quantitative rate does not make that error vanish. A weighted mass-decay hypothesis could compensate for this factor, but none is established for the target class.
