# Affine transport of radial neutral vorticity

STATUS: new self-contained lemma packet; independent audit required before acceptance.

This packet isolates a local cancellation mechanism. It does not assert that arbitrary signed vorticity can be decomposed into these profiles, or that an Euler flow preserves the needed geometry.

## 1. Definitions and exact invariants

Let \(J=\begin{pmatrix}0&-1\\1&0\end{pmatrix}\), so \(K(x)=Jx/(2\pi|x|^2)\).
For \(z\neq0\), define

\[
S(z)=\frac{Jz\otimes z+z\otimes Jz}{2|z|^2},
\qquad S(0)=0.
\]

This matrix is symmetric, trace-free, even, homogeneous of degree zero, and has Frobenius norm \(1/\sqrt2\).
For any finite atomless signed measure \(\mu\), put

\[
Q(\mu)=\iint S(x-y)\,d\mu(x)d\mu(y).
\]

The integral is absolutely bounded against \(|\mu|\otimes|\mu|\), and its diagonal value is irrelevant.
The total variation bound is
\(\|Q(\mu)\|_F\leq\|\mu\|_{\mathcal M}^2/\sqrt2\).

For \(z/|z|=(\cos\theta,\sin\theta)\),

\[
S(z)=\frac12\begin{pmatrix}
-\sin2\theta&\cos2\theta\\
\cos2\theta&\sin2\theta
\end{pmatrix}.
\]

Equivalently, if
\(b_2(\mu)=\iint e^{2i\arg(x-y)}d\mu(x)d\mu(y)\), then

\[
Q(\mu)=\frac12\begin{pmatrix}
-\operatorname{Im}b_2&\operatorname{Re}b_2\\
\operatorname{Re}b_2&\operatorname{Im}b_2
\end{pmatrix},
\qquad \|Q(\mu)\|_F=|b_2(\mu)|/\sqrt2.
\]

Thus the relevant quantity is exactly the second angular Fourier coefficient of the signed pair-separation measure, not the absolute diagonal mass.

### Proposition 1: affine neutral cancellation

Let \(\mu\) be a finite atomless signed measure, invariant under all rotations about a point \(c\), and satisfying \(\mu(\mathbb R^2)=0\).
For every invertible real matrix \(A\) and every \(b\in\mathbb R^2\), define \(Y(x)=b+A(x-c)\).
Then

\[
\boxed{Q(Y_\#\mu)=0.}
\]

No area-preservation assumption \(\det A=1\) is necessary.

**Proof.** Translation does not affect the pair differences, so assume \(c=b=0\).
Let \(\lambda\) be the pushforward of \(\mu\otimes\mu\) under \((x,y)\mapsto x-y\).
This is a finite signed rotationally invariant measure, of total mass \(\mu(\mathbb R^2)^2=0\).
It has no atom at zero, because

\[
|\mu|\otimes|\mu|(\{x=y\})
=\int |\mu|(\{x\})\,d|\mu|(x)=0.
\]

Rotational invariance and Fubini give

\[
Q(A_\#\mu)
=\int S(Az)\,d\lambda(z)
=\int\left[\frac1{2\pi}\int_0^{2\pi}S(AR_\theta z)\,d\theta\right]d\lambda(z).
\]

For every \(z\neq0\), the bracket is the same matrix, denoted by \(B_A\): rotations remove the direction of \(z\), and degree-zero homogeneity removes its length.
Since \(\lambda(\{0\})=0\) and \(\lambda(\mathbb R^2)=0\), the result is \(B_A\lambda(\mathbb R^2)=0\). \(\square\)

**Necessary scope restrictions.** Neutrality is essential: without it, the same calculation gives
\(Q(A_\#\mu)=\mu(\mathbb R^2)^2B_A\).
Atomlessness cannot simply be dropped, because the signed pair measure can then charge the point zero.
Radiality is essential; the anisotropic compact stream profile in `route_signed_compactness.md`, section C, is a neutral counterexample for \(A=I\).

### Proposition 2: exact finite-energy and integrated-stress invariance

Let \(\mu\in\mathcal M(\mathbb R^2)\) be radial about \(c\) and assume \(u=K*\mu\in L^2(\mathbb R^2)\).
Then \(\mu\) is neutral and atomless, and for every invertible affine map \(Y\) as above,

\[
\boxed{
\|K*(Y_\#\mu)\|_2^2=\|K*\mu\|_2^2,
\qquad
\int (K*(Y_\#\mu))\otimes(K*(Y_\#\mu))\,dx
=\frac12\|K*\mu\|_2^2I.}
\]

In particular, the whole integrated stress is isotropic and independent of \(A\).
Compact support is not needed for this proposition.

**Proof.** Use \(\widehat f(\xi)=\int e^{-ix\cdot\xi}f(x)dx\).
After translating the center to zero, rotational invariance gives \(\widehat\mu(\xi)=f(|\xi|)\) for a bounded continuous scalar function \(f\).
The Fourier identity for the canonical Biot–Savart convolution and Plancherel give

\[
\|K*\mu\|_2^2
=\frac1{2\pi}\int_0^\infty|f(r)|^2\frac{dr}{r}<\infty.
\]

Continuity at zero forces \(f(0)=0\), proving neutrality.
Atomlessness follows from \(\mu=\operatorname{curl}u\in H^{-1}_{\mathrm{loc}}\) by the logarithmic cutoff argument.

For the affine pushforward, the Fourier transform is \(e^{-ib\cdot\xi}f(|A^T\xi|)\), apart from the irrelevant original-center phase.
Writing \(\vartheta=(\cos\theta,\sin\theta)\), Tonelli gives

\[
\begin{aligned}
\|K*(Y_\#\mu)\|_2^2
&=\frac1{(2\pi)^2}\int_0^{2\pi}\int_0^\infty
 |f(r|A^T\vartheta|)|^2\frac{dr}{r}\,d\theta\\
&=\frac1{2\pi}\int_0^\infty|f(s)|^2\frac{ds}{s}.
\end{aligned}
\]

For each angle, invertibility ensures \(|A^T\vartheta|>0\), and the substitution \(s=r|A^T\vartheta|\) preserves \(dr/r\).
This proves the energy identity and also proves that the transformed canonical velocity belongs to \(L^2\).
For its stress tensor, the same calculation leaves the directional factor \(J\vartheta\otimes J\vartheta\), so

\[
\int u_Y\otimes u_Y\,dx
=\frac1{(2\pi)^2}
\left(\int_0^\infty|f(s)|^2\frac{ds}{s}\right)
\int_0^{2\pi}J\vartheta\otimes J\vartheta\,d\theta
=\frac12\|u\|_2^2I.
\]

The component integrals are absolutely dominated by the finite energy integral, justifying these operations. \(\square\)

For compactly supported radial neutral \(\mu\in\mathcal M\cap H^{-1}\), the finite-energy hypothesis follows automatically: \(\widehat\mu(\xi)=O(|\xi|)\) at zero by the finite first moment, and the inhomogeneous \(H^{-1}\) bound handles high frequencies.

## 2. Quantitative stability under nearly affine geometry

### Proposition 3: angular stability

Let \(\mu\) satisfy Proposition 1, write \(M=\|\mu\|_{\mathcal M}\), and let \(X\) be a continuous map on its support.
Suppose an invertible matrix \(A\) satisfies

\[
|X(x)-X(y)-A(x-y)|\leq\varepsilon|A(x-y)|
\quad\text{for all }x,y\in\operatorname{supp}\mu,
\qquad 0\leq\varepsilon<1.
\tag{NA}
\]

Then \(X\) is injective on the support and

\[
\boxed{\|Q(X_\#\mu)\|_F\leq4\varepsilon M^2.}
\]

**Proof.** For \(v\neq0\) and \(w\neq0\) with \(|w-v|\leq\varepsilon|v|\),

\[
\left|\frac w{|w|}-\frac v{|v|}\right|\leq2\varepsilon.
\]

The map \(q\mapsto(Jq\otimes q+q\otimes Jq)/2\) on unit vectors satisfies a Frobenius Lipschitz bound with constant two, by expanding the tensor difference.
Therefore \(\|S(w)-S(v)\|_F\leq4\varepsilon\).
Apply this pointwise with \(v=A(x-y)\), \(w=X(x)-X(y)\), integrate against \(|\mu|\otimes|\mu|\), and use Proposition 1. \(\square\)

### Corollary 4: explicit C² condition

Suppose \(\operatorname{supp}\mu\subset\overline B(c,r)\), and \(X\) is \(C^2\) on a neighborhood of that ball.
Let

\[
A=DX(c),\quad s=\sigma_{\min}(A)>0,\quad
L=\sup_{B(c,r)}\|D^2X\|.
\]

The fundamental theorem of calculus along the line segment from \(y\) to \(x\) gives

\[
|X(x)-X(y)-A(x-y)|\leq rL|x-y|
\leq\frac{rL}{s}|A(x-y)|.
\]

Thus \(\varepsilon=rL/s\) is a sufficient relative-distortion bound.
If \(X\) is already known to be injective, the trivial bound on \(Q\) handles the large-distortion case, yielding the universally valid estimate

\[
\boxed{\|Q(X_\#\mu)\|_F
\leq4M^2\min\left\{1,\frac{rL}{s}\right\}.}
\tag{QC}
\]

The sufficient smallness quantity is \(rL/s\), not \(rL\) alone.
Equivalently it is \(\kappa(A)\,rL/\|A\|\), where \(\kappa(A)=\|A\|/\sigma_{\min}(A)\).
Strong anisotropic strain can amplify curvature relative to the contracting direction.

### Proposition 5: energy stability without assuming finite Jordan-part energy

Let \(\mu\in\mathcal M\cap H^{-1}\) have compact support, total mass zero, and total variation \(M\).
Let \(X\) be a \(C^2\) diffeomorphism on a neighborhood of a closed ball containing the support in its interior.
Let \(Y(x)=b+A(x-c)\), with \(A\) invertible.
Assume (NA) holds throughout that ball, with \(0\leq\varepsilon<1\).
Then both pushed-forward canonical velocities have finite global energy and

\[
\begin{aligned}
\|K*(X_\#\mu)\|_2^2-\|K*(Y_\#\mu)\|_2^2
&=-\frac1{2\pi}\iint
\log\frac{|X(x)-X(y)|}{|A(x-y)|}\,d\mu(x)d\mu(y),\\
\left|\|K*(X_\#\mu)\|_2^2-\|K*(Y_\#\mu)\|_2^2\right|
&\leq\frac{M^2}{2\pi}\bigl[-\log(1-\varepsilon)\bigr].
\end{aligned}
\tag{ED}
\]

The logarithmic ratio is assigned any value on the diagonal.
It is bounded in absolute value by \(-\log(1-\varepsilon)\), so the right side is an absolutely defined signed-measure integral.
For \(\varepsilon\leq1/2\), the last bound is at most \(M^2\varepsilon/\pi\).
When \(\mu\) is radial, Proposition 2 replaces the reference affine energy by \(\|K*\mu\|_2^2\).

**Proof, including the signed-energy issue.** A \(C^1\) diffeomorphism on a neighborhood of the compact support maps \(H^{-1}\) distributions with that support continuously into \(H^{-1}\): pair a test with its composition with the diffeomorphism, multiply by a fixed cutoff near the original support, and use change of variables to bound the resulting \(H^1\) norm.
All constants are finite on the chosen compact neighborhood because the Jacobian is bounded above and away from zero.
Both pushforwards are thus compactly supported, zero-mass \(H^{-1}\) measures, implying finite global velocity energy by the low/high frequency split noted after Proposition 2.

Mollify \(\mu\) by compactly supported smooth kernels to obtain \(\mu_k\), with support remaining in the chosen neighborhood, zero total mass, TV at most \(M\), and \(\mu_k\to\mu\) strongly in \(H^{-1}\).
Composition continuity gives strong \(H^{-1}\) convergence after either pushforward.
The corresponding velocities converge strongly in global \(L^2\): for their signed differences \(\nu_k\), the uniform compact support and TV give \(|\widehat\nu_k(\xi)|\leq C|\xi|\), hence the low-frequency energy below \(\delta\) is at most \(C\delta^2\); above \(\delta\), strong \(H^{-1}\) convergence gives convergence of the Biot–Savart energy.

For the bounded compact densities \(\mu_k\) and their diffeomorphic images, integration by parts for the stream function is legitimate and yields

\[
\|K*\nu\|_2^2
=-\frac1{2\pi}\iint\log|x-y|\,d\nu(x)d\nu(y).
\]

Subtract this identity for \(X_\#\mu_k\) and \(Y_\#\mu_k\); changing variables produces the logarithmic ratio in (ED).
This subtraction is performed before passage to the limit, avoiding an unjustified separate logarithmic-energy integral for the Jordan parts of \(\mu\).

The ratio kernel is continuous off the diagonal and uniformly bounded.
Because \(\mu\) is atomless, its mollifications satisfy
\(\sup_x|\mu_k|(B_\delta(x))\leq\sup_x|\mu|(B_{\delta+\epsilon_k}(x))\to0\) as \(\delta+\epsilon_k\to0\).
Consequently, the near-diagonal integral is uniformly negligible; off the diagonal, weak-* product convergence applies on the common compact support.
The ratio integrals therefore converge to the asserted one, while the velocity energies converge by the preceding strong \(L^2\) statement.
The bound follows directly from (NA). \(\square\)

## 3. Which norm of a nearly radial profile is sufficient?

For finite atomless signed measures \(\mu,\nu\), the algebraic identity
\(\mu\otimes\mu-\nu\otimes\nu=(\mu-\nu)\otimes\mu+\nu\otimes(\mu-\nu)\)
gives

\[
\|Q(\mu)-Q(\nu)\|_F
\leq\frac{\|\mu\|_{\mathcal M}+\|\nu\|_{\mathcal M}}{\sqrt2}
\|\mu-\nu\|_{\mathcal M}.
\tag{TVQ}
\]

The same bound holds after a common injective pushforward, because total variation is preserved.
Thus total-variation proximity to a radial neutral profile, combined with near-affine transport of that profile, controls the angular quadrupole.
More precisely, if \(\nu\) is radial neutral, \(X\) satisfies (NA) on its support, and is injective on both supports, then

\[
\|Q(X_\#\mu)\|_F
\leq4\varepsilon\|\nu\|_{\mathcal M}^2
 +\frac{\|\mu\|_{\mathcal M}+\|\nu\|_{\mathcal M}}{\sqrt2}
  \|\mu-\nu\|_{\mathcal M}.
\]

This is sufficient, not necessary: only the second angular coefficient \(b_2\) needs to be small.
Small TV distance alone does not control kinetic energy; a very small circulation can be concentrated at an exponentially smaller core radius and carry large finite energy.
For velocity-energy proximity to a radial reference one instead has the standard strong-energy estimate

\[
\left\|\int u\otimes u-\int v\otimes v\right\|_F
\leq(\|u\|_2+\|v\|_2)\|u-v\|_2,
\]

so strong \(\dot H^{-1}\) proximity of the vorticities is a sufficient norm condition for integrated-stress proximity.
Weak \(H^{-1}\) convergence and bounded TV do not suffice, as the explicitly anisotropic neutral profile shows.

## 4. Consequence for a shrinking transported cluster

Suppose \(\mu_t=X_t{}_{\#}\nu\), where \(\nu\) is radial, neutral, atomless, supported in \(B(c,r)\), and has TV \(M\).
Assume \(X_t\) is a \(C^2\) diffeomorphism on the ball, and write

\[
D_t=\sup_{x\in\operatorname{supp}\nu}|X_t(x)-X_t(c)|,
\qquad
e_t=\min\left\{1,
\frac{r\sup_{B(c,r)}\|D^2X_t\|}{\sigma_{\min}(DX_t(c))}\right\}.
\]

For every compact smooth scalar test \(\psi\), expanding its Hessian at \(X_t(c)\) gives

\[
\iint H_\psi(t,x,y)\,d\mu_t(x)d\mu_t(y)
=\frac1{4\pi}D^2\psi(t,X_t(c)):Q(\mu_t)+\mathcal R_t,
\]

where

\[
|\mathcal R_t|\leq\frac{M^2D_t}{4\pi}
 [D^2\psi(t)]_{\mathrm{Lip},F}.
\]

Here the segment between any two support points stays within their enclosing ball, so Hessian variation is bounded by \(D_t\) times the displayed Lipschitz seminorm.
Combining with (QC),

\[
\left|\int_0^T\iint H_\psi\,d\mu_t d\mu_t\,dt\right|
\leq C_\psi M^2\int_0^T(e_t+D_t)\,dt.
\tag{TC}
\]

Therefore a sequence of such isolated clusters has vanishing signed nonlinear contribution whenever \(M\) is uniformly bounded and

\[
\int_0^T(e_{n,t}+D_{n,t})\,dt\longrightarrow0.
\]

This also gives the corresponding diagonal-cutoff condition: for fixed cutoff radius \(\delta\), the cutoff equals one whenever \(2D_{n,t}\leq\delta\); the exceptional time set has measure at most \((2/\delta)\int D_{n,t}dt\).
The uniformly bounded kernel controls its error, after which (TC) applies.

**Scope:** this treats the self-interaction of an isolated cluster. Cross interactions between different clusters and a decomposition of arbitrary evolving data into these clusters have not been proved here.

### A sufficient flow estimate

If \(X_t\) is the flow of a spatially \(C^2\) divergence-free velocity \(w\), let
\(b(t)=\|Dw(t)\|_\infty\), \(c(t)=\|D^2w(t)\|_\infty\), and \(B(t)=\int_0^t b(s)ds\), assuming these bounds are finite on the relevant region and interval.
Differentiating the flow equation gives

\[
\|DX_t\|\leq e^{B(t)},\qquad
\sigma_{\min}(DX_t)\geq e^{-B(t)},\qquad
\|D^2X_t\|\leq e^{B(t)}\int_0^t c(s)e^{B(s)}ds.
\]

The last inequality follows from
\(\partial_tD^2X=(Dw\circ X)D^2X+(D^2w\circ X)[DX,DX]\)
and variation of constants.
Consequently,

\[
D_t\leq r e^{B(t)},\qquad
e_t\leq\min\left\{1,
r e^{2B(t)}\int_0^t c(s)e^{B(s)}ds\right\}.
\]

These estimates provide an explicit sufficient cumulative condition through (TC).
When \(w\) is exactly affine, \(c=0\) and the cancellation is exact regardless of the condition number.
For the general measure-data approximation problem, neither the relevant gradient-curvature norms nor these cumulative bounds are controlled by the known TV and kinetic-energy estimates.
Moreover, a radial blob's own differential rotation can make its flow map highly non-affine while leaving the vorticity radial, so near-affinity is a sufficient geometric criterion rather than a necessary one.

## 5. Arbitrary area-preserving transport does not preserve this cancellation

The following exact example prevents an overstatement of the preceding results.
Let \(\sigma_R\) be uniform probability arclength measure on the circle \(|x|=R\), and take

\[
\mu=a\sigma_1-a\sigma_{10},\qquad a>0.
\]

This is radial, neutral, compact, and atomless.
Its velocity is \(a e_\theta/(2\pi r)\) for \(1<r<10\), and zero inside the inner circle and outside the outer circle.
Thus

\[
\|K*\mu\|_2^2=\frac{a^2}{2\pi}\log10,
\qquad \mu\in H^{-1}.
\]

Choose a smooth radial cutoff \(\eta\) equal to one on \(B_3\) and zero off \(B_4\), and let
\(w=\nabla^\perp(-x_1x_2\eta)\).
Its smooth global flow is area preserving.
On \(B_3\), the velocity is \((x_1,-x_2)\).
For \(0\leq t\leq\log2\), the inner circle therefore evolves exactly under
\(A_t=\operatorname{diag}(e^t,e^{-t})\), remaining inside \(B_2\), while the outer circle is fixed.
At \(t=\log2\), the transported measure is

\[
\mu_*=aA_\#\sigma_1-a\sigma_{10},
\qquad A=\operatorname{diag}(2,1/2).
\]

For a nonneutral radial measure of mass \(a\), the proof of Proposition 1 gives its affine quadrupole as \(a^2B_A\).
For \(A=\operatorname{diag}(\lambda,\lambda^{-1})\), write
\(\alpha=(\lambda+\lambda^{-1})/2\), \(\beta=(\lambda-\lambda^{-1})/2\).
Using complex notation and \(z=e^{i\theta}\),

\[
e^{2i\arg(Ae^{i\theta})}
=\frac{\alpha z^2+\beta}{\alpha+\beta z^2}.
\]

Since \(|\beta/\alpha|<1\), expansion into a uniformly convergent geometric series shows that its angular mean is \(\beta/\alpha\).
For \(\lambda=2\), this mean is \(3/5\), so the inner self-pair contribution to \(Q\) is
\(\frac{3a^2}{10}\begin{pmatrix}0&1\\1&0\end{pmatrix}\).
The outer self contribution vanishes by radiality.
The cross contribution also vanishes: for any complex \(x\) with \(|x|<R\),

\[
\frac1{2\pi}\int_0^{2\pi}
\frac{x-Re^{i\theta}}{\bar x-Re^{-i\theta}}\,d\theta=0.
\]

Indeed the integrand equals
\(e^{2i\theta}(1-(x/R)e^{-i\theta})/(1-(\bar x/R)e^{i\theta})\),
whose geometric expansion contains only strictly positive Fourier modes.
Every point of the inner ellipse lies inside the outer circle, so this identity applies pointwise to the cross interaction.
Therefore

\[
\boxed{Q(\mu_*)=
\frac{3a^2}{10}\begin{pmatrix}0&1\\1&0\end{pmatrix}\neq0.}
\]

The transported velocity energy changes as well:

\[
\boxed{\|K*\mu_*\|_2^2-\|K*\mu\|_2^2
=-\frac{a^2}{2\pi}\log\frac54.}
\]

To verify the last formula, the outer-circle logarithmic potential is constant \(\log10\) throughout the inner ellipse, so the cross logarithmic interaction is unchanged.
Only the inner self-interaction changes.
Its radial pair-separation distribution gives the change
\(a^2(2\pi)^{-1}\int\log|Ae^{i\theta}|d\theta=a^2\log\alpha\).
The mean is \(\log\alpha\) because
\(|Ae^{i\theta}|=\alpha|1+(\beta/\alpha)e^{-2i\theta}|\),
and the logarithm of the second factor has zero angular mean by its absolutely convergent Fourier expansion.
Multiplying by the kinetic-energy factor \(-1/(2\pi)\) gives the result.
All circle logarithmic self-integrals are finite, so no signed-energy ambiguity is present in this example.

This is a prescribed transport flow, **not** the Euler velocity generated by \(\mu_t\).
It proves exactly that smooth incompressibility or area preservation alone does not propagate the special angular cancellation.
It does not prove that an Euler solution can create the same defect.

## 6. Verification packet and route disposition

- **Exact new facts proposed:** affine invariance of radial neutral quadrupoles; affine invariance of their full finite energy and isotropic integrated stress; relative-geometric distortion bounds; an explicit nonlinear incompressible-transport counterexample.
- **Hypotheses retained:** radiality, neutrality, atomlessness where angular pairs are used; global finite energy for Fourier stress; compact support, \(H^{-1}\), and a local diffeomorphism for the energy-difference extension.
- **External theorem dependencies:** Fourier transform/Plancherel, elementary measure pushforward and Fubini, smooth ODE flow differentiation, and elementary Sobolev composition on a compact diffeomorphism chart. No research-paper theorem is required.
- **Fragile interface checked explicitly:** the logarithmic ratio is subtracted before passing to signed measures; individual Jordan logarithmic energies are never assumed finite.
- **No target resolution:** no decomposition theorem, no uniform near-affinity for general Euler approximants, and no control of all intercluster interactions is established.
- **Next falsifiable obligation:** identify an actual approximation scheme in which the self-interaction of every concentrating signed cluster has either the affine-radial structure or a vanishing second angular coefficient, with a controlled interaction remainder.
- **Independent verification:** pending.
