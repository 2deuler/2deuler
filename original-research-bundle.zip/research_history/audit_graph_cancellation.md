# Independent hostile audit: graph-supported stress cancellation

## Frozen source and provenance

Source: `route_primary_interfaces.md`, Section 3, lines 84--147 of the
snapshot read for this audit.

Full-file SHA-256:
`f93b6be01d44afb499a6e154d96ed641df136c42fb459aa5ac4ca673373cfe70`.

Exact Section 3 byte-range SHA-256 (4,738 UTF-8 bytes, beginning with
`## 3. Verification packet:` and ending immediately before `## 4. Route record`):
`bcd690c89cee83389fdbdcbae644504a70af026c3cce1d0225d486cbdc373582`.

VERIFICATION_MODE_AND_PROVENANCE: One independent mathematical reconstruction
and hostile edge-case pass by a worker not responsible for the candidate.
The source was read without adopting its verdict. This is not a formal proof
certificate and is not the four-pass manuscript audit prescribed for a final
resolution.

VERDICT: **PASS** for the exact Section 3 conditional lemma.

CRITICAL_ERRORS: None found.

GAPS: None material in the stated conditional lemma.

REFERENCE_AND_PREDECESSOR_CHECKS: The proof is self-contained and does not
depend on the unverified Schochet theorem interface or on any primary-source
claims elsewhere in the file.

## Independent reconstruction and edge checks

Fix a compact time interval containing the support of the temporal test.
Mollifying a locally one-half-Hölder path at time scale \(\varepsilon^2\)
gives a smooth path \(b_\varepsilon\) with
\[
 \|b_\varepsilon-a\|_\infty\leq C\varepsilon,
 \|b_\varepsilon'\|_\infty\leq C\varepsilon^{-1}.
\]
Constant extension beyond the time interval preserves the needed local
Hölder bound and does not alter the path near the test support for small
\(\varepsilon\).

For every trace-free matrix \(P\), let
\(J=\begin{psmallmatrix}0&-1\\1&0\end{psmallmatrix}\) and
\(H=-JP\). Writing
\(P=\begin{psmallmatrix}p&q\\r&-p\end{psmallmatrix}\) gives
\(H=\begin{psmallmatrix}r&-p\\-p&-q\end{psmallmatrix}\), so \(H\)
is symmetric without needing \(P\) symmetric. A compact stream function
equal to \(z^THz/2\) on a sufficiently large ball produces a compactly
supported divergence-free \(\Phi\) equal to \(Pz\) on that ball. Thus
\[
 \varphi_\varepsilon(t,x)
 =\varepsilon\chi(t)\Phi((x-b_\varepsilon(t))/\varepsilon)
\]
is an admissible smooth test, with uniformly bounded spatial gradient and
\(\nabla_x\varphi_\varepsilon(t,a(t))=\chi(t)P\) exactly.

The support and all derivative supports lie in a fixed compact set and in a
shrinking tube around the graph. Each spatial section of the graph is a
singleton, hence the graph has zero space-time Lebesgue measure by Fubini.
Therefore the \(L^2\) mass of \(u\) in the tube tends to zero. The temporal
derivative has a translation contribution with norm bounded by
\[
 C\varepsilon\|b_\varepsilon'\|_{L^2_t}\leq C;
\]
the contribution involving \(\chi'\) is \(O(\varepsilon^2)\). Their
pairing with \(u\) tends to zero. The quadratic velocity term is bounded
by the velocity energy in the same tube and also tends to zero.

Pointwise, the spatial test gradient converges to \(\chi P\) on the graph
and to zero at every point off it. Bounded convergence against the finite
total variation of the stress on the fixed compact set extracts exactly the
restriction of the stress to the graph. Its contraction with every
trace-free \(P\), against every \(\chi\), is zero. Projection of the
continuous graph onto the time axis is a Borel isomorphism, so this is a
measure identity, not merely a global integral identity. The annihilator of
all trace-free matrices is the scalar matrices.

Specific hostile checks:

| Issue | Result |
|---|---|
| Endpoint Hölder exponent \(1/2\) | Included. Only boundedness of the temporal derivative test is needed; the shrinking-tube \(L^2\) mass supplies the vanishing factor. |
| Arbitrary locally finite stress | Allowed. Positivity is never used; total variation gives dominated convergence. |
| Stress with atoms in time | Allowed. The pointwise gradient identity holds at every time, including atoms. The velocity terms are estimated with Lebesgue integration independently. |
| Intersections of countably many graphs | Harmless. Restrict each graph to its complement in earlier graphs and use countable additivity on disjoint Borel pieces. |
| Antisymmetric trace-free test matrices | Admissible because \(-JP\) remains symmetric for every trace-free \(P\). |
| Spatial or time infinity | Irrelevant after fixing a compact test support. No global energy or stress norm is silently used. |
| Initial-time trace | Not proved by this interior-time lemma; the source correctly records this limitation. |

REPAIR_INSTRUCTIONS: No mathematical repair is required. A stronger useful
corollary can be added as follows.

## Only the deviatoric stress needs graph support

Let \(D=R-\tfrac12(\operatorname{tr}R)I\). Suppose only \(D\), rather
than all of \(R\), is carried by a countable union of the stated graphs.
For every divergence-free test, its gradient annihilates the scalar part of
\(R\), so the Euler--Reynolds identity may be written with \(D\). The
lemma makes each graph restriction of \(D\) isotropic. Since \(D\) is
trace-free, each restriction is zero. The disjoint-piece argument yields
\(D=0\). The remaining scalar stress has no effect on Euler. No support
assumption on \(\operatorname{tr}R\) is necessary.

## Extension A: an exact variable-radius approximation criterion

The following extension was derived in this audit; it needs its own
independent verification before acceptance as a project theorem.

**Claim A.** Keep the Euler--Reynolds and local \(L^2\) hypotheses. Let
\(a:I\to\mathbb R^2\) be continuous. Suppose that on every compact time
interval relevant to a test there are smooth centers \(b_n\) and smooth
positive radii \(r_n\) such that
\[
 \|r_n\|_\infty\to0,\qquad
 |a(t)-b_n(t)|\leq C r_n(t),\qquad
 \sup_n\int r_n(t)^2\bigl(|b_n'(t)|^2+|r_n'(t)|^2\bigr)dt<\infty.
                                                        \tag{A.1}
\]
Then the stress restricted to \(\Gamma_a\) is isotropic.

**Proof.** Choose the compact divergence-free \(\Phi\) above equal to
\(Pz\) on \(|z|\leq C+1\), and use
\[
 \varphi_n(t,x)=r_n(t)\chi(t)
            \Phi((x-b_n(t))/r_n(t)).
\]
Writing \(z=(x-b_n)/r_n\),
\[
 \partial_t\varphi_n
 =r_n\chi'\Phi
  +\chi r_n'[\Phi-(z\cdot\nabla)\Phi]
  -\chi(b_n'\cdot\nabla)\Phi.
\]
The spatial change of variables contributes the factor \(r_n^2\), so
\[
 \|\partial_t\varphi_n\|_2^2
 \leq C\int
 [r_n^4|\chi'|^2+r_n^2|r_n'|^2|\chi|^2
                     +r_n^2|b_n'|^2|\chi|^2]dt.
\]
This is bounded by (A.1). The supports shrink to the graph, the gradients
are uniformly bounded, and their values on the graph are exactly \(\chi P\).
All remaining steps of the independently verified proof apply. \(\square\)

Condition (A.1) is sufficient; necessity is not asserted. The radii may vary
with time, which improves the Sobolev range below.

## Extension B: an explicit local-oscillation criterion

For a continuous path on a slightly enlarged compact interval, define
\[
 O_\delta(t)=\operatorname{osc}_{[t-\delta,t+\delta]}a
 =\sup_{s_1,s_2\in[t-\delta,t+\delta]}|a(s_1)-a(s_2)|.
\]
It is enough that, along a sequence \(\delta_n\downarrow0\),
\[
 \delta_n^{-2}\int O_{C\delta_n}(t)^4dt\leq C_0               \tag{B.1}
\]
for a fixed numerical enlargement \(C\) (for example \(C=4\)).

To verify this, fix a nonnegative smooth time mollifier \(\eta\), supported
in \([-1,1]\), of integral one. Let
\[
 b_\delta=\eta_\delta*a,\qquad
 r_\delta=\eta_\delta*O_{2\delta}+\delta.
\]
If \(|h|\leq\delta\), the interval centered at \(t-h\) with radius
\(2\delta\) contains the interval centered at \(t\) with radius
\(\delta\). Therefore
\[
 r_\delta(t)\geq O_\delta(t),\qquad
 |a(t)-b_\delta(t)|\leq O_\delta(t).
\]
Also
\[
 r_\delta(t)\leq O_{3\delta}(t)+\delta,
 \quad |b_\delta'(t)|\leq C\delta^{-1}O_\delta(t),
 \quad |r_\delta'(t)|\leq C\delta^{-1}O_{3\delta}(t).
\]
The last inequality follows by differentiating the convolution, bounding
\(O_{2\delta}(t-h)\) by \(O_{3\delta}(t)\), and using the
\(L^1\) norm of \(\eta_\delta'\). Consequently
\[
 \int r_\delta^2(|b_\delta'|^2+|r_\delta'|^2)
 \leq C\delta^{-2}\int O_{3\delta}^4+C\int O_{3\delta}^2.
\]
The second term is bounded; the first is controlled by (B.1). Uniform
continuity gives \(\|r_\delta\|_\infty\to0\). Thus Claim A applies.

## Extension C: rigorous Sobolev ranges without a time-marginal assumption

For \(0<s<1\), \(1<p<\infty\), \(sp>1\), let
\(a\in W^{s,p}_{\rm loc}(I;\mathbb R^2)\) have its continuous
representative. Then criterion (B.1) holds if
\[
 s\geq\max\left\{\frac12,\frac14+\frac1p\right\}.       \tag{C.1}
\]
The endpoint \(a\in W^{1,4/3}_{\rm loc}\), and more generally
\(a\in W^{1,p}_{\rm loc}\) for \(p\geq4/3\), also satisfies the
criterion. These are sufficient ranges, not claimed optimal.

Here are explicit estimates. For a local interval \(I_\delta(t)\) of
length comparable to \(\delta\), put
\[
 E_\delta(t)=\iint_{I_\delta(t)^2}
   \frac{|a(x)-a(y)|^p}{|x-y|^{1+sp}}dxdy.
\]
The elementary fractional Morrey estimate gives
\[
 O_{C\delta}(t)\leq C\delta^{s-1/p}E_\delta(t)^{1/p}.
                                                        \tag{C.2}
\]
For completeness, compare averages on nested half-length intervals around
each point. Each consecutive difference of averages is bounded by the local
Gagliardo seminorm times \((2^{-k}\delta)^{s-1/p}\), by Hölder and
\(|x-y|\leq C2^{-k}\delta\). Summing the geometric series, which
converges because \(s-1/p>0\), bounds the difference from the interval
average at every point of the continuous representative. Applying this to
two points gives (C.2).

On a fixed enlarged interval, Fubini gives
\(\int E_\delta(t)dt\leq C\delta[a]_{W^{s,p}}^p\), and
\(\sup E_\delta\leq[a]_{W^{s,p}}^p\). If \(p\leq4\), use the
latter bound for the excess power \(4/p-1\); if \(p\geq4\), use
Hölder in time. Thus
\[
 \int O_{C\delta}^4dt\leq
 \begin{cases}
 C\delta^{4s-4/p+1}[a]_{W^{s,p}}^4,&1<p\leq4,\\
 C\delta^{4s}[a]_{W^{s,p}}^4,&p\geq4.
 \end{cases}
\]
Dividing by \(\delta^2\) proves (C.1), including equality. For
\(W^{1,p}\), replace (C.2) by
\[
 O_{C\delta}(t)\leq C\delta^{1-1/p}
       \left(\int_{I_\delta(t)}|a'|^p\right)^{1/p}.
\]
The same calculation yields exponent \(3-4/p\) after division by
\(\delta^2\) when \(p\leq4\), proving the endpoint \(p=4/3\).

## Extension D: weaker Sobolev hypotheses with time-absolute-continuous stress

There is a different useful extension when the deviatoric stress \(D\)
obeys \(|D|(N\times B_R)=0\) for each Lebesgue-null time set \(N\)
and each spatial ball \(B_R\). Suppose \(D\) is carried by a graph of
a measurable finite-valued representative of
\(a\in W^{s,p}_{\rm loc}(I;\mathbb R^2)\), where
\(1/2\leq s<1\) and \(1\leq p<\infty\). Then \(D=0\).

This does not require \(sp>1\) or global continuity of that representative.
On a fixed compact interval define
\[
 g(t)=\left(\int
 \frac{|a(t)-a(z)|^p}{|t-z|^{1+sp}}dz\right)^{1/p}.
\]
Fubini gives \(g\in L^p\). For \(t\ne r\), averaging over the
interval between them and applying weighted Hölder gives
\[
 |a(t)-a(r)|\leq C|t-r|^s(g(t)+g(r))                 \tag{D.1}
\]
whenever the two values of \(g\) are finite. For \(p=1\), the same
estimate follows directly by bounding \(|t-z|^{1+s}\) by
\(|t-r|^{1+s}\) inside the averaging interval.

On each set \(E_k=\{g\leq k\}\), the path is therefore \(s\)-Hölder.
Each scalar coordinate extends to an \(s\)-Hölder function on the whole
time interval by the explicit infimum extension
\(b(t)=\inf_{r\in E_k}[a(r)+Ck|t-r|^s]\); the metric inequality for
\(|t-r|^s\), \(0<s\leq1\), verifies the extension. The two coordinates
give a vector extension. Since \(s\geq1/2\), its graph is locally
one-half-Hölder. These countably many extended graphs cover the original
graph outside a Lebesgue-null time set. The time-marginal hypothesis makes
the omitted part \(|D|\)-null. The verified countable-graph cancellation
therefore gives \(D=0\). Exhausting the time interval by compact intervals
preserves countability.

## Finite quadratic variation: what was and was not established

The phrase must specify whether it means bounded strong two-variation over
all partitions or a quadratic-variation limit along one prescribed family.
Neither meaning alone was converted here into (A.1) or a countable graph
cover. In particular finite quadratic variation does not imply the sufficient
oscillation criterion (B.1).

An explicit test is \(a(t)=(t^\alpha,0)\) near an interior time approached
from the right, continued constantly on the left, with
\(0<\alpha<1/4\). This path is continuous and of bounded variation, so
its sums of squared increments tend to zero along every vanishing-mesh
partition: they are bounded by its total variation times its largest
increment. Yet for \(t\) in an interval of length comparable to
\(\delta\) around the singular time,
\(O_{C\delta}(t)\geq c\delta^\alpha\), whence
\[
 \delta^{-2}\int O_{C\delta}^4dt
 \geq c\delta^{4\alpha-1}\longrightarrow\infty.
\]
This is **not a counterexample to stress cancellation**. Its graph is a
countable union of smooth graph pieces plus one point, and the verified
lemma already cancels stress there. It proves only that (B.1) is not
necessary and that finite variation does not automatically verify it.

A rigorous sufficient variation condition is available. If a continuous
path admits an increasing locally absolutely continuous control \(v\)
satisfying
\[
 |a(t)-a(s)|^2\leq v(t)-v(s),\qquad v'\in L^2_{\rm loc},
\]
then
\(O_\delta(t)^2\leq\int_{t-\delta}^{t+\delta}v'(r)dr\). Young's
convolution inequality gives
\(\int O_\delta^4\leq4\delta^2\|v'\|_2^2\), proving (B.1).
For a path of bounded strong two-variation, its cumulative squared
two-variation is one such increasing control; the additional \(W^{1,2}\)
condition on that control is sufficient.

GENERAL FINITE-QUADRATIC-VARIATION EXTENSION: **INCONCLUSIVE**. The unresolved
step is to replace the quantitative approximation/oscillation condition by
finite variation alone while retaining extraction of arbitrary stress time
atoms and singular time marginals. Failure of (B.1) cannot be used to deny
such an extension, and no counterexample to it was constructed.
