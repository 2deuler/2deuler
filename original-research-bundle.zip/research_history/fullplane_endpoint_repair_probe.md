# Full-plane endpoint stress repair: construction probe

Worker C, 2026-10-08. This is a proof-development packet. The algebraic building-block statements in sections 1–4 are independently derived below. Sections 5–8 specify a proposed repair construction; they require an independent whole-packet audit before being accepted as a lemma. They are not yet an existence proof for the target.

Later clarification: the root worker independently proposed the simpler two-scale quadrature below. It can replace the exact partition-of-unity auxiliary without changing the argument: take a radial probability bump of radius H, row spacing d=H^2, and tau=H^6. Replace h in (7) by d, keep h=H in (4),(5),(9), and obtain r_0 of order H^8. Standard translation estimates give quadrature error bounded by C[d(||partial_perp a||_1+H^{-1}||a||_1)+H||grad a||_1], tending to zero. This makes the moment cancellation of the auxiliary immediate.

## 1. Exact dipole normalization, chosen independently of source sign conventions

Let b be the first positive root of J_1. In polar coordinates define

    psi(rho,theta) = -rho sin(theta)
                       + 2 J_1(b rho)/(b J_0(b)) sin(theta), rho<=1,
                    -sin(theta)/rho,                         rho>=1.

Set V=grad^perp psi with grad^perp=(-partial_2,partial_1). Thus the exterior velocity is

    V(x)=grad(-x_1/|x|^2), |x|>=1.

Inside the unit disk, q=psi+x_2 is the stream function of V-e_1 and curl V=Delta psi=-b^2 q. Outside, curl V=0. The matching J_1(b)=0 and J_1'(b)=J_0(b) gives the appropriate matching values and first derivatives at radius one. Therefore (V-e_1).grad curl V=0 distributionally, and there is a pressure P such that

    -partial_1 V + div(V tensor V)+grad P=0.

This normalization has translation velocity +e_1. It fixes the sign of the stream function directly; no convention for perpendicular derivatives is imported from a paper.

For r>0 set V_r(x)=r^{-1}V(x/r), and rotate both the argument and output to obtain direction xi. Then

    -(1/r) partial_xi V_r + div(V_r tensor V_r)+grad P_r=0,
    div V_r=0,
    ||V_r||_2=C_2,             ||curl V_r||_1=C_omega,
    ||V_r||_{3/2}=C_{3/2} r^{1/3}.

The finite constants follow from boundedness in the core and the exterior decay V(x)=O(|x|^{-2}). The gradient L1 norm is also bounded uniformly in r. Curl is supported in B_r.

An explicit pressure certificate is P=-|V-e1|^2/2-(b^2/2)q^2 1_{B1}, up to a constant. Indeed V-e1=grad^perp q, curl V=-b^2 q in B1, and (w.grad)w=(curl w)w^perp+grad(|w|^2/2). Since q=0 at the circle and omega=0 outside, this formula matches across the boundary and yields the traveling equation distributionally.

Spatial smoothing of the complete profile at a sufficiently small fixed scale on each construction cell yields smooth blocks; it adds the usual quadratic mollification commutator to the stress. This commutator can be made arbitrarily small in L1 while preserving the L2 and curl-L1 bounds. Dependence of the smoothing scale on r must be handled consistently: keep the smoothing scale fixed within a cell when differentiating in r, and choose it smaller than the cell's positive minimum r.

## 2. Symmetric anti-divergence with two canceled moments

For a vector field f supported in B_R, suppose

    integral f=0,          integral x_j f_i(x) dx=0 for every i,j.

Define

    (A f)_{ij}=partial_i Delta^{-1}f_j
               +partial_j Delta^{-1}f_i
               -delta_ij div Delta^{-1}f.

Then A f is symmetric and div(A f)=f. Its convolution kernel is homogeneous of degree -1. For |x|<=3R the kernel is locally integrable, and Fubini gives an L1 bound C R||f||_1. For |x|>3R, subtract the constant and linear Taylor terms of the kernel using the two moment conditions. The remaining kernel is bounded by C R^2 |x|^{-3}; its integral over the exterior is bounded by C R. Hence

    ||A f||_1 <= C R ||f||_1.                              (1)

The conclusion does not assert compact support of A f. Integrability of its far field is precisely where the first-moment cancellation is used. A mean-zero condition alone would generally leave the nonintegrable |x|^{-2} tail in dimension two.

## 3. Radius derivative of the exact full-plane dipole

Direct differentiation of the rescaling gives

    partial_r V_r = r^{-1}V_r - div(V_r tensor x/r).

Let f_r=div(V_r tensor x/r). Outside B_r the dipole is homogeneous of degree -2, so f_r=0 there. Its L1 norm is uniformly bounded. Since V_r is even under x->-x, f_r is even, and its first moments vanish. Its mean also vanishes: integrating over B_L, L>r, its boundary flux is (L^2/r) times the angular mean of V_r on the circle, and that mean is zero. Put F_r=-A f_r. Formula (1) gives

    partial_r V_r=r^{-1}V_r+div F_r,       ||F_r||_1<=C r. (2)

Every identity here uses the exact full-plane dipole, not the periodized or truncated velocity.

## 4. Variable-amplitude moving packet and compact source

Let r(t)>0, eta(t)>=0, and X'(t)=eta(t)xi/r(t). The velocity

    v(t,x)=eta(t)V_{r(t)}(x-X(t))

satisfies, after incorporating gradient terms into pressure,

    partial_t v+div(v tensor v)+grad p
      =(eta r)' V_r/r + div(eta r' F_r).                   (3)

Choose a radial cutoff chi that is zero in the unit disk and one outside the disk of radius two, set alpha=1/5, and define

    Phi_xi(x)=-(xi.x)/|x|^2,
    Pi_r(x)=r chi(x/r^alpha) Phi_xi(x),
    W_r=V_r-grad Pi_r.

Then W_r is supported in B_{2r^alpha}, is even, and satisfies

    integral W_r=2 pi r xi,
    ||W_r||_1<=C r(1+|log r|),          0<r<1.

The integral follows directly by taking the difference of the boundary integrals of V_r and grad Pi_r: they equal +pi r xi and -pi r xi respectively on a large circle. Replacing V_r/r by W_r/r in (3) changes only the pressure. Thus the compact source profile is S_r=W_r/r, with integral 2 pi xi and all first moments zero.

Let U_h be a nonnegative even scalar probability density supported in B_{C h}. If 2r^alpha<=h, then S_r-2 pi U_h xi has zero zeroth and first moments and support in B_{C h}. Applying (1),

    ||A(S_r-2 pi U_h xi)||_1
       <=C h(1+|log r|).                                 (4)

Consequently (3) can be written

    partial_t v+div(v tensor v)+grad p
      = U + div E,

    U=2 pi (eta r)' U_h(x-X(t)) xi,
    E=eta r' F_r+(eta r)' A(S_r-2 pi U_h xi),

with

    ||E||_1 <=C |eta r'|r
                +C |(eta r)'|h(1+|log r|).               (5)

The endpoint curl estimate is exact:

    ||curl v(t)||_1=|eta(t)|C_omega.

There is no frequency factor in this estimate.

## 5. Proposed raster-sweep averaging lemma

Fix a smooth nonnegative scalar target coefficient a on a bounded rectangle in coordinates (s,y) directed along xi, with a constant positive floor epsilon in buffers at the two longitudinal ends. Its positive minimum and all derivatives are fixed before h tends to zero. Transverse grid lines have spacing h. Each line is visited once, sequentially, by one packet; no two packets are active simultaneously. Between visits the amplitude vanishes to every order, permitting the center to reset.

In the interior of a line the amplitude is a constant eta>0 and the radius is r(s)=r_0 a(s,kh). The trajectory obeys X'=eta xi/r. Therefore

    dt=(r_0/eta)a(s,kh) ds,
    integral eta^2 U_h(x-X(t)) dt
       =eta r_0 integral a(s,kh) U_h(x-s xi-kh xi^perp) ds. (6)

Choose U_h to have a transverse partition of unity:

    U_h(s,y)=h^{-2} kappa(s/h) theta(y/h),
    integral kappa=integral theta=1,
    sum_{k in Z} theta(z-k)=1.

Both profiles can be smooth, nonnegative, even, and compactly supported. Thus

    h sum_k integral a(s,kh)U_h(x-s xi-kh xi^perp)ds

approximates a in L1 with error tending to zero as h->0. For smooth compact a, the error is bounded by a constant times h times suitable L1 first-derivative bounds; the exact partition-of-unity condition prevents a persistent transverse comb oscillation.

At a line's entry and exit use a fixed smooth time ramp, flat at its ends, while r=r_0 epsilon stays constant in the buffer. If zeta is the ramp, choose its duration d=r_0 epsilon L_buffer/(eta integral_0^1 zeta), so the trajectory traverses exactly the chosen buffer length. Then

    |(eta(t)r(t))'|<=C eta^2

in the ramps. The missing averaged stress compared with a constant-amplitude pass occurs only in buffers where a=epsilon and therefore has L1 size O(epsilon times total buffer area). In the interior,

    |eta r'|=eta^2 |partial_xi log a|,
    |(eta r)'|=eta^2 |partial_xi log a|.

Let tau be the complete cycle duration. The relation

    2 pi eta r_0/tau=h                                   (7)

normalizes (6) to the desired target coefficient. The total scan duration is (r_0/eta) times a finite sum of line integrals of a, modified by fixed buffer factors. Hence eta^2 is a fixed multiple of the transverse Riemann sum of the total mass of a. In particular

    eta^2<=C (||a||_1+epsilon times rectangle area),
    r_0 comparable to tau h/eta.

For four directions, allocate one quarter of each cycle to each direction and use (7) with the full cycle tau; the amplitudes acquire only a fixed factor two.

For a time-independent coefficient, integration by parts within each line visit, using eta=0 at its endpoints, gives exactly

    average_cycle U
      =div[ (2 pi/tau) integral_cycle eta(t)^2
                       U_h(x-X(t)) xi tensor xi dt ].     (8)

The right-hand tensor approximates a xi tensor xi up to the spatial sampling and buffer errors. Freeze slowly varying target coefficients on each cycle; the additional stress error is at most tau times a time-derivative bound.

### Parameter probe

After fixing the rectangle, coefficient floors, and all coefficient norms, take tau=h^6 (up to a harmless discretization to divide a time interval). Then r_0 is of order h^7, r^alpha is of order h^{7/5}=o(h), and all radii are bounded above and below by fixed multiples of h^7. Formula (5) tends to zero: the second term is O(h log(1/h)), with constants depending on the frozen coefficient norms. The curl cost stays C sqrt(||a||_1). Arbitrarily bad but finite coefficient derivatives affect how small h must be, not the leading curl cost.

## 6. Time corrector, endpoint curl, and nonlinear cross terms

On each cycle [t_k,t_k+tau], let bar U be the cycle average and set

    Q(t)=-P integral_{t_k}^t [U(s)-bar U] ds,

where P is the full-plane Leray projection. Then Q is divergence-free and vanishes at both cycle endpoints. The Leray projection is bounded on L2 and on L^{3/2}. It also satisfies curl P f=curl f. If B bounds |(eta r)'|, direct bump scaling gives

    ||Q||_2<=C tau h^{-1} B,
    ||Q||_{3/2}<=C tau h^{-2/3} B,
    ||curl Q||_1<=C tau h^{-1} B.                         (9)

These estimates do not require L1 boundedness of the Leray projection. For tau=h^6 all tend to zero. The tensor errors produced by interactions with a smooth seed u are controlled by

    ||u tensor v||_1<=||u||_3 ||v||_{3/2}
                     <=C ||u||_3 eta r^{1/3},
    ||u tensor Q||_1<=||u||_3 ||Q||_{3/2},
    ||v tensor Q||_1<=||v||_2 ||Q||_2,
    ||Q tensor Q||_1<=||Q||_2^2.

Thus all tend to zero for a seed with finite L3 norm on the construction interval. Combining packet and corrector estimates suggests

    ||v+Q||_{L_infinity_t L2_x}<=C sqrt(delta)+small,
    ||curl(v+Q)||_{L_infinity_t L1_x}<=C sqrt(delta)+small,

where delta controls the total L1 mass of the decomposed stress coefficients.

## 7. Tensor decomposition and expected one-step statement

For symmetric R, use directions e1,e2,(e1+e2)/sqrt2,(e1-e2)/sqrt2. Smooth positive regularizations of |R_12| and sqrt(R_11^2+R_22^2) give smooth nonnegative coefficients a_i and a scalar q with

    -R+q I=sum_i a_i xi_i tensor xi_i,
    sum_i ||a_i||_1<=C||R||_1+small.

For example, if A>=|R_12| and B>=max{R_11,R_22}, take

    a1=B-R_11, a2=B-R_22,
    a3=A-R_12, a4=A+R_12, q=A+B.

Compactly supported positive floors are needed for smoothness. For a globally integrable R, first truncate its spatial tail in L1 on each compact time interval; keep the discarded tail as a small residual. Extend each coefficient by a small positive constant to its scanning rectangle and use small constant end buffers. These extensions add an arbitrarily small L1 error.

Proposed one-step conclusion: a smooth Euler–Reynolds seed (u,p,R) on a finite time interval with sup_t||R||_1<=delta and finite sup_t||u||_3 can be repaired to a new seed with stress smaller than any prescribed epsilon, with velocity and curl increments bounded by C sqrt(delta)+epsilon. Frequencies depend on seed derivatives, but the increment bound does not. The correction vanishes at the chosen time-cycle endpoints. The constants should be independent of the support size after floors are measured by their L1 mass.

This one-step conclusion is not marked proved here: the following interfaces need explicit independent audit:

1. Exact normalization of total scan time, the ramps, and the four-direction schedule, including eta very small or a identically zero.
2. Reconciliation of smoothness at cycle boundaries: Q is continuous and zero there, but its time derivative can jump. Piecewise smooth seeds and nested time partitions may suffice; the Euler–Reynolds weak identity must be written with this class.
3. Profile smoothing with r varying, preserving all required moments and the uniform curl bound.
4. Global integrability and symmetry of every assembled stress term after full-plane anti-divergence.
5. Uniform spatial tail truncation for R on a compact time interval.

## 8. Trace-preserving iteration: proposed interface

On strips approaching t=0, the one-step frequencies may grow without bound. The packet radii can be chosen to tend to zero toward t=0. Their amplitudes remain bounded. Uniformly over their centers, bounded-L2 rescalings r^{-1}V((x-X)/r) converge weakly to zero as r->0. To prove this, truncate V in L2 at a fixed large radius and use absolute continuity of the integral of |g|^2 over small sets for any L2 test g; the truncated tail is uniformly small. Formula (9) makes Q tend strongly to zero by choosing h sufficiently small.

Hence a repair of nonvanishing L2 size can still preserve an exact weak initial trace. A summable sequence sqrt(delta_q) then gives a uniform-L2 Cauchy series of corrections, so the final trace remains the seed trace and the total curl is uniformly bounded by the seed's bound plus C sum_q sqrt(delta_q).

Every fixed positive time should lie in one construction cell at each stage. A nested sequence of locally finite time partitions can treat the finite derivative bounds of each seed away from t=0. At old boundaries the new velocity correction should vanish; jumps of stress itself do not produce time delta functions because the equation differentiates the velocity in time, not the stress. This framework must be constructed and audited, not inferred from a published locality remark.

## 9. General initial data and a smooth Euler background

Take a nonnegative smooth radial probability density rho supported in B1. Each component of K is harmonic away from the origin, so K*rho=K outside B1. Thus L=K-K*rho is supported in B1 and belongs to L1. For any target datum mu,

    b0=K*(rho*mu),       v0=L*mu,
    ||v0||_1<=||L||_1||mu||_M.

The high-frequency Sobolev condition gives v0 in L2 as well. Evolve the smooth L1-intersect-Linfinity vorticity rho*mu by classical Euler to obtain b(t). Its velocity is bounded and in weak L2, hence in L3, on finite time intervals. The exact theorem giving this global background and its derivative regularity must be cited with its hypotheses checked.

For the L2 assertion, the multiplier (1-rho_hat(xi)) i xi^perp/|xi|^2 is bounded by C(1+|xi|^2)^(-1/2): near zero, evenness of rho gives 1-rho_hat=O(|xi|^2), while at high frequency the multiplier is O(|xi|^{-1}). Plancherel proves ||v0||_2<=C||mu||_{H^{-1}}.

Use the root worker's biharmonic seed for v0 and set u_seed=b+v_seed. Since v_seed is L1-intersect-L2, the initial stress

    R_seed=v_seed tensor v_seed+b tensor v_seed
             +v_seed tensor b+R_time

is globally L1. The repair linear term can use u_seed in L3, and subsequent finite-stage seeds remain in L3. It is therefore unnecessary to require the entire target velocity to have finite global L2 energy.

An affirmative proof would still have to check u=K*curl u at every time. For the perturbation, global L2 excludes a nonzero harmonic discrepancy; for the background the identity is built into its construction. This final interface is not waived.

## 10. Why this probe is materially different from the published theorem interface

The desired endpoint is curl in M, not a fixed p>1 norm. Exact full-plane dipoles give scale-independent curl-L1 cost, while a p>1 curl cost grows as the core shrinks. Sequential spatial sweeps replace periodic winding. Weak continuity allows concentrated corrections of bounded energy near the initial time. These three changes are essential and jointly require a new proof. No statement in the published BCK theorem is being silently upgraded to supply them.
