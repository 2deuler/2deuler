# Universal-obstruction route: exact entry probes

Status: worker derivations, submitted for independent verification. No disproof of the target is claimed. This file does not modify the authoritative target or checkpoint.

## 1. Route and quantifier audit

The required disproof would be one fixed finite signed measure
\(\omega _0\in H^{-1}(\mathbb R^2)\) for which **every** velocity satisfying
the stated initial trace, Biot--Savart identity, weak local \(L^2\) continuity,
and locally bounded total vorticity variation violates Euler or another target
requirement. Failure of one approximation, of a classical sheet parametrization,
of an energy inequality, or of uniqueness does not establish this statement.

The entry probes below establish three facts relevant to this universal
quantifier:

1. Every admissible rotationally invariant datum has a stationary target-class
   solution, including a concrete datum whose two Jordan parts both fail
   \(H^{-1}\).
2. Every target-class solution obeys a bounded symmetrized vorticity equation,
   weak-* measure continuity, atomlessness, and circulation conservation.
3. In the finite-energy subclass, every datum admits a kinematically admissible
   path matching Euler to first order at its initial time. This is only a
   compatibility test and is not an existence construction.

Consequently, neither bad Jordan-part energy nor initial first-order
compatibility supplies the desired universal obstruction.

## 2. Radial stationary solutions

### Proposition R1

Let \(\mu\in\mathcal M(\mathbb R^2)\cap H^{-1}(\mathbb R^2)\) be invariant
under rotations about the origin. Then \(u(t,x)=K*\mu(x)\) for all
\(t\geq0\) satisfies every requirement of the target.

### Proof

First, the following elementary Fourier observation shows
\(K*\mu\in L^2_{\rm loc}\). With Fourier convention
\(\widehat f(\xi)=\int e^{-ix\cdot\xi}f(x)\,dx\), the Biot--Savart
multiplier is \(-i\xi^\perp/|\xi|^2\). On \(|\xi|>1\), its squared
modulus is controlled by twice the \(H^{-1}\) weight. On
\(|\xi|\leq1\), the bound \(|\widehat\mu|\leq\|\mu\|_{\mathcal M}\)
makes this multiplier times \(\widehat\mu\) integrable, because
\(|\xi|^{-1}\in L^1(B_1)\) in dimension two. Thus the velocity is the sum
of an \(L^2\) field and a bounded field. The distributional convolution with
the given kernel realizes this multiplier, with no added harmonic velocity.

The velocity is a radial swirl. More precisely, for almost every \(r>0\),
\[
 u(r,\theta)=v(r)e_\theta,\qquad
 v(r)=\frac{\mu(B_r)}{2\pi r}.
\]
One direct justification is to decompose a rotationally invariant measure into
its distribution of radii. The normalized circle measure \(\sigma_a\) has
logarithmic potential \((2\pi)^{-1}\log\max(a,|x|)\), so
\(K*\sigma_a=K(x)\mathbf1_{\{|x|>a\}}\) almost everywhere. Integrating
this identity against the signed distribution of radii gives the displayed
formula. Possible values on the circles do not affect the velocity as an
\(L^2_{\rm loc}\) field. An atom at the origin is excluded by
\(H^{-1}\); a direct proof of atomlessness is given in Proposition N1 below.

Let \(\varphi\in C_c^\infty(\mathbb R^2;\mathbb R^2)\) be
divergence-free. The integrand \((u\otimes u):\nabla\varphi\) is
integrable. At each radius \(r>0\), polar differentiation gives
\[
 \int_0^{2\pi} e_\theta\cdot(\nabla\varphi)e_\theta\,d\theta
 =\frac1r\int_0^{2\pi}
     \bigl[\partial_\theta(\varphi\cdot e_\theta)
                +\varphi\cdot e_r\bigr],d\theta=0.
\]
The derivative integrates to zero by periodicity, and the other term is zero
by the divergence theorem on \(B_r\). Fubini applies to the original
integrable tensor contraction, so
\(\int(u\otimes u):\nabla\varphi=0\). There is no need to assert
integrability of the pressure gradient or to integrate the two polar terms
separately in radius.

For a time-dependent target test, apply this calculation at each time and
integrate \(u\cdot\partial_t\varphi\) in time. Its value is
\(-\int u\cdot\varphi(0)\), giving exactly the prescribed weak Euler
identity. The velocity is constant in time, its curl is \(\mu\), its
Biot--Savart identity holds at every time, and its measure norm is constant.
This proves every target requirement. \(\square\)

### Proposition R2: bad Jordan parts coexist with a stationary solution

Let \(\sigma_a\) be normalized arclength measure on \(|x|=a\). Set
\[
 a_n=n^{-2},\qquad r_n=e^{-n^3},\qquad s_n=e^{-n^3-1},\qquad
 \omega_0=\sum_{n=1}^{\infty}a_n(\sigma_{s_n}-\sigma_{r_n}).
\]
Then \(\omega_0\in\mathcal M\cap H^{-1}\), both Jordan parts fail
\(H^{-1}\), and the datum has the stationary solution in Proposition R1.

### Proof

All supporting circles are distinct because
\(s_{n+1}<r_{n+1}<s_n<r_n\). The series converges in total variation,
and
\[
 \|\omega_0\|_{\mathcal M}=2\sum_n n^{-2},\qquad
 \omega_0^+=\sum_n n^{-2}\sigma_{s_n},\qquad
 \omega_0^-=\sum_n n^{-2}\sigma_{r_n}.
\]
Every pair has zero circulation outside its annulus. Consequently
\[
 \Gamma(r):=\omega_0(B_r)
 =\sum_n n^{-2}\mathbf1_{(s_n,r_n)}(r),\qquad
 u_0(r,\theta)=\frac{\Gamma(r)}{2\pi r}e_\theta
\]
almost everywhere, and
\[
 \|u_0\|_{L^2(\mathbb R^2)}^2
 =\frac1{2\pi}\int_0^\infty\Gamma(r)^2\frac{dr}{r}
 =\frac1{2\pi}\sum_n n^{-4}<\infty.
\]
The curl of this velocity is the stated measure. For example, the finite
partial sums converge in \(L^2\) by the disjoint-annulus calculation, while
their curls converge in total variation to \(\omega_0\), identifying the
distributional curl. Since the curl maps \(L^2\) into \(H^{-1}\),
the full signed measure belongs to \(H^{-1}\).

Write \(A_{n+1}=\sum_{k\geq n+1}k^{-2}\), so
\(A_{n+1}\geq1/(n+1)\). Throughout
\(r\in(r_{n+1},s_n)\), the cumulative mass of each Jordan part equals
\(A_{n+1}\). The logarithmic length of this interval is
\[
 \log(s_n/r_{n+1})=3n^2+3n.
\]
Thus for either Jordan part \(\mu\), its radial Biot--Savart velocity
satisfies
\[
 \int_{B_1}|K*\mu|^2
 \geq\frac1{2\pi}\sum_{n=1}^{\infty}
 (3n^2+3n)A_{n+1}^2=\infty.
\]
The Fourier observation in Proposition R1 implies that any finite measure in
\(H^{-1}\) has locally square-integrable Biot--Savart velocity. The last
display therefore proves \(\omega_0^\pm\notin H^{-1}\). Proposition R1
gives the stationary solution. \(\square\)

**Downstream implication.** A proof requiring both Jordan parts to belong to
\(H^{-1}\) excludes valid target data. Conversely, this failure does not
itself suggest nonexistence: the preceding datum is explicitly solvable.

## 3. Necessary conditions for every target solution

### Proposition N1

Let \(u,\omega\) satisfy the target on \([0,T]\), and let
\(M_T=\sup_{0\leq t\leq T}\|\omega(t)\|_{\mathcal M}\). Then:

1. \(\omega(t)\) has no atoms, for every \(t\).
2. \(\omega\in C_{w^*}([0,T];\mathcal M)\), with \(C_0\) as predual.
3. For every real \(\phi\in C_c^\infty(\mathbb R^2)\) and every
   \(0\leq s\leq t\leq T\),
   \[
   \langle\omega(t)-\omega(s),\phi\rangle
   =\int_s^t\iint H_\phi(x,y)\,d\omega(\tau,x)d\omega(\tau,y)\,d\tau,
   \]
   where
   \[
   H_\phi(x,y)=\tfrac12K(x-y)\cdot
           (\nabla\phi(x)-\nabla\phi(y)),\qquad x\ne y,
   \]
   and its value on the diagonal can be arbitrary.
4. With the operator norm convention for the Hessian,
   \[
   |\langle\omega(t)-\omega(s),\phi\rangle|
   \leq\frac{M_T^2}{4\pi}|t-s|\|D^2\phi\|_\infty.
   \]
5. \(\omega(t)(\mathbb R^2)=\omega(0)(\mathbb R^2)\) for every \(t\).

### Proof of 1 and 2

For a fixed time and point \(a\), take smooth logarithmic cutoffs
\(0\leq\eta_j\leq1\), equal to one in a neighborhood of \(a\), whose
supports shrink to \(a\) and whose gradient \(L^2\) norms tend to zero.
For instance, smooth versions of the profile equal to one on \(B_{r^2}(a)\),
equal to \(\log(r/|x-a|)/\log(1/r)\) on the annulus to \(B_r(a)\),
and zero outside have gradient energy \(2\pi/\log(1/r)\). Pairing with
\(\omega=\operatorname{curl}u\) gives
\[
 |\langle\omega,\eta_j\rangle|
 \leq\|u\|_{L^2(B_1(a))}\|\nabla\eta_j\|_2\longrightarrow0.
\]
Dominated convergence against the finite signed measure identifies the limit
with \(\omega(\{a\})\). Hence there are no atoms.

For smooth compactly supported \(\phi\),
\(\langle\omega(t),\phi\rangle=-\int u(t)\cdot\nabla^\perp\phi\)
is continuous by weak local \(L^2\) continuity. Approximation of a fixed
\(f\in C_0\) uniformly by such \(\phi\), with error bounded by
\(M_T\|f-\phi\|_\infty\), proves weak-* measure continuity.

### Fixed-time symmetrization lemma

Suppose \(\mu\in\mathcal M\) is non-atomic and
\(v=K*\mu\in L^2_{\rm loc}\). Then
\[
 -\int (v\otimes v):\nabla\nabla^\perp\phi
   =\iint H_\phi\,d\mu\,d\mu.                    \tag{N.1}
\]

To prove it, mollify with a smooth nonnegative compactly supported approximate
identity: \(\mu_\varepsilon=\rho_\varepsilon*\mu\) and
\(v_\varepsilon=\rho_\varepsilon*v=K*\mu_\varepsilon\).
For these smooth fields, integration by parts and \(\operatorname{div}v=0\)
give
\[
 -\int(v_\varepsilon\otimes v_\varepsilon):
       \nabla\nabla^\perp\phi
 =\int\mu_\varepsilon v_\varepsilon\cdot\nabla\phi
 =\iint H_\phi\,d\mu_\varepsilon d\mu_\varepsilon.
\]
The unsymmetrized integral is absolutely integrable: \(\mu_\varepsilon\)
is bounded and integrable, \(K\) is locally integrable and bounded away from
its singularity, and \(\nabla\phi\) is compactly supported. This also
justifies Fubini and interchange of the two variables.

The velocity mollification converges strongly in \(L^2\) on every fixed
compact set, proving convergence on the left. For the right, note
\[
 |H_\phi|\leq\frac1{4\pi}\|D^2\phi\|_\infty,
 \qquad |\mu_\varepsilon|\leq\rho_\varepsilon*|\mu|.
\]
Away from the diagonal, \(H_\phi\) is continuous and tends to zero at
infinity in \(\mathbb R^2\times\mathbb R^2\). The dominating positive
measures \(\rho_\varepsilon*|\mu|\) converge narrowly to \(|\mu|\).
Their product masses in a closed diagonal neighborhood have limsup bounded
by the limiting product mass there. Since
\((|\mu|\otimes|\mu|)(\{x=y\})=0\), those bounds tend to zero as
the neighborhood shrinks. A continuous diagonal cutoff therefore proves
convergence of the double integrals. This proves (N.1) without assuming
\(|\mu|\in H^{-1}\).

### Proof of 3--5

Use \(\nabla^\perp\phi\) as the spatial part of a separated Euler test.
The identity
\(\int u\cdot\nabla^\perp\phi=-\langle\omega,\phi\rangle\)
and (N.1) give, in distributions in time,
\[
 \frac d{dt}\langle\omega(t),\phi\rangle
 =\iint H_\phi\,d\omega(t)d\omega(t).
\]
The right side is bounded in absolute value by
\(M_T^2\|D^2\phi\|_\infty/(4\pi)\); it is measurable, for example
as the fixed-time limit of continuous double integrals with diagonal cutoffs.
The already continuous left-side pairing thus has the asserted Lipschitz
representative and obeys the integrated identity at all endpoints.

Finally let \(\phi_R(x)=\chi(x/R)\), where
\(\chi\in C_c^\infty\), \(0\leq\chi\leq1\), and \(\chi=1\)
near the origin. Then
\[
 |\langle\omega(t)-\omega(0),\phi_R\rangle|
 \leq\frac{M_T^2t}{4\pi R^2}\|D^2\chi\|_\infty\longrightarrow0.
\]
Dominated convergence at the two fixed times gives equality of the total
circulations. No spatial energy bound at infinity, sign hypothesis, moment
bound, or transport theorem was used. \(\square\)

**Converse interface.** If the Biot--Savart and local \(L^2\) hypotheses
hold and the displayed symmetrized vorticity equation holds, (N.1) recovers
the velocity weak formulation: every compactly supported smooth
divergence-free field on \(\mathbb R^2\) is \(\nabla^\perp\phi\)
for a compactly supported smooth scalar stream function. For time-dependent
fields this construction can be made smoothly in time by fixing the stream
function to zero in the unbounded exterior region. This equivalence does not
by itself supply a path satisfying the equation.

## 4. Initial-time tangent test in the finite-energy subclass

### Proposition T1

Let \(u_0\in L^2(\mathbb R^2;\mathbb R^2)\) be divergence-free and
let \(\omega_0=\operatorname{curl}u_0\in\mathcal M\). Denote by
\(P\) the Fourier orthogonal projection onto divergence-free fields and
put \(F=u_0\otimes u_0\in L^1\). Define
\[
 u(t)=u_0-t e^{t\Delta}P\operatorname{div}F\quad(t>0),
 \qquad u(0)=u_0.
\]
Then \(u\in C([0,\infty);L^2)\), it is divergence-free, its curl
is a finite measure with locally bounded total variation, and
\(u(t)=K*\operatorname{curl}u(t)\). In fact
\(\|\operatorname{curl}u(t)-\omega_0\|_{\mathcal M}\to0\) as
\(t\downarrow0\). For each compactly supported smooth divergence-free
\(\varphi\),
\[
 \langle u(t)-u_0,\varphi\rangle
 -\int_0^t\int (u(s)\otimes u(s)): \nabla\varphi\,dx\,ds=o(t).
                                                        \tag{T.1}
\]
No assertion that the residual vanishes for positive \(t\) is made.

### Proof

The operator \(e^{t\Delta}P\operatorname{div}\) has an \(L^1\to L^2\)
bound \(Ct^{-1}\) in two dimensions. This follows directly from
Plancherel, \(|\widehat F|\leq\|F\|_1\), \(\|P(\xi)\|\leq1\),
and \(\int_{\mathbb R^2}|\xi|^2e^{-2t|\xi|^2}\,d\xi=Ct^{-2}\).
Thus the correction is uniformly bounded in \(L^2\). Approximate \(F\)
in \(L^1\) by smooth compactly supported tensors. For each such tensor
the correction tends to zero in \(L^2\), since its divergence lies in
\(L^2\) and the extra factor is \(t\). The uniform bound handles the
approximation error. Hence \(u(t)\to u_0\) strongly in \(L^2\).
Continuity at positive times follows from the same multiplier representation
and dominated convergence on a compact positive time interval.

Curl annihilates the gradient part of \(P\), so
\[
 \operatorname{curl}u(t)=\omega_0
   -t e^{t\Delta}\operatorname{curl}\operatorname{div}F.
\]
The correction is in \(L^1\), bounded by \(C\|F\|_1\), because the
second derivatives of the heat kernel have \(L^1\) norm bounded by
\(Ct^{-1}\). The same \(L^1\)-density argument, this time using the
\(L^1\) second derivatives of a smooth approximant, proves that the
correction tends to zero in \(L^1\). Its \(L^1\) continuity at positive
times is equally direct. The divergence-free assertion follows from \(P\).

For any divergence-free \(L^2\) field with finite-measure curl, the given
Biot--Savart convolution recovers the field. In Fourier variables the identity
holds off \(\xi=0\); both fields are tempered, and their difference is a
harmonic distribution. The Biot--Savart field is globally weak \(L^2\),
while the original field is \(L^2\); a harmonic polynomial in weak
\(L^2\) is zero. Equivalently one may use the usual low/high Fourier
split and eliminate the harmonic remainder by decay of averages at infinity.

For the residual, self-adjointness of the heat semigroup and of \(P\),
together with \(P\varphi=\varphi\), yields
\[
 \frac1t\langle u(t)-u_0,\varphi\rangle
 =\int F:\nabla e^{t\Delta}\varphi
 \longrightarrow\int F:\nabla\varphi.
\]
Meanwhile strong \(L^2\) convergence gives
\(u(s)\otimes u(s)\to F\) in \(L^1\). Averaging this limit over
\((0,t)\) proves (T.1). \(\square\)

**Interpretation.** The tangent construction confirms compatibility of all
the kinematic conditions and the first-order Euler identity for every datum
in this subclass. It does not control higher-order residuals and cannot be
iterated without a new stability estimate.

## 5. Tests of proposed universal obstructions

| Candidate obstruction | Entry-probe result | Earliest missing bridge |
|---|---|---|
| Jordan parts have infinite logarithmic energy | Explicitly compatible with the stationary solution R2 | Would need a genuinely dynamical constraint not satisfied by stationary radial fields |
| An admissible datum forces an atomic vorticity | Every target solution is atomless, but no datum was shown to force atoms in every solution | Universality beyond a chosen approximation or classical-sheet evolution |
| Initial Euler acceleration is too singular | T1 realizes the required first-order acceleration with measure curl and strong initial trace | A higher-order or positive-time incompatibility theorem |
| Circulation changes are unavoidable | N1 proves circulation must be constant, but no admissible datum contradicts this | A datum forcing a circulation change by another independently proved identity |
| Classical Birkhoff--Rott curve develops a singularity | Curve curvature failure is not failure of the target measure/local-energy class | A theorem forcing all target solutions to remain in, and fail with, the classical curve class |
| Selected approximate solutions develop stress concentration | Does not exclude another solution with the same fixed datum | A selection-independent necessity theorem |

The primary source checked for the Birkhoff--Rott interface was Caflisch and
Orellana, *Singular Solutions and Ill-Posedness for the Evolution of Vortex
Sheets*, SIAM J. Math. Anal. **20** (1989), 293--307:
https://www.math.ucla.edu/~caflisch/Pubs/Pubs1980-1989/OrellanaSIMA1989.pdf .
Theorem 1 concerns analytic parametrized Birkhoff--Rott solutions; Section 7
draws Sobolev ill-posedness consequences. The setup is a periodic perturbation
of an infinite uniform sheet, not finite total vorticity on the whole plane.
Both the solution-class and data-domain interfaces therefore fail for a direct
application to the target. No external result is load-bearing in R1, R2,
N1, or T1.

## 6. Disposition and next concrete bridge

The static/initial-compatibility universal-obstruction route has not produced
an incompatible datum. Its useful output is the preceding falsification of
several tempting but invalid obstruction claims and the exact necessary
conditions in N1.

To reopen a nonexistence route, one needs a positive-time constraint that
holds for every target solution, stronger than atomlessness, circulation
conservation, and C²-dual Lipschitz continuity, and a fixed admissible datum
incompatible with it. A transport, Jordan-mass, energy, support, or symmetry
constraint may not be inserted without proof from the target hypotheses.

Possible next executable tests: derive localized signed-moment identities
solely from N1; determine whether any positive quantity built from those
identities has a sign-definite evolution despite signed vorticity; test the
result against R2 and arbitrary radial stationary data before treating it as
a universal obstruction.

## 7. Localized signed-moment probe

### Proposition M1: no universal sign for a nontrivial compact linear moment

For every nonzero real \(\phi\in C_c^\infty(\mathbb R^2)\), the
quadratic functional
\[
 Q_\phi(\mu)=\iint H_\phi(x,y)\,d\mu(x)d\mu(y)
\]
takes both positive and negative values on real smooth compactly supported
vorticities. In particular the N1 evolution of any such localized linear
moment has no sign valid for all admissible signed data.

### Proof

First \(H_\phi\) cannot vanish identically off the diagonal. If it did,
letting \(y\to x\) along each direction would give
\(z^\perp\cdot D^2\phi(x)z=0\) for every \(z\), hence
\(D^2\phi(x)=\lambda(x)I\). The mixed derivative is zero, so
\(\phi(x_1,x_2)=f(x_1)+g(x_2)\), and equality of the diagonal derivatives
forces \(f''(x_1)=g''(x_2)\) to be one constant. Thus \(\phi\) is an
isotropic quadratic plus an affine function; compact support forces it to
be zero, a contradiction. Choose distinct \(x,y\) with
\(H_\phi(x,y)\ne0\).

Let \(\rho\in C_c^\infty\) be radial, nonnegative, and of integral one,
and write \(\rho_{\varepsilon,c}(z)=\varepsilon^{-2}
\rho((z-c)/\varepsilon)\). The self-interaction obeys
\[
 Q_\phi(\rho_{\varepsilon,c})\longrightarrow
 \frac1{4\pi}\iint
 \frac{(p-q)^\perp\cdot D^2\phi(c)(p-q)}{|p-q|^2}
 \rho(p)\rho(q)\,dp\,dq=0.
\]
Boundedness of \(H_\phi\) justifies the limit. The final integral vanishes
because the distribution of \(p-q\) is radial and the angular average of
\(e_\theta^\perp\cdot A e_\theta\) is zero for every symmetric matrix
\(A\). The cross interaction converges to \(H_\phi(x,y)\). Hence
\[
 Q_\phi(\rho_{\varepsilon,x}+\rho_{\varepsilon,y})
       \longrightarrow 2H_\phi(x,y),\qquad
 Q_\phi(\rho_{\varepsilon,x}-\rho_{\varepsilon,y})
       \longrightarrow-2H_\phi(x,y).
\]
For small enough \(\varepsilon\), these quantities have opposite strict
signs. Both constructed vorticities are in \(C_c^\infty\), hence in the
target initial-data class. \(\square\)

The formal nonlocalized kernel identities for \(1,x_1,x_2,|x|^2\) are
zero, explaining the usual conserved signed moments when their integrals
and limiting procedures are justified. The target imposes neither moment
finiteness nor their propagation. Moreover these signed quantities have no
coercive relation to total variation for general signed measures. Thus this
probe found no incompatible datum and falsified a universal-sign version of
the localized-moment mechanism. A data-dependent monotonicity route would
need an additional propagated geometric/sign property derived from the
target, not imposed on all solutions.
