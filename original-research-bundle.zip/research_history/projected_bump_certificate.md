# Explicit projected bump and time-corrector certificate

Worker: initial_velocity_interfaces. Exact elementary lemma packet; no Calderón–Zygmund boundedness theorem is invoked. The main identities and signs below are derived directly from the radial Newtonian potential.

## 1. Hypotheses and notation

Let \(\rho\in C_c^\infty(B_1(0))\) be radial, nonnegative, and have integral one. For \(H>0\), set \(\rho_H(x)=H^{-2}\rho(x/H)\). Fix a unit vector \(\xi=(\xi_1,\xi_2)\). Use
\[
G(x)=\frac1{2\pi}\log|x|,\qquad \Delta G=\delta_0,
\qquad \operatorname{curl}v=\partial_1v_2-\partial_2v_1.
\]
Define
\[
\Psi_H=G*\rho_H,\quad q_{H,\xi}=\xi\cdot\nabla\Psi_H,
\qquad
Z_{H,\xi}=\rho_H\xi-\nabla q_{H,\xi}.
\tag{P1}
\]
Thus the notation \(P(\rho_H\xi)=Z_{H,\xi}\) can be used, but no general \(L^p\) theory of \(P\) is needed.

## 2. Divergence, curl, smoothness, scaling and pointwise tail

The functions in (P1) are smooth, because the convolution of the locally integrable fundamental solution with a compact smooth function is smooth; derivatives may be transferred to the compact smooth factor in the distributional convolution. Since \(\Delta\Psi_H=\rho_H\),
\[
\operatorname{div}Z_{H,\xi}
=\xi\cdot\nabla\rho_H-\Delta(\xi\cdot\nabla\Psi_H)=0,
\]
and
\[
\operatorname{curl}Z_{H,\xi}
=\operatorname{curl}(\rho_H\xi)
=\xi_2\partial_1\rho_H-\xi_1\partial_2\rho_H.
\tag{P2}
\]
In particular, the curl is supported in \(B_H\), and
\[
\|\operatorname{curl}Z_{H,\xi}\|_1
\leq H^{-1}\|\nabla\rho\|_1.
\tag{P3}
\]

Here is an explicit bound on the velocity profile. First take \(H=1\), write \(r=|x|\), and set
\(M(r)=\int_{B_r}\rho\).
The radial Poisson equation gives
\[
\Psi_1'(r)=\frac{M(r)}{2\pi r},\qquad
\Psi_1''(r)=\rho(r)-\frac{M(r)}{2\pi r^2}.
\tag{P4}
\]
The integration constant in the first identity vanishes by smoothness at the origin. Since \(M(r)\leq\pi r^2\|\rho\|_\infty\), both radial Hessian eigenvalues \(\Psi_1''\) and \(\Psi_1'/r\) are bounded by \(C\|\rho\|_\infty\). Therefore
\[
|Z_{1,\xi}(x)|\leq C_\rho\quad\text{for }|x|\leq1.
\tag{P5}
\]
For \(r\geq1\), \(M(r)=1\) and \(\rho(r)=0\), so the formula is exact:
\[
Z_{1,\xi}(x)
=\frac1{2\pi r^2}\left(2\frac{x}{r}\left(\frac{x}{r}\cdot\xi\right)-\xi\right),
\qquad
|Z_{1,\xi}(x)|=\frac1{2\pi r^2}.
\tag{P6}
\]
The equality of the norm follows because \(2e\otimes e-I\) is an orthogonal reflection when \(|e|=1\).

The identity
\(\Psi_H(x)=\Psi_1(x/H)+(2\pi)^{-1}\log H\)
gives
\[
Z_{H,\xi}(x)=H^{-2}Z_{1,\xi}(x/H).
\tag{P7}
\]
Thus \(|Z_{H,\xi}|\leq C_\rho H^{-2}\) in the core and (P6), with \(r=|x|\), remains the exact exterior formula for \(|x|\geq H\).

For every \(1<p<\infty\), direct integration yields
\[
\int_{|x|\geq1}|Z_{1,\xi}|^p\,dx
=(2\pi)^{1-p}\int_1^\infty r^{1-2p}\,dr
=\frac{(2\pi)^{1-p}}{2p-2}.
\]
Together with (P5), (P7), this proves
\[
\|Z_{H,\xi}\|_p\leq C_{p,\rho}H^{2/p-2},
\qquad 1<p\leq\infty.
\tag{P8}
\]
The endpoint \(p=1\) is deliberately excluded: (P6) gives a logarithmically divergent absolute integral.

## 3. Fixed spatial mollification

Let \(\kappa\in C_c^\infty(B_1)\) be a nonnegative even probability kernel and \(\kappa_\ell(x)=\ell^{-2}\kappa(x/\ell)\). Define
\[
\widetilde\rho_{H,\ell}=\rho_H*\kappa_\ell,
\quad \widetilde q_{H,\ell,\xi}=q_{H,\xi}*\kappa_\ell,
\quad \widetilde Z_{H,\ell,\xi}=Z_{H,\xi}*\kappa_\ell.
\tag{P9}
\]
Distributional differentiation and convolution commute, so
\[
\widetilde Z_{H,\ell,\xi}
=\widetilde\rho_{H,\ell}\xi-\nabla\widetilde q_{H,\ell,\xi},
\quad \Delta\widetilde q_{H,\ell,\xi}
=\operatorname{div}(\widetilde\rho_{H,\ell}\xi),
\]
and the divergence and curl identities in (P2) remain valid with tildes. The curl is supported in \(B_{H+\ell}\). Minkowski's integral inequality, together with \(\|\kappa_\ell\|_1=1\), gives
\[
\|\widetilde Z_{H,\ell,\xi}\|_p
\leq\|Z_{H,\xi}\|_p
\leq C_{p,\rho}H^{2/p-2},
\qquad
\|\operatorname{curl}\widetilde Z_{H,\ell,\xi}\|_1
\leq H^{-1}\|\nabla\rho\|_1.
\tag{P10}
\]
These constants are independent of \(\ell>0\); no radiality of \(\kappa\) is required. For \(|x|\geq2(H+\ell)\), (P6) also gives
\[
|\widetilde Z_{H,\ell,\xi}(x)|\leq C|x|^{-2}.
\tag{P11}
\]
Indeed \(|x-y|\geq|x|/2\geq H\) for every \(y\in\operatorname{supp}\kappa_\ell\), and one integrates the original tail estimate. Smoothness follows either from (P9) or from the preceding potential formula.

The mollification scale is fixed throughout a construction cell. Consequently all time derivatives commute with this mollification when centers, amplitudes, or radii vary. This statement would need extra terms if \(\ell\) depended on time.

## 4. Exact time corrector and pressure sign

Let \(I=[a,b]\), \(\tau=b-a>0\). Let \(B\in W^{1,1}(I)\), let \(c:I\to\mathbb R^2\) be measurable, and let \(m_\star>0\) be a fixed source normalization (in the explicit Lamb convention, \(m_\star=2\pi\)). Define
\[
F(t,x)=m_\star B'(t)\rho_H(x-c(t))\xi,
\qquad
\overline F(x)=\frac1\tau\int_a^bF(s,x)\,ds.
\]
The explicit corrector is
\[
\begin{split}
Q(t,x)={}&-m_\star\int_a^t B'(s)Z_{H,\xi}(x-c(s))\,ds\\
&+\frac{m_\star(t-a)}\tau
\int_a^b B'(s)Z_{H,\xi}(x-c(s))\,ds.
\end{split}
\tag{P12}
\]
The integrals are Bochner integrals in each \(L^p\), \(1<p<\infty\). Translation is continuous in these spaces, so measurability of \(c\), integrability of \(B'\), and (P8) give strong measurability and integrability. The same construction holds in the mollified case (P9).

One has \(Q(a)=Q(b)=0\), \(\operatorname{div}Q=0\), and, almost everywhere in time,
\[
\partial_tQ
=-m_\star B'(t)Z_{H,\xi}(\cdot-c(t))
+\frac{m_\star}\tau\int_a^b B'(s)Z_{H,\xi}(\cdot-c(s))\,ds.
\tag{P13}
\]
Substituting \(Z=\rho_H\xi-\nabla q\) verifies the exact sign certificate
\[
\partial_tQ+F+\nabla p_Q=\overline F,
\tag{P14}
\]
where
\[
p_Q(t,x)=-m_\star B'(t)q_{H,\xi}(x-c(t))
+\frac{m_\star}\tau\int_a^b B'(s)q_{H,\xi}(x-c(s))\,ds.
\tag{P15}
\]
This is also a distributional identity if the coefficients are only measurable with the stated integrability. It directly supplies the pressure needed in the Euler–Reynolds assembly.

## 5. Norm bounds, curl support, continuity and tails

Write
\(\mathcal V_B=\int_a^b|B'(s)|\,ds\).
The triangle inequality in (P12), followed by (P8), gives
\[
\sup_{t\in I}\|Q(t)\|_p
\leq 2m_\star C_{p,\rho}H^{2/p-2}\mathcal V_B.
\tag{P16}
\]
The two required cases are therefore
\[
\sup_t\|Q(t)\|_2\leq C m_\star H^{-1}\mathcal V_B,
\qquad
\sup_t\|Q(t)\|_{3/2}\leq C m_\star H^{-2/3}\mathcal V_B.
\tag{P17}
\]
Curl commutes with the integral; using (P2)–(P3) gives
\[
\sup_t\|\operatorname{curl}Q(t)\|_1
\leq2m_\star H^{-1}\|\nabla\rho\|_1\mathcal V_B.
\tag{P18}
\]
If \(\|B'\|_\infty\leq A\), replace \(\mathcal V_B\) by \(\tau A\). In the exact raster clock where \(\mathcal V_B=\tau D/m_\star\), these become
\[
\|Q\|_{L^\infty_tL^2_x}
+\|\operatorname{curl}Q\|_{L^\infty_tL^1_x}
\leq C\tau H^{-1}D,
\qquad
\|Q\|_{L^\infty_tL^{3/2}_x}\leq C\tau H^{-2/3}D.
\tag{P19}
\]
All these estimates remain unchanged, up to the same fixed constants, after the fixed mollification in Section 3.

Formula (P12) gives \(Q\in C(I;L^p)\), \(1<p<\infty\), and the curl formula gives \(\operatorname{curl}Q\in C(I;L^1)\). If the centers lie in a fixed ball \(B_L\), the curl support lies in \(B_{L+H}\), or \(B_{L+H+\ell}\) after mollification. For \(|x|\geq2(L+H+\ell)\), the translated bound (P11) yields
\[
|Q(t,x)|\leq C m_\star\mathcal V_B|x|^{-2},
\tag{P20}
\]
uniformly in \(t\). Thus the velocity has uniform \(L^p\) tails for every \(p>1\), while its curl has compact support.

Finally, extending \(Q\) by zero outside \([a,b]\) creates no delta at the endpoints in \(\partial_tQ\), because both endpoint traces are zero. Its one-sided derivatives need not agree with zero. This distinction is essential if a later argument asks for smoothness across construction-cell boundaries; the present certificate only asserts continuity and the distributional identity.

## 6. Dependency and scope check

The proof uses the radial Poisson ODE, the fundamental-solution identity, differentiation of smooth convolutions, direct integration of \(|x|^{-2p}\), Minkowski's inequality, and differentiation of time integrals. It uses neither a general Leray-projection \(L^p\) theorem nor general Calderón–Zygmund estimates. The field itself is not asserted to be in \(L^1\). The pressure sign is fixed explicitly in (P14)–(P15), and the curl convention is fixed in (P2).

Verification provenance: independent worker derivation; ready for hostile audit and inclusion in the manuscript's dependency closure.
