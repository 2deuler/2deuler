# Exact-trace time-strip iteration: conditional construction packet

STATUS: A self-contained abstract implication from an explicitly stated
one-step repair property. The one-step property is not proved in this file.
This is not a proof of the target existence statement. The seed packet
`route_initial_subsolution.md` is an input candidate undergoing a separate
audit.

## 1. Hostile interface assessment

The inspected construction source `route_alternative_construction.md`
correctly distinguishes nearby endpoint traces from the exact initial trace
in the target. Four separate properties are needed to turn local building
blocks into the requested solution:

1. The repair must remove a **prescribed stress piece** of a current
   Euler--Reynolds pair, not merely produce a different approximate endpoint.
2. Every velocity corrector and stress error used on a time patch must vanish
   outside that patch. In particular a time-antiderivative corrector cannot
   leave a nonzero constant after the patch ends.
3. Its leading \(L^2\)-velocity and curl-\(L^1\) costs must be uniform as
   patch times approach zero and seed derivatives diverge. Derivatives may
   determine how large a frequency is chosen, but cannot enter an uncontrolled
   leading cost.
4. The construction must have bounded temporal overlap. Summing an order-one
   cost over infinitely many fresh strips is not a valid total-variation
   estimate.

The full-plane raster worker reported exact force-replacement and
antidivergence building blocks with derivative-independent leading curl cost,
but explicitly identified the smooth complete schedule and compact time
localization of all correctors as remaining obligations. Those building
blocks are not substituted for the one-step property below.

The main positive finding here is that arbitrary negative-Sobolev smallness
of the corrections is **not required** for the initial trace if the exact
Euler--Reynolds identity, uniformly bounded stress, and time localization are
available. A colored time cover supplies exact anchor times approaching zero.

## 2. Trace preservation through gaps

### Lemma T: a localized correction has weakly zero initial trace

Let \(U,\widetilde U\) be smooth divergence-free velocities on
\((0,T)\times\mathbb R^2\), solving Euler--Reynolds in the convention
\[
 \partial_t U+\operatorname{div}(U\otimes U)+\nabla p
   =\operatorname{div}R,
\]
and analogously with \(\widetilde U,\widetilde R\). It suffices that
these equations hold against divergence-free tests. Assume
\[
 \sup_{0<t<T}\|U(t)\|_{L^2(B)}+
 \sup_{0<t<T}\|\widetilde U(t)\|_{L^2(B)}<\infty
 \quad\text{for each bounded ball }B,
\]
\[
 \sup_{0<t<T}(\|R(t)\|_1+\|\widetilde R(t)\|_1)<\infty,
 \qquad
 \sup_{0<t<T}\|W(t)\|_2<\infty,
 \quad W=\widetilde U-U.
\]
Suppose there are times \(t_k\downarrow0\) with \(W(t_k)=0\). Then
\(W(t)\rightharpoonup0\) in global \(L^2\) as \(t\downarrow0\).
Thus, if \(U\) has the target weak local \(L^2\) trace \(u_0\), so
does \(\widetilde U\).

**Proof.** For any compactly supported smooth divergence-free spatial test
\(\psi\), the difference of the equations gives
\[
 \frac d{dt}\int W\cdot\psi
 =\int(\widetilde U\otimes\widetilde U-U\otimes U):\nabla\psi
   -\int(\widetilde R-R):\nabla\psi.
\]
The hypotheses bound the right side uniformly in \(t\). The pairing is
therefore Lipschitz and has a limit at zero. Its values at \(t_k\) are
zero, so that limit is zero.

For any sequence tending to zero, a subsequence of \(W(t)\) has a weak
global \(L^2\) limit \(W_*\). It is divergence-free and annihilates
every compactly supported smooth divergence-free test. Choosing
\(\psi=\nabla^\perp\phi\) shows \(\operatorname{curl}W_*=0\).
In Fourier variables, the simultaneous divergence and curl constraints force
\(\widehat W_*(\xi)=0\) for almost every \(\xi\ne0\); an \(L^2\)
function has no nonzero zero-frequency point mass. Thus \(W_*=0\).
Every possible subsequential weak limit is zero, proving the full weak
limit. \(\square\)

No energy inequality, vorticity transport theorem, or pointwise vorticity
bound is used in Lemma T. Its global \(L^2\) assumption is on the
**correction**, so a nonzero-circulation background is permitted.

## 3. Exact conditional one-step property

Fix a class of smooth positive-time Euler--Reynolds pairs containing the
seed, with all auxiliary norms needed by the local construction finite on
compact positive-time intervals. This class must remain stable under the
locally finite temporal pasting described below. In particular velocities
and stresses remain smooth, stresses are globally \(L^1\) in space,
and added velocities are globally \(L^2\) with curl in \(L^1\).
If a concrete construction needs a background \(L^4\) or \(L^3\) norm,
or derivatives of the stress in \(L^1\), its finiteness and preservation
must be checked separately; it is not inferred from a local energy bound.

The required one-step assertion is the following property **P**.

For any current pair \((U,R)\) in this class, any open time patch
\(J\Subset(0,\infty)\), and any smooth symmetric prescribed stress
\(S\) compactly supported in time in \(J\), with
\[
 d=\sup_{t\in J}\|S(t)\|_1<\infty,
\]
and any two positive tolerances \(\epsilon,\zeta\), there are smooth
\(w,E\), compactly supported in time in \(J\), such that
\[
 (U+w,\ R-S+E)
\]
is again an Euler--Reynolds pair in the same class,
\(\operatorname{div}w=0\), \(E\) is symmetric, and
\[
 \sup_t\|E(t)\|_1\leq\epsilon,
 \qquad
 \sup_t\bigl(\|w(t)\|_2+\|\operatorname{curl}w(t)\|_1\bigr)
       \leq C\sqrt d+\zeta.                       \tag{P}
\]
The constant \(C\) must be independent of the patch location, patch length,
and the large derivative norms of \(U,S\). Dependence through frequency
choices and other parameters is allowed. More generally a bound with
constants depending on controlled a priori norms would suffice if those
constants are proved uniformly bounded throughout the iteration.

Spatial compact support of \(S\) is optional in this statement. If a
proved repair lemma requires it, one must first approximate the desired
\(S\) uniformly in time in global \(L^1\) by spatially compact pieces
and charge the omitted tail to \(\epsilon\). Uniform tail approximation
on \(J\) follows if \(t\mapsto S(t)\) is continuous into \(L^1\):
its image is compact and a finite-net argument supplies one common spatial
cutoff. The actual stress-tail error, including its symmetry and time
support, then remains explicit.

Property P is stronger than nearby endpoint controllability. It is also
stronger than a repair estimate with a large uncontrolled multiplicative
constant depending on \(\|\partial_t^kD_x^\ell U\|\).

## 4. Conditional global iteration theorem

### Theorem I

Suppose a smooth positive-time seed \((U^{(0)},R^{(0)})\) solves
Euler--Reynolds on \((0,\infty)\times\mathbb R^2\), with the exact
initial trace \(u_0=K*\omega_0\). Assume:

- \(U^{(0)}\in C_w([0,\infty);L^2_{\rm loc})\), and is strongly
  continuous in local \(L^2\) at positive times;
- for each \(T<\infty\), its local velocity energy, its global curl
  \(L^1\) norm for \(0<t\leq T\), and
  \(\sup_{0<t\leq T}\|R^{(0)}(t)\|_1\) are finite;
- at every positive time \(U^{(0)}(t)=K*\operatorname{curl}U^{(0)}(t)\);
- the admissible class and property P are available for the seed and every
  pair generated below, with the uniform constant specified in P.

Then there is a global solution with every requirement of the target.
Moreover its vorticity is globally \(L^1\) at every positive time, with
locally uniform total variation up to time zero. Strong continuity in local
\(L^2\) holds at positive times; only the required weak continuity is
asserted at zero.

### Proof: the time cover

Choose a nonnegative \(\eta\in C_c^\infty((1/2,2))\) whose dyadic
dilates cover \((0,\infty)\), and define
\[
 I_j=(2^{j-1},2^{j+1}),\qquad
 \chi_j(t)=\frac{\eta(t/2^j)}{\sum_{k\in\mathbb Z}\eta(t/2^k)}.
\]
The denominator is positive. The partition is locally finite on positive
times, \(\sum_j\chi_j=1\), and \(\operatorname{supp}\chi_j\Subset I_j\).
Use three colors \(j\bmod3\). Intervals of one color are disjoint and
leave open gaps; for \(j\) of that color, the time \(3\cdot2^j\) lies
between \(I_j\) and \(I_{j+3}\). These gap times approach zero as
\(j\to-\infty\). Let \(N=3\), a valid uniform overlap bound.

Choose a smooth nondecreasing function \(\Theta\geq1\), finite on every
bounded time interval including zero, with
\(\|R^{(0)}(t)\|_1\leq\Theta(t)\). Such a majorant exists from the
seed bounds. Put \(\delta_q=16^{-q}\). Inductively require
\[
 \|R^{(q)}(t)\|_1\leq\delta_q\Theta(t).           \tag{I.1}
\]

### Proof: one complete stage

Freeze the prescribed pieces
\(S_{qj}=\chi_jR^{(q)}\) before making any changes at this stage. Let
\[
 M_j=\sup_{I_j}\Theta,\qquad m_j=\inf_{I_j}\Theta\geq1.
\]
Apply P with
\[
 \epsilon_{qj}=\delta_{q+1}m_j/N,
 \qquad \zeta_{qj}=\sqrt{\delta_q}/N.
\]
First process all patches of the first color, then the second and third.
Within one color the patches are disjoint, so the outputs can be pasted
simultaneously without a quadratic cross term between different patches.
Every compact positive-time interval meets only finitely many patches.
Between colors use the newly current velocity and stress as input to P,
while still removing the frozen prescribed piece \(S_{qj}\).

The exact identity is retained at every patch and every color. At the end,
\[
 U^{(q+1)}=U^{(q)}+w_q,
 \qquad R^{(q+1)}=\sum_jE_{qj},
 \qquad w_q=\sum_jw_{qj}.
\]
At a given time there are at most \(N\) nonzero summands and
\(m_j\leq\Theta(t)\) for each active patch. Hence
\(\|R^{(q+1)}(t)\|_1\leq\delta_{q+1}\Theta(t)\), proving
(I.1). During the intermediate colors the stress has the form
\[
 \left(1-\sum_{j\text{ already processed}}\chi_j\right)R^{(q)}
       +\sum_{j\text{ already processed}}E_{qj}.
\]
The prefactor lies in \([0,1]\), so the intermediate stress is bounded
by \((\delta_q+\delta_{q+1})\Theta(t)\).

For \(0<t\leq T\), any active \(I_j\) lies below \(4T\). Thus
\[
 \sup_{0<t\leq T}
 \bigl(\|w_q(t)\|_2+\|\operatorname{curl}w_q(t)\|_1\bigr)
 \leq [NC\sqrt{\Theta(4T)}+1]\sqrt{\delta_q}.      \tag{I.2}
\]
The right sides are summable in \(q\). Intermediate color increments
satisfy the same type of bound.

### Proof: exact trace at every stage

At one color the total correction is zero at its gap times tending to zero.
Its global \(L^2\) norm is uniformly bounded near zero by (P), and both
old and new stresses have the bounds just established. The seed and all
preceding increments give uniform local velocity energy. Lemma T therefore
shows that the correction has weakly zero initial trace. There are only
three colors, so one complete stage preserves the exact trace \(u_0\).
Induction gives that trace at every stage.

There is no passage from merely nearby traces in this argument. The exact
anchor values come from compact time support, and the between-anchor
control comes from the exact Euler--Reynolds identity and bounded stress.

### Proof: convergence, vorticity, and Biot--Savart

By (I.2), the correction series converges uniformly in global \(L^2\)
on every finite time interval \((0,T]\). On every positive compact time
interval its terms are strongly continuous in local \(L^2\), by their
joint smoothness. Uniform global \(L^2\) control of the tails therefore
makes the sum strongly continuous in local \(L^2\) there. Denote the
resulting velocity by \(u\).

Each stage correction has weakly zero global \(L^2\) trace at zero.
For a fixed global \(L^2\) test, split the series into finitely many
terms and a uniformly small \(L^2\) tail; the finite terms tend weakly
to zero and the tail is bounded by its norm. Thus the total correction also
has weakly zero global \(L^2\) trace. Together with the seed trace and
local energy bound this proves
\(u\in C_w([0,\infty);L^2_{\rm loc})\), with \(u(0)=u_0\).

For every fixed \(t>0\), (I.2) also gives convergence of the curl series
in \(L^1\). Its sum is the distributional curl of the velocity limit.
Consequently
\[
 \sup_{0<t\leq T}\|\operatorname{curl}u(t)\|_1
 \leq \sup_{0<t\leq T}\|\operatorname{curl}U^{(0)}(t)\|_1
   +[NC\sqrt{\Theta(4T)}+1]\sum_q\sqrt{\delta_q}<\infty.
\]
Adding the finite initial norm gives the target bound including \(t=0\).

At each positive time, let \(w=u-U^{(0)}\in L^2\), and let
\(\tau=\operatorname{curl}w\in L^1\). The canonical Biot--Savart
field \(K*\tau\) belongs to global weak \(L^2\), since
\(K\in L^{2,\infty}\) and \(\tau\) is finite. It has divergence
zero and curl \(\tau\). Thus \(w-K*\tau\) is a tempered harmonic
vector distribution. Such a distribution is a harmonic polynomial; no
nonzero polynomial belongs to weak \(L^2\). Hence
\(w=K*\tau\). Adding the seed Biot--Savart identity gives the required
identity for \(u(t)\). It holds at zero by the prescribed datum.

### Proof: exact Euler and initial weak formulation

On every compact positive-time cylinder, the velocity convergence is strong
in \(L^2\). Therefore the quadratic products converge in \(L^1\).
The stress tends to zero in \(L^1\) by (I.1). Passing to the limit in
the divergence-free weak identities gives Euler on \((0,\infty)\).

To include time zero, multiply a target test by a smooth temporal cutoff
which rises from zero to one on \((\varepsilon,2\varepsilon)\).
The local uniform energy bound makes the omitted convection integral tend
to zero. Weak local \(L^2\) continuity, and smoothness of the fixed test,
identify the cutoff-derivative term with
\(\int u_0\cdot\varphi(0)\). The remaining terms converge directly.
This is exactly the initial-value weak formulation in the target. The
construction is on \((0,\infty)\) from the outset, so no separate
finite-horizon solutions need to be reconciled. \(\square\)

## 5. Why nearby endpoint traces do not suffice

Gluing exact Euler solutions on adjacent strips produces the additional
distributional term
\[
 \sum_n (u(t_n+)-u(t_n-))\,\delta_{t_n}
\]
in the time derivative. A small but nonzero mismatch is still a nonzero
residual at each fixed seam. Refining only strips nearer zero does not remove
an error at a previously fixed positive seam. Pressure cannot absorb a
general divergence-free jump with nonzero curl.

For a direct test, take zero velocity before one seam and a small nonzero
smooth compactly supported stationary radial swirl after it. Both pieces
solve Euler, have finite total vorticity and finite energy, and their traces
can be made arbitrarily close. The joined velocity has a nonzero jump and
fails the weak Euler identity. Thus endpoint approximation is not an exact
gluing theorem.

An alternative exact-strip approach would work if each strip solution had
exactly the same trace as its neighbor, with uniform local energy and
vorticity variation. The seam terms would then cancel. If their common
traces approach \(u_0\), Euler's uniformly bounded compact test pairings
would control the times between seams. But constructing those exact
endpoints is itself an additional theorem, not supplied by nearby endpoint
controllability.

## 6. Remaining obligations for an actual construction

Theorem I separates the infinite iteration from the hard one-step question.
To invoke it, the construction still needs a proved version of P with:

- prescribed-piece removal for a changing current background, so finite
  coloring can be applied without ignoring overlap interactions;
- exact compact time support of the principal perturbation, divergence
  correction, temporal antiderivative correction, and stress error;
- global \(L^1\) stress-error estimates on the full plane, including the
  background cross terms; small \(L^2\) and curl variation alone do not
  establish those estimates;
- the derivative-independent leading bounds in (P), with one simultaneous
  parameter choice satisfying all error and localization requirements;
- stability of the admissible smooth class on positive-time compacts,
  including any global \(L^3\), \(L^4\), or \(L^1\)-derivative norms
  required by the concrete raster construction;
- independent verification of the exact-data seed for noncompact data and
  nonzero circulation.

The strip iteration does not require a uniform \(L^p\) vorticity bound
for any \(p>1\), a strong initial velocity trace of the final solution,
or compact spatial support of its vorticity. In particular it does not
silently remove singular initial measures from the target class.

VERIFICATION STATUS: Theorem I and Lemma T are worker proofs submitted for
independent hostile audit. Property P remains an unproved construction
interface, so the target remains unresolved by this route.

## 7. Piecewise-time version matching finite raster cycles

This section replaces the temporal smoothness requirements by the weaker
ones actually needed in Theorem I. It does not claim that all estimates in
the raster construction have been verified.

### Admissible class and modified property

At each finite stage permit:

- \(U\in C((0,\infty);L^2_{\rm loc})\cap
  C((0,\infty);L^3(\mathbb R^2))\); spatial smoothness of the old
  velocity is not required;
- a symmetric stress \(R\), bounded in global \(L^1\) on every finite
  time interval down to zero, which is continuous into \(L^1\) on each
  closed piece of a locally finite positive-time partition, using one-sided
  values at its boundaries;
- the exact Euler--Reynolds identity in distributions, rather than a
  classical time derivative at the partition boundaries.

Replace P by \(P_{\rm pw}\): the same prescribed-piece removal and the
same bounds (P), but the output velocity correction is continuous into
\(L^2\cap L^3\cap L^{3/2}\), its stress error is piecewise continuous
into \(L^1\), and only finitely many new boundaries occur inside each
compact time patch. Both outputs still have compact time support in that
patch. Any specific construction may use an arbitrarily small
\(L^{3/2}\) norm to achieve the stress-error tolerance; no uniform bound
on the new correction's \(L^3\) norm is needed across all stages.

The prescribed \(S=\chi_jR^{(q)}\) may be piecewise continuous in
\(L^1\). A finite subdivision at its inherited jump times is allowed.
Within each closed continuity piece, a finite freezing partition must
approximate it uniformly in global \(L^1\) to the requested tolerance.
Its spatial approximation and any finite-direction decomposition belong to
proving \(P_{\rm pw}\); they are not consequences of this abstract lemma.

If the available local repair accepts only spatially smooth stresses,
approximate this prescribed piece by a symmetric spatially smooth compact
piece \(\widetilde S\), uniformly on each continuity cell, with
\(\sup_t\|S-\widetilde S\|_1\leq\epsilon/2\). Apply the repair to
\(\widetilde S\) with stress tolerance \(\epsilon/2\), and define its
error relative to the desired removal by
\(E_{\rm desired}=E+S-\widetilde S\). Then
\(R-\widetilde S+E=R-S+E_{\rm desired}\) exactly. The velocity is not
mollified in this operation, so no old-velocity commutator is introduced.
The smooth piece has norm at most \(d+\epsilon/2\). With the stage
tolerances used in Theorem I, \(\epsilon\leq C\delta_qM_j\), so its
leading repair cost remains bounded by a fixed constant times
\(\sqrt{\delta_qM_j}\). Smooth approximation and spatial truncation
can preserve symmetry and time support. Finite freezing partitions and the
compact-image tail argument below supply the uniform approximation.

**Claim.** Theorem I holds with this class and \(P_{\rm pw}\).

**Proof.** Lemma T needs only the distributional identity, the stated
integrability bounds, and continuity of the compact spatial pairings at
positive times. Their distributional derivatives are bounded functions, so
the pairings have the Lipschitz representative used in that proof. Positive
time continuity identifies the given representative with it. Therefore its
trace argument is unchanged.

Pasting continuous velocity corrections across finitely many cell boundaries
introduces no delta into \(\partial_tU\). A jump in their time derivative
is harmless. Stress jumps introduce no temporal delta because the stress
appears only under spatial divergence. Thus the exact identities paste in
distributions. Each color still leaves the same gap times approaching zero,
and the bounds and algebra of Theorem I are unchanged.

At every fixed finite stage, the inherited boundary set is locally finite:
each compact positive-time interval meets finitely many dyadic patches;
inside each patch there are finitely many old boundaries and, by hypothesis,
finitely many new frozen cells and cycles. Taking the union over the three
colors preserves this property. This is an induction over finite stages.
The union over **all** stages need not be locally finite and is not claimed
to be. The final limit does not require such a property, since strong local
\(L^2\) convergence supplies the quadratic limit and continuity.

The seed and every newly added correction are continuous into global
\(L^3\) on positive-time compacts. At any fixed stage only finitely many
patch outputs are active on one such compact, so the current background is
continuous and bounded in \(L^3\) there. New frequencies may depend on
that bound, even if it grows with the stage or near time zero. The leading
cost in (P) must remain independent of it. All remaining steps of Theorem I
are unchanged. \(\square\)

### Exact support of the temporal corrector

For one cycle \([a,b]\), an exact corrector of the form
\[
 Q(t)=-P\int_a^t(F(s)-\overline F)ds,
 \qquad \overline F=(b-a)^{-1}\int_a^bF(s)ds,
\]
satisfies \(Q(a)=Q(b)=0\). If \(F\in L^1([a,b];L^p)\),
\(1<p<\infty\), the boundedness of the Leray projection on \(L^p\)
shows \(Q\in C([a,b];L^p)\). Extending it by zero produces no temporal
delta: integration by parts against a time test has boundary terms
\(Q(b)\phi(b)-Q(a)\phi(a)=0\). Its first time derivative may jump,
which is allowed by the piecewise class.

Endpoint vanishing is enough here. Vanishing on a neighborhood of **every
internal cycle endpoint** is unnecessary. To obtain compact support inside
the larger patch \(J\), place its finitely many cycles in one closed
interval \([a,b]\Subset J\); then the full correction is zero outside
\([a,b]\). A mean defined only approximately would leave
\(Q(b)\ne0\), destroying this argument. The averaging identity must
therefore be exact, with approximation errors assigned to the stress rather
than to the mean-zero time identity.

### Why bounded old-velocity \(L^3\) is available on each cell

For the initial seed, this is an explicit additional checked interface:
the smooth low-frequency Euler background has finite vorticity and bounded
velocity, hence it belongs to global \(L^3\) by weak-\(L^2\) control
and interpolation. Its bounds are uniform on compact time intervals. The
regularized finite-energy component is in \(L^2\cap L^\infty\) away
from zero, hence also in \(L^3\). Continuity in these norms, or directly
in \(L^3\), must be verified for the chosen seed.

For a new principal block, fix its spatial mollification scale \(\ell>0\)
on an entire finite time cell. Convolution maps global \(L^2\) to
\(L^3\) with norm \(C\ell^{-1/3}\), by Young's inequality. A
principal dipole which is continuous in \(L^2\) during the cell, and has
zero \(L^2\) limit at its reset times, therefore yields a mollified block
continuous in \(L^3\), including the resets. Its \(L^3\) norm may be
large but is finite. The time corrector is continuous in \(L^3\) by the
previous paragraph. Finite addition and exact zero endpoint values preserve
that property at the cell boundaries.

Thus there is no need to remollify the whole old velocity. If a new
correction is small in \(L^{3/2}\), the old-new interaction is bounded by
\[
 \|U\otimes w+w\otimes U\|_1
 \leq2\|U\|_3\|w\|_{3/2}.
\]
For a fixed cell the old norm is finite, so arbitrary smallness of the new
\(L^{3/2}\) norm can make this interaction smaller than the requested
stress tolerance. Claiming this estimate from small \(L^2\) alone would
be invalid on the whole plane.

### Uniform spatial tail control at a later stage

A finite union of compact images of closed time cells under continuous
\(L^1\)-valued stresses is compact in \(L^1\). Given a tolerance,
take a finite net and choose one sufficiently large spatial ball controlling
the tails of every net element. The triangle inequality then controls all
stresses in those cells uniformly. Thus later stages can truncate the
stress to a finite spatial box with uniform error on each time patch,
provided the claimed piecewise \(L^1\) continuity is verified for the
actual stress formulas. Mere \(L^\infty_tL^1_x\) boundedness would not
provide this compactness.

### Audit amendment

An independent reader accepted the trace and coloring arguments but noted
that joint smoothness and bounded global \(L^2\) norm alone do not imply
strong continuity in **global** \(L^2\), because energy can arrive from
spatial infinity. The convergence paragraph of Theorem I was corrected to
use strong continuity in **local** \(L^2\), which is sufficient for every
claimed conclusion. The piecewise class above explicitly assumes global
\(L^2\) continuity of each finite new corrector, as supplied by its
finite-cycle formulas; no such global continuity is inferred for an arbitrary
smooth field.
