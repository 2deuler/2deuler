# Independent hostile audit: signed compactness packet

AUDITED_FILE: `route_signed_compactness.md`

FROZEN_SHA256: `22b1bea72797e839661840f6796bfc852c07bf59242212f48f0204593cad8ccb`

VERIFICATION_MODE_AND_PROVENANCE: One independent reconstruction and hostile counterexample pass by worker `/root/jordan_energy`; all sections A–H were read. This is a claim-level research-packet audit, not a four-pass TeX manuscript completeness certificate. No claim of full procedural completeness under the attached forensic-audit protocol is made.

## Verdict

**PASS for the mathematical conditional bridge, counterexamples, and angular formula in A–C and F–G.** No material mathematical error was found in those results. The claimed external interfaces in H were checked directly against the primary source and match it. The Schochet abstract lead in D remains independently unverified because the publisher returned HTTP 403; it is explicitly non-load-bearing in the source packet.

The packet does not prove the Euler target: the dynamical signed-diagonal condition (SD) remains an additional hypothesis. Its necessity is only for the specified convergent subsequence.

## Source-ordered claim ledger

| ID | Source claim | Status | Independent reconstruction or limitation |
|---|---|---|---|
| A01 | Smooth Euler solutions with uniform TV and every-time local energy are the hypotheses. | VERIFIED SCOPE | These are conditional inputs, not conclusions claimed from the original datum. |
| A02 | Smoothness may be replaced by a vanishing residual and equicontinuity. | UNFORMALIZED, UNUSED | The topology and test class for the residual are not specified. A precise version must require the scalar weak-vorticity identity for every compact smooth spacetime test with residual tending to zero, together with the stated bounds and sufficient temporal equicontinuity. This optional sentence is not used later. |
| A03 | Symmetry, coefficient, and boundedness of \(H_\psi\). | VERIFIED | Both factors change sign under exchanging \(x,y\), giving symmetry. The gradient difference is bounded by \(\|D^2\psi\|_\infty|x-y|\); multiplying by the Biot–Savart factor gives exactly \(1/(4\pi)\). |
| A04 | Values on the diagonal may be assigned arbitrarily. | VERIFIED IN SCOPE | Smooth approximants and the subsequently proved atomless limit give zero absolute product mass to the diagonal. This would be false for arbitrary atomic input measures, which are not used at this step. |
| A05 | (SD) has the stated sufficient quantifier order. | VERIFIED | Fixed test, then \(\limsup_n\), then \(\delta\downarrow0\). Subsequence extraction preserves this property. No uniformity over all tests is needed after a subsequence with uniform measure convergence is extracted. |
| A06 | One global solution follows by diagonalization over finite intervals. | VERIFIED | Extract nested subsequences on integer time intervals; restrictions of the limiting curves agree by uniqueness of distributional limits. The bounds may depend on the interval. |
| A07 | Smooth vorticity pairings have the stated derivative and Lipschitz bound. | VERIFIED | The compact test makes the transport integral finite. Symmetrizing the absolutely integrable smooth Biot–Savart pairing gives \(H_\zeta\), and its supremum times \(M^2\) gives the stated constant. |
| A08 | Countable-test Arzelà–Ascoli gives uniform-in-time weak-* measure convergence. | VERIFIED | Choose a countable dense subset of \(C_0\) consisting of compact smooth functions, diagonalize their scalar equicontinuous curves, and extend uniformly using the common TV bound. A bounded limiting functional exists at every time. |
| A09 | No tightness is required; the limit curve is weak-* continuous and has correct initial measure. | VERIFIED | The topology is precisely duality with \(C_0\), allowing mass loss at infinity. Uniform convergence of every such scalar pairing gives continuity and the initial trace. |
| A10 | \(F_f(y)=\int K(x-y)\cdot f(x)dx\) is in \(C_0\). | VERIFIED | The local singular part contributes at most \(C\delta\|f\|_\infty\), the complement is continuous, and the far field is \(O(|y|^{-1})\). |
| A11 | The canonical velocity limit exists in \(L^2(B_R)\) at every time. | VERIFIED | For each fixed time, the distributional limiting functional is bounded by \(E_R\|f\|_2\) on compact tests, so Riesz representation yields an \(L^2\) function with the same bound. No almost-every-time selection is made. |
| A12 | The velocity is weakly continuous on every bounded subdomain. | VERIFIED | Uniform convergence for compact smooth vector tests plus density in \(L^2(B_R)\) and the common bound extend the scalar continuity to all \(L^2\) tests. Restriction to any bounded subdomain follows by zero extension of test functions. |
| A13 | Divergence zero, measure curl, and Biot–Savart equality hold for every time. | VERIFIED | These follow in distributions from the convolution identities and the preceding every-time construction. No undetermined harmonic field is introduced. |
| A14 | Every fixed-time signed limiting measure is atomless. | VERIFIED | The logarithmic cutoffs have vanishing \(H^1\) norm and converge pointwise to the point indicator. Duality with the signed curl and dominated convergence against its TV isolate the atom. The displayed Dirichlet energy is correct for \(k\geq2\). |
| A15 | The absolute variation is atomless as well. | VERIFIED | For a signed measure, \(|\mu|(\{a\})=|\mu(\{a\})|\). This does not assert \(|\mu|\in H^{-1}\). |
| A16 | The cutoff off-diagonal kernel is continuous and has controlled spatial tails. | VERIFIED | It is identically zero near the only singular set. If both variables are outside the gradient support the kernel vanishes; otherwise a distant variable gives the \(1/R\) bound. The corresponding time-integrated error includes an additional harmless factor \(T\). |
| A17 | Products pass to the limit off the diagonal. | VERIFIED | After compact truncation, finite sums of product functions approximate the continuous kernel uniformly. Uniform scalar weak-* convergence handles every factor. For time-dependent tests, pointwise convergence and the uniform \(M^2\) bound suffice for dominated convergence. |
| A18 | The limit's absolute product diagonal tube mass vanishes. | VERIFIED | Continuity from above of the finite product measure reduces to its diagonal mass, equal to the integral of singleton masses. This is zero. The time-dependent integrands are measurable under the weak-* continuous curve, and bounded by \(M^2\). |
| A19 | (SD) and off-diagonal convergence yield the limiting scalar identity. | VERIFIED | First keep \(\delta>0\) fixed, then let \(n\to\infty\), and finally use (SD) and the limit's own diagonal vanishing as \(\delta\downarrow0\). This avoids interchanging an uncontrolled pair of limits. |
| A20 | Fixed-measure identity (I), including the minus sign. | VERIFIED | Mollified velocities converge strongly in local \(L^2\). The smooth identity is \(\int u\otimes u:\nabla\nabla^\perp\psi=-\int\omega u\cdot\nabla\psi\), since \((u\cdot\nabla)u=\nabla(|u|^2/2)+\omega u^\perp\). Symmetrization gives the printed negative sign. |
| A21 | Fixed-measure mollifications have uniform diagonal control. | VERIFIED WITH CONVENTION | Choose the standard mollifier supported in \(B_1\), so its scaled support is \(B_\varepsilon\). Positivity gives \(|\rho_\varepsilon*\mu|\leq\rho_\varepsilon*|\mu|\), hence the printed ball bound. The limit \(\sup_x|\mu|(B_r(x))\to0\) follows from nonatomicity and finite mass, including centers escaping to infinity. |
| A22 | Every compact divergence-free spacetime vector test has a compact smooth stream function. | VERIFIED | Set \(\psi(t,x)=\int_{-\infty}^{x_1}\varphi_2(t,s,x_2)ds\). Divergence zero gives \(\partial_2\psi=-\varphi_1\). The integral at \(x_1=+\infty\) is constant in \(x_2\), and is zero outside the common spatial support, hence zero everywhere. Thus \(\psi\) has common compact spatial support and the same temporal support. Holes in the support cause no obstruction. |
| A23 | The scalar limiting identity is exactly the target velocity weak identity. | VERIFIED | Apply A20 and \(\int u\cdot\nabla^\perp\psi=-\int\psi\,d\omega\), then multiply the scalar identity by minus one. The initial velocity equals \(K*\omega_0\) through the every-time construction. |
| A24 | The Navier–Stokes modification needs no \(\nu\nabla u\) estimate. | VERIFIED | Testing scalar diffusion gives \(\nu_n\langle\omega_n,\Delta\zeta\rangle\); TV bounds it by \(\nu_n M\|\Delta\zeta\|_\infty\). The sequence of viscosities is bounded and tends to zero, respectively giving equicontinuity and disappearance of the residual. |
| A25 | (SD) is necessary for an Euler limit within this compactness setup. | VERIFIED SUBSEQUENCE SCOPE | The smooth weak identities determine convergence of the full nonlinear time integral through convergence of linear terms. Subtract the convergent fixed-cutoff terms; the remaining limit is the limit solution's cutoff integral, tending to zero. This proves (SD) along that convergent subsequence, not along arbitrary discarded indices. |
| B01 | (NC) implies (SD), with the printed bound. | VERIFIED | Integrate the ball mass against \(|\omega_n(t)|\), use its total mass at most \(M\), then the supremum bound for \(H_\psi\). |
| B02 | Initial mollifications satisfy nonconcentration. | VERIFIED INTERPRETATION | The intended initial-time statement is \(\lim_{r\downarrow0}\limsup_n\sup_x|\omega_n(0)|(B_r(x))=0\). The time-integrated formula (NC) itself is not literally a condition at a single time. No propagation claim is made. |
| B03 | Area preservation does not by itself propagate ball-mass control for arbitrary measures. | VERIFIED | It controls only Lebesgue measure of images. Singular measure mass may occupy thin elongated preimages of small balls. Additional regularity of the map or the measure is required. |
| C01 | Compact profile and scaled fields have the specified curl/divergence and Biot–Savart relation. | VERIFIED | \(\operatorname{curl}\nabla^\perp\Psi=\Delta\Psi\). Integration by parts against the fundamental solution proves \(K*\Delta\Psi=\nabla^\perp\Psi\); equivalently use a globally smooth decaying harmonic difference. Scaling yields the printed powers. |
| C02 | Energy, TV, \(H^{-1}\), and zero-mass assertions. | VERIFIED | Two-dimensional changes of variables preserve \(\|v_\varepsilon\|_2\) and \(\|\zeta_\varepsilon\|_1\). Curl duality gives \(\|\zeta_\varepsilon\|_{H^{-1}}\leq\|v\|_2\), and integrating a compact Laplacian gives zero. |
| C03 | Weak velocity and measure limits are zero. | VERIFIED | Shrinking velocity supports and the absolute continuity of the \(L^2\) test norm prove weak velocity convergence; zero signed mass and uniform continuity of compact tests prove weak-* measure convergence. |
| C04 | Stress concentration matrix is \(C\operatorname{diag}(2,1/2)\). | VERIFIED | Directly squared \(v_1=-2f(x_1)f'(2x_2)\), \(v_2=f'(x_1)f(2x_2)\). The two diagonal integrals are \(2C\) and \(C/2\); \(\int ff'=0\) kills the mixed term. |
| C05 | The selected divergence-free test detects \(3C/2\). | VERIFIED | Near zero, \(\nabla^\perp(-x_1x_2)=(x_1,-x_2)\), whose derivative is \(\operatorname{diag}(1,-1)\). The contraction is \(2C-C/2\). |
| C06 | Absolute measures concentrate although the signed limit is atomless. | VERIFIED | Rescaling \(|\zeta|\) gives its full mass at the origin; this does not contradict any property of the signed zero limit. |
| C07 | The example is not an Euler nonexistence counterexample. | VERIFIED SCOPE | It is only a sequence of spatial fields and does not have the assumed smooth Euler evolution or one strongly approximated initial datum. |
| D01 | Schochet bibliography and Hölder-path abstract lead. | NOT INDEPENDENTLY VERIFIABLE IN THIS PASS | The publisher URL returned 403. Other primary references confirm the bibliography, but the specific abstract claim was not independently read here. It is not used as a theorem. |
| D02 | Cheverry–Guès abstract concerns failure of weak local \(L^2\) closure without certifying a uniform vorticity-measure bound. | VERIFIED SOURCE INTERFACE | The publisher abstract directly states the weak closure failure and does not state that extra vorticity bound. No stronger theorem was imported. |
| D03 | Domínguez–Spector lead is a maximal-function rate criterion, not bare measure control. | VERIFIED SOURCE INTERFACE | The arXiv abstract states a uniform logarithmic decay assumption on vorticity maximal functions. The explicit concentrating fields in C show that uniform TV plus signed \(H^{-1}\) alone do not supply such decay. |
| E01 | The remaining obligation is dynamical (SD), and the cited routes are future work. | VERIFIED SCOPE | None of these programmatic statements is represented as a solved theorem or a proof of the exact target. |
| F01 | Moving-packet norms and weak temporal Lipschitz estimate. | VERIFIED | Translation preserves the norms; \(|a_n'|\leq n\) cancels the \(1/n\) from the gradient difference. The resulting test bound is exactly the printed second-derivative norm. |
| F02 | Signed moving packets converge uniformly in time to zero. | VERIFIED | Subtract the test value at the center and use \(\int\zeta=0\); the error is uniformly \(O(1/n)\). The extra vanishing first moment of a compact Laplacian is available but unnecessary. |
| F03 | Absolute products have the diagonal arcsine spacetime limit. | VERIFIED | Uniform continuity replaces each pair of microscopic positions by the center. Periodic averaging on finite time partitions yields the angular mean; sine pushforward of the uniform angle law is the arcsine probability. The displayed limit has total mass \(m^2\), not one. |
| F04 | The limiting product is not a spatial product measure. | VERIFIED | It has positive mass \(m^2\) on the diagonal, whereas the product of any diffuse marginal with itself assigns zero mass there. The prose calling the marginal “the arcsine law” suppresses its harmless factor \(m^2\). |
| F05 | No subsequence of absolute measures converges at almost every time. | VERIFIED | A fixed compact test equal to \(x_1\) on the common support gives \(m\sin(nt)+O(1/n)\). Almost-everywhere convergence would imply strong \(L^2_t\) convergence by boundedness, contradicting orthogonality and constant squared norm \(\pi\). |
| F06 | Stress has the stated anisotropic limit and the residual is not vanishing Euler residual. | VERIFIED | The same averaging applies to the rescaled stress. A spatial test equal to \((x_1,-x_2)\) near the segment and a nonzero nonnegative time cutoff detects a nonzero quadratic term, while the linear terms tend to zero. |
| G01 | A quadratic spacetime product limit exists locally and absence of its diagonal mass implies (SD). | VERIFIED | Restrict using a compact spatial cutoff equal to one on a neighborhood of the relevant test support. Uniform TV gives finite measure compactness. Portmanteau on closed diagonal tubes and continuity from above yield vanishing tube mass; tails are handled as in A16. |
| G02 | Diffuseness of the linear spacetime limit alone is insufficient. | VERIFIED | The independently reconstructed F example has diffuse arcsine marginal and entirely diagonal quadratic limit. |
| G03 | A fixed-time absolute weak-* limit factorizes and its diagonal is the sum of squared atoms. | VERIFIED | Uniform TV permits product convergence by compact-product approximation and tails. The diagonal mass disintegrates into singleton masses, yielding the displayed countable atomic measure. |
| G04 | Scalar energy defects may diffuse for steady Euler sequences. | VERIFIED SOURCE INTERFACE | Directly checked De Rosa–Park Proposition 7.2 and Remark 7.4; this concerns scalar energy, not failure of the Euler nonlinear identity. |
| G05 | The angular Taylor formula, coefficient, trace, and error are correct. | VERIFIED | Writing \(z=x-y\), \(\nabla\psi(x)-\nabla\psi(y)=D^2\psi(x)z+O(|z|^2)\). Contraction with \(z^\perp/|z|^2\) gives the printed symmetrized matrix and an \(O(|z|)\) error. Its trace is \(z\cdot z^\perp/|z|^2=0\); the integrated bound is \(C\delta TM^2\). |
| G06 | Scalar signed product cancellation does not force angular cancellation. | VERIFIED | Section C has signed product limit zero but the explicitly nonzero anisotropic test pairing. |
| H01 | De Rosa–Park Proposition 7.2 supplies TV-one compact fields with diffuse scalar energy defect. | VERIFIED SOURCE INTERFACE | Checked the exact proposition at the primary publisher source; its domain is a square in \(\mathbb R^2\), and the construction also embeds in the torus. |
| H02 | Remark 7.4 permits steady radial examples and preserves weak Euler closure. | VERIFIED SOURCE INTERFACE | Read the remark in full. It says the radial building blocks lead to steady Euler solutions and that the weak limit remains a weak solution. |
| H03 | Remark 3.7 identifies the temporal-factorization obstruction. | VERIFIED SOURCE INTERFACE | Read the stated oscillating sequence and its nonfactorizable quadratic measure. F independently reconstructs the mechanism. |

## Fragile-interface reconstruction

### Exact necessity quantifier

Fix the subsequence already possessing the compactness conclusions, and let \(N_n(\psi)\) denote its full nonlinear integral. The smooth weak identities and convergence of all linear terms give \(N_n(\psi)\to N(\psi)\) if the limit is Euler. For every fixed \(\delta\), the off-diagonal part \(O_{n,\delta}\to O_\delta\). Therefore

\[
\limsup_n|N_n-O_{n,\delta}|=|N-O_\delta|\longrightarrow0
\quad(\delta\downarrow0),
\]

where the last step uses the atomless limiting measure. This is precisely (SD) along that subsequence.

### Angular signs

For \(z/|z|=(\cos\theta,\sin\theta)\), the matrix in G is

\[
S(z)=\frac12
\begin{pmatrix}
-\sin2\theta&\cos2\theta\\
\cos2\theta&\sin2\theta
\end{pmatrix}.
\]

Taking \(\psi=-x_1x_2\) gives \(D^2\psi:S(z)=-\cos2\theta\), agreeing with the negative sign in identity (I) and with the positive \(3C/2\) stress pairing in C. There is no sign conflict among A, C, and G.

## References checked in this pass

- [De Rosa–Park, publisher full text](https://link.springer.com/article/10.1007/s00220-026-05662-w): Proposition 7.2, Remarks 7.4 and 3.7. Used only for the limited interfaces H01–H03 and G04.
- [Cheverry–Guès, publisher abstract](https://link.springer.com/article/10.1007/s00205-008-0132-6): confirms D02's limited abstract claim.
- [Domínguez–Spector, arXiv abstract](https://arxiv.org/abs/2409.02344): confirms D03's rate-assumption interface.
- Schochet publisher access failed with HTTP 403; no theorem from that source was assumed.

## Issue and dependency summary

- **Fatal or major mathematical errors:** none found.
- **Unformalized optional extension:** A02 needs an explicit residual/test topology before use; the main proof does not depend on it.
- **Source unavailable in this independent pass:** D01's abstract detail; no proved claim depends on it.
- **Minor conventions to state if assembling a manuscript:** compact unit-ball mollifier in A21; \(k\geq2\) for the displayed atom-removing cutoff; initial-time interpretation in B02; arcsine marginal normalization in F04; compact cutoffs before the local Portmanteau argument G01.
- **Unproved target bridge:** propagation of (SD), or a replacement guaranteeing it, for an actual approximation family of every admissible initial datum.

REPAIR_INSTRUCTIONS: Retain the exact subsequence qualification for necessity, keep all conditional approximation hypotheses visible, and do not convert the spatial or moving-packet examples into Euler nonexistence claims. No mathematical correction to the principal conditional theorem is required.
