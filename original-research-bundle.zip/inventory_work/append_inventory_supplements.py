#!/usr/bin/env python3
"""Append neutral child focuses; never rewrite frozen source or original inventory."""
from pathlib import Path
import hashlib, json

ROOT=Path('/workspace/scratch/de6aed6f6a22/audit_v1')
ORIGINAL=ROOT/'audit_inventory.json'
OUTPUT=ROOT/'audit_inventory_supplemented.json'
SOURCE=ROOT/'proof.tex'
SOURCE_SHA='b6741b471ba2f128b147f5a5c05fea0afe639c2c3a535b99a5afaf03ea6d4a43'
ORIGINAL_SHA='efbd3fc4311f910b394581f46718f3b73a03f99a5891b38d2e7e2be24d7b9b71'

REQUESTS=[
 ('supp-001','S0084','Check the claimed strong L2 continuity of V(t)-V_0 using its Fourier-multiplier representation and the Bochner time integral F_t introduced in S0083; include the time-integrability and bounded-operator conditions needed for that conclusion.',['S0083']),
 ('supp-002','S0130','Check the rho=0 endpoint of the polar definition: whether the core streamfunction has a removable polar-coordinate singularity and the regularity needed to define D=nabla-perp psi there.',[]),
 ('supp-003','S0162','Check the respective boundary-integral assignment and sign: the asserted contribution for gradient Pi_r is -pi r xi on the large circle. Read this together with the full respective-pair sentence.',['S0160']),
 ('supp-004','S0373','Check how a positive radius parameter r_* quantified in the LER statement is selected when applying LER at the displayed patch budgets; do not insert a choice into the source.',['S0270']),
 ('supp-005','S0158','Check the temporal regularity of r(t), eta(t), and X(t) needed for the subsequent derivatives, chain rules, and products in the packet calculation; distinguish the stated data from any regularity required by that calculation.',['S0159']),
 ('supp-006','S0164','Check whether the family U_H is specified or used as a fixed dilation H^-2 U_1(x/H), and check the profile uniformity needed for the subsequent estimates as H tends to zero; do not add a dilation convention to the source.',[]),
]

def digest(b): return hashlib.sha256(b).hexdigest()

def main():
 source=SOURCE.read_bytes(); original_bytes=ORIGINAL.read_bytes()
 assert digest(source)==SOURCE_SHA
 assert digest(original_bytes)==ORIGINAL_SHA
 base=json.loads(original_bytes)
 ledger=json.loads(OUTPUT.read_text()) if OUTPUT.exists() else json.loads(original_bytes)
 old={c['id']:c for c in base['containers']}; current={c['id']:c for c in ledger['containers']}
 assert list(old)==list(current)
 for sid,parent in current.items():
  frozen=old[sid]
  assert {k:v for k,v in parent.items() if k!='nested_checks'}=={k:v for k,v in frozen.items() if k!='nested_checks'}
  assert parent['nested_checks'][:len(frozen['nested_checks'])]==frozen['nested_checks']
 provenance=ledger.setdefault('supplement_provenance',dict(original_inventory_path=str(ORIGINAL),original_inventory_sha256=ORIGINAL_SHA,source_sha256=SOURCE_SHA,state='OPEN_AWAITING_ADDITIONAL_FOCUSES',mathematical_verdicts='none',requests=[]))
 known={r['request_key'] for r in provenance['requests']}
 for request,sid,focus,related in REQUESTS:
  if request in known: continue
  parent=current[sid]
  suffix=max([int(n['id'].rsplit('.C',1)[1]) for n in parent['nested_checks']]+[0])+1
  child={k:parent[k] for k in ['byte_start','byte_end_exclusive','line_start','line_end','text','sha256']}
  child.update(id=f'{sid}.C{suffix:02d}',kind='supplemental neutral mathematical focus',focus_description=focus,scope=f'The unchanged full parent {sid} is the exact source anchor. The focus is an audit obligation, not a correctness conclusion or a source amendment.',related_container_ids=related,supplement_request_key=request,provenance='Focus supplied by the coordinator from an independent pass; neutral inventory coordinator inspected source anchors only.',required_passes=['A','B','C','D'])
  parent['nested_checks'].append(child)
  provenance['requests'].append(dict(request_key=request,parent_id=sid,appended_child_id=child['id'],focus_description=focus,related_container_ids=related,source_anchor_sha256=parent['sha256'],status='APPENDED_AWAITING_ALL_PASS_CONFIRMATIONS'))
  known.add(request)
 provenance['original_parent_count']=len(old)
 provenance['original_nested_count']=sum(len(c['nested_checks']) for c in base['containers'])
 provenance['current_supplement_count']=len(provenance['requests'])
 provenance['current_consolidated_nested_count']=sum(len(c['nested_checks']) for c in ledger['containers'])
 provenance['counts_are_final']=False
 provenance['factual_scaffolding_notes']=[dict(parent_id='S0130',child_ids=['S0130.C05','S0130.C10','S0130.C11'],note='Frozen C05 is an empty exact span; C10 is whitespace; C11 contains only the cases closing command and surrounding whitespace. They are retained verbatim. This is a source-scaffolding observation, not a mathematical verdict or an added mathematical assertion.')]
 ledger['metadata']['inventory_state']='FROZEN_PARENTS_WITH_OPEN_APPEND_ONLY_SUPPLEMENT'
 ledger['metadata']['nested_checks']=provenance['current_consolidated_nested_count']
 ledger['metadata']['original_frozen_nested_checks']=provenance['original_nested_count']
 ledger['metadata']['compound_containers']=sum(bool(c['nested_checks']) for c in ledger['containers'])
 ledger['metadata']['nested_check_consolidation_final']=False
 # All parent spans/text/digests, old child objects, and complete source coverage stay exactly identical.
 assert b''.join(c['text'].encode() for c in ledger['containers'])==source
 for parent in ledger['containers']:
  assert source[parent['byte_start']:parent['byte_end_exclusive']]==parent['text'].encode()
  assert digest(parent['text'].encode())==parent['sha256']
  for n in parent['nested_checks']:
   assert source[n['byte_start']:n['byte_end_exclusive']]==n['text'].encode()
   assert digest(n['text'].encode())==n['sha256']
   assert 'nested_checks' not in n
 OUTPUT.write_text(json.dumps(ledger,ensure_ascii=False,indent=2)+'\n')
 (ROOT/'inventory_supplement_provenance.json').write_text(json.dumps(provenance,ensure_ascii=False,indent=2)+'\n')
 lines=['# Open neutral inventory supplement','', 'The immutable proof and original frozen ledger are unchanged. This is an append-only collection of audit focuses, not mathematical findings. Counts remain provisional until the coordinator closes consolidation.','', f'Original inventory SHA-256: `{ORIGINAL_SHA}`.',f'Source SHA-256: `{SOURCE_SHA}`.','', '| Parent | Added child | Source lines | Neutral focus |','|---|---|---|---|']
 for r in provenance['requests']:
  c=current[r['parent_id']]
  lines.append(f"| {c['id']} | {r['appended_child_id']} | {c['line_start']}–{c['line_end']} | {r['focus_description']} |")
 lines+=['','All six initial additions use their complete unchanged parent as the exact source anchor; related parent IDs supply source context only. Every final addition must receive an affirmative check from all four required passes before audit finalization.','', '## Factual frozen-scaffolding note','',provenance['factual_scaffolding_notes'][0]['note'],'','The original 419 parent records and all original 834 child objects were compared as exact JSON values, with parent anchors reconstructed against the proof. No original parent ID, order, text, span, digest, or child object changed.']
 (ROOT/'inventory_supplement_provenance.md').write_text('\n'.join(lines)+'\n')
 assert digest(ORIGINAL.read_bytes())==ORIGINAL_SHA and digest(SOURCE.read_bytes())==SOURCE_SHA
 print(json.dumps(dict(output=str(OUTPUT),output_sha256=digest(OUTPUT.read_bytes()),new_children=[r['appended_child_id'] for r in provenance['requests']],consolidation_state=provenance['state'],counts_are_final=False),indent=2))

if __name__=='__main__': main()
