#!/usr/bin/env python3
"""Neutral, exact-byte source scaffolding. No mathematical verdicts are produced."""
import argparse, bisect, collections, hashlib, json, re
from pathlib import Path

DISPLAY_ENVS = {'equation','equation*','align','align*','gather','gather*','multline','multline*','displaymath','eqnarray','eqnarray*'}
THEOREM_ENVS = {'theorem','lemma','proposition','assumption','remark','proof','corollary','definition'}
STRUCTURAL = re.compile(r'\\(?:documentclass|usepackage|geometry|setlength|hypersetup|newtheorem|theoremstyle|newcommand|title|author|date|maketitle|section|subsection|paragraph)\b')
ABBREVIATIONS = {'Calc','Var','PDE','Dr','Mr','Prof','i.e','e.g','cf','etc','vs'}

def sha(b): return hashlib.sha256(b).hexdigest()

def balanced(s, start, opening='{', closing='}'):
    depth=0
    for i in range(start,len(s)):
        if s[i]=='\\': continue
        if i and s[i-1]=='\\': continue
        if s[i]==opening: depth+=1
        elif s[i]==closing:
            depth-=1
            if depth==0: return i+1
    return len(s)

def command_end(s,i):
    m=re.match(r'\\(?:[A-Za-z@]+\*?|.)',s[i:], re.S)
    if not m: return i+1
    j=i+len(m.group())
    while j<len(s) and s[j] in '[{':
        j=balanced(s,j,s[j],']' if s[j]=='[' else '}')
    return j

def math_token(s,i):
    if s.startswith('\\[',i):
        j=s.find('\\]',i+2); return (len(s) if j<0 else j+2,'display','bracket',i+2,j if j>=0 else len(s))
    if s.startswith('\\(',i):
        j=s.find('\\)',i+2); return (len(s) if j<0 else j+2,'inline','parenthesis',i+2,j if j>=0 else len(s))
    if s[i:i+1]=='$' and (i==0 or s[i-1]!='\\'):
        delim='$$' if s.startswith('$$',i) else '$'; j=i+len(delim)
        while j<len(s):
            if s.startswith(delim,j) and s[j-1]!='\\': break
            j+=1
        return (min(len(s),j+len(delim)), 'display' if len(delim)==2 else 'inline', 'dollar',i+len(delim),j)
    m=re.match(r'\\begin\{([^}]+)\}',s[i:])
    if m and m.group(1) in DISPLAY_ENVS:
        env=m.group(1); close='\\end{'+env+'}'; j=s.find(close,i+len(m.group()))
        return (len(s) if j<0 else j+len(close),'display',env,i+len(m.group()),j if j>=0 else len(s))
    return None

def tokenize(s):
    out=[]; i=0
    while i<len(s):
        mt=math_token(s,i)
        if mt:
            j,kind,env,a,b=mt; out.append(dict(start=i,end=j,kind=kind,environment=env,inner_start=a,inner_end=b)); i=j
        elif s[i]=='%' and (i==0 or s[i-1]!='\\'):
            j=s.find('\n',i); j=len(s) if j<0 else j; i=j
        elif s[i]=='\\':
            # Parse through prose wrappers, but leave protected macro arguments atomic.
            m=re.match(r'\\(?:emph|textbf|textit|text|unproved)\b',s[i:])
            if m: i+=len(m.group())
            else: i=command_end(s,i)
        else: i+=1
    return out

def segment(s, formula_tokens):
    mt={x['start']:x for x in formula_tokens}; raw=[]; pending=0; i=0; brace=0
    def flush(end,mode='SENTENCE',note=None):
        nonlocal pending
        if end>pending:
            raw.append(dict(start=pending,end=end,mode=mode,boundary_note=note)); pending=end
    while i<len(s):
        # Line-level standalone objects. Whitespace before each belongs to it.
        if (i==0 or s[i-1]=='\n'):
            le=s.find('\n',i); le=len(s) if le<0 else le+1
            line=s[i:le]; stripped=line.lstrip()
            heading=re.match(r'\s*\\noindent\\textbf\{',line)
            if heading:
                if s[pending:i].strip(): flush(i)
                brace_start=i+heading.end()-1; he=balanced(s,brace_start)
                flush(he,'STRUCTURAL'); i=he; continue
            if STRUCTURAL.match(stripped):
                if s[pending:i].strip(): flush(i)
                flush(le,'STRUCTURAL'); i=le; continue
            doc=re.match(r'\\(?:begin|end)\{document\}',stripped)
            if doc:
                if s[pending:i].strip(): flush(i)
                flush(le,'STRUCTURAL'); i=le; continue
            closing=re.match(r'\\end\{('+ '|'.join(THEOREM_ENVS)+r')\}',stripped)
            if closing:
                if s[pending:i].strip(): flush(le)
                elif raw: raw[-1]['end']=le; pending=le
                else: flush(le,'STRUCTURAL')
                i=le; continue
        if i in mt:
            tok=mt[i]; i=tok['end']
            if tok['kind']=='display':
                inner=s[tok['inner_start']:tok['inner_end']].rstrip()
                tail=s[i:].lstrip(); nxt=re.sub(r'^\\end\{[^}]+\}\s*','',tail)
                # Mathematical punctuation is only evidence; surrounding grammar controls attachment.
                closes=inner.endswith(('.', '?','!'))
                if closes and not re.match(r'(?:where|with|which|and|or|so that|such that|for|is|gives)\b',tail):
                    flush(i)
                elif tail and (tail.startswith('The average here') or tail.startswith('The scalar')):
                    # Manually reviewed omitted prose punctuation after a grammatically complete definition.
                    flush(i,'SENTENCE','Display ends with comma, but the following capitalized sentence is grammatically independent; complete introduced definition retained.')
            continue
        c=s[i]
        if c=='\\':
            # Environment open/title/label are nearest-content attachments.
            m=re.match(r'\\begin\{([^}]+)\}',s[i:])
            if m and m.group(1) in THEOREM_ENVS:
                i=command_end(s,i); continue
            if s.startswith('\\unproved{',i):
                i+=len('\\unproved{'); continue
            i=command_end(s,i); continue
        if c in '.?!':
            pre=s[max(pending,i-12):i]
            word=re.search(r'([A-Za-z.]+)$',pre)
            decimal=i>0 and i+1<len(s) and s[i-1].isdigit() and s[i+1].isdigit()
            abbreviation=bool(word and word.group(1) in ABBREVIATIONS)
            if not decimal and not abbreviation:
                end=i+1
                # Closing braces of prose wrapper belong to preceding sentence.
                while end<len(s) and s[end]=='}': end+=1
                flush(end); i=end; continue
        i+=1
    if pending<len(s):
        if s[pending:].strip(): flush(len(s),'STRUCTURAL' if not s[pending:].strip().strip('{}') else 'SENTENCE')
        elif raw: raw[-1]['end']=len(s)
    # Keep the mathematical sentence after a short bold status label, which is not prose punctuation.
    return raw

def top_level_parts(s,start,end):
    """Factual rows/relations. Ignore relations inside operands and macro arguments."""
    splits=[]; depth=0; left=0; paren=0; i=start; row=start
    while i<end:
        c=s[i]
        if c=='\\':
            m=re.match(r'\\([A-Za-z]+|.)',s[i:])
            name=m.group(1) if m else ''; n=len(m.group()) if m else 1
            if name=='left': left+=1
            elif name=='right': left=max(0,left-1)
            if name=='\\' and depth==0 and left==0:
                splits.append((row,i,'align row')); row=i+n
            elif name in {'quad','qquad'} and depth==0 and left==0 and paren==0:
                splits.append((row,i,'separate formula assertion')); row=i+n
            i+=n; continue
        if c=='{': depth+=1
        elif c=='}': depth=max(0,depth-1)
        elif c in '([': paren+=1
        elif c in ')]': paren=max(0,paren-1)
        elif c==',' and depth==0 and left==0 and paren==0:
            splits.append((row,i,'separate formula assertion')); row=i+1
        i+=1
    splits.append((row,end,'formula row'))
    result=[]
    rel_pat=re.compile(r'(?:=|(?<!\\)[<>]|\\(?:leq?|geq?|ne(?:q)?|notin|equiv|implies|iff|asymp|to|rightharpoonup|in|subset(?:eq)?|supset(?:eq)?|approx)(?![A-Za-z]))')
    for a,b,kind in splits:
        rel=[]; depth=0; left=0; i=a
        while i<b:
            if s[i]=='{': depth+=1
            elif s[i]=='}': depth=max(0,depth-1)
            if depth==0 and left==0:
                mm=rel_pat.match(s,i)
                if mm: rel.append((i,i+len(mm.group())))
            if s.startswith('\\left',i): left+=1
            if s.startswith('\\right',i): left=max(0,left-1)
            if s[i]=='\\':
                mm=re.match(r'\\(?:[A-Za-z]+|.)',s[i:]); i+=len(mm.group()) if mm else 1
            else: i+=1
        if len(rel)>1:
            for j,(ra,rb) in enumerate(rel):
                result.append((a if j==0 else rel[j-1][1], rel[j+1][0] if j+1<len(rel) else b, 'successive relation',s[ra:rb]))
        else: result.append((a,b,kind,s[rel[0][0]:rel[0][1]] if rel else None))
    return result

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('source'); ap.add_argument('--out',default='.'); ap.add_argument('--draft',action='store_true'); args=ap.parse_args()
    p=Path(args.source); b=p.read_bytes(); s=b.decode('utf-8'); out=Path(args.out); out.mkdir(parents=True,exist_ok=True)
    starts=[0]+[m.end() for m in re.finditer('\n',s)]; byte_map=[0]; acc=0
    for c in s: acc+=len(c.encode()); byte_map.append(acc)
    def anchor(a,z):
        text=s[a:z]; return dict(byte_start=byte_map[a],byte_end_exclusive=byte_map[z],line_start=bisect.bisect_right(starts,a),line_end=bisect.bisect_right(starts,max(a,z-1)),text=text,sha256=sha(text.encode()))
    formulas=tokenize(s); segments=segment(s,formulas); containers=[]
    for idx,seg in enumerate(segments,1):
        a,z=seg['start'],seg['end']; text=s[a:z]; sid=f'S{idx:04d}'; fs=[f for f in formulas if a<=f['start'] and f['end']<=z]
        if text.lstrip().startswith('Crippa--Stefani,'): seg['mode']='STRUCTURAL'
        if text.lstrip().startswith('Define\n\\[') and '\\]\nThen ' in text:
            seg['mode']='BOUNDARY-GROUP'; seg['boundary_note']='The source omits punctuation between the introduced display definition and the following Then clause. Both are retained through the earliest safe following sentence terminator, with no source repair.'
        if seg['boundary_note'] and 'Display ends with comma' in seg['boundary_note']:
            seg['mode']='BOUNDARY-GROUP'
        math=bool(fs) or bool(re.search(r'\\newcommand\{\\(?:R|M|curl|Div|supp|norm|dd)\}',text)) or text.lstrip().startswith('Crippa--Stefani,')
        if seg['mode']!='STRUCTURAL' and not math:
            # Mathematical prose without explicit dollar math is common. Only unmistakable provenance remains nonmathematical.
            math=not bool(re.search(r'Status\.|candidate proof document|received one independent|received the four independent|independently checked|verification provenance|They await|Verification boundary|hostile audit|hostile|independently certified|audit rather than|This document does|four-audit proof|No implication from that source|proposed proof|The derivations below collect|External inputs are delimited|not a presumption|checked specialization|This document proposes|not a certified solution|new proposed\s+arguments|local endpoint repair is stated as a proposed lemma|No audit conclusion|time iteration is the piecewise-time version|translating dipole is motivated|local construction combines independently|No target-resolution claim|failure found by those audits|Research proof manuscript|Verification status is recorded|this source alone is not a verification',text,re.I))
        c=dict(id=sid,filename=p.name,original_filename='candidate_proof.tex',**anchor(a,z),mode=seg['mode'],mathematical=math,boundary_note=seg['boundary_note'],nested_checks=[],pass_statuses={'A':None,'B':None,'C':None,'D':None},rationale=None)
        c['_char_start']=a; c['_char_end']=z
        containers.append(c)
    for fi,f in enumerate(formulas,1):
        parent=next(c for c in containers if c['_char_start']<=f['start'] and f['end']<=c['_char_end'])
        f.update(id=f'F{fi:04d}',container_id=parent['id'],**anchor(f['start'],f['end']))
    for c in containers:
        if not c['mathematical']: continue
        a,z=c['_char_start'],c['_char_end']; fs=[f for f in formulas if f['container_id']==c['id']]
        items=[]
        # Clause extraction operates on prose with formula atoms masked; atoms are never split by commas or conjunctions.
        mask=list(s[a:z])
        for f in fs:
            for k in range(f['start']-a,f['end']-a): mask[k]=' ' if s[a+k]!='\n' else '\n'
        masked=''.join(mask)
        delim=re.compile(r';|,\s*(?:and|while|so|but|with|where)\b|\b(?:and|while|but)\b')
        bounds=[a]+[a+m.end() for m in delim.finditer(masked)]+[z]
        formula_items=[]
        for f in fs:
            pieces=top_level_parts(s,f['inner_start'],f['inner_end'])
            for pa,pz,kind,relation in pieces:
                # A symbol occurrence is inventoried as a formula, not falsely promoted to an independent assertion.
                if s[pa:pz].strip() and (relation or f['kind']=='display'):
                    formula_items.append(dict(kind=kind,formula_id=f['id'],relation=relation,**anchor(pa,pz)))
            for cm in re.finditer(r'\\begin\{cases\}(.*?)\\end\{cases\}',s[f['inner_start']:f['inner_end']],re.S):
                ca=f['inner_start']+cm.start(1); cz=f['inner_start']+cm.end(1)
                for pa,pz,kind,relation in top_level_parts(s,ca,cz):
                    formula_items.append(dict(kind='explicit case',formula_id=f['id'],**anchor(pa,pz)))
        for ca,cz in zip(bounds,bounds[1:]):
            pro=''.join(mask[ca-a:cz-a]); pro=re.sub(r'\\(?:begin|end)\{[^}]+\}(?:\[[^]]*\])?|\\label\{[^}]+\}', '',pro)
            words=re.findall(r'[A-Za-z]{2,}',pro)
            claims=[x for x in formula_items if byte_map[ca]<=x['byte_start']<byte_map[cz]]
            clause_formulas=[f for f in fs if ca<=f['start']<cz]
            if not claims and (len(words)>=2 or (clause_formulas and len(words)>=1)):
                items.append(dict(kind='prose assertion, definition, or hypothesis (including its scope)',**anchor(ca,cz)))
            elif len(claims)==1:
                item=dict(claims[0]); item.update(anchor(ca,cz)); item['kind']='asserted relation with its complete prose scope'; items.append(item)
            else: items.extend(claims)
        # Explicit independently checkable adjectives/conditions remain factual scaffolding, with enclosing scope in the parent.
        property_pat=re.compile(r'\b(?:nonnegative|nonincreasing|strictly positive|positive(?![- ](?:time|order))|radial|real|Schwartz|smooth|symmetric|scalar|unique|continuous|continuously differentiable|bounded|integrable|square integrable|divergence[- ]free|curl[- ]free|finite|signed|compactly supported|compact support|supported|probability|even|evenness|flat|zero circulation|energy inequality|kinetic-energy assumption|uniform convergence|all first moments zero|integral one|almost everywhere|at every time|every time|for every|for all|uniformly|independent of)\b',re.I)
        for pm in property_pat.finditer(masked):
            pa=a+pm.start(); pz=a+pm.end()
            items.append(dict(kind='explicit mathematical property/condition and its stated scope: '+pm.group(),**anchor(pa,pz)))
        items.sort(key=lambda x:(x['byte_start'],x['byte_end_exclusive']))
        if len(items)>1:
            for j,item in enumerate(items,1):
                item['id']=c['id']+f'.C{j:02d}'
                item['scope']='Read with the entire unchanged parent container '+c['id']+'; the exact focus span does not omit its subject, hypothesis, quantifier, or surrounding grammatical scope.'
            c['nested_checks']=items
        c['algebra_bearing']=any(x.get('relation') in {'=','\\leq','\\geq','\\asymp','\\equiv','\\implies','\\iff'} for x in items) and bool(re.search(r'gives|give|yields|Thus|Then|therefore|Hence|Consequently|proves|equals|satisfies|estimate|bound|becomes|Expanding|Combining|Scaling|By|Indeed|derive|identity|Integration|integrat|norm|partial|Delta|hat|sum|frac',c['text']))
        c['external_theorem_invocation']=bool(re.search(r'Apply E1|Crippa--Stefani|Theorem 3\.3|Riemann--Lebesgue|Weyl.s lemma|Young.s inequality|Plancherel|Tonelli|Fubini|Chebyshev|Minkowski|dominated convergence|Fourier inversion|intermediate value theorem|Uniqueness for the regular|fundamental theorem of calculus|Hölder estimates|modulus is Osgood|weakly convergent.*subsequence|layer cake|the Jacobian equation|approximation of the identity is uniform',c['text'],re.S))
    for c in containers:
        c.setdefault('algebra_bearing',False); c.setdefault('external_theorem_invocation',False)
        del c['_char_start']; del c['_char_end']
    ff=[]
    for f in formulas:
        ff.append({k:v for k,v in f.items() if k not in {'start','end','inner_start','inner_end'}})
    assert containers[0]['byte_start']==0 and containers[-1]['byte_end_exclusive']==len(b)
    assert all(x['byte_end_exclusive']==y['byte_start'] for x,y in zip(containers,containers[1:]))
    assert b''.join(c['text'].encode() for c in containers)==b
    meta=dict(source_filename=p.name,original_source_filename='candidate_proof.tex',snapshot_path=str(p.resolve()),source_sha256=sha(b),source_bytes=len(b),source_lines=len(s.splitlines()),inventory_state='DRAFT_NOT_FROZEN' if args.draft else 'FROZEN',encoding='UTF-8',byte_span_convention='zero-based, half-open',line_span_convention='one-based, inclusive',coverage='exact disjoint contiguous byte partition; leading layout bytes attach to the next content container and environment closing bytes to preceding content',mathematical_judgments='none; neutral scaffolding only',total_containers=len(containers),modes=dict(collections.Counter(c['mode'] for c in containers)),mathematical_containers=sum(c['mathematical'] for c in containers),non_mathematical_containers=sum(not c['mathematical'] for c in containers),compound_containers=sum(bool(c['nested_checks']) for c in containers),nested_checks=sum(len(c['nested_checks']) for c in containers),formula_occurrences=len(ff),inline_occurrences=sum(f['kind']=='inline' for f in ff),display_occurrences=sum(f['kind']=='display' for f in ff),algebra_bearing_containers=sum(c['algebra_bearing'] for c in containers),external_theorem_containers=sum(c['external_theorem_invocation'] for c in containers),proof_environments=len(re.findall(r'\\begin\{proof\}',s)),uncovered_source_bytes=0,uncovered_source_lines=0)
    major_results=[]; proof_objects=[]
    for em in re.finditer(r'\\begin\{(lemma|proposition|theorem|assumption|corollary|proof)\}(?:\[([^]]*)\])?',s):
        env=em.group(1); close=re.search(r'\\end\{'+env+r'\}',s[em.end():]); ez=em.end()+close.end() if close else len(s)
        members=[c['id'] for c in containers if c['byte_start']<byte_map[ez] and c['byte_end_exclusive']>byte_map[em.start()]]
        obj=dict(environment=env,title=em.group(2),container_ids=members,**anchor(em.start(),ez))
        (proof_objects if env=='proof' else major_results).append(obj)
    meta['major_result_environments']=len(major_results)
    (out/'audit_inventory.json').write_text(json.dumps(dict(metadata=meta,containers=containers,major_results=major_results,proof_environments=proof_objects),ensure_ascii=False,indent=2)+'\n')
    (out/'audit_formulas.json').write_text(json.dumps(dict(metadata=meta,formulas=ff),ensure_ascii=False,indent=2)+'\n')
    rows=['# Neutral permanent-container inventory','',f"Source SHA-256: `{meta['source_sha256']}`.",'',f"State: {meta['inventory_state']}. Exact texts and full digests are in audit_inventory.json.",'','| Container | Lines | Mode | Math | Children | Exact opening excerpt |','|---|---:|---|---|---:|---|']
    for c in containers:
        excerpt=c['text'].strip().replace('\n',' ')[:120].replace('|','\\|').replace('`','\\`')
        rows.append(f"| {c['id']} | {c['line_start']}–{c['line_end']} | {c['mode']} | {'yes' if c['mathematical'] else 'no'} | {len(c['nested_checks'])} | `{excerpt}` |")
    (out/'audit_inventory.md').write_text('\n'.join(rows)+'\n')
    # Reading view is scratch-only and includes every exact source anchor for boundary review.
    (out/'boundary_review.txt').write_text('\n'.join(f"[{c['id']} {c['line_start']}-{c['line_end']} {c['mode']} math={c['mathematical']} children={len(c['nested_checks'])}]\n{c['text']}" for c in containers))
    facts=['# Factual source, macro, notation, and reference inventory','',f"Source: `{p.name}` (immutable copy of `candidate_proof.tex`), lines 1–{meta['source_lines']}; SHA-256 `{meta['source_sha256']}`.",'','This inventory records source declarations and references, without a correctness finding.','', '## Macro and theorem declarations','']
    for c in containers:
        if re.search(r'\\(?:newcommand|newtheorem|theoremstyle)',c['text']): facts.append(f"- {c['id']} (lines {c['line_start']}–{c['line_end']}): `{c['text'].strip()}`")
    facts+=['','## Inclusion and bibliography commands','']
    inc=list(re.finditer(r'\\(?:input|include|bibliography|addbibresource)\{([^}]+)\}',s))
    facts.append('No TeX input, include, bibliography, or addbibresource commands occur.' if not inc else '\n'.join(m.group() for m in inc))
    facts+=['','## External URLs and named sources','']
    for c in containers:
        if re.search(r'\\(?:url|path)\{|Crippa--Stefani|Bruè--Colombo--Kumar',c['text']): facts.append(f"- {c['id']} (lines {c['line_start']}–{c['line_end']}): `{c['text'].strip().replace(chr(10),' ')}`")
    labels={m.group(1):next(c['id'] for c in containers if c['byte_start']<=byte_map[m.start()]<c['byte_end_exclusive']) for m in re.finditer(r'\\label\{([^}]+)\}',s)}
    facts+=['','## Labels and references','', '| Label | Declared in | Used in |','|---|---|---|']
    for label,parent in labels.items():
        uses=[c['id'] for c in containers if re.search(r'\\(?:eqref|ref)\{'+re.escape(label)+r'\}',c['text'])]
        facts.append(f"| `{label}` | {parent} | {', '.join(uses) or '—'} |")
    facts+=['','## Notation-definition locations','', 'The following source containers introduce or set mathematical data. Their exact texts remain in the canonical JSON ledger.','']
    for c in containers:
        if c['mathematical'] and re.search(r'\b(?:Let|let|Set|set|Define|define|Write|write|Choose|choose|Fix|fix|put|We use|convention|denote|Suppose|Assume)\b',c['text']):
            facts.append(f"- {c['id']} (lines {c['line_start']}–{c['line_end']}): `{c['text'].strip().replace(chr(10),' ')[:240]}`")
    (out/'audit_notation.md').write_text('\n'.join(facts)+'\n')
    print(json.dumps(meta,indent=2))

if __name__=='__main__': main()
