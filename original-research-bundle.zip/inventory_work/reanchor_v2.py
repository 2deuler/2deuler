#!/usr/bin/env python3
"""Apply a reviewed exact per-parent revision map; never resegment or renumber parents."""
import bisect, collections, copy, hashlib, importlib.util, json, re
from pathlib import Path

ROOT=Path('/workspace/scratch/de6aed6f6a22')
OLD=ROOT/'audit_v1'; NEW=ROOT/'audit_v2'
OLD_SOURCE_SHA='b6741b471ba2f128b147f5a5c05fea0afe639c2c3a535b99a5afaf03ea6d4a43'
NEW_SOURCE_SHA='1ffbeee20c4208e954396b55c3f4bc5289e478d76555579b09d5e7fbfae975bd'
OLD_LEDGER_SHA='6c93b60ef4b6b83665605caf389746d2009bb6f4e7520be9f01dfa67cd5082e2'
sha=lambda b:hashlib.sha256(b).hexdigest()

spec=importlib.util.spec_from_file_location('neutral_parser',ROOT/'inventory_work/build_inventory.py')
parser=importlib.util.module_from_spec(spec); spec.loader.exec_module(parser)

# Manually reviewed continuations of existing assertion roles. The new text is always an exact source substring.
OVERRIDES={
 'S0049.C04': '\nfor $|\\alpha|\\geq1$ the latter multipliers $\\xi^\\alpha m\\widehat a$ are also square integrable.',
 'S0139.C01': 'rotate the velocity and pressure profiles together',
 'S0139.C02': '$D_r(x)=r^{-1}D(x/r)$',
 'S0158.C03': "$X'=\\eta\\xi/r$",
 'S0158.C04': 'On each visit take $r,\\eta,X$ to be $C^1$ in time',
 'S0159.C03': "\\label{eq:packet}\n \\partial_tv+\\Div(v\\otimes v)+\\nabla p\n =(\\eta r)'T_XD_r/r+\\Div(\\eta r'T_XF_r).\n",
 'S0164.C01': '__FULL_PARENT__',
 'S0164.C07': '$U_H(x)=H^{-2}U(x/H)$',
 'S0167.C03': "\\label{eq:E-bound}\n E=\\eta r'T_XF_r+(\\eta r)'T_X\\mathcal A(S_r-2\\pi U_H\\xi)",
 'S0242.C02': ' the new velocity correction\nis continuous and',
 'S0242.C04': 'piecewise\nsmooth in time;',
 'S0247.C01': ' The displayed expression for $\\widetilde R$ is symmetric',
 'S0268.C01': '\n\nLet $(u,R)$ be any current pair in this class, $J\\Subset(0,\\infty)$ an\nopen interval, and',
 'S0304.C02': " $|\\eta r'|$ stay bounded independently\nof $N_k$, because their formulas involve only the uniformly bounded peak amplitudes, fixed\nramp functions, and",
 'S0373.C03': '\\kappa_{qj}=2^{-q}/N',
 'S0373.C04': 'r_*=1',
}
SCOPE_NOTES={
 'S0049':'The positive-order square-integrability clause now expressly refers to the latter multiplier family; its property-check role persists.',
 'S0139':'The direction and joint rotation clause is revised; the existing velocity scaling definition persists, while the new unit-type condition and pressure definition receive new children.',
 'S0158':'The existing temporal-regularity supplement now anchors the express C1 data clause; positivity and center-motion checks persist.',
 'S0159':'The packet-equation role persists with explicit translations in its revised exact formula.',
 'S0164':'Nonnegative/radial/smooth/probability adjectives now describe the fixed base U rather than directly describing U_H; this defining-profile role is preserved explicitly. The B_H support clause remains about U_H. The old dilation supplement now anchors the explicit definition.',
 'S0167':'The intrinsic-stress definition role persists with explicit translations in the revised exact formula.',
 'S0242':'Continuity and time-regularity checks now concern the new correction, not the arbitrary old seed. The first smooth occurrence denotes piecewise smoothness; the last remains in the global-smoothness disclaimer.',
 'S0247':'The symmetry-check subject is the assembled stress expression rather than all individually displayed tensor factors.',
 'S0268':'The old patch-data clause now explicitly gives J interval type.',
 'S0304':'The original bounded adjective focus remains the first occurrence, about derivative quantities; the peak-amplitude property is newly explicit.',
 'S0357':'The previously simple weak-subsequence statement is now explicitly quantified over sequences of times decreasing to zero and states boundedness; its first one-layer decomposition is appended.',
 'S0373':'The kappa-budget role persists with equality in place of inequality. The existing radius-selection supplement now anchors the express r_*=1 choice.',
}
NEW_FOCUSES=[
 ('S0139','a unit direction $\\xi\\in\\mathbb S^1$','Explicit unit-direction membership and its type.'),
 ('S0139','$P_r(x)=r^{-2}P(x/r)$','Definition of the scaled pressure profile.'),
 ('S0158','$T_X f(x)=f(x-X)$','Definition and argument convention of the translation operator.'),
 ('S0159',"(\\eta r)'T_XD_r/r",'Explicit translation of the profile term in the packet identity.'),
 ('S0159',"\\Div(\\eta r'T_XF_r)",'Explicit translation of the radial correction tensor in the packet identity.'),
 ('S0164','$U\\in C_c^\\infty(B_1)$','Membership and compact support of the fixed base bump.'),
 ('S0167',"\\eta r'T_XF_r",'Explicit translation of the first intrinsic-stress contribution.'),
 ('S0167',"(\\eta r)'T_X\\mathcal A(S_r-2\\pi U_H\\xi)",'Explicit translation of the anti-divergence contribution.'),
 ('S0242','after the fixed spatial mollification below','Mollification qualification attached to piecewise time smoothness.'),
 ('S0247','since each mixed product occurs with its transpose','Stated paired-transpose justification for symmetry of the assembled expression.'),
 ('S0268','$J\\Subset(0,\\infty)$ an\nopen interval','Explicit open-interval type and relative compactness of J.'),
 ('S0304','uniformly bounded peak amplitudes','Uniform boundedness of the peak amplitudes in the stated parameter regime.'),
 ('S0357','For any sequence $t_n\\downarrow0$','Sequence quantifier and limiting regime.'),
 ('S0357','the bounded sequence $W(t_n)$','Boundedness of the velocity-difference sequence.'),
 ('S0357','has a weakly convergent $L^2$ subsequence','Weak-subsequence conclusion and function-space type.'),
]

def occurrences(haystack,needle):
 if needle=='': return []
 out=[]; start=0
 while True:
  j=haystack.find(needle,start)
  if j<0: return out
  out.append(j); start=j+1

def main():
 old_source=(OLD/'proof.tex').read_bytes(); new_source=(NEW/'proof.tex').read_bytes()
 old_ledger_bytes=(OLD/'audit_inventory_supplemented.json').read_bytes()
 assert sha(old_source)==OLD_SOURCE_SHA and sha(new_source)==NEW_SOURCE_SHA and sha(old_ledger_bytes)==OLD_LEDGER_SHA
 old=json.loads(old_ledger_bytes); changes=json.loads((NEW/'source_change_manifest.json').read_text())
 edit={e['id']:e for e in changes['edits']}; assert len(edit)==12
 assert b''.join(edit.get(c['id'],{}).get('new_text',c['text']).encode() for c in old['containers'])==new_source
 text=new_source.decode('utf8'); byte_starts=[0]+[m.end() for m in re.finditer(b'\n',new_source)]
 char_bytes=[0]; count=0
 for char in text: count+=len(char.encode()); char_bytes.append(count)
 def anchor(a,z):
  raw=new_source[a:z]
  return dict(byte_start=a,byte_end_exclusive=z,line_start=bisect.bisect_right(byte_starts,a),line_end=bisect.bisect_right(byte_starts,max(a,z-1)),text=raw.decode('utf8'),sha256=sha(raw))
 containers=[]; correspondence=[]; child_map=[]; cursor=0
 for prior in old['containers']:
  sid=prior['id']; e=edit.get(sid); new_text=e['new_text'] if e else prior['text']; raw=new_text.encode(); current=copy.deepcopy(prior)
  if e:
   assert prior['text']==e['old_text'] and prior['sha256']==e['old_sha256']
   assert sha(raw)==e['new_sha256']
  current.update(anchor(cursor,cursor+len(raw))); current['pass_statuses']={p:None for p in 'ABCD'}; current['rationale']=None
  for nc in current['nested_checks']:
   oc=next(n for n in prior['nested_checks'] if n['id']==nc['id'])
   if not e:
    rel_a=oc['byte_start']-prior['byte_start']; rel_z=oc['byte_end_exclusive']-prior['byte_start']; method='identical-parent bytes; exact relative span retained'
   elif nc['id'] in OVERRIDES:
    focus=OVERRIDES[nc['id']]
    if focus=='__FULL_PARENT__': rel_a=0; rel_z=len(raw)
    else:
     assert new_text.count(focus)==1,(nc['id'],focus)
     rel_a=len(new_text[:new_text.index(focus)].encode()); rel_z=rel_a+len(focus.encode())
    method='explicitly reviewed same-role focus in revised parent'
   else:
    old_focus=oc['text']; assert old_focus, nc['id']
    old_hits=occurrences(prior['text'],old_focus); new_hits=occurrences(new_text,old_focus)
    old_char=len(prior['text'].encode()[:oc['byte_start']-prior['byte_start']].decode())
    assert old_char in old_hits,nc['id']; ordinal=old_hits.index(old_char)
    if nc['id']=='S0304.C03':
     assert ordinal==0 and new_hits[0]==old_hits[0]
    else: assert len(new_hits)==len(old_hits),(nc['id'],old_hits,new_hits)
    pos=new_hits[ordinal]; rel_a=len(new_text[:pos].encode()); rel_z=rel_a+len(old_focus.encode())
    method='exact unchanged focus; reviewed occurrence ordinal retained within revised parent'
   nc.update(anchor(cursor+rel_a,cursor+rel_z))
   if nc['id']=='S0373.C03': nc['relation']='='
   if nc['id'] in {'S0130.C05','S0130.C10','S0130.C11'}:
    nc['scaffolding_semantic_status']={'S0130.C05':'EMPTY_FOCUS_SPAN','S0130.C10':'WHITESPACE_ONLY_FOCUS_SPAN','S0130.C11':'TEX_ENVIRONMENT_CLOSURE_ONLY_FOCUS_SPAN'}[nc['id']]
   child_map.append(dict(id=nc['id'],parent_id=sid,lifecycle='RETAINED',mapping_method=method,old_anchor_sha256=oc['sha256'],new_anchor_sha256=nc['sha256'],old_byte_start=oc['byte_start'],old_byte_end_exclusive=oc['byte_end_exclusive'],new_byte_start=nc['byte_start'],new_byte_end_exclusive=nc['byte_end_exclusive'],scope_note=SCOPE_NOTES.get(sid)))
  correspondence.append(dict(id=sid,lifecycle='RETAINED',source_object='same grammatical container',changed=bool(e),old_sha256=prior['sha256'],new_sha256=current['sha256'],old_byte_start=prior['byte_start'],old_byte_end_exclusive=prior['byte_end_exclusive'],new_byte_start=current['byte_start'],new_byte_end_exclusive=current['byte_end_exclusive'],old_lines=[prior['line_start'],prior['line_end']],new_lines=[current['line_start'],current['line_end']],scope_note=SCOPE_NOTES.get(sid)))
  containers.append(current); cursor+=len(raw)
 assert cursor==len(new_source)
 lookup={c['id']:c for c in containers}; old_lookup={c['id']:c for c in old['containers']}
 added=[]
 for sid,focus,description in NEW_FOCUSES:
  c=lookup[sid]; assert c['text'].count(focus)==1,(sid,focus)
  pos=c['text'].index(focus); a=c['byte_start']+len(c['text'][:pos].encode()); z=a+len(focus.encode())
  suffix=max([int(n['id'].rsplit('.C',1)[1]) for n in c['nested_checks']]+[0])+1
  nid=sid+f'.C{suffix:02d}'
  n=dict(id=nid,kind='new revision assertion or explicit condition',focus_description=description,**anchor(a,z),scope=f'Read with the entire frozen v2 parent {sid}; the focused exact span retains its parent hypotheses, grammatical subject, and quantifier scope.',required_passes=['A','B','C','D'])
  c['nested_checks'].append(n); added.append(nid)
  child_map.append(dict(id=nid,parent_id=sid,lifecycle='APPENDED',mapping_method='new expressly stated assertion/condition, or first-layer decomposition of newly compound parent',old_anchor_sha256=None,new_anchor_sha256=n['sha256'],new_byte_start=a,new_byte_end_exclusive=z,focus_description=description))
 # Regenerate TeX formula occurrences against the revised source; F identifiers are revision-local.
 formulas=[]
 for idx,token in enumerate(parser.tokenize(text),1):
  a=char_bytes[token['start']]; z=char_bytes[token['end']]
  parent=next(c for c in containers if c['byte_start']<=a and z<=c['byte_end_exclusive'])
  formulas.append(dict(id=f'F{idx:04d}',kind=token['kind'],environment=token['environment'],container_id=parent['id'],**anchor(a,z)))
 old_formulas=json.loads((OLD/'audit_formulas.json').read_text())['formulas']; old_f={f['id']:f for f in old_formulas}
 formula_correspondence={}
 for c in containers:
  sid=c['id']; ofs=[f for f in old_formulas if f['container_id']==sid]; nfs=[f for f in formulas if f['container_id']==sid]
  for of in ofs:
   matches=[f for f in nfs if (f['kind'],f['environment'],f['text'])==(of['kind'],of['environment'],of['text'])]
   sameold=[f for f in ofs if f['text']==of['text']]
   if matches and len(matches)==len(sameold):
    nf=matches[sameold.index(of)]; formula_correspondence[of['id']]=nf['id']
   elif of['kind']=='display':
    displayold=[f for f in ofs if (f['kind'],f['environment'])==(of['kind'],of['environment'])]
    displaynew=[f for f in nfs if (f['kind'],f['environment'])==(of['kind'],of['environment'])]
    assert len(displayold)==len(displaynew),(sid,of['id'])
    formula_correspondence[of['id']]=displaynew[displayold.index(of)]['id']
  for n in c['nested_checks']:
   if 'formula_id' in n:
    old_id=n['formula_id']; assert old_id in formula_correspondence,(n['id'],old_id)
    n['formula_id']=formula_correspondence[old_id]
   related=[f['id'] for f in nfs if f['byte_start']<n['byte_end_exclusive'] and n['byte_start']<f['byte_end_exclusive']]
   if n['id'] in added and related: n['formula_ids']=related
 meta=copy.deepcopy(old['metadata'])
 meta.update(revision_id='v2',source_filename='proof.tex',snapshot_path=str((NEW/'proof.tex').resolve()),source_sha256=NEW_SOURCE_SHA,source_bytes=len(new_source),source_lines=len(new_source.splitlines()),inventory_state='FROZEN_REANCHORED_REVISION',previous_revision='v1',previous_source_sha256=OLD_SOURCE_SHA,previous_consolidated_inventory_sha256=OLD_LEDGER_SHA,permanent_container_identity_policy='All 419 parent IDs preserved by the reviewed exact per-parent replacement manifest; no new/split/merged/deleted parents.',total_containers=len(containers),modes=dict(collections.Counter(c['mode'] for c in containers)),mathematical_containers=sum(c['mathematical'] for c in containers),non_mathematical_containers=sum(not c['mathematical'] for c in containers),compound_containers=sum(bool(c['nested_checks']) for c in containers),nested_checks=sum(len(c['nested_checks']) for c in containers),previous_allocated_nested_checks=840,appended_v2_nested_checks=len(added),formula_occurrences=len(formulas),inline_occurrences=sum(f['kind']=='inline' for f in formulas),display_occurrences=sum(f['kind']=='display' for f in formulas),nested_check_consolidation_final=True,uncovered_source_bytes=0,uncovered_source_lines=0)
 # Retain algebra/theorem classifications as factual parent roles; all current children still require independent v2 checks.
 major=[]; proofs=[]
 for em in re.finditer(r'\\begin\{(lemma|proposition|theorem|assumption|corollary|proof)\}(?:\[([^]]*)\])?',text):
  env=em.group(1); close=re.search(r'\\end\{'+env+r'\}',text[em.end():]); assert close
  ez=em.end()+close.end(); a=char_bytes[em.start()]; z=char_bytes[ez]
  obj=dict(environment=env,title=em.group(2),container_ids=[c['id'] for c in containers if c['byte_start']<z and c['byte_end_exclusive']>a],**anchor(a,z))
  (proofs if env=='proof' else major).append(obj)
 ledger=dict(metadata=meta,containers=containers,major_results=major,proof_environments=proofs,scaffolding_only_child_ids=['S0130.C05','S0130.C10','S0130.C11'])
 # Enforce every identity, raw-byte coverage, exact digest, child containment, one-layer depth, and formula association.
 assert [c['id'] for c in containers]==[c['id'] for c in old['containers']]
 assert b''.join(c['text'].encode() for c in containers)==new_source
 old_child_ids=[n['id'] for c in old['containers'] for n in c['nested_checks']]
 new_child_ids=[n['id'] for c in containers for n in c['nested_checks']]
 assert len(old_child_ids)==840 and set(old_child_ids)<=set(new_child_ids) and len(new_child_ids)==len(set(new_child_ids))
 covered=set()
 for i,c in enumerate(containers):
  assert c['byte_start']==(containers[i-1]['byte_end_exclusive'] if i else 0)
  assert new_source[c['byte_start']:c['byte_end_exclusive']]==c['text'].encode() and sha(c['text'].encode())==c['sha256']
  covered.update(range(c['line_start'],c['line_end']+1))
  assert [n['id'] for n in c['nested_checks'][:len(old_lookup[c['id']]['nested_checks'])]]==[n['id'] for n in old_lookup[c['id']]['nested_checks']]
  for n in c['nested_checks']:
   assert c['byte_start']<=n['byte_start']<=n['byte_end_exclusive']<=c['byte_end_exclusive']
   assert new_source[n['byte_start']:n['byte_end_exclusive']]==n['text'].encode() and sha(n['text'].encode())==n['sha256']
   assert 'nested_checks' not in n
 assert covered==set(range(1,meta['source_lines']+1))
 for f in formulas:
  assert new_source[f['byte_start']:f['byte_end_exclusive']]==f['text'].encode() and sha(f['text'].encode())==f['sha256']
 (NEW/'audit_inventory.json').write_text(json.dumps(ledger,ensure_ascii=False,indent=2)+'\n')
 (NEW/'audit_formulas.json').write_text(json.dumps(dict(metadata=meta,formulas=formulas),ensure_ascii=False,indent=2)+'\n')
 (NEW/'boundary_review.txt').write_text('\n'.join(f"[{c['id']} {c['line_start']}-{c['line_end']} {c['mode']} math={c['mathematical']} children={len(c['nested_checks'])}]\n{c['text']}" for c in containers))
 rows=['# Frozen v2 permanent-container inventory','',f'Source SHA-256: `{NEW_SOURCE_SHA}`.',f'Parent identities: 419 preserved; allocated children: 840 retained plus {len(added)} appended.', 'Exact full texts, spans, full digests, and nested checks are in audit_inventory.json.','', '| Container | Lines | Mode | Math | Children | Digest prefix | Exact opening excerpt |','|---|---|---|---|---|---|---|']
 for c in containers:
  excerpt=c['text'].strip().replace('\n',' ')[:100].replace('|','\\|').replace('`','\\`')
  rows.append(f"| {c['id']} | {c['line_start']}–{c['line_end']} | {c['mode']} | {'yes' if c['mathematical'] else 'no'} | {len(c['nested_checks'])} | `{c['sha256'][:16]}` | `{excerpt}` |")
 (NEW/'audit_inventory.md').write_text('\n'.join(rows)+'\n')
 facts=['# Neutral v2 source and notation inventory','',f'Source `proof.tex`, immutable revision of `candidate_proof.tex`; {meta["source_lines"]} lines; SHA-256 `{NEW_SOURCE_SHA}`.','', 'No correctness conclusions are recorded. No TeX input/include/bibliography commands occur.','', '## Macro and theorem declarations','']
 for c in containers:
  if re.search(r'\\(?:newcommand|newtheorem|theoremstyle)',c['text']): facts.append(f"- {c['id']}, lines {c['line_start']}–{c['line_end']}: `{c['text'].strip()}`")
 facts+=['','## External URLs and source pointers','']
 for c in containers:
  if re.search(r'\\(?:url|path)\{|Crippa--Stefani|Bruè--Colombo--Kumar',c['text']): facts.append(f"- {c['id']}, lines {c['line_start']}–{c['line_end']}: `{c['text'].strip().replace(chr(10),' ')}`")
 facts+=['','## Labels and references','', '| Label | Declared in | Used in |','|---|---|---|']
 for lm in re.finditer(r'\\label\{([^}]+)\}',text):
  label=lm.group(1); a=char_bytes[lm.start()]; parent=next(c['id'] for c in containers if c['byte_start']<=a<c['byte_end_exclusive'])
  uses=[c['id'] for c in containers if re.search(r'\\(?:eqref|ref)\{'+re.escape(label)+r'\}',c['text'])]
  facts.append(f"| `{label}` | {parent} | {', '.join(uses) or '—'} |")
 facts+=['','## Definition and data-declaration locations','']
 for c in containers:
  if c['mathematical'] and re.search(r'\b(?:Let|let|Set|set|Define|define|Write|write|Choose|choose|Fix|fix|put|We use|convention|denote|Suppose|Assume)\b',c['text']): facts.append(f"- {c['id']}, lines {c['line_start']}–{c['line_end']}: `{c['text'].strip().replace(chr(10),' ')[:260]}`")
 facts+=['','## Revised explicit definitions and conditions','']
 for nid in added:
  c=lookup[nid.split('.')[0]]; n=next(n for n in c['nested_checks'] if n['id']==nid)
  facts.append(f"- {nid}: {n['focus_description']} Exact focus: `{n['text'].replace(chr(10),' ')}`")
 facts+=['','Existing supplemental identities now directly anchor temporal C1 regularity (S0158.C04), the fixed bump dilation (S0164.C07), and r_*=1 (S0373.C04).','', 'S0130.C05, C10, C11 remain allocated as empty, whitespace-only, and TeX-environment-closure focus spans; these are source-scaffolding descriptions, not mathematical verdicts.']
 (NEW/'audit_notation.md').write_text('\n'.join(facts)+'\n')
 target=(OLD/'target_problem.txt').read_bytes(); (NEW/'target_problem.txt').write_bytes(target)
 correspondence_manifest=dict(state='FROZEN',revision_id='v2',previous_revision_id='v1',source_sha256=NEW_SOURCE_SHA,previous_source_sha256=OLD_SOURCE_SHA,previous_consolidated_inventory_sha256=OLD_LEDGER_SHA,source_change_manifest_sha256=sha((NEW/'source_change_manifest.json').read_bytes()),permanent_parent_count=419,retained_parent_count=419,changed_parent_count=12,new_parent_count=0,split_parent_count=0,merged_parent_count=0,deleted_parent_count=0,old_allocated_child_count=840,new_child_count=len(added),consolidated_child_count=meta['nested_checks'],new_child_ids=added,scaffolding_only_child_ids=ledger['scaffolding_only_child_ids'],formula_identifier_scope='Formula occurrence IDs are regenerated and local to revision v2; all child formula references resolve to v2 occurrences.',parent_correspondence=correspondence,child_correspondence=child_map,target_problem_sha256=sha(target),neutral_boundary_review='All 12 replacements retain their single grammatical sentence containers and attached displays; reviewed independently by two neutral inventory contexts.',mathematical_verdicts='none',audit_status='All pass statuses unset; no v1 mathematical verdicts carried forward.',uncovered_source_bytes=0,uncovered_source_lines=0)
 correspondence_manifest['artifact_sha256']={name:sha((NEW/name).read_bytes()) for name in ['proof.tex','audit_inventory.json','audit_formulas.json','audit_inventory.md','audit_notation.md','boundary_review.txt','target_problem.txt']}
 (NEW/'identity_correspondence_manifest.json').write_text(json.dumps(correspondence_manifest,ensure_ascii=False,indent=2)+'\n')
 notes=['# V2 neutral identity and source correspondence','', 'All 419 permanent parents survive with their identifiers and source order unchanged. Twelve exact reviewed replacements reconstruct the complete revised source. No parent was split, merged, inserted, or deleted.','', f'V2 source SHA-256: `{NEW_SOURCE_SHA}`.',f'V1 source SHA-256: `{OLD_SOURCE_SHA}`.',f'V1 consolidated ledger SHA-256: `{OLD_LEDGER_SHA}`.',f'V2 ledger SHA-256: `{sha((NEW/"audit_inventory.json").read_bytes())}`.','', f'All 840 allocated child identities are retained; {len(added)} new children are appended, giving {meta["nested_checks"]} in {meta["compound_containers"]} compound parents. The three scaffolding-only S0130 spans remain allocated. Exact old/new anchor hashes and byte positions for every parent and child appear in identity_correspondence_manifest.json.','', '| Changed parent | Identity/scope correspondence |','|---|---|']
 for sid in edit: notes.append(f'| {sid} | {SCOPE_NOTES[sid]} |')
 notes+=['','## Appended child identities','']+[f'- {nid}' for nid in added]
 notes+=['','All current source bytes, line positions, parent/child/formula digests, formula-parent containment, and one-layer child depth were validated. The exact target_problem.txt bytes were copied from v1. Original v1 artifacts were checked again and remain unchanged.','', 'Every v2 pass must use the v2 source and frozen v2 inventory hashes. No mathematical verdict from v1 was read or copied. This is a source-identity certificate only.']
 (NEW/'identity_correspondence.md').write_text('\n'.join(notes)+'\n')
 assert sha((OLD/'proof.tex').read_bytes())==OLD_SOURCE_SHA
 assert sha((OLD/'audit_inventory_supplemented.json').read_bytes())==OLD_LEDGER_SHA
 assert sha((NEW/'proof.tex').read_bytes())==NEW_SOURCE_SHA
 print(json.dumps(dict(metadata=meta,new_children=added,artifact_sha256=correspondence_manifest['artifact_sha256']),indent=2))

if __name__=='__main__': main()
